# National Technical Guidelines for Integrated Disease Surveillance and Response

**Edition:** Third Edition  
**Publication date:** April 2023  
**Publisher:** Ministry of Health, Republic of Uganda  
**Source:** TECHNICAL GUIDELINES - Final 3rd IDSR Technical Guideline, post-launch edition  
**Source length:** 427 pages

> This Markdown was transcribed from an image-only source PDF using OCR. Figure assets are cropped from the figure regions—not exported as full-page screenshots. Verify clinical values, tables, forms, and OCR-sensitive text against the source PDF during editorial review.

## FOREWORD

In 2001, Uganda adapted the Integrated Disease Surveillance and Response (IDS) developed by World Health Organization (WHO) for member states in African region. The Ministry of Health has been implementing the IDSR strategy since then with success across the country. This strategy provides the opportunity for rational use of resources and maximises investments in health surveillance systems. The 3 edition IDSR guidelines incorporates lessons learnt from previous epidemics, new frameworks like the Global Health Security Agenda (GHSA), One Health, Disaster Risk Management (DRM), the WHO regional strategy for health security and emergencies, and the rising non-communicable diseases, and aims to strengthen implementation of IHR (2005) core surveillance and response capacities. These guidelines have been adapted to reflect national priorities, policies and public health structures; and shall be used in conjunction with other similar guidelines/strategies or initiatives.

Overall, the 3r edition technical guidelines will incorporate the following:

- Strengthening Indicator Based Surveillance

- Strengthening Event Based Surveillance

- Improving community-based disease surveillance

- Improving Cross Border Surveillance and response

- Scaling up e-IDSR implementation

- Improving reporting and information sharing platforms

- Improved data sharing across sectors

- Tailoring IDSR to Emergency or Disaster contexts.

The 3rd edition guidelines are intended for use as:

- A general reference for surveillance activities across all levels

- A set of definitions for thresholds that trigger some action for response

- A stand-alone reference for level-specific guidelines on surveillance and response

- A resource for developing training, supervision and evaluation of surveillance activities

- A guide for improving early detection and preparedness for outbreak response.

These guidelines will be used by; health workers at all levels of public and private settings, IHR National Focal Points, health authorities at Points of Entry (PoE), Hospital managers, clinicians, infection prevention and control officers, national and regional reference laboratories, veterinary and wildlife officers, environmental health officers, district health teams, health training institutions, communication officers, community leaders, other health partners including Non-Governmental Organizations (NGOs), other line ministries, departments and agencies.

Dr. Henry G. Mwebesa DIRECTOR GENERAL HEALTH SERVICES

## ACKNOWLEDGMENTS

We would like to acknowledge the following persons that participated in the adaptation of the 3rd edition IDSR technical guidelines.

xiii

Title/Function Name No.

Organisation Commissioner Health Services, Dr. Allan Muruta Ministry of Health IES&PHE 2 Dr. Issa Makumbi Manager, PHEOC Ministry of Health WHO-AFRO Dr. Allan Mpairwe Technical Officer 4 Ms. Carol Kyozira Principal Biostatistician Ministry of Health 5 Dr. Immaculate Nabukenya Ministry of Health / IDI Project Manager 6 Ministry of Health ACHS, SIKM Dr. Michael Mwanga 7 Dr. Edson Katushabe Surveillance Officer World Health Organization Dr. Julie Harris Resident Advisor, PHFP CDC Uganda Dr. Anne Nakinsige Ministry of Health Principal Epidemiologist IDSR Consultant / Senior 10 Ministry of Health Dr. Godfrey Nsereko Epidemiologist Dr. Ario Alex Riolexus Director, UNIPH Ministry of Health Dr. Stella Lunkuse Ministry of Health Senior Epidemiologist Ministry of Health/Baylor Principal Medical Officer Dr. Mabumba Donald Eldard Uganda Ms. Leocadia Warren Ministry of Health/Baylor Senior Epidemiologist Kwagonza Uganda 15 Public Health Specialist CDC Uganda Dr. Joseph Ojwang 16 Dr. Herbert Kazoora AFENET Director Programs 17 AFENET Epidemiologist Dr. Kayita Godfrey 18 CDC Atlanta Ms. Adella Hoffman Epidemiologist 19 Senior Biostatistician Mr. Jimmy Ogwal Ministry of Health 20 Dr. Solome Okware Surveillance Officer World Health Organization 21 Africa CDC Dr. Justine Maeda Public Health Specialist 22 Mr. Eric Debe SACIDS Engineer 23 Ms. Dativa Aliddeki World Health Organization Epidemiologist 24 Ms. Sandra Nabatanzi EMR Specialist/Outbreak Coordinator CDC Uganda 25 Research Officer Ministry of Health Ms. Harriet Mayinja Ms. Doreen Gonahasa 26 Ministry of Health RA, UNIPH Mr. Arinaitwe Emmanuel 27 Senior Biostatistician Ministry of Health Sam 28 Consultant Dr. Simon Walusimbi World Health Organization Dr. Damian Rutazana 29 Ministry of Health Epidemiologist, NMCD Dr. Felix Ocom 30 Ministry of Health Deputy Manager, PHEOC Dr. Ben Masiira AFENET Epidemiologist Dr. Atim Danstan Senior Medical Officer Ministry of Health Dr. Opolot John Ministry of Health ACHS, Veterinary Public Health Mr. Richardson Mafigiri Epidemiologist Intectious Diseases Institute Dr. Wilbrod Mwanje Ministry of Health Epidemiologist Mbarara Regional Referral 36 Dr. Francis Mugabi Regional Coordinator, EPI/IDSR Hospital Mr. Daniel Eurien 37 Coordinator, GHSA Baylor Uganda Naguru Regional Referral 38 Dr. Robert Isabirye Regional Coordinator, EPI/IDSR Hospital 39 Senior Medical Officer Dr. Immaculate Ampaire Ministry of Health 40 Laboratory Technologist Mr. Mugabe Raymond Ministry of Health 41 Ministry of Health Senior Health Educationist Mr. David Mutegeki Mr. Joshua Kayiwa 42 Ministry of Health Data Manager, PHEOC Senior Public Health Veterinary 43 Ministry of Health Dr. David Muwanguzi Officer 44 Ministry of Health Mr. Milton Wetaka Laboratory focal point, PHEOC Kabale Regional Referral 45 Mr. Turinawe Pelegrino Regional Coordinator, EPI/IDSR Hospital xiv

Arua Regional Referral 46 Mr. Dradiku Christopher Regional Coordinator, EPI/IDSR Hospital Ms. Maureen Nabatanzi 47 Ministry of Health/IDI Epidemiologist Gulu Regional Referral 48 Mr. Loum Bishop Janan Regional Coordinator, EPI/IDSR Hospital Ministry of Health/Baylor 49 Mr. Bernard Lubwama Senior Epidemiologist Uganda Consultant 50 Dr. Ssekitoleko Richard World Health Organization SI Infectious Diseases Institute Mr. Marvin Malikisi eIDSR Specialist Mr. Balinandi Steven 52 Ministry of Health Laboratory Specialist, UVRI 53 Ministry of Health Mr. Daniel Jacob Emong Epidemiologist 54 Mr. Paul Mbaka Ministry of Health Ag. ACHS, DHI Kikuube District Local 55 District Surveillance Focal Point Mr. Patrick Byaruhanga Government 56 Dr. John Lule CDC Uganda Surveillance Specialist Ms. Safari Specioza 57 Senior Research Officer Ministry of Health Katusiime 58 Ministry of Health Epidemiologist Ms. Judith Namugga 59 Surveillance Technical Advisor Ms. Lydia Nakiire Infectious Diseases Institute 60 Dr. Peter Elyanu Baylor Uganda Director, GHSA 61 Ms. Moreen Asimire M&E Officer Ministry of Health 62 Communications Officer Ms. Rita Mwagale Ministry of Health 63 Program Manager, GHSA Baylor Uganda Mr. Rogers Kisame 64 Ministry of Health Ms. Anita Kisakye M&E Officer, PHEOC XV

## LIST OF ABBREVIATIONS

AAR After Action Review ACHS Assistant Commissioner of Health Services AEFI Adverse Events Following Immunization AFENET Africa Field Epidemiology Network AFP Acute Flaccid Paralysis AFRO WHO Regional Office for Africa AR Attack Rate ART Antiretroviral therapy AWD Acute Watery Diarrhoea CBS Community Based Surveillance Centres for Disease Control and Prevention CDC CEBS Community Event Based Surveillance CFR Case Fatality Rate CHS Commissioner of Health Services CIBS Community Indicator Based Surveillance CIF Case Investigation Form CMR Crude Mortality Rate CONOPS Concept of Operations DCE Diseases, Conditions and Events Director General of Health Services DGHS District Health Educator DHE DHI Division of Health Information DHIS2 District Health Information System version 2 District Health Officer DHO DHT District Health Team DQA Data Quality Assessment DRC Democratic Republic of Congo DRM Disaster Risk Management DSFP District Surveillance Focal Person DTF District Task Force EBS Event Based Surveillance eELMIS Electronic Emergency Logistics Management Information System eIDSR Electronic Integrated Disease Surveillance and Response ELISA Enzyme-linked immunosorbent assay EMR Emergency Management and Response eMTCT Elimination of Mother-to-Child Transmission EPC Epidemic Prevention and Control EPI Expanded Program on Immunization EPR Epidemic Preparedness and Response EVD Ebola Virus Disease EWAR Early Warning Alert and Response GHSA Global Health Security Agenda GIS Geographical Information Systems Health Assistants HC Health Centre Healthcare Worker HCW HISP-U Health Information Systems Program-Uganda HIV/AIDS Human Immunodeficiency Virus and / Acquired Immune Deficiency Syndrome HMIS Health Management Information System HSD Health Sub-District Surveillance Officer xvi

IAP Incident Action Plan JAR Intra Action Review IBS Indicator Based Surveillance IDI Infectious Diseases Institute IDSR Integrated Disease Surveillance and Response IEC Information, Education and Communication Department of Integrated Epidemiology, Surveillance and Public Health IES&PHE Emergencies IFA Immuno-fluorescence Assay IgM Immunoglobin M IHR International Health Regulations IMS Incident Management System IOM International Organization for Migration Infection Prevention and Control IPC IPD Inpatients department IRA Initial Risk Assessment IRC International Rescue Committee JEE Joint External Evaluation KOFIH Korean Foundation for International Healthcare MAAIF Ministry of Agriculture, Animal Industry and Fisheries MAKSPH Makerere University School of Public Health MDA Ministries, Departments and Agencies MDR Multi Drug Resistance MRNCH Maternal, Reproductive, Neonatal, and Child Health MUWRP Makerere University Walter Reed Project NECOC National Emergency Coordination and Operation Centre NGO Non-Government Organization National Malaria Control Division NMCD NNT Neonatal Tetanus NTF National Task Force OPD Outpatients department OPM Office of the Prime Minister PFP Private for Profit PHC Primary Health Care PHE Public Health Events PHEIC Public Health Emergency of International Concern PHEMC Public Health Emergency Management Committee PHEOC Public Health Emergency Operations Centre PNFP Private Not for Profit PoE Points of Entry PPE Personal Protective Equipment QGIS Quantum Geographical Information Systems RA Resident Advisor Rif Rifampicin RRA Rapid Risk Assessment RRT Rapid Response Team Road Traffic Accident RTA RT-PCR Reverse Transcriptase Polymerase Chain Reaction RVF Rift Valley Fever SACIDS Southern Africa Centre for Infectious Disease Surveillance SARS Severe Acute Respiratory Syndrome xvii

Standard Case Definition SCD Simulation Exercise SIMEX SPAR State Party Annual Reporting STI Sexually Transmitted Infections STOP Stop Transmission of Polio TB Tuberculosis TDDAP Tackling Deadly Diseases in Africa Project TG Technical Guidelines TM Training Module TOR Terms of Reference TWG Technical Working Group USMR Under-5 Mortality Rate UNEPI Uganda National Expanded Program on Immunization UNICEF United Nations Children's Emergency Fund UNIPH Uganda National Institute of Public Health VHF Viral Haemorrhagic Fever VHT Village Health Team VPD Vaccine Preventable Disease WHA World Health Assembly WHO World Health Organization XDR Extensively drug-resistant xvili

## GLOSSARY (DEFINITION OF KEY TERMS)

Acute Any disease/ event having a rapid (sudden) onset and following a short course.

Alert An indirect early warning sign of a potential public health event occurring in a community under surveillance. Alerts must be investigated further and verified as to whether they represent a true event or not Chronic Any health condition that develops slowly or of long duration and tends to result in some functional limitation and need for ongoing medical care.

Cluster An aggregation of cases or health related condition in a given area over a particular period regardless of whether the number of cases is more than expected in relation to time or place or both.

Disease An illness or medical condition, irrespective of origin or source, which presents or could present significant harm to animals, humans and plants.

Disaster the serious disruption of the functioning of a community or a society, causing widespread human, material, economic or environmental losses exceeding the ability of the affected community or society to cope using its own resources.

Elimination Reduction to zero (or a very low defined target rate) of new cases in a defined geographical area Endemic A disease or condition regularly found among particular people or in a certain area.

Refers to an increase in the number of cases of a disease or an event above Epidemic what is normally expected in that population in a given area over a particular period of time.

When a patient has or had exposure to a probable or confirmed case.

Epidemiological link The study of the distribution and determinants of health-related states and Epidemiology the application of this information to controlling public health problems.

Eradication The purposeful reduction of specific disease prevalence to the point of continued absence of transmission in the world.

Refers to the cause, set of causes, or origin of a disease or condition.

Aetiology Event Under the IHR (2005) (Article 1), an event is defined as 'a manifestation of disease, or an occurrence that creates a potential for disease' (with particular reference to public health events of international concern, or PHEIC). An emergency incident or occurrence.

An event may be insignificant or could be a significant occurrence, planned or unplanned (e.g., extreme weather event or mass gathering), that may impact the safety and security of communities NB: 'Event' and 'incident' are often used interchangeably Health A monthly reporting system for diseases, conditions, and risks that is Management reported to the MINISTRY OF HEALTH from every healthcare facility Information electronically or on paper System Human-animal- A continuum of contacts and interactions among people, animals, their environment products, and their environments); in some cases, facilitating transmission interface of zoonotic pathogens or shared health threats.

Incident An occurrence or event, natural or human-caused that requires an emergency response to protect life, property, or the environment. An incident may be geographically confined (e.g. within a clearly delineated site or sites) or dispersed (e.g. a widespread power outage or an epidemic).

xix

Incidents may start suddenly (e.g. a chemical plant explosion) or gradually (e.g. a drought). They may be of very short duration (e.g. a call for emergency medical assistance), or continue for months or even years. warrelated disasters, public health and medical emergencies, and other emergencies.

Incident This is a standardized approach to emergency management encompassing personnel, facilities, equipment, procedures, and communications Management operating within a common organizational structure System (IMS) The IMS Standardized processes allow all who respond to the same incident to formulate a unified plan to manage the incident International International legal instrument that is binding in 196 countries. The Health regulations aim to support countries to prevent, detect and respond to Regulations public health risks and hazards without unnecessary interference with trade and travel.

(2005) Multi-sectoral Participation of more than one sector working together on a joint program or response to an event (e.g., a joint investigation by public health and law enforcement).

One Health An approach to address a shared health threat at the human-animalenvironment interface based on collaboration, communication, and coordination across all relevant sectors and disciplines, with the ultimate goal of achieving optimal health outcomes for both people and animals. A One Health approach applies to the local, regional, national, and global levels.

The occurrence of cases of a disease in numbers more than expected in a Outbreak defined geographic area over a specific period.

Pandemic An epidemic occurring worldwide, or over a very wide area, crossing international borders and usually affecting a large number of people.

Point of Entry Any passage, via land, air or sea, for international entry or exit of travellers, baggage, cargo, containers, conveyances, goods and postal parcels as well as agencies and areas providing services to them on entry or exit.

A site which reports about surveillance and outbreak data to the district Reporting site level. A reporting site includes all health facilities (public, private and quasi-governmental, faith based), standalone laboratories, PoE. A reporting site also contains event reports from community surveillance and response Zoonotic disease An infectious disease that can be shared between animals and people or zoonosis XX

## Introduction Section

### A.0 Introduction

This section introduces public health surveillance, concepts of Integrated Disease Surveillance and Response (IDSR) strategy, Early Warning Alert and Response (EWAR) system using indicator-based and event-based surveillance mechanisms, guidance on how IDSR works, the objectives of IDSR, and how IDSR can facilitate the implementation the International Health Regulation (IHR) core capacities. Furthermore, this section introduces other aspects such as; the One Health approach; the linkage between Disaster Risk Management (DRM) and IDSR; the core surveillance functions; guidelines to strengthen surveillance and response and roles and responsibilities of the various actors at different levels.

Note: These guidelines are meant to help build and strengthen surveillance systems for priority diseases, conditions and events, whether known or unknown.

### A.1 Public Health Surveillance

Public Health Surveillance is the ongoing systematic identification, collection, collation, analysis, and interpretation of disease occurrence and public health event data to take timely and robust action. It includes the timely dissemination of this information for effective and appropriate action? like planning, response, monitoring and evaluation and improving public health practice. Uganda implements public health surveillance through the IDSR strategy.

#### A.1.1 Approaches to public health surveillance

a) Passive surveillance: routine surveillance reports are submitted by health facilities and the

community through the Health Management Information System (HMIS)

b) Active surveillance: Especially suitable for diseases targeted for elimination and

eradication e.g., Polio (through Acute Flaccid Paralysis (AFP) surveillance), Guinea Worm and outbreaks of infectious diseases. It involves actively looking for the cases in the community or health facilities through;

- Review of records of health facilities

- Screening for specific health conditions e.g., at points of entry, health facilities etc.

- Directly engaging with the reporting resources through phone calls to health workers

or laboratory or physically moving to the site.

- Finding additional cases through alert management and contact tracing in outbreaks.

c) Integrated Disease Surveillance: The approach uses standardized data collection and

analysis tools to collect health data to support the Early Warning Alert and Response (EWAR) system through the Indicator-Based Surveillance (IBS) and Event-Based Surveillance (EBS) networks. Figure 1 shows the IDSR EBS and IBS interactions for EWAR

#### A.1.2 Event -based surveillance (EBS) and Indicator-based Surveillance (IBS) as

back-bone to the IDSR Strategy EBS and IBS are complimentary components of the Early Warning and Response Network (EWARN) for IDSR EBS supports EWARN by promptly picking up signals of health threats and clusters especially where access to healthcare is limited. IBS is useful in monitoring disease trends overtime and detection of seasonality of public health threats through, for example, disease thresholds. EBS is also better at picking up alerts indicating outbreaks in areas. Both systems follow the same IDSR reporting lines

INTEGRATED DISEASE SURVEILLANCE AND RESPONSE (IDSR) EARLY WARNING ALERT AND RESPONSE SYSTEM (EWAR) EBS IBS CHARACTERSISTICS PROCESS CHARACTERSISTICS OF DATA OF DATA PROCESS Systematic Not organized Routine/Regular Organized/structured Formalized Multiple and variable time bound Flexible Not predefined Active Mainly passive Pre-determined Informal and formal Formal Ad-hoc Always same sources Reliability not established Real time Trusted and reliable Routine/Regular Mainly health care-based EXAMPLES OF EBS SOURCES EXAMPLES OF IBS SOURCES Media Community Epidemiological surveillance Mandatory notification Internet, blogs, social networks Informal networks Sentinel surveillance Official websites (Ministry of Syndromic surveillance Registers Health, MoA, etc,) Alert networks Mortality data NGOs Laboratory data Private sectors Surveys/Research Animal health Environmental disasters

**Figure 1. Indicator- and event-based surveillance for Early Warning Alert and Response (EWAR) for**

![Figure 1: Indicator- and event-based surveillance for Early Warning Alert and Response (EWAR) for the IDSR strategy](uganda-idsr-technical-guidelines-assets/figures/figure-01-indicator-event-surveillance.png)

IDSR Strategy Intersection of IBS and EBS: All events detected in the EBS system that are investigated and meet the standard case definition should be captured in the IBS system and reported to the next level of health care system

**Figure 2: Levels of Applications and Reporting of EBS and IBS in the context of IDSR**

![Figure 2: Levels of application and reporting of EBS and IBS in the context of IDSR](uganda-idsr-technical-guidelines-assets/figures/figure-02-ebs-ibs-reporting-levels.png)

At National level:

- EBS implementation using eIDSR, hotlines and media scanning at PHEOC

and Call Centre at Ministry of Health Partners

- Oversees implementation of EBS and IBS at all levels

District level:

Regional level:

- DHMT ensures EBS implementation using

- EBS implementation using hotlines and media

hotlines and media scanning scanning at regional PHEOC.

- Supervises implementation of EBS and IBS at

- Supervises implementation of EBS and IBS at

→ health facility and community levels district, health facilities and community levels HSD / Health Facility level:

- HSD/Health facility in-charges ensures IBS and EBS implementation at

Feedback health facilities

- Supervision of EBS and IBS at community level

T Reporting Community level:

- VHTs implement EBS and IBS

Detects and notify signal to nearest health facilities

### A.2 Integrated Disease Surveillance and Response (IDSR) Strategy

In 2001, Uganda adopted the IDSR strategy as the approach for improving public health surveillance and response for priority diseases, conditions and events at community, health facility, district and national levels. IDSR promotes rational and efficient use of resources by integrating and streamlining common surveillance activities and functions such as data, use timely monitoring and tracking achievements.

IDSR activities involve similar functions (detection, sample collection, reporting, analysis and interpretation, feedback, action) using the same structures, processes and personnel except for those targeted for elimination or eradication, whose e time-limited intensive efforts must prove the absence of disease.

#### A.2.1 What takes place in an integrated system?

Integration refers to harnessing of available (scarce) health resources to support disease surveillance joint action (planning, implementation, monitoring and evaluation) through efficient use of available resources and harmonizing different methods, software, data collection forms, standards and case definitions in order to maximize efforts among all disease prevention and control programs and stakeholders.

Coordination refers to working or acting together effectively for the rational and efficient use of available but limited resources through collaboration, multi-sectoral, multidisciplinary approaches. Coordination involves information sharing, joint planning, monitoring and evaluation in order to provide accurate, consistent and relevant data and information to policymakers and stakeholders:

- All surveillance activities are coordinated and streamlined by combining

resources to collect, manage and analyse surveillance information at a single point at each level.

- Ensure timely bi-directional (horizontal and vertical) flow of health information

- Surveillance activities are integrated activity through similar functions, skills,

resources and target populations.

- The district health office is the hub of integrated surveillance functions, structures

and resources for implementation. These include planning public health interventions.

#### A.2.2 Objectives of Integrated Disease Surveillance and Response

The objectives of IDSR are to:

- Strengthen national capacity for early detection, complete recording, timely reporting,

use of electronic tools, regular analysis and prompt feedback of IDSR priority diseases, events and conditions at all levels.

- Strengthen national and subnational laboratory capacity to confirm IDSR priority

diseases, events and conditions.

- Strengthen national capacity for public health emergency preparedness and response

- Strengthen the supervision, monitoring and evaluation system for IDSR

- Integrate multiple surveillance systems so that tools, personnel and resources are used

more efficiently.

- Emphasize community participation in detection, reporting and response to public

health events including case-based and event-based surveillance and response and risk communication in line with International Health Regulations (IHR).

### A.3 IDSR and IHR (2005)

International Health Regulations (2005) is a binding and legal instrument which urges all State Parties to develop minimum core public health capacities.

#### A.3.1 IHR (2005) Purpose and Goal

The purpose of the IHR 20054 is to prevent, protect against, control and provide public health response to the international spread of disease in ways that are relevant and restricted to public health risks, and which avoid unnecessary interference with international traffic and trade. The IHR (2005) guidelines include the measures at points of entry (airports, ports and ground crossing) and containment of public health events at source'.

The scope of IHR was expanded from three diseases (cholera, plague and yellow fever) to all Public Health Emergencies of International Concern (PHEIC). These include events caused by infectious diseases, chemical agents, radioactive materials, natural disasters and contaminated food.

The goal of IDSR is to strengthen the overall national system for the surveillance of diseases.

It aims to ensure a continuous and timely provision and use of information for public health decision making. Therefore, in Uganda, we implement IHR (2005) using IDSR through the following ways:

- Infrastructure for surveillance, investigation, confirmation, reporting and response

- Skilled human resources

- Defined implementation process (sensitization, assessment, plan of action,

implementation, monitoring and evaluation)

- Generic guides for assessment; Plan of action development; technical guidelines;

training materials; tools and Standard Operating Procedures that incorporate IHR 2005 components.

Uganda is implementing IHR (2005) in the context of IDSR. IHR (2005) provides an excellent opportunity, and acts as a potent driver for IDSR implementation. Therefore, IDSR not a separate surveillance system but a sensitive, reliable and flexible system that meets international standards.

IDSR and IHR (2005) share common functions of detection, notification, reporting, verification and confirmation, and timely response as described in figure 3 below;

IDSR DETECT a strategy for strengthening CONFIRM / VERIFY surveillance, laboratory and a requirement NOTIFY / REPORT response capacities for meeting core at each level of the surveillance TIMELY RESPONSE health system and response capacities

**Figure 3: Implementing IHR through IDSR**

![Figure 3: Implementing IHR through IDSR](uganda-idsr-technical-guidelines-assets/figures/figure-03-ihr-through-idsr.png)

#### A.3.2 Monitoring and valuating implementation of IHR (2005)

Since 2016, WHO, member states and partners have adopted the combined approach of the IHR (2005) monitoring and evaluation process. The four components of the IHR (2005) Monitoring and Evaluation Framework include:

1. State Party Self- Assessment Annual Reporting (SPAR) 2. Joint external evaluation' (JEE) 3. After Action Review (AAR) 4. Simulation Exercises (SIMEX) The four components highlight a more functional approach to assessing IHR (2005) capacities: and foster transparency and mutual accountability, as illustrated in Figure 4 below:

GUIDING ANNUAL REPORT (TO WHA) PRINCIPLES Transparency INDEPENDENT/EXTERNAL Mutual EVALUATION (4-5 YEARS) Accountability Trust Building AFTER ACTION REVIEW Appreciation of (DONE AFTER EVERY PUBLIC HEALTH Benefits RESPONSE!

Dialogue SIMULATION Sustainability (DONE BEFORE PUBLIC HEALTH RESPONSE)

**Figure 4: IHR monitoring and evaluation framework**

![Figure 4: IHR monitoring and evaluation framework](uganda-idsr-technical-guidelines-assets/figures/figure-04-ihr-monitoring-evaluation-framework.png)

### A.4 One Health and IDSR

One Health is an approach to address a shared health threat at the human-animal-environment interface based on collaboration, communication, and coordination across all relevant sectors and disciplines, with the ultimate goal of achieving optimal health outcomes for both humans

and animals. Humans and animals (domestic and wildlife) share the same eco-system and the risk for spill-over of diseases are increasing with modern trends in globalization, growing population pressures, climate change, economic development, mass urbanization, and increasing demand for animal-sourced foods'.

The One Health approach applies toward improving indicator and event-based surveillance.

Animal and human health workers as well as other relevant partners should be engaged at various levels to be sources of information sources for IDSR to further facilitate information sharing and joint rapid response activities.

The principle of One Health approach also considers the role of changing environments with regard to infectious and chronic disease risks affecting humans and animals. By utilizing data, expertise and management approaches in the environment, environmental health practitioners can assist in enhancing the understanding of the root causes of diseases, and better account for complexity of environmental factors. A strong functional IDSR thus requires improved communication, coordination and collaboration from all sectors for the implementation of an effective One Health framework.

### A.5 IDSR and Disaster Risk Management (DRM)

A Disaster is a serious disruption of the functioning of a community or society, causing widespread human, material, economic or environmental losses exceeding the ability of the affected community or society to cope using its own resources. In Uganda, the Office of the Prime Minister is mandated to coordinate all disaster management and response guided by the Disaster Risk Management strategy. The ultimate objective of DRM is reducing risk by lowering vulnerability or improving the capacity to mitigate impact of a hazard. DRM is also in line with National Multi-Hazard Preparedness and Response Plan!° IDSR is an important tool in the DRM, as it provides early warning information, which is crucial for risk assessment and ultimately, risk reduction. IDSR assists in identification of hazards, assessment, risk communication and monitoring of disaster risks.

### A.6 Implementing Cross-Border activities in the context of IDSR

The free movement of people and goods across the borders increases the risk for cross-border spread of diseases. A disaster on one side of the border can easily affect the health of a large number of people on both sides of the borders. It is therefore important that cross border communities engage in coordinated and synchronized implementation of interventions so as to control public health threats.

Uganda follows the East African Community frameworks that were developed to strengthen priority cross-border activities for disease control. These include East African Integrated Disease Surveillance Network and the Inter-Governmental Authority on Development (IGAD).

### A.7 Electronic IDSR (eIDSR) as a platform to enhance realtime surveillance

eIDSR is the application of electronic tools to the principles of IDSR to facilitate prevention, prediction, detection, reporting and response. The application of e-tools in the health sector has the potential to provide real-time validated data for public health surveillance, investigation and prompt outbreak response. eIDSR provides new opportunities for acceleration of the achievement of the IHR (2005) core capacities. eIDSR is based on:

- Standardized interoperable and interconnected information systems administered within the

national context.

- Rapid collection, analysis, reporting and use of disease/events data in real-time for

appropriate public health action.

### A.8 Core functions of IDSR

All levels of the health system are involved in conducting surveillance activities for detecting and responding to priority diseases, conditions and events (even though the different levels do not perform identical functions). These activities include the following core functions:

Step 1: Identify and record cases, conditions and events: Use of standard case definitions and simplified case definitions for community level, to identify priority diseases, conditions, and alerts that can signal emerging public health events).

Step 2: Report priority diseases, conditions and events: Using available paper based and electronic platforms.

Step 3: Analyse surveillance data and interpret findings: Through direct counts, rates, ratios, trends, maps to make meaning of surveillance data so as to take action.

Step 4: Investigate and confirm suspected cases, outbreaks or events: One of the desired actions to minimise the morbidity or mortality of a priority disease.

Step 5: Prepare: A function for ensuring availability of mechanisms for making ready the necessary resources require for taking desired public health action.

Step 6: Respond: Coordination mechanisms for minimising the related morbidity and mortality of an infectious disease outbreak by instituting appropriate public health actions.

Step 7: Risk communication: Real-time exchange of information, advice and opinions between experts and the population at risk to avert the public health threat.

Step 8 - Monitor, evaluate, supervise and provide feedback to improve the surveillance system: Assessment measures of performance of the surveillance and response system A. The different levels where surveillance activities are performed.

Community: Represented by basic community-level services such as VHTs, village leaders (religious, political, traditional), teachers, and traditional healers'.

Health facility: The surveillance site. All institutions (public and private health services providers) with outpatient and/or in-patient facilities are defined as a "health facility."

Health Sub-district (HSD): The basic level for delivery of the Uganda National Minimum Health Care Package. It is mandated with planning, organization, budgeting, supervision and management of health services at this and lower-level health centres. It carries an oversight function of health care services within the HSD with a referral facility at the level of a general hospital or HC IV. For surveillance purposes the HSD receives and reviews reports from lower-level health facilities in its catchment area.

District: The surveillance unit. Through the District Health Services, they plan, direct implementation, supervise and monitor implementation of IDSR Regional Level: It consists of Regional Referral Hospitals (RRH), which provide support supervision for IDSR implementation to districts within their respective regions.

National level: The Ministry of Health and other MDAs (including; national referral hospitals, national reference laboratories and national medical stores) where surveillance policies, guidelines, SOPs and resources are allocated. They report surveillance implementation including PHEICs, using the IHR decision instrument, to WHO.

In an integrated system, some laboratory services are available at each level described above.

A description of laboratory functions by level is in Section 1.0.

### A.10 How districts can use the IDSR matrix to strengthen surveillance and

response The IDSR matrix describes the roles of each level of the health system in surveillance including the desired skills, activities and support functions for successful decision-making.

Practical uses of the IDSR matrix include:

- Ensuring that all necessary functions and capacities have been identified

Establishing accountability by assigning functions to each level of the system

- Organizing activities and training for human resource development

- Managing, monitoring and evaluating programs

- Strengthening district laboratory capacity, including laboratory information system

- Planning for resources (human, material/supplies and financial).

The risk of failure increases for achieving surveillance and control objectives if one or more of the elements at each level is not present or is being performed poorly.

Annexes to Introduction Section

#### Annex A: IDSR matrix: Core functions and activities by health system levels

Annex B: Potential public health emergencies of international concern (PHEIC) that require reporting to WHO under the International Health Regulations (2005).

Annex C: Guide for establishing surveillance and response systems at PoE Annex D: Roles and responsibilities of various actors in IDSR.

Annex E: Checklist for School Re-Opening, Surveillance & Preparation for COVID-19 resurgencies.

#### Annex A: IDSR matrix: Core functions and activities by health system levels

feedback Monitor, Evaluate, Supervise and provide about reported cases, community members Give feedback to activities action reviews took place as events, and prevention Participate in after- Verify if public health interventions planned Communicate risk leaders and influencers communication with ensure ownership of Incorporate crossfor communication and environmental sectors to establish a Onein the community to sectoral Identify opinion communication process animal and community level.

coordination Build relationship with Health approach at the nearby health facility Respond in case of emergency research and conduct behavioural and and control (IPC) education for activities communication change response-based Ensure community and signs of disease infection prevention seeks care immediately community health practices in basic participation Participate in measures Follow and model best Participate in social prevention and Encourage community Prepare diseases, conditions public health risks events, and identifying potential Participate in identifying simulation exercises Participate in training on 12 Investigate and confirm Support investigation to community on follow up Act as liaisons for feedback unusual events reported by community leaders or actions activities.

members.

Follow up on rumours or Analyse and interpret catchment area.

Map community trends in community.

Involve local leaders in patterns, events, and observing, describing, and interpreting disease health facility (HF) and information on alert triggers to Report authorities appropriate Report essential Identify Use alert promote use of Support conditions or triggers to other hazards in diseases, events, the community.

identify priority community in case finding and alert triggers Community IDSR matrix: Core functions and activities by health system level

facilities to the district needed VHTs meetings flow Together with the national level select activities send daily district guidelines measures Sitreps workers and VHTs Participate in district DIF task force Monitor and maintain training and simulation emergency response teams exercises Participate in response supplies 13 Collect, package, store and laboratory confirmation Arrange and lead level transport specimens for during investigation Tore in restigation of trends or patterns weekly Prepare and periodically Integrate analysis national level Report case-based priority diseases summary data to information for Report weekly next level materials for conditions materials from community quality specimens for Ensure record priority Ensure health confirmation.

Verify alerts diseases or appropriate laboratory Use standard case facilities have detect, laboratory Support Health Collect definitions to Collect, and surveillance confirm and storage of Health Care Facilities

supervisory visits.

to districts facilities findings Monitor and evaluate including cross border Establish risk Ensure risk planning communication is part outbreaks or events of the emergency response systems implement Select and messages behaviour change Conduct training and staff 14 events Arrange and support level are available cases conclusions about trends region Compare data and make Ensure accuracy of and thresholds conclusions and person periods to make reports Ensure that Districts and events the quality the MoH collection and sample transportation laboratory Regional

countries activities emergency population guidelines for all Set policies and response pillars procedures for teams Adapt and follow tools (PHEOC) 15 response.

trends of priority events nost lones lorale Train, inform and events response with IHR (2005) and and

levels research the IDSR Task Force levels planning Coordinate and supervision Mobilize resources for System.

16 instrument te products analysis generic Develop and disseminate

evaluate prevention according to revised modify them as needed and IHR and Monitor and activities and ERF Regularly monitor the performance standard simulation exercises indicators for IDSR Conduct periodic key performance IHRNFP regarding facility Assist in referring the activities measures 17 centre contacts.

potentially members.

cases/events detected Prepare and periodically update database of Report level Point of Entry

Annex B: Events of potential international health concern requiring reporting to WHO under the International Health Regulations (2005) Surveillance on specific risks.

The threat posed by known risks constitutes the vast majority of events with a potential to cause public health emergencies which fall within the scope of the IHR (2005). There are already existing control programs which address infectious diseases as well as food and environmental safety and contribute significantly to WHO global alert and response system.

The environmental hazards include but are not limited to:

- Chemical

- Food

- Ionizing radiation

- Non-ionizing radiation

IDSR seeks to address control of specific risks & posed by the following hazards 1. Infectious disease hazards Known, new and unknown infectious disease threats.

2. Zoonotic disease events One Health approach is critical to link human health to animal health at the human-animalenvironment interface. Detecting diseases that affect animals is important as they may pose a risk to human health and could save lives'.

3. Food safety events Food and waterborne, diarrhoeal diseases are among the leading causes of illness and death in Uganda. The identification of the source of an outbreak and its containment are critical to IHR.

4. Chemical events 13 The detection and control of chemical, toxic and environmentally-induced events are critical for the implementation of the IHR (2005).

5. Radiological and nuclear events Radiation injuries can result from various sources such as radiotherapy, nuclear medicines and occupational exposure.

6. Natural and man-made disasters

Annex C: Guide for Establishing Surveillance and Response systems at Points of Entry (PoE) A. Purpose IHR calls for strengthening of national capacity for surveillance and control, including sites such as points of entry (PoE) (i.e., ports, airports and ground crossings); prevention, alert and response to international public health emergencies; global partnerships and international collaboration. In addition to the IHR, it is essential that border health activities be sustainable and align with other surveillance activities under IDSR.

A system to detect, report, and appropriately respond to ill travellers is appropriate. The longterm strategy is to work towards full compliance with IHR at official POEs, while ensuring that the PoE have also contingency plans. All designated PoE must have routine capacities established at PoE for surveillance and response as well as for Effective Public Health Response at Points of Entry.

B. Key Partners:

Ministry of Health, Ministry of Internal affairs, Ministry of Works and Transport, Local Government, Uganda Civil Aviation Authority (CAA), Immigration, Uganda Revenue Authority, Ministry of information, communication technology and National guidance and partners.

C. Key Areas for Surveillance and Response at Points of Entry:

1. Routine measures should be in place at points of entry for the detection of ill travellers; reporting to health authorities; rapid public health assessment; and access to healthcare for severely ill travellers or those whose symptoms suggest a risk to public health, including safe transportation from the point of entry to a healthcare facility.

2. Detection of ill travellers should include, at a minimum, the following:

- Reporting of ill travellers or deaths on board international aircraft, ships or ground

crossings points who arrive at PoE stipulated by various guidelines.

- Port Health officers and /or immigration officers who are present at selected points of entry

should be trained to recognize ill travellers they encounter during their routine assessments as well as to conduct an initial assessment of whether the illness poses a potential public health risk.

3. Initiation of initial response to an ill traveller if detected at a point of entry should include, at a minimum, the following:

- The ability to rapidly isolate the ill traveller from others to avoid potential spread of disease.

- Standby health teams should be available, either in person or remotely by telephone, to

conduct a rapid assessment of ill travellers detected at points of entry to determine if a communicable disease of public health concern is suspected.

- A healthcare facility located close to the point of entry should be designated to provide

medical care as needed to severely ill travellers or those with a suspected communicable disease of public health concern. The designated facility should have adequate infection

prevention and control capacity to prevent spread of disease to staff or other patients and diagnostic capacity.

- Ambulance service or other safe transportation should be available to facilitate transport of

ill travellers from the point of entry to the designated healthcare facility.

4. As needed, during a declared public health emergency affecting international travellers or with the potential for international spread of disease, there should also be capacity to implement at short notice, traveller screening or other border health measures as recommended by the WHO.

Role of Competent Authorities:

Competent authorities at designated Point of Entry shall:

- Report immediately to the next higher level all events and diseases with epidemic potential

detected at Points of Entry, Notification should also be done at the same time to the National level, with copy of the report for the National IHR Focal Point., include yellow fever vaccination requirement for all travellers.

- If a traveller is a suspect case, immediately fill the passenger locator form/alert notification

form. Ensure that the traveller/suspect case is kept separate from others including family members. Ensure that the suspected case is transferred to the nearest holding room

- Be responsible to ensure that if a suspected traveller is recognized and may not be

symptomatic at the time of travel, to take appropriate details and transfer that information to the nearby health facility for close monitoring. The health facility will liaise with the community focal point for close follow-up

- Be responsible for monitoring baggage, cargo, containers, conveyances, goods, postal

parcels and human remains departing and arriving from affected areas, so that they are maintained in such a condition that they are free of sources of infection or contamination, including vectors and reservoirs;

- Ensure, as far as practicable, that facilities used by travellers at Points of Entry are

maintained in a sanitary condition and are kept free of sources of infection or contamination, including vectors and reservoirs;

- Be responsible for the supervision of any de-ratting, disinfection or decontamination of

baggage, cargo, containers, conveyances, goods, postal parcels and human remains or sanitary measures for persons,

- Advise conveyance operators, as far in advance as possible, of their intent to apply control

measures to a conveyance, and shall provide, where available, written information concerning the methods to be employed.

- Report suspected cases to the health facility as soon as possible to organize transport.

- Ensure that all competed forms are stored in a proper way. Create a database for events, if

a computer is available. Keep a record for register for all events.

During an emergency or outbreak response, cross-border coordination should include:

- Partners meeting as soon as the epidemic or event is recognized

- Assessing the need for, and request support from, the National Task Force when necessary.

- Meeting regularly to assess the status of the outbreak or epidemic as indicated

- Regularly sharing surveillance data addressing case counts (including zero cases if

applicable) and status of contact tracing (if indicated)

- Sharing information on travel history of cases and identified contacts to facilitate

coordinated response on both sides of the border

- Regularly reviewing the epidemic response and taking action to improve epidemic control

actions as indicated

- Document and communicate epidemic response actions

## Section 1: IDENTIFY AND RECORD CASES OF PRIORITY DISEASES, CONDITIONS AND EVENTS

### 1.0 Identify and record cases of priority diseases, conditions and events

The IDSR strategy incorporates both Indicator-Based Surveillance (IBS) and Event-Based Surveillance (EBS) approaches to detect priority diseases, conditions and events (DCEs) early.

This section describes how to detect priority DCEs using standard case definitions. The section also gives guidance on establishing EBS and using this approach for alerts detection, triaging and verification to detect public health events. In addition, this section gives a description of procedures which need to be followed when planning for improvements of surveillance and response activities and emphasizes the role of the laboratory in surveillance and response.

### 1.1 Priority diseases, conditions and events included in the IDSR

The priority diseases for IDSR are selected based on the following criteria:

- Notification requirement under IHR (2005): (for example, smallpox, poliomyelitis due

to wild-type poliovirus, human influenza caused by a new subtype, SARS, COVID-19);

- Diseases with highly epidemic potential to cause serious public health impact due to

their ability to spread rapidly internationally (for example, cholera, plague, yellow fever, viral haemorrhagic fever);

- Principal causes of morbidity and mortality due to communicable diseases and

conditions in Uganda (for example, malaria, pneumonia, diarrheal diseases, tuberculosis, HIV/AIDS, maternal deaths and injuries)

- Priority non-communicable diseases or conditions (hypertension, diabetes mellitus,

cancers, mental illnesses and malnutrition)

- Effective control and prevention interventions are available for addressing the public

health problems they pose (for example onchocerciasis, trypanosomiasis);

- Diseases targeted for elimination or eradication by WHO for example, vaccine

preventable diseases, leprosy, and guinea worm.

Table 1 below shows the list of priority diseases, conditions and events under IDSR for Uganda.

Table 1: Priority diseases, conditions and events for Integrated Disease Surveillance and Response Epidemic prone diseases, Diseases targeted for Other major diseases, events or conditions or events which eradication or elimination conditions of public health importance require immediate reporting 1. Buruli ulcer 1. Acute haemorrhagic fever 1. Acute and chronic viral hepatitis syndrome* 2. Bacterial Meningitis 2. Adverse events following 2. Acute Flaccid Paralysis immunization (AEFI) 3. Dracunculiasis (Guinea 3. Anthrax 3. Brucellosis Worm Disease) Leprosy 4. Diabetes mellitus (new cases) 4.

4. Bacterial Meningitis 5.

5.

Lymphatic filariasis Chikungunya 5. Diarrhoea with dehydration less than 6.

Malaria Cholera 6.

5 years of age 6. Epilepsy 7. COVID-19 7. Measles 8.

Neonatal tetanus 7. Human Rabies Dengue fever 8.

8. HIV/AIDS (new cases) 9.

9.

Diarrhoea with blood Poliomyelitis"** 9. Hypertension (new cases) (Shigella) 10. Onchocerciasis 10. Injuries (Road traffic Accidents) Trachoma 10. Malaria 11. Leishmaniasis 11. Measles 12. Malaria *** Disease specified by IHR 12. Plague (2005) for immediate 13. Malnutrition in children under 5 years 13. SARI** notification of age 14. Typhoid fever 14. Maternal deaths 15. Yellow fever 15. Non-neonatal tetanus 16. Zika virus disease 16. Perinatal deaths 17. Maternal deaths 17. Severe pneumonia in less than 5 years 18. Perinatal deaths of age 19. Acute viral hepatitis 18. STIs 20. Human Rabies (Animal 19. Schistosomiasis Bites) 20. Soil transmitted helminths Also:

21. Trachoma A cluster of deaths in the 22. Human African Trypanosomiasis community (animal or human deaths) 23. Tuberculosis 24. Tuberculosis (new cases) A cluster of unwell people or 25. MDR/XDR Tuberculosis animals with similar symptoms *Ebola, Marburg, Rift Valley, Lassa, Diseases or events of international concern Crimean Congo, West Nile Fever, Dengue COVID-19 Acute Viral Haemorrhagic Fever Human influenza due to a new subtype*** SARS*** Zika virus disease Yellow fever Any public health event of international or national concern (infectious, zoonotic, food borne, chemical, radio nuclear, or due to unknown condition.

Note: It is important to remember that countries may select from this list according to national priorities and the epidemiologic situation. Disease-specific summary pages are available in Section 11.0 of this guide.

### 1.2 Detection of priority diseases, conditions and events

The IDSR strategy uses both Indicator-based Surveillance (IBS) and Event-Based Surveillance (EBS) approaches to disease surveillance. An essential function of a public health surveillance system is to be vigilant in its capacity to detect not only known public health threats with established case definitions and formal reporting channels but also events or hazards that are not specifically included in the formal reporting system. These may be clusters or rumours of disease patterns or events of unexplained deaths. Detection of events thus requires all levels from community, district, region and national to strengthen collaboration, coordination, and communication across sectors and jointly share responsibility of detecting events which might have impact on the health of humans, animals and their shared environment.

These diseases, conditions, and events may come to the attention of the health system in several ways. For example:

A person falls ill and seeks treatment from a health facility.

- 

High rate of hospital admission for the same diseases or symptoms.

- Community members report unusual events or occurrences such as a cluster of deaths

or unusual disease to the health facility, or a school reports unusual absenteeism due to similar signs and symptoms such as an influenza-like illness (ILI).

- Health workers conduct routine record reviews and find cases for a specific disease that

have not been reported. For example, routine review of registers for cases of Acute Flaccid Paralysis (AFP) also finds a case of cholera recorded in the register.

- Health workers conduct routine reviews of the laboratory register and observe recorded

confirmed cases of priority diseases such as yellow fever or cholera.

- Radio, television, newspapers, or social media report a rumour of rare or unexplained

events in the area with potential exposure for humans.

Vital events records show an increase in maternal deaths.

- Unusual reports of illness among health care workers.

Analysis of the routine reports from health facilities.

- Unusual deaths among animals (such as livestock, birds, rodent species, wild animals, fish)

or an unusually high number of sick animals with the same signs.

- Environmental officers during an assessment of water bodies, observe contamination due

to chemicals like lead or other chemicals related to mining or agricultural activities, which might be an early trigger for public health interventions.

### 1.3 Use of standard case definitions to detect priority diseases, conditions or events

Standard case definitions are a set of agreed-upon criteria used to decide if a person has a particular disease or condition. It specifies clinical criteria, laboratory diagnosis and specifications on time, place and person.

Why do we need case definitions?

- To help decide if a person has a suspected disease or condition or event, and/or to exclude

other potential disease diagnoses.

- To ensure that every case is diagnosed in the same way, regardless of where or when it

occurred, or who identified it.

- To initiate quick action for reporting and investigation if the laboratory diagnosis takes

longer to confirm.

In describing Standard Case Definitions for health facility level, a three-tiered classification system is normally used - suspected, probable, confirmed (as detailed in Annex 1A):

1. Suspected case: indicative clinical picture i.e. clinical presentation. In outbreaks a more sensitive suspected case definition should be used to capture as many cases as possible.

2. Probable case: clearer clinical picture (meeting the suspected case definition) and/or linked epidemiologically to a confirmed case (by person, place or time) but a laboratory sample cannot be taken because the case is lost, dead or a sample was taken but not available for laboratory testing, was not viable for sufficient laboratory testing or returns inconclusive results. Point of Care labs may also be included.

3. Confirmed case: a suspected or probable case confirmed by the laboratory.

NOTE: The classification might vary according to the epidemiology of the individual diseases.

At the community level, case definitions are simplified using key signs and symptoms to facilitate rapid detection of priority diseases, events and conditions or other hazards in the community. Case definitions will help the community to recognize when they should refer a person with these signs and symptoms for treatment and notify the health facility, as described in the SCD booklet.

NOTE: All cases (suspected, probable and confirmed) must be recorded in the appropriate health facility Outpatient (OPD) or Inpatient (IPD) register, and reported using the HMIS forms (disease specific case-based forms, HMIS 033а, HMIS 033b, HMIS 105, and HMIS 108).

#### 1.3.1 How to make case definitions available in health facilities and communities

- Distribute standard case definitions as well as registers to health facilities in the form of a

poster or as a small pocket-sized booklet.

- Ensure Health facility personnel at all levels including Point of Entries to use the SCDs.

- Ensure availability of records of rumours in the rumors/alerts logbook at health facilities.

- Disseminate community case definitions, and emphasize on the use of key signs and

symptoms.

- Provide information to community health workers, traditional healers,, community leaders

and community volunteers on how to recognize and detect priority diseases, conditions or events using the community case definitions.

- The case definitions for community level should be simpler than those used in health

facilities.

### 1.4 Role of the laboratory in detection of diseases, conditions and events

Several diseases or conditions have signs and symptoms that are similar. For example, a child with fever and rash over the entire body might be diagnosed with measles, even though there could be several causes for the child's clinical presentation (e.g., scarlet fever, rubella).

Laboratory investigation is essential for routine laboratory surveillance and therefore health workers should ensure that all suspected cases have appropriate samples collected for investigation. Laboratory confirmation of diagnoses of diseases, conditions and events under surveillance is essential in order to:

- Accurately confirm the diagnosis in an individual patient, and

- Verify the cause (aetiology) of a suspected outbreak 16,17

- Rule out other differential/possible causes

#### 1.4.1 Specimen collection, storage and transportation

The type of specimen collected, its packaging and transportation depends on the suspected disease. Specimens should be collected in adequate quantity into appropriate containers at the health facility level or in the field during an outbreak investigation and transported using recommended means.

All specimens for laboratory testing must be in good condition, triple packaged, correctly labelled accompanied with the laboratory investigation form, and should reach the laboratory at the earliest time possible to provide reliable results. Avoid delays between collection of the specimen and processing in the laboratory.

Ensure health facilities have trained personnel, equipment as well as adequate reagents and consumables to enable specimen collection and testing. Health facilities should utilize the hub (national specimen and result transport network) system or any other designated transport system for specimen transportation.

Many factors can affect the quality and timeliness of laboratory results:

- Poor and inappropriate specimen collection and handling

- Delay in specimen transportation and/or processing

- Wrong transport or storage media or container

- When patient has been started on antibiotics treatment before specimen especially for

cultures are collected

- Inappropriate temperatures during specimen transportation and storage

- Delays in sample collection

- Lack of well trained and skilled laboratory personnel

- Poorly serviced, calibrated and maintained laboratory equipment

- No accompanying or incomplete case investigation forms

- Missing labels or mislabelling of specimens during laboratory processing

- Wrong choice of test

NOTE:

1. For disease specific reference tables and laboratory procedures see section 11.

2. Always observe universal biosafety precautions when dealing with biological specimens.

3. Isolate patients basing on signs and symptoms and initiate case management even prior to laboratory results.

#### 1.4.2 Establishing a district laboratory network

- The district surveillance and the laboratory focal persons should maintain an updated list

of the laboratories in the district ad their testing capacity. A list of national laboratories for confirming priority diseases and conditions is in Annex 1G.

- Provide SOPS to all health facilities about the methods for transporting specimens

including how to prepare, handle, ship and store the specimens, packaging and shipping of infectious material.

- The district laboratory and surveillance focal persons should maintain routine

communication with identified laboratories that receive specimens from health facilities.

- Follow the Ministry of Health guidelines for referring, testing and receiving samples.

- Improve collaboration between human, veterinary and other relevant public health

laboratories at all levels in line with the One Health approach.

#### 1.4.3 Update inventory of supplies, reagents and equipment used for disease

confirmation Based on the risk assessment and mapping, the district laboratory focal person should maintain an updated list of required supplies. This list should be used to inform requisitions at the district level to ensure adequate supply of laboratory equipment and related supplies.

This list should be used in both public and private health facilities to obtain a comprehensive inventory and ensure that they have the required supplies.

#### 1.4.4 Describe laboratory procedures for confirming priority diseases and

conditions The DLFP should make sure that established laboratory protocols and guidelines are availed/distributed to all health facilities. The DLFP should make sure that laboratory protocols, guidelines, and procedures are followed to diagnose each priority diseases and conditions. Refer to Annex 1F for roles and responsibilities of laboratory focal persons at all levels.

#### 1.4.5 Establish a laboratory quality assurance program

Establish and maintain a quality assurance program (internal and external quality control) at all laboratories to improve reliability and reproducibility of results. Coordinate with regional or national laboratory authorities to establish activities for ensuring quality results from laboratories in the catchment area.

Ensure each laboratory has up-to-date written SOPs for all techniques performed in the laboratory in regard to external quality assurance. Refer to the WHO Stepwise Laboratory Improvement Process towards Accreditation (SLIPTA) if not yet accredited 18

### Annexes to SECTION 1

#### Annex 1A: Guide for establishing Event Based Surveillance (EBS) at National, Regional,

District and Health Facility levels

#### Annex 1B: Sample list of district reporting sites

#### Annex 1C: Laboratory functions by health system level

#### Annex 1D: Roles and Responsibilities of Laboratory Focal Persons at all levels

#### Annex 1E: List of national health and veterinary laboratories for confirming priority diseases,

conditions, and events

#### Annex 1F: Sample verification tool for unusual health events

#### Annex 1A: Guide for establishing Event-Based Surveillance (EBS) at National,

Regional, District and Health Facility levels Event-based surveillance (EBS) is the organized and rapid capture of information about events that are of potential risk to public health. Information is initially captured as a signal which is considered by the Early Warning and Response system as a signal representing potential acute risk to human health, such as an outbreak. All signals may not necessarily become real events, as such they all need to be triaged and verified before a response is initiated. EBS provides the opportunity for early detection of events leading to timely response. It is therefore mandatory that EBS is established alongside IBS at all levels of the health system; national, regional, district, health sub-district, health facility and community levels.

NOTE: EBS at community level have been described in the Introduction Section of these Guidelines.

STEPS FOR ESTABLISHING EBS AT NATIONAL, REGIONAL LEVELS Step 1: Establish EBS Hotlines and Media Scanning for Signal Detection This step involves two major activities namely establishing EBS Hotlines and Media Scanning Centres as described below:

A. Establish EBS Hotlines:

- A hotline is a designated phone line or social media platform that the public can use to

obtain information from an organization or to give the organization information. If a phoneline Iit is desirable that a hotline should be a short number for ease of memory. It should be able to receive direct phone calls or information from social media platforms such as WhatsApp, Facebook, or Twitter.

- It should be toll free.

- It is recommended to have a single number that can be used as a hotline to make

reporting easy to remember. The national hotline number is 0800203033 and / or send a free SMS to 6767.

- Community members should be motivated to self-report events that may impact the

public health including emerging public health events or outbreaks.

- Disseminate the hotline number by advocacy through health authorities, community

health volunteers, non-governmental organizations, religious and other leaders, or schools and also advertise through messaging in local languages by TV, radio and newspapers.

- Develop partnership with communication companies that can spread the hotline number

by text messages to their clients. The messages sent should include the purpose of the EBS, the importance of immediately reporting alerts and how alerts can be reported.

- Train a team of employees to operate the EBS hotline 24hours to respond to calls or

request information from the community.

The Call methodology:

The responder to the call should start by greating and thanking the caller for their proactivity to report to the Ministry of Health or district, or relevant Ministry hosting the hotline, concerning potential public health events. Then the responder should follow a prepared set of questions that directly reflect the questions posed in the rumors logbook. The call should be ended by thanking the caller for their time, patience and proactivity. The responder should directly register in the rumors logbook the signal/alerts that meet the pre-defined list of signal/alerts.

Calls should be returned as soon as possible in situations where a call is interupted or disconnected or if calls are received while the responder is busy; this will ensure that all signal/alerts are collected.

The Messaging methodology:

Once an SMS or a social media message is received, an instant automated message should greet the sender, thank them and state that an operator will contact them. Automated questions or responders can collect information from the sender. Data should be registered directly in the rumors logbook according to the pre-defined list of signal/alerts for the country. Information about the sender should be collected for further communication and details about the signal/alerts reported. A direct call to the sender may be needed if more information is required.

B. Establish Media Scanning Centre

- Media are channels of general communication amongst a population and they act as

gathering tools used to store and disseminate information or data. E.g. newspapers, magazines, TV, radio, bulletins and other printed forms of communication, as well as electronic or online sources.

- Media scanning is an active process that should be performed using different media.

- Media scanning is should be performed at national level.

- Train health personnel to conduct media scanning daily.

- The sources of media scanning can be official and non-official.

I. Official media sources Alerts detected from official sources are reliable and do not need further verification.

Examples of official media sources:

- Websites of governmental sectors including, Ministries of health, Agriculture,

Environment, foreign Affairs etc.

- Websites for official organizations such as universities, Centres of research, and

recognized partners.

- WHO Official websites for Early Warning e.g. WHO IHR Event Information Site for

National Focal Points.

- WHO Disease Outbreak News.

- Websites for WHO regional offices.

- Disease-specific websites e.g. Global Influenza Surveillance and Response.

II. Unofficial Media sources:

Alerts detected through these sources are not reliable and need to be verified.

Examples of unofficial media sources:

- Newspapers and magazines

- Online content of TV and radio channels

- Social media e.g. Facebook, Twitter, WhatsApp

- Unofficial websites e.g. ProMED, The Global Information Network (GPHIN),

HealthMap, MEDISYS etc.

Methods of online media scanning Online information scanning can be done manually and automatically.

The Steps for manual Scanning

(a) Develop a checklist for scheduled (e.g. daily) review of online sources.

(b) Develop a list of prioritized signal/alerts regarding strategies, capacities and resources of

the country.

(c) Develop a list for keywords related to the prioritized signal/alerts including diseases,

syndromes or events.

(d) Visit all predetermined websites in the checklist of online sources to scan for keywords.

The steps for automated scanning

(a) There are multiple automated technological tools that can be used for scanning of online

information from predefined sources.

(b) These tools can save time and effort and support early detection of public health threats.

(c) Examples of automated scanning are:

(i) Rich site summary (RSS feeds) are standardized software tools that monitor the pre-

defined websites and inform the user with updates.

(ii) Contributor-based sources are based on sharing information among health professionals, in which individuals collect information that can be accessed through shared feeds e.g. ProMed.

(iii) Automated information feeds or services developed by governments or international organizations that collect health information from several sources and then can decrease time spent in scanning for individual sources. These are called data aggregators.

Step 2: Signal Detection Signal detection is the process of capturing information on the potential public health events reported to the hotline. Members of the general public may communicate with the hotline desk through phone calls, SMS, social media messaging or website chats.

The hotline desk team should filter received notifications from callers to determine which signals are valid. A list of signals definitions developed by national public health authorities should be provided to the hotline desk operators, or responders, so that they are able to continue

with the registration of signals. The call responder or operator should register valid signals in a signal logbook. Signals can also be detected by media scanning either manually or automated.

Examples of pre-detemined signal/alerts:

Code Signal/alerts to be reported Two or more persons presenting with similar severe illness in the same setting (e.g.

01 household, workplace, school, street) within one week Unexplained large number of deaths of poultry, livestock, other domestic animals or 02 wildlife 03 Severe illness of a healthcare worker after exposure to patients with similar symptoms One or more hospitalized patients with unexplained severe illness, including failure to 04 respond to standard treatment Step 3: Registration of EBS Signals

- Signals that are captured from media and hotlines and correspond to the pre-defined list

of signals. Signals should be registered in the Signal book. See Sample Signal Logbook for Hotlines and/or Media Scanning on the next page.

- Each signal captured should include data about the signal's detection, triage and

verification, until the response.

- Signal registration should include the minimum data set for tracking the signals for

example; Source/informant: Name, contact phone and time and date of the call/detection.

Signal: when it happened, who was affected (cases, deaths) and where it starts and spreads.

Follow-up of the signal: Triage, verification, risk assessment and response.

Table 2: Sample signal logbook for hotlines and/or media Scanning Signal Logbook for Hotlines and/or Media Scanning [NB: This should be completed by The Call Responder/Designated Media Scanner] Variables Response 1.Source of Information:

(a) Source: CBS, Health facility based EBS,

Media Scanning, Hotline (This can be further categorized)

(b) Reporter info: Employee at national team,

community health volunteer, healthcare worker etc.

(c) Date and Time: of detection/receiving alert

(DD/MM/YYYY and HH:MM)

(d) Reference/Contact: Link, Contact name and

Phone number 2.Alert Information:

(a) Signal Type: Human; Animal; Environmental

(b) Signal/Alert: from the country's list of alerts

EE

Signal Logbook for Hotlines and/or Media Scanning [NB: This should be completed by The Call Responder/Designated Media Scanner] Variables Response

(c) Location: details about the location that can

follow the administrative levels

(d) Date of start: when did this start

(e) Cases: number of cases

(1) Deaths: number of deaths

(g) Description: narrative text for any further

information including any response activities (by community or health authority or else 3. Follow up activities

(a)

Follow up: Discard, Monitor, Verify Date-Time: DD/MM/YYYY/ HH:MM Sent for verification: Yes/No

(b)

Date-Time: DD/MM/YYYY/ HH:MM

(c)

Verified: Yes/No Date-Time: DD/MM/YYYY/ HH:MM Risk Assessment:

(d)

Very Low/Low/Moderate/High /Very High

(e)

Sent to Response: Yes/No Date-Time: DD/MM/YYYY/ HH:MM

(f)

Response Status: Not started; On-going; Completed Date-Time: DD/MM/YYYY/ HH:MM

Step 4: Conduct triaging of EBS Alerts Conduct assessment of signals for verification

(a) If the signal matches with one of the priority signals for the country, the alert should

immediately undergo verification.

(b) If the signal is generically defined, e.g. an unusual event that may pose a public health

threat, a qualified public health specialist or team leader should assess the signal to decide whether to discard the it, or to proceed for verification.

Step 5: Conduct Verification of EBS signals

(a) Verification is an essential step to confirm the validity of the captured signals and should

be conducted by subject matter experts e.g. public health specialist.

(b) Verification should be done at the local level nearest to the location of the signal.

(c) If the signal is detected at national level, this is reported to the respective DHO and

regional focal point where the signal is located by phone call or SMS or email etc.

(d) Trained District Health Team with support from regional/national experts should

conduct verification of the signals.

(e) All signals should be verified within 24hours.

(f) Once a signal is verified and requires public health action, it is determined to be an

EVENT.

(g) The District Health Team should promptly start investigations by collecting further

information in the field using appropriate case investigation forms, conduct physical examinations, collect lab samples etc.

(h) The confirmed events that meet the standard case definition should be captured by the

respective District Health Team in the IBS system and reported to the next level of health care system i.e. through the existing HMIS data collection tools and follow the HMIS reporting procedures (refer to section 2 of these Technical Guidelines).

Step 6: Conduct risk assessment and characterization

a)

Once a signal is verified as an event, risk assessment begins. Risk assessment is a systematic and continuous process for gathering, assessing and documenting information to provide the basis for actions to manage and reduce the negative consequences of an acute public health event.

b) The first risk assessment of an event should take place within 48 hours of the detection

of one or more signals.

c) The District health team should lead the risk assessment with support from the regional

and national team.

d) For a signal that has been substantiated as a true event but does not pose an immediate

threat to the public, the team should monitor the event and undertake risk assessments when new information becomes available (refer to section 4 of these Technical Guidelines).

STEPS FOR ESTABLISHING EBS AT DISTRICT LEVEL The steps for establishing EBS at district level is similar to national level. However, the district health office mostly receives EBS-related information in the form of alerts mainly from the health facilities and communities through Walk-ins, phone calls, text messages, WhatsApp, etc.

Record verbal or written information from health facilities and communities about suspected outbreaks, rumours, unexplained events into the district log of suspected outbreaks (refer to Section 4, Annex 4A of these Technical Guidelines).

The district health team should carry out the following functions: triaging, verification and risk assessment.

Step 1: Triage signals When the district health team receives information about a reported alert, they should conduct triaging by asking the following questions:

a) Is the reported information relevant to early warning (i.e. could this alert be genuine

public health event?)

b) Was this alert previously reported (i.e., is this alert a duplicate?)

Triage can take place through field visits, text messaging or over the phone.

After triage:

a) If the report is not relevant or is a duplicate, then it can be discarded. There is no further

action that is needed to be taken.

b) If the information is to be discarded, communicate the following information to the

health facility surveillance focal persons to provide feedback to whoever reported the signal:

They should continue to monitor the situation and notify the district if the situation changes and alert is met.

It is okay that they have reported an alert that has been determined to be a false alert, and they are encouraged to continue reporting alerts when they are detected.

c) If the report is pertinent and is not a duplicate, then the information must be verified by

the district health team that received the information about the signal.

Step 2: Verify alerts

a) The district health team receiving signals from health facilities and communities must

verify these signals before they are determined to be events.

b) Use the EBS verification tool; see sample of Event-Based Surveillance: Verification

Tool on next page.

c) The result of verification is the confirmation that the signal is true or false. Once alert is

verified it becomes an event.

The process of signal verification should answer three main questions:

(a) Is the report accurate (i.e. true)?

(b) Has the information been reported by a reliable source or sources?

(c) Does the report meet the criteria for one or more alerts?

The graphic shown below can be used to determine the outcome of the alert verification, once sufficient information has been collected and validated Report is a hoax or a false Information is accurate and rumour true Information has been

- 

Report meets one or more reported by an unreliable pre-defined signals source (e.g. by word of Information has been mouth and cannot be reported by a credible traced) source or sources (e.g.

Discard if.......

community health volunteer, Report does not meet prehealth facility focal point or defined alert key informants Confirm as an event if.....

**Figure 5: Sample of Event-Based Surveillance: Verification Tool**

![Figure 5: Event-based surveillance verification tool](uganda-idsr-technical-guidelines-assets/figures/figure-05-event-verification-tool.png)

After verification:

- If the alert is considered to be a public health event, it is reported immediately to the

PHEOC.

- If the alert is not considered to be a public health event, the situation will be monitored.

- Record confirmed events in existing HMIS data collection tools and platforms and report

to next level (Refer to section 2 of these Technical Guidelines).

Step 3: Conduct Risk assessment (Refer to step 6 under setting up EBS at national level) STEPS FOR ESTABLISHING EBS AT HEALTH FACILITY LEVEL Important points to consider:

- Indicator-Based Surveillance (IBS) in health facilities encompasses immediate, weekly

or monthly reporting of pre-determined list of diseases based on case definitions.

- Health facility based EBS trains clinicians, nurses, and other relevant healthcare

professionals to report on pattern of disease alerts, such as a cluster of illnesses.

- EBS may allow for detection of emerging or re-emerging public health threats because it

is not disease-specific, requires immediate notification, and is highly sensitive and broad.

- Additionally, since reporting does not require laboratory results for reporting and relies

on clinicians' experience, EBS is more practical and fairly simple to establish and sustain.

- Health facilities should participate in both IBS and EBS since the two complement each

other leading to early detection of diseases, conditions and events.

Step 1: Alert detection

- Select and train Health Facility EBS focal persons: Existing health facility surveillance

focal persons can be trained to perform this role.

- Health Facility EBS focal persons must inform other staff to immediately notify them

when they see or hear about one of the alerts happening in their workplace.

Examples of Health Facility EBS alerts:

1. Any severe illness in health staff after taking care of a patient with similar illness 2. Large, sudden increase in admission for any severe illness of the same type 3. Any severe, unusual, unexplainable illness including a failure to respond to standard treatment 4. Increased use of a particular medicine Step 2: Reporting Alerts Reporting alerts involves communicating with surveillance focal persons in the health facilities that reports to the district team immediately by phone call to the DSFP, SMS to 6767, or inperson.

Step 3: Triaging and verification The district health team upon receipt of report of alerts should triage and verify all alerts within 24 hours of alert detection using the verification tool. In case of true event immediate investigations and response measures is implemented as per the existing IDSR structures. The district team should provide regular feedback to the reporting health facilities.

#### Annex 1B: Sample list of district reporting sites

Below is an example of an inventory for reference Example: List of reporting sites in Hoima District for the FY 2020/21 Name of health Designated focal Telephone or email (or Location of facility or person for reporting sites other contact info) facility or Mr. Kugonza Fred.

Village: Mparangasi Tel: 077-2 ****** or Mparangasi send email on cell; Parish: Central ward; xxxxx@gmail.com Sub County: Bulindi Town Council;

#### Annex 1E: Laboratory functions by health system level

Laboratory functions by health system level Level Confirm Collect Report Use standard case definitions Health Use standard case Record details of specimen to determine initiation of definitions to initiate collection and transport facility or specimen collection process request Receive test results and appropriate testing for disease Assist Field Laboratory in provide feedback confirmation specimen collection within approved guidelines Handle specimens Document specimens with using approved clinical history SOPs and guidelines Transport specimens to Field Laboratory and Referral Laboratory per approved guidelines including the laboratory reporting form District Perform laboratory Record, store and backup Communicate specimen lab results and details of tests for collection policies and lab testing including all procedure to providers presumptive tests done and timeliness diagnosis as of testing Request additional specimen appropriate and collection materials as needed available Provide feedback of results to clinical staff and Store specimens per Store representative patients appropriate conditions samples for pending transport or transportation in Ensure regular receipt of additional studies specified conditions Laboratory results from as per guidelines National level Direct additional collection as Routinely examine needed based on outbreak Update line-lists with the laboratory investigation laboratory results and analysis for changes follow-up on any missing results with testing in trends for specimen Arrange laboratory transport to Field Laboratory and Referral Laboratory per Report results and approved guidelines including timeliness details to next level the laboratory investigation and reporting form Report observed changes in trends during routine analysis of laboratory results to the National level

Laboratory functions by health system level Confirm Level Collect Report Use summary information for outbreak investigation Set confirmation National Record, store and backup Set specimen collection laboratory results and policies and referral guidelines, policies and procedures with the details of laboratory procedures with the national laboratory national authorities authorities testing including all tests done and timeliness of Perform laboratory testing Distribute appropriate studies for specimen collection confirmation as Report results to materials, triple packaging appropriate:

Regional/District Health and transport media for Teams and all relevant microscopy, culture, epidemic prone diseases antimicrobial stakeholders at National susceptibility and Regional/District Request for additional levels for onward testing, serotyping, specimen to be collected by dissemination to serological laboratory or providers as submitting health facility investigation, needed molecular detections or laboratory and identification, Store specimens within genomic sequencing Report case-based and approved conditions for summary data according further referral and analysis Store representative to the agreed protocol or additional research or isolates from the investigation outbreak as needed Report laboratory results from screening sentinel populations at target sites Carry out routine analysis of laboratory data and results so as to monitor changes in trends Perform additional Global or Record, store and backup Set specimen collection laboratory results and Collaborati guidelines, policies and analysis on referred details of laboratory procedures, and share with ng specimens or the national authorities testing including all Reference isolates as tests done and timeliness Laboratorie appropriate of analysis Request for additional specimen to be collected, as needed Report laboratory results to National Reference Laboratory or National Laboratory for Coordination Team onward dissemination

#### Annex 1C: Responsibilities of Laboratory Focal Persons at All Levels

National level laboratory focal person The national laboratory focal persons for the various diseases/ conditions should:

- Coordinate all laboratory related activities in support of disease preparedness,

surveillance and response

- Establish and support collaboration with epidemiologists/surveillance officers

- Define laboratory testing capabilities in-country and those referred internationally and

share this information with all stakeholders

- Coordinate laboratory logistics through development of supplies/reagents and equipment

lists, their specifications and quantification based on the updated laboratory inventory.

Support the laboratory through advocacy with higher levels in accessing the necessary infrastructure, equipment and supplies to collect, handle, test, store and ship specimens safely

- Support establishment and management of a national proficiency testing scheme for

regional referral hospital and peripheral laboratories.

- Support development of standards and guidelines for collection, handling, testing,

packaging, storage and transportation of specimens including proper record for laboratory results for regional and peripheral laboratories.

- Support establishing protocols and guidelines for bio-safety

Regional laboratory focal person

- Maintain an updated list of the laboratories that will perform required laboratory testing.

- Provide information to all health facilities for appropriate specimen collection, packaging

and shipment

- Maintain and update an inventory of supplies, reagents and equipment from all the

laboratories in the region

- Ensure that laboratory confirmation procedures established at the national level are

available and followed in the region and districts

- Ensure that specimen collection, transport materials and laboratory diagnostic tests are

available to enable the timely detection of priority diseases

- Coordinate with health facilities and laboratory in collecting, safely packaging and

reliably transporting the appropriate specimen for confirming the suspected case

- Receive results from the laboratory and promptly report them according to country

procedures to all that require them for public health action and patient clinical care.

- Ensure there is a proper record for laboratory results

- Communicate with reference laboratory and National Laboratory Coordinators as

necessary

- Ensure the laboratories have quality assurance programme to improve the reliability and

reproducibility of laboratory results

- Ensure support supervision and mentorship of the laboratories in the region.

District laboratory focal person

- In liaison with the hub coordinator, establish or strengthen routine communication

between identified laboratories that send and receive specimens at all levels

- Prepare district laboratory procurement plans and provide technical support in

procurement of laboratory supplies, and equipment and monitor their distribution and utilization as informed by the laboratory inventory.

- Ensure that laboratory staff are trained and SOPs for sample collection, transportation,

confirming the disease or condition and reporting the results are clear and in place Ensure the laboratories have quality assurance programme to improve the reliability and reproducibility of laboratory results.

- Coordinate and provide mentorship through support supervision to the hub laboratories.

- Ensure implementation of Laboratory Quality Management Systems in all laboratories

within the district.

Facility laboratory focal person

- Maintain and update list of inventory of supplies, reagents and equipment at the facility.

- Ensure that standard operating procedures (SOPs) for sample collection, testing, storage,

packaging, and transportation, confirming the disease or condition and reporting the results are available and being followed.

- Communicate with district laboratory focal person, hub coordinator, and the district

health Office for laboratory data harmonisation.

- Ensure there is a proper record for laboratory results.

- Ensure the laboratory has quality assurance programme (internal and external quality

control) to improve the reliability and reproducibility of laboratory results.

#### Annex 1D: List of National Reference laboratories for confirming priority diseases,

conditions and events Periodically update the list of laboratories in your district or those specified by the national level for confirming priority diseases and conditions. Include in the list whom to contact for assistance. The following list is an example.

Example:

Priority disease, Focal Person, Name of Lab, address, phone number, email conditions and events EPT Laboratory, Uganda Virus Research Institute Polio Plot 5159, Nakiwogo Road, P.O. Box 49, Entebbe Phone: +256 414 320385/6/ +256 414 320305 Cholera Uganda National Health Laboratory and Diagnostic Services, Plot 106-1062, Butabika Phone +256-0800221100 HIV Uganda National Health Laboratory and Diagnostic Services, Plot 106-1062, Butabika Phone +256-0800221100 Tuberculosis National Tuberculosis Reference Laboratory/SRL, Plot 106-1062, Butabika EPI Laboratory, Uganda Virus Research Institute Measles Plot 5159, Nakiwogo Road, P.O. Box 49, Entebbe Phone: +256 414 320385/6/ +256 414 320305 Uganda Virus Research Institute Plague Reference Laboratory, Plague Weather Head Park Lane, Arua.

Human influenza caused National Influenza Centre, Uganda Virus Research Institute by a new subtype Plot 5159, Nakiwogo Road, P.O. Box 49, Entebbe Phone: +256 414 320385/6/ +256 414 320305 Viral Haemorrhagic Special Pathogens Laboratory, Uganda Virus Research Institute Fevers (e.g. EVD, Plot 5159, Nakiwogo Road, P.O. Box 49, Entebbe Marburg) Phone: +256 414 320385/6/ +256 414 320305 Dengue fever Arbovirology Laboratory, National Influenza Centre, Uganda Virus Research Institute Plot 5159, Nakiwogo Road, P.O. Box 49, Entebbe Phone: +256 414 320385/6/ +256 414 320305 Public health Uganda National Health Laboratory and Diagnostic Services, events of national Plot 106-1062, Butabika or international Phone +256-0800221100

Anthrax Uganda National Health Laboratory and Diagnostic Services, Plot 106-1062, Butabika Phone +256-0800221100 Chikungunya Arbovirology Laboratory, National Influenza Centre, Uganda Virus Research Institute Plot 5159, Nakiwogo Road, P.O. Box 49, Entebbe Phone: +256 414 320385/6/ +256 414 320305 Typhoid fever Uganda National Health Laboratory and Diagnostic Services, Plot 106-1062, Butabika Phone +256-0800221100 COVID-19 National Influenza Centre, Uganda Virus Research Institute Plot 5159, Nakiwogo Road, P.O. Box 49, Entebbe Phone: +256 414 320385/6/ +256 414 320305

#### Annex 1E: Sample verification tool for unusual health events

The process of signal verification should answer three main questions:

(a) Is the report accurate (i.e. True)?

(b) Has the information been reported by a reliable source or sources?

(c) Does the report meet the criteria for the respective community case definition or

the criteria for one or more signals?

The following are examples:

Community-based surveillance: Verification tool for unusual health events Two or more persons presenting with similar severe illnesses in the same community within one week There are two or more There is only one person presenting with illness persons presenting with similar signs & symptoms The persons present with who live or work in the same dissimilar signs and community symptoms The ill persons had an There is no temporal opportunity for exposure or association, and > 1 week True if...

close contact with each other False if..

separates the patients' illness The persons' illness requires The persons presenting with hospitalization similar symptoms reside in different communities that One or more persons has died are physically well-separated There is a common source of exposure

## Section 2: REPORT PRIORITY DISEASES, CONDITIONS AND EVENTS

### 2.0 Report priority diseases, conditions and events

This section describes how to report priority diseases, conditions and events within the required timelines. In IDSR, data collection and data reporting follow different timeliness for different purposes:

- Immediate reporting of case-based information allows for early detection of outbreaks

and other priority public health events.

- Weekly reporting: Aggregate reporting of epidemic prone diseases and disease of public

health concern provides data for monitoring trends of diseases, conditions or events to detect outbreaks early

- Monthly (HMIS 105 & HMIS 108), quarterly (HMIS 097) and annually (HMIS 107)

aggregated reporting provides data for monitoring the health status of the population and impact of disease specific programs, and for planning allocation of resources.

To increase the sensitivity of surveillance and allow for early detection of outbreaks, reporting should NOT be limited to cases detected through inpatient and outpatient data but should be followed up with additional community case search.

### 2.1 Immediate reportable diseases, conditions and events.

Immediate reporting is indicated when an epidemic-prone disease or other potential Public Health Emergency of International Concern (PHEIC) is suspected.

The diseases, conditions and events requiring immediate reporting to the next level are listed in Table 2. Immediate reporting allows timely action to be taken to prevent the rapid transmission of epidemic prone diseases or events.

Information that is reported immediately, will generate an alert and initiate a case-based reporting system. This means that, specific information about that suspected case or if it is a cluster, specific information of each of cases identified, will be collected in detail and reported to the next level.

For events reported at PoE, information is reported to the next level (district in which the PoE is situated) as well as simultaneously to the IHR National Focal Point.

For maternal and perinatal deaths, an audit shall be done to determine the circumstances leading to the death. Health providers should use the national Maternal Perinatal Death Surveillance and Response (MPDSR) in consultation with the relevant focal points.

Table 3: List of priority Diseases, conditions or events that require immediate reporting 1. Acute haemorrhagic fever syndrome 17. Meningococcal meningitis 18. Middle East Respiratory Syndrome (Ebola Virus Disease, Marburg, Lassa Coronavirus (MERS-CoV) Fever, RVF, Crimean-Congo) 19. Neonatal tetanus 2. Acute Viral Hepatitis 3. Adverse Events Following Immunization 20. Noma (AEFI) 21. Perinatal death 4. Anthrax 22. Plague 5. Bacterial meningitis 23. Poliomyelitis (Acute Flaccid Paralysis) (AFP) 6. Buruli Ulcer 24. Rabies (Human) 7. Chikungunya 25. SARIS 26. SARS e.g. COVID-19 8. Cholera 9. Dengue fever 27. Smallpox 28. Typhoid fever 10. Diarrhoca with blood (Shigellosis) 29. Yellow fever 11. Dracunculiasis (Guinea Worm disease) 30. Zika virus disease 12. Hepatitis B 13. Influenza due to new subtype 31. Unexplained cluster of illness/death from human or animal/bird* 14. Listeriosis 15. Maternal death 32. Any public health event of international 16. Measles concern (infectious, zoonotic, food borne, chemical, radio nuclear or due to an unknown condition) * Examples of clusters can be:

- Any cluster of illness or deaths among people living in the same community within a

specific time period (for-example one week)

- Unexplained cluster of deaths of animals/birds within a specific time period

- Illness or death among people after exposure to animals

- Health worker illness after exposure to patients with similar illnesses

- Unexpected increases in admission to health facilities of persons with similar severe

symptoms

- Any unusual illness or sudden death in the community within a specific time period

- Unexpected large numbers of children absent from school due to the same illness

- Unexpected large numbers of sales at pharmacies of many people buying medicines

for the same kind of illness

#### 2.1.1 Report case-based information to the next level

If an immediately reportable disease, condition or other public health event is suspected, the health facility must report case-based information to the next level within 24 hours of detection. Information obtained through preliminary investigation of a suspected case includes:

- Patient's geographical location

- Health facility or facilities that managed or handled the patient or referred the patient

- Patient's identification and demographic information

- Information about signs and symptoms including date of onset, history of vaccination

(where applicable) and information about any relevant risk factors including contacts

- Laboratory results (if available)

- History of travel

- History of Exposures (Human, Animal or Environment).

Any maternal or perinatal death should be reported immediately within 48 hours of occurrence.

A sample reporting form is provided in Annex 2K. Reference should be made to the national integrated Maternal Perinatal Death Surveillance and Response guidelines.

Make the initial report by the fastest means possible (6767, telephone, e-mail, radiophone, text message, social media). The health facility should contact the District Health Officer immediately and provide information about the patient or event.

Follow up the initial verbal report with a written report using a standardized case-based reporting form. A sample case-based reporting form for recording case-based information is in Annex 2F at the end of this section. If a computer or other electronic device is available for surveillance or case management, complete and submit the form electronically to the next level.

On electronic platforms, protect the patient privacy by encrypting patient ID data so only few health staff can access the detailed information, or set up appropriate user rights such as creating a password when using a common office computer.

If a laboratory specimen is requested at this time, make sure that the patient's identifying information on the specimen, the lab investigation form, and the case-based reporting form all match. Ensure proper packaging for reliable results. A copy of the case-based form must accompany the laboratory form and the specimen. A sample laboratory form is included in Annex 2G.

Note: Some epidemic-prone diseases or conditions like Maternal or Perinatal deaths, have specific reporting requirements. Please refer to disease-specific and conditions requirements in Section 11 of this guide.

For all events, establish a line listing of suspected cases or events or conditions reported as part of initial and ongoing investigation and ensure it is always updated, while at the same time maintaining the link with appropriate sectors, depending on a particular disease or event. The line list should be kept where there is a suspected outbreak and where an isolation unit has been opened, but if several isolation units have been opened, the district should maintain a combined line list. Refer to Annex 4E for a sample line list.

#### 2.1.2 Notifying a potential PHEIC under IHR (2005)

If a potential Public Health Emergency of International Concern (PHEIC) is suspected (as defined in Annex 2 of the IHR 2005), the District Health Officer should report to the National IHR Focal Point immediately using the fastest means of communication. If the potential PHEIC is detected at Point of Entry, immediate reporting should also be made to the National IHR Focal Point, while at the same time notifying the district and region (See Annex 2B for a framework of reporting).

The process of notifying WHO of events under the IHR involves the use of the Decision instrument" in the IHR. This is a national level function coordinated by the THR NFP with the support of appropriate experts, depending on the emergency.

#### 2.1.3 Reporting events from community sources

Any suspected event occurring in the community including cases of maternal and neonatal deaths should be reported immediately. The trigger mechanisms of reporting must be clearly defined and the information must be immediately notified to a VHT, or to a nearby health facility or sub district head. Minimum information collected should include:

- Date of event and date of report

- Suspected disease, condition, or event

- What happened?

- When did this happen? (day, month, year)

- Where did this happen? (Exact location, Village, Parish, sub-county, District)

Who is affected? (age, gender, occupation etc)

- How many people have been affected?

Has anyone died? If yes, how many?

Is the event ongoing?

Are there any animal deaths/exposures?

- Recent history of travel to an affected area

- Other information you have.

Name and contact number of the person reporting

- Any action taken

See Annex 2C for a reporting format when an event is identified, Annex 2D for monthly summary and Annex 2E for reporting structure for community alert and verification of events from community sources.

2.2. Weekly reporting of immediate notifiable diseases Weekly reporting provides data for monitoring trends of diseases or conditions to detect outbreaks early. It is important to ensure that the HMIS weekly reporting format is adhered to across all health facilities and districts to facilitate comparison within and between the facilities and districts.

With eIDSR (See Section 9), this will be updated automatically in the database, and also manually entered into a computer. This aggregation is important to understand the trend of the immediate reportable diseases and plan for effective intervention.

#### 2.2.1 Zero reporting

If no cases of an immediately reportable disease have been diagnosed during the week as verified through health facility record review, record a zero (0) on the reporting form for that disease. If the space is left blank, the staff that receives the report will not be able to develop information from a blank space. Submitting a zero report for each immediately reportable disease when no cases were detected during the week tells the staff at the next level that a complete report has been filled and filed.

### 2.3 Report monthly and quarterly routine summary information for other diseases

of public health importance All the cases seen during the month including those reported on a weekly basis are aggregated in the monthly summary reports. Each month, the health facility including referral or regional or teaching hospitals and private should calculate the total number of cases (Suspected and Laboratory Confirmed) and deaths due to priority diseases, conditions and events seen in the health facility. Separate totals are calculated for outpatient cases and inpatient cases. The summary totals are recorded on HMIS 105 and sent to the district level. The district enters the health facility specific data into DHIS2 and the district aggregate totals are automatically generated by the DHIS2. data verification and validation should be conducted by the biostatistician before transmission to the national level.

The summary results should be analysed and the results used to monitor progress towards disease control and prevention targets at all levels.

At least once every month, Laboratory data should be organized in a register so that it can generate monthly summaries. During outbreak, submission of the weekly summaries from the laboratory of the specimen processed, types of specimen and the results should be done to update and complete the variables in the line list. This is important, as the analysis can produce important trends which can necessitate further investigations.

NB: Data harmonization between case-based reporting, weekly reporting and monthly reporting should be done.

### 2.4 Improve routine reporting practices

In some health facilities, more than one person may be responsible for recording information about patients seen in the facility. For example, the clinician records the patient's name and diagnosis in a clinic register. Later in the day, a nurse tallies the number of cases and deaths seen in an out-patient department. The ward nurse tallies the number of admitted cases.

Each week, month, or quarter, a records clerk or statistician calculates summaries for all the diseases and records them in a standard form. Events should be aggregated separately from diseases. In case the health facility is equipped with computers, individual patient records should be entered, from which the IDSR priority diseases or conditions subset will be extracted and analysed to get the required weekly, monthly or quarterly compilations.

In outbreak scenarios, isolation units that are separate from health facilities can be opened, and they will use a different register to record diseases or events. It is important that this information be captured in the overall HMIS weekly, monthly or quarterly summaries.

#### 2.4.1 Keeping records and procedures for managing reporting forms

Data Clerks / Health Information Assistants / Medical records assistants or Biostatisticians should ensure the following:

- Keep a record of HMIS forms, notifications and reports generated or received at their

level. The records are an essential data source for calculating indicators for the IHR report and for monitoring performance of the IDSR indicators. Sample IDSR Reports and a Data Sharing Log Book form is in Annex 21.

- Periodically check with health facilities that you supervise (community, health facility,

sub-district and district) to ensure that the correct forms and procedures are available to staff so they can record and report the required cases of priority diseases and conditions:

- Take steps to ensure that all health workers know or have access to the standard case

definitions recommended by the IDSR guidelines. Ensure that reporting procedures are in place so that all health workers are able to apply the standard case definitions in detection and reporting of priority diseases, conditions, outbreaks or events.

- Sensitize staff on diseases or conditions that require immediate reporting for case-based

surveillance including potential PHEIC and other priority diseases, conditions or events.

All the health staff should be aware of epidemic-prone diseases for which a single suspected or probable case is a suspected outbreak requiring immediate reporting and action, and of any unusual or unexplained events with potential for affecting human health.

- Review with health staff the role that case-based data plays in determining risk factors

and the means of disease transmission or exposure to health risks in a public health event. The staff should have access to standardized forms for reporting case-based information.

#### 2.4.2 Perform periodic checks on data quality

While each provider may have some preferred methods for filling in forms, describing diseases, or abbreviating terms, it is important for every reporting level (Facility, district, region, national) to stick to the standard approach to recording and reporting, so as data are comparable, leading to appropriate decisions.

Some of the examples of factors which may affect data quality that need to be periodically checked include;

- Poorly completed forms (wrong name, sex, dates, etc.)

- Incomplete forms (e.g. presence of blanks)

- Under-reporting or Over-reporting of cases

- Duplicate reporting

- Unsystematic data collection and reporting

- Untruthful reporting, (e.g. reporting zero, while there is an ongoing outbreak of

epidemic prone diseases)

- Inconsistent reporting formats (forms)

- Late submission or reporting

Inconsistent reporting periods

- Calculation errors on aggregate reports

- Lack of documentation and source Data or files are lost

During supervision, stress the importance of data quality and surveillance; that correct data will lead to analysis, interpretation, and the information that will be communicated will lead to action and evaluation. It is recommended that health facilities, districts and MoH conduct regular data quality audits as well as surveillance performance reviews. (See Annex 2J for checklist on key elements to assess in data quality audits)

#### 2.4.3 Enhancing linkages to strengthen community-based surveillance

A community-based surveillance system relies on the community members' capacity to identify and report public health problems to the nearest health facility or to the district health office. In this system, CBS focal persons identify and report events in the community that have public health significance. CBS focal persons act as community informants, and they report to the health facility, or in the case of a serious event, directly to the district authorities. Refer to section 1 for details on who can be a member of the CBS team.

#### 2.4.4 Strengthen linkages between laboratory and surveillance information

Public health laboratory system complements the syndromic disease surveillance.

- Ensure samples are tracked from the point of sample collection to the laboratory

ensuring that the case report forms are properly filled and the integrity is maintained during collection, packaging, storage, transportation and receiving at the laboratory.

- In case of an epidemic prone disease the laboratory where confirmation took place

should report the results as soon as the confirmation has been done to the respective health facility and surveillance officer, and simultaneously to the National level, as well as district.

- To strengthen the linkages between surveillance and laboratory data, the case reported

and the lab samples should have the same unique ID.

- Submission of weekly summaries of the samples processed, and the types of samples

as well as the results should be done whenever there is an outbreak, to assist in completion of the variables in the line list.

- During supervision at health facilities, liaise with the Laboratory Focal Person to

ensure that the laboratory personnel record correctly data for diseases under surveillance and also that there is an established register.

- Make sure that the test results are linked with HMIS data at national, regional and

district levels.

- The laboratory component of the HMIS Weekly or Monthly Summary Reporting

Forms should be regularly updated immediately the respective disease laboratory results are ready

- Liaise with the other sectors such as animal, environment for comprehensive report

especially if they have any information linked to the public health event.

For further reading, refer to 1,3,4,9, 12,14,23,

### Annexes to SECTION 2

#### Annex 2A: IHR (2005) Decision Instrument

#### Annex 2B: Algorithm of reporting immediate notifiable events/diseases

#### Annex 2C: Community Alert Form for reporting of event from community sources

#### Annex 2D: Community-Based Surveillance Suspected Diseases and Public Health Events

Monthly Log Sheet

#### Annex 2E: Reporting Structure for community alert and verification

#### Annex 2F: IDSR immediate case-based reporting form

#### Annex 2G: IDSR case-based laboratory reporting form

#### Annex 2H: IDSR weekly/monthly summary reporting form

#### Annex 21: IDSR reports and data sharing log book

#### Annex 2J: District level IDSR data quality audit checklist

#### Annex 2K: Maternal deaths, Perinatal deaths reporting form, and Still and neonatal deaths

summary reporting form

#### Annex 2L: WHO weekly reporting format

#### Annex 2A: IHR 2005 Decision Instrument

SSMENT AND NOTIFICATION DECISION INSTRUMENT FOR THE ASS OF EVENTS THAT MAY CONSTITUTE A PUBLIC HEALTH EMERGENCY OF INTERNATIONAL CONCERN Events detected by national surveillance system (see Annex 1) Any event of potential An event involving the following A case of the following diseases is unusual or international public diseases shall always lead to health concern.

unexpected and may utilization of the algorithm.

have serious public including those of because they have demonstrated the ability to cause serious unknown causes health impact, and thus public health impact and to shall be notified":

Smallpes involving other events spread rapidly internationally?:

Cholera or diseases than thos Poliomyelitis due to listed in the box on the wild-type Pneumonic plague left and the box on the Yellow fever poliovirus Viral haemorrhagic fevers Human influenza right shall lead to caused by a new utilization of the (Ebola, Lassa, Marburg) West Nile Fever subtype algorithm.

Other diseases that are of respiratory special national or regional concern, e.g. dengue fever.

syndrome (SARS).

Is the public health impa‹ Kift Valley fever, and of the event serious:

meningococcal disease i the event unusual or unexpected there a significant risk Is there a significant risk of international spread international spread?

Is there a significant risk of international travel or trade restrictions?

: Not notified at thi

- stage. Reassess wher

Yes ...

more information becomes available.

EVENT SHALL BE NOTIFIED TO WHO UNDER THE INTERNATIONAL HEALTH REGULATIONS ' As per WHO case definitions.

'The disease list shall be used only for the purposes of these Regulations.

*States Parties that answer "yes" to the question whether the event meets any two of the four criteria above shall notify WHO according to Article 6 of the IHR

#### Annex 2B: Algorithm of reporting immediate notifiable diseases/conditions/events

WHO Epidemiologists at the National level review immediately notifiable diseases and liaise with IHR National Focal Point (NFP) IHR NFP report also liaise with disease specific FPs National eg OIE/INFOSAN/other FP depending on a particular event; use Annex 2C and immediately report to WHO Reference Lab Epidemiologists at the National level link with HMIS Share with other MINISTRY OF HEALTH and other sectors to ensure an integrated approach in sectors e.g.

data management Veterinary, Environmental health Share with other sectors e.g.

DSFP should review the information from all the Veterinary District health facilities; and liaise with relevant Laboratory Environmental personnel; report immediately all notifiable diseases health within 24hours to the National level DSFP liaise with HMIS focal person and biostatistician; as well as other sectors like animal and agricultural to have a comprehensive report Share with other sectors e.g.

Veterinary, Health sub-district Environmental health HSD Surveillance FP review the information from all the Health Facilities and PoE; and liaise with Laboratory focal person; report immediately all notifiable diseases within 24hours to next level; and notify IHR NFP HSD Surveillance FP liaise with HMIS; as well as other sectors like animal, agricultural and environment to Share with other have a comprehensive report sectors e.g.

HSD surveillance FP reports to the DSFP and DHO Veterinary, simultaneously.

Environmental POE health HFs Identify cases using Standard Case Definition and record cases in a register

- Report information to the district by fastest means

possible if you have identified and recorded a notifiable disease (within 24hours) and ensure you also fill a case based investigation form

- During outbreaks, initiate a line list and record daily

new cases and deaths. Update the line list including lab data

- PoE reports must be also sent to the DHO and IHRNFP

simultaneously Report weekly summaries of priority diseases :

Summarize all the cases reported during the month using the monthly summary report Identify and report immediately all suspected public health events using the community case and event definition 57 Community Level (VHTs, LCI, Traditional Healers, Schools, Churches etc)

#### Annex 2C: Community alert reporting form

[Send this form immediately to your supervisor or nearby health facility] Instructions: This form is completed by the VHT and submitted immediately to nearest health facility in charge/ surveillance focal person. He or she identifies disease (s) or public health event as per the community case definition. It is also completed for unusual health events/alerts that are not captured by the given case definition. It is also used to initiate additional case search for additional community cases following identification of cases in OPD and IPD.

Community alert reporting form [Send this form immediately to your supervisor or nearby health facility] Community alert reporting form Send this form immediately to your supervisor or nearby health facility] Telephone number:

1. Name of CBS focal person reporting:

Parish/Ward:

_Sub-county:

2. Village/LC1 District 3. Date reporting (day, month, year) — 4. Type of illness/Condition/Event/Alert (please describe):

5. When did the illness/Condition/Event/Alert happen (Date: Day/Month/Year); Time 6. Date/time this was detected (Date:

Day/Month/Year); Time:

7. Where did this happen?

(Location: village, parish/ward, sub-county/division, district) 8. How many people have been affected?

9. Has anyone died? If yes, how many 10. Are there sick or dead animals involved?

11. Is the event on-going as at the time of this report?

12. What action has been taken?

#### Annex 2D: Community-Based Surveillance (CBS) Suspected Diseases and Public

Health Events Monthly Log Sheet Instructions: This form is a line listing of all the diseases/events/alerts identified during the month. It is completed by the VHT and submitted monthly to nearest health facility in-charge/ surveillance focal person every month.

Community-Based Surveillance Suspected Diseases and Public Health Events Monthly Log Sheet _Sub-county/Division:

_Village:

_Parish/Ward District: _ FY Month Serial When did this How what Where did this How many Type of illness/ action Condition/Event/Alert Number have been many happen?

happen died was taken affected (DD/MM/YYY) (Community, District)

#### Annex 2E: Reporting Structure for community alert and verification

WHO National Level: National PHRRT support investigation in community Provincial/Regional Level: Provincial/Regional PHRRT support investigation in community District Level: District PHRRT deployed to initiate investigation of the alert in community If an alert is NOT a TRUE EVENT, If an alert is a TRUE EVENT, informs the community: No Notifies District Health Team investigation required within 24 hours TAKE ACTION RE-ASSURANCE Health Facility/Sub-districtTeam verifies the alert to CBS and in the community maintain CBS FP may report to the National level as well SURVELLANCE Community Based Surveillance Focal Person (e.g. CBS Volunteer, CHW) detects a an alert (unusual event) in community and notifies his supervisor (health facility/Sub-district Team)

#### Annex 2F: Generic case-based reporting form

Generic Case-Based Reporting Form Answers - Case n Variables / Questions XX Record's unique identifier (YYYY-WEEK-CCC-PPP-DDD-Case nnn) District Reporting Site (Health Facility, Camp, Village...) Disease/Event (diagnosis): * In-patient or Out-patient?

5 Date seen at health facility (day/month/year) Patient Name(s) 7 Date of Birth (day/month/year) 8 Age (... Years/...Months/...Days).

Sex:

9 M=Male F=Female 10 Patient's residence: Name of village/ Neighbourhood 11 Phone and email address of clinician 12 Town/City 13 District of residence 14 Urban/Rural? (U=Urban R=Rural) 15 Address, (cell)phone number... If applicable, name of mother and father if neonate or child 16 Occupation 17 Date of onset (day/month/year) of first symptoms 18 Travel history (Y or N), if Yes, state destination 19 Number of vaccine doses received in the past against the disease being reported** Date of last vaccination 20 21 Date specimen collected 22 Date specimen sent to lab 23 Date specimen received by lab 24 Type of test(s) performed 25 Final Laboratory results 26 Date (dd/mm/yyyy) lab sent results to district 27 Outcome: (Alive, Dead, transferred out, Lost to follow-up or unknown) 28 Final Classification: Confirmed, Probable, Compatible, Discarded 29 ______/ Date health facility notified District (day/month/year) 30 Date form sent to district (day/month/year) 31 Person completing form: name, function, signature 32 Date Results sent to the clinician (dd/mm/yyyy) * Disease/Event (Diagnosis):

AFP, Anthrax, Cholera, Bloody Diarrhoea, Dracunculiasis (Guinea Worm Disease), Neonatal Tetanus, Non-neonatal Tetanus, Measles, Dengue, Chikungunya, Meningitis, Monkey Pox, Yellow Fever, SARS, SARI, Maternal death, Neonatal death, Viral Haemorrhagic Fever, Plague, Typhoid fever, Rabies (Human), Smallpox, death, Influenza due to new subtypes, Adverse Effects following immunization (AEFI), Any event or disease of public health importance (Specify) ** Measles, Neonatal Tetanus (TT in mother), Yellow Fever, and Meningitis, etc.

For cases of Measles, NT (TT in mother), Yellow Fever, and Meningitis; 9-unknown NOTE: Some diseases/event/conditions have existing case reporting and investigation forms)

#### Annex 2G: Sample case-based laboratory reporting form

IDSR Case-based Laboratory Reporting Form Part I: Referring health worker to complete this form and a copy sent to the laboratory with the specimen Answers Variables Date of specimen collection (day/month/year) 2 Suspected Disease or Condition Specimen type * 4 Specimen unique identifier ** 5 Patient Name (s) 6 Sex (M= Male F= Female) Age (..... Years/..... Months/.... Days).

Date Specimen sent to lab (day/month/year) Phone and email address of clinician Part II. Lab to complete this section and return the form to district and clinician Answers Variables 1 Laboratory Name and location 2 Date lab received specimen (dd/mm/yyyy) Specimen condition: (Adequate/Not adequate) Type of test(s) performed 5 Final Lab Result(s) Date (dd/mm/yyyy) lab sent results to district Date Results sent to the clinician (dd/mm/yyyy) Date district received lab results (dd/mm/yyyy) * Blood, Plasma, Serum, Aspirate, CSF, Pus, Saliva, Biopsy, Stool, Urethral/Vaginal discharge, Urine, Sputum, food/water samples ** Same as the patient's identifier in the IDSR immediate case-based reporting form

#### Annex 2H: Weekly summary reporting form

DESCRIPTION AND INSTRUCTIONS Objective:

To report cases of notifiable diseases, other diseases of public health importance, OPD attendances, eMTCT appointments, Malaria tested and treated, TB tested and treated and stock balances of select tracer items.

Frequency:

Every Monday of the Week in a calendar year Copies:

Three Copies (Triplicate). Triplicate stays at the health unit, duplicate is sent to the HSD Headquarters, the Original copy is sent to the District health office.

Responsibility:

Health Unit In-charge PROCEDURE:

1. All health units (government, Private Health Providers and PNFP) must report this information to the HSD and DHO. In addition, the health facility should report any other priority disease and/or events as required by the District Health Officer.

2. The report should be clearly labelled to show the period covered i.e., date for the first (Monday) and last day (Sunday) of the week for which the report is being made.

3. For each disease category indicate the number of new cases during the week (cases this week), the number of deaths that occurred during the week (deaths this week) and those tested (tested cases), tested positive (Pos(+ve) cases) 4. For Maternal deaths, Perinatal deaths, OPD and eMTCT summary, summary of malaria cases tested and treated, summary of tuberculosis cases tested and treated during the week, tracer medicines - stock balance, HIV testing kits, TB, & eMTCT drugs - stock balance, summary of Genexpert report and summary of IPT initiation, refer to the SOPs for the case definitions and how to extract the data.

5. For Other conditions (EPC.), refer to the given table below of other priority diseases/conditions for the codes when reporting using mTrac.

6. Refer to the SOPs for the case definitions and how to extract the data.

7. The health unit continues to report every week throughout the year whether there are cases or not and this should take care of "zero" report.

8. Transcribe the data every week into HMIS form 033c (Health Unit Weekly Epidemiological Surveillance Summary for the year) for the respective weeks. For example, 10 cases with 2 deaths are recorded as 10 (2).

SELECTED OTHER PRIORITY DISEASES UNDER IDSR (INTEGRATED DISEASE SURVEILLANCE AND RESPONSES) Cod Cod Diseases/conditi Code Epidemic Prone Diseases/ Disease of public health e Conditions e importance ons targeted for elimination or eradication CG DC DD Dracunculiasis Chikungu with Diarrhoea nya dehydration <5 LP DG PN Dengue Leprosy Severe pneumonia <5 Onchocerciasis OC TX IL Influenza-like illness African Human Trypanosomiasis TR AX BU Trachoma Buruli ulcer Anthrax (human) Schistosomiasis LF SC HP Acute viral hepatitis Lymphatic Filariasis NO DP Noma Diphth eria Human HN WC Pertussis (Whooping influenza due to cough) a new subtype Brucellosis Severe Acute SS BC Respiratory Syndrome (SARS) SP KA Kala azar Smallpox NS Nodding Syndrome AR Adverse Drug Reactions (ADR) NB: The health unit continues to report every week throughout the year whether there are cases or not and this should take care of "zero report". For standard case definition of all priority IDSR diseases and conditions refer to the standard operating procedures.

HMIS FORM 033b: HEALTH UNIT WEEKLY EPIDEMIOLOGICAL SURVEILLANCE FORM Page 1 To (Date) Date of Report Period: From (Date) Week No. (#) Parish Health Unit Unit Code HSD District Sub-county CASES and DEATHS THIS WEEK Total Tested DEATH.

Pos. (tve) CASES.

Code cases Cases Total Death Cases this week this week MA.

Malaria (diagnosed) DY.

Dysentery SA Severe Acute Respiratory Infection (SARI) AF Acute Flaccid Paralysis Adverse Events Following Immunization (AEFI) Animal Bites (suspected rabies) Bacterial Meningitis Cholera Guinea Worm Measles Neonatal tetanus Plague Typhoid Fever Hepatitis B DR Rifampicin resistant TB cases YF Yellow Fever VF.

Other Viral Haemorrhagic Fevers (EVD, MVD, RVF, CCHF) Maternal death MD.

MB.

Macerated Still births Fresh Still Birth ND Early Neonatal deaths 0-7 days 3. Other conditions (refer to the table below for the other priority diseases/conditions) Total Cases this Tested Pos(+ve) DEATH (EPD.) week Cases cases CASES (EPC.) Code Total Death this week 1.

2.

3.

4.

HMIS FORM 033b: HEALTH UNIT WEEKLY EPIDEMIOLOGICAL SURVEILLANCE FORM Page 2 Health Unit Wk No:

4. OPD AND eMTCT SUMMARY Total OPD Attendance * OPD New Attendance * Expected eMTCT Mothers on appt * eMTCT Missed appointments APT.

5. SUMMARY OF MALARIA CASES TESTED AND TREATED Cases tested with RDT RDT Positive Cases * Not tested cases treated * Microscopy Positive Cases Microscopy Negative Cases Treated *Cases tested with Microscopy * RDT Negative Cases Treated

- RDT Positive Cases Treated

* Suspected malaria (fever) Microscopy Positive Cases Treated MAT.

6. SUMMARY OF TUBERCULOSIS CASES TESTED AND TREATED DURING THE WEEK Bacteriologically confirmed TB cases

- Number of TB contacts traced and screened

Tested with Genexpert *New and Relapse diagnosed and registered

- New and Relapse TB cases started on treatment

- Clients screened for TB in OPD

*Presumptive TB cases identified

- Bacteriologically TB cases registered

TB.

7. TRACER MEDICINES - STOCK BALANCE + IV artesunate 60 mg vials + ORS (Sackets) * Measles Vaccine Doses *Amoxicillin Dispersible 250mg Tablets

- Fansidar Tablets

* ACT (Tablets) * Depot medroxy progesterone acetate (DMPA) injectable + RDT (Malaria) Tests TRA

8. HIV TESTING KITS, TB, & eMTCT Drugs - STOCK BALANCE ARVs (Fixed - DC eMTCT) RH Blisters of 28 tablets + Tenofovir/Lamivudine/Dolutegravir Packs of 30 + Nevirapine suspension-bottle of 10 MI/I(100ml) + Lopinavir/Ritonavir pellets-Pack of 120 capsules * RHZE Blister of 28 tables

- INH 100mg blisters of 10 tablets

* INH 300mg Blisters of 28 tablets 4 R(75)H(50)Z(150) Blisters of 28 tablets * Determine HIV 1 & 2 screening test ARV.

9. SUMMARY OF GENEXPERT REPORT FOR GENEXPERT SITES ONLY No. of errors/invalid results Total No. Rif R * Total MTB detected * No of cartridges remaining Tick * No of samples rejected * No. GeneXpert modules working * No of samples tested upon GP.

10. SUMMARY OF TPT INITIATION * Number of Adult ART clients initiated TPT Number of children and adolescents on ART who started TPT * Number of TPT eligible adult ART clients —Number of TPT eligible children/adolescent ART clients ГРТ

For HMIS FORM 105: (HEALTH UNIT OUTPATIENT MONTHLY REPORT) and HMIS 108 (HEALTH UNIT INPATIENT MONTHLY REPORT) (Refer to HMIS Form 105 and HMIS 108 in the HMIS manual)

#### Annex 21: IDSR reports and data sharing logbook

IDSR Reports and Data Sharing Log book District:

Financial Year:

Feedback Reception Report Report Report sent Date of the Reporting Reported form well received to the description: Site name Period ** filled?

Timely or Report or pick one health Data (Y/N) Comments Late?

from the list set facility?

below * (Yes/No) *Weekly AFP polio; Weekly Epidemic Prone Diseases; Weekly Influenza sentinel sites and labs Monthly findings; Monthly IDSR Aggregated data including malaria and Guinea worm disease; Paediatric bacterial Meningitis surveillance data; Monthly Measles and yellow fever lab data; Monthly Measles, yellow fever and NNT case-based data; Monthly Bacteriology lab data; Monthly Rotavirus surveillance data; Quarterly Tuberculosis Report; Quarterly MDR and XDR Tuberculosis Report; Quarterly Leprosy Report; Quarterly Trypanosomiasis Report; Annual HIV Surveillance **(Use epidemiologic notation to record the reporting period, for example: W-2010-18 for weekly data, M-2010-12 for monthly data, Q-2010-02 for quarterly data)

#### Annex 2J: District level IDSR data quality audit checklist

District Level IDSR Data Quality Audit Checklist Name of Reporting Officer:

Contact Phone Number:

E-mail: _ District:

Health Facility:

Region:

Date: _____- Persons Met and Title THINGS TO LOOK IN THE FACILITY CORE ACTIVITY NOTES General

1) Is there an information flow for reporting to the district level (diagram or

description)?

2) How frequently do you review and collect data (e.g., daily, weekly,

monthly)?

3) Is there a list of the notifiable diseases?

4) Is there a list of priority reportable diseases/conditions/events?

5) For each priority reportable disease, condition or event, does this facility

have case definitions for suspect and confirmed cases?

### 6.0 Priority Reportable Diseases/conditions/events with case definitions

Yes Notes No Disease (examples only) 1. DATA COLLECTION TO AFP (Suspected Polio) IDENTIFY SUSPECTED Tuberculosis CASES WITHIN Viral Haemorrhagic Fever e.g. Ebola HEALTH FACILITY Yellow Fever Monkey Pox Others specity Case Based Reporting or Line List Form, IDSR weekly/monthly summary forms Is the cased-based form or line listing form or IDSR weekly/summary 1) form paper-based or electronic?

If paper based, do you have adequate supply of case-based reporting or line listing forms?

Is your facility using them?

Do you get feedback about the final diagnosis?

List possible causes of omissions or problems.

Thoughts on Possible problems in data collection process Examples:

- Unsystematic data collection

and reporting procedures due List recommended solutions, including target date and person responsible.

to HCW not knowing

- Lack of lab results due to

lack of feedback from higher levels or from the requested lab 1.For suspected cases, what material is reviewed to determine suspected cases (e.g. patient chart/folder/card, facility record, case-based form, line list)?

2.For suspected cases, how was diagnosis assessed (e.g., laboratory confirmatory tests, patient signs and/or symptoms, patient history, or consultation)?

2. RECORDING OF CASES 3.Are priority reportable diseases recorded in the health facility register or facility line list according to the country 4.Select randomly 3 priority diseases; verify how they are diagnosed and recorded List possible causes of omissions or problems Thoughts on Possible problems in recording of cases e.g.

Lack of documentation/recording List recommended solutions, including target date and person responsible Data or files are lost Poorly completed forms (missing values, forms not filled, presence of blanks, etc.).

Who is responsible to report priority reportable diseases (health care provider, laboratory, institution)?

2) When was the last time a supervisor made a site visit to your facility?

How often do you report information to the next level?

3) 4) Is there a standard method for reporting each immediate reportable disease?

Is there a standard method for summary reporting each priority disease?

5) Is there a standard method of reporting an outbreak?

Is the report case-based or aggregate format?

7) 8) Is the reporting protocol process mapped out or summarized in narrative format and readily visible in the facility (e.g., on the wall)?

3.REPORTING For priority diseases, are "O" cases recorded and reported?

9) 10) Are number of cases of notifiable diseases seen at the facility within a specified reporting period same as that reported to the district level?

(Randomly select 3 notifiable diseases and verify) Are each of the immediately reportable diseases consistently reported in 11) a timely manner?

Immediately Reportable Diseases Notes Yes Disease No

List findings seen E.g.: Under-reporting or Overreporting of cases.

Duplicate reporting Untruthful reporting, (e.g.

reporting zero, while there is an ongoing outbreak of epidemic prone diseases) Inconsistent reporting formats (forms).

Late submission/reporting.

Inconsistent reporting periods, List possible causes of omissions or problems Thoughts on Report List recommended solutions, including target date and person responsible

#### Annex 2K: Maternal and perinatal death-reporting form reporting forms

Maternal Death Reporting Form The form must be completed for all deaths, including abortions and ectopic gestation related deaths, in pregnant Answers Questions / Variables 1 Country District Reporting Site How many of such maternal deaths occurred cumulatively this 4 year at this site?

5 Date this maternal death occurred (day/month/year) Maternal death locality (Village or Town) Record's unique identifier (year-Country Code-District-site- 7 maternal death rank) Maternal death place (Community, health facility, district hospital, referral hospital or private hospital, on the way to health facility or Age (in years) of the deceased 10 Gravida: how many times was the deceases pregnant?

Parity: how many times did the late deliver a baby of 22 weeks/500g or more?

Time of death (specify During pregnancy, At delivery, during 12 delivery, during the immediate post-partum period, or long after If abortion: was it spontaneous or induced?

13 Maternal death history and risk factors Was the deceased receiving any antenatal care? (Yes/No) 14 Did she have Malaria? (Yes or No) Did she have Hypertension? (Yes or No) 15 Did she have Anaemia? (Yes or No) 16 Did she have Abnormal Lie? (Yes or No) 17 Did she undergo any Previous Caesarean Section? (Yes or No) 18 19 What was her HIV Status? (choose 'HIV+; HIV-; or Unknown Delivery, puerperium and neonatal information How long (hours) was the duration of labour 20 What type of delivery was it? (choose one from i1=Vaginal nonassisted delivery, 2= vaginal-assisted delivery (Vacuum/forceps), 21 or 3=Caesarean section" 22 What was the baby status at birth? (Alive or Stillborn)

Maternal Death Reporting Form The form must be completed for all deaths, including abortions and ectopic gestation related deaths, in pregnant women or within 42 days after termination of pregnancy irrespective of duration or site of pregnancy Answers Questions / Variables In case the baby was born alive, is he/she still alive or died within 28 days after his/her birth? (choose 1=Still alive, 2=neonatal death, 23 3=died beyond 28 days of age) Was the deceased referred to any health facility or hospital?

(Yes/No/Don't know) 24 25 If yes, how long did it take to get there? (hours) Did the deceased receive any medical care or obstetrical/surgical interventions for what led to her death?

26 If yes, specify where and the treatment received* 27 Primary cause of the Maternal Death 28 Secondary cause of the Maternal Death 29 Analysis and Interpretation of the information collected so far (investigator's opinion on this death) 30 Remarks 32 Maternal death notification date (day/month/year) 33 Investigator (Title, name and function) * Treatment received I.V. Fluids; Plasma; Blood Transfusion; Antibiotics; Oxytocin; Anti-seizure drugs; Oxygen; Anti-malarial; Other medical treatment; Surgery; Manual removal of placenta; Manual intra uterine aspiration; Curettage, laparotomy, hysterectomy, instrumental delivery (Forceps; Vacuum), Caesarean section, anaesthesia (general, spinal, epidural, local) Definitions Gravida: The number of times the woman was pregnant- Parity: Number of times the woman delivered a baby of 22 weeks/500g or more, whether alive or dead

Perinatal death - reporting form The form must be completed for selected perinatal deaths, comprising of stillbirths and early neonatal deaths Answers Questions / Variables Identification 1 Country District Reporting site/facility Perinatal death locality (village or town) Place of death (community, health facility, district hospital, referral hospital or private hospital, on the way to health facility or hospital) Date this perinatal death occurred (day/month/year) 7 Record's unique identifier (year-country code-district-site) for the mother.

Record's unique identifier (year-country code-district-site) for the baby (diseased).

Pregnancy progress and care (Perinatal death history and risk factors) 9 Mother's age (in years) Type of pregnancy (singleton/twin/higher multiples) 10 11 Did the mother of the deceased receive any antenatal care?

(Yes/No/Unknown), 12 If yes to 11, how many visits?

Did the mother of the deceased have malaria? (Yes/No/Unknown) 13 14 If yes to 13, did the mother receive treatment _ (Yes/No/Unknown) Did the mother of the deceased have pre-eclampsia disease?

15 (Yes/No/Unknown) 16 If yes to15, did the mother receive any treatment? (Yes/No/Unknown) Did the mother of the deceased have severe anaemia (HB,7g/dl)?

17 (Yes/No/Unknown) 18 If yes to 17, did the mother receive any treatment? (Yes/No/Unknown) Did the mother of the deceased have recommended maternal immunizations (e.g. tetanus toxoid) (Yes/ No/Unknown) Did the mother of the deceased have Rhesus factor (Rh) or ABO incompatibility? (Yes/ No/Unknown) If Rhesus positive, did the mother of the deceased receive Anti-D injection during this baby's pregnancy? (Yes/ No/Unknown) 22 Did the deceased present in an abnormal Lie (including breech presentation)? (Yes/ No/Unknown) What was the HIV status of the mother? (choose "HIV+; HIV-; or Unknown HIV status") What was the status of the syphilis test of mother? Positive (+) or negative 24 (-> If she was positive for syphilis did, she receive treatment Labour, birth, puerperium

25 Date of birth (day/month/year) 26 Attendance at delivery (Nurse/midwife/doctor/other-specify).

Was foetal heart rate assessed on admission? (Yes, No) 27 What type of delivery was it? (choose one from "1=Vaginal non-assisted delivery, 2= vaginal-assisted delivery (Vacuum/forceps), or 3=Caesarean 28 Sex of the baby (1=male; 2=female, 3=ambiguous) 29 Birth weight in grams (>=2500; 1500-2499 (LBW); 1000-1499g (VLBW); < 1000 (ELBW)) 30 Did the mother of the deceased have premature rupture of membranes (PROM) (Yes/No/Unknown) 31 Did the mother of the deceased have foul smelling liquor?

32 Gestational age (in weeks) Method of estimation: Ultrasound /LMP (DD/MM/YY) 33 How long (hours) was the duration of labour Information on the death and actions taken before and after the death If stillbirth - gestational age (in weeks) of the deceased If neonatal death - age (in days) of the deceased 31 32 If the deceased baby was born alive what was the APGAR Score?

33 If the deceased baby was born alive, was resuscitation with bag and mask conducted?

34 If the deceased baby was born alive was, he/she referred to any health facility or hospital? (Yes/No/Unknown) 35 If the deceased baby was born alive did, he/she receive any other medical care beyond resuscitation? (Yes/No/Unknown) If yes, specify where and the treatment received: * I.V. Fluids; Blood/Plasma transfusion; Antibiotics; Oxygen; Other medical treatment; Primary cause of death:

Secondary cause of death:

Maternal condition (if applicable) 34 Timing of death (1-fresh stillbirth; 2-macerated stillbirth) 35 Any physical malformation noted on the deceased? (Yes/No) If yes, type of birth defect (with full description):

Investigator's report 36 Analysis and interpretation of the information collected so far (investigator's opinion on this death) 37 Perinatal death notification date (day/month/vear) 38 Investigator (Title, name and function)

Stillbirths and neonatal deaths monthly summary reporting form The form must be completed for stillbirths and neonatal deaths Ouestions / Variables Answers Identification 1 Data for the month of 2 Country District 4 Reporting site/facility Births Neonatal Stillbirths deaths Total Births Lat Unknown Early Antepartum Intrapartum e <1000 g (ELBW) 1000-1499 g (VLBW) 1500 - 1999 g (LBW) 2000 - 2499 g (MLB W) 2500 + g Total Pregnancy progress and care (Perinatal death history and risk factors) 6 Multiple pregnancies Born before arrival 7 Mode of delivery 8 Normal Unkno Vacuum Caesarean Forceps wn vaginal delivery Gestational age Term Post- Mod Ext Unkn Very own term preterm preterm preterm (1500- (1000- (<1000g) 2499) 1499) HIV status 10 Positive Unknown Negative Syphilis serology 11 Unknown Positive Negative Maternal age 12 <18 20-34 Unknow 18-19 y >34 Y

SECTION 3 ANALYSE AND INTERPRET DATA

## Section 3: ANALYSE AND INTERPRET DATA

### 3.0 Analyse data

This section describes methods for data analysis, steps for interpreting and summarizing the findings. The analysis may be done electronically or manually.

Organizing and analysing data is an important function of surveillance. It is not enough to collect, record and report information about illness, death and disability from the catchment area; the data must be analysed at each level where it is collected. Analysing data provides the information that is used to take relevant, timely and appropriate action. Analysis of surveillance data allows us to:

- Observe trends over time and alert the system about emerging events due to unusual

patterns

- Identify geographic areas at higher risk

- Characterize the risk for the disease or event using age, gender or occupation etc

- Monitoring and evaluation of public health interventions.

In general, analysing routine surveillance data should address the following questions:

- Have any priority diseases, conditions or events been detected during the reporting period

(this week, for example)? Is there anything unusual from the analysis?

- Of the cases, deaths or events detected, how many were confirmed?

- Where did they occur?

- How does the observed situation in a given geographical area this year compare with

previous observation time periods in this same geographical area? For example, if Bududa District reports 60 cholera cases in September 2020, we could compare with the number of cases reported in October 2020, to find out whether the problem is increasing. We could also compare with the number of cholera cases reported in Bududa District in September 2019 and September 2018 to find out whether cholera at this time of year is expected or unusual.

- Are the disease trends stable, improving or worsening?

- Is the reported surveillance information representative of the reporting site's catchment

area? Out of all the sites that should report, what proportion has actually reported (completeness)?

- How timely were the data received from the health facilities (timeliness)?

- What period (seasonality) is it occurring?

- Who is affected? Which occupational group are most at risk?

Each site that collects or receives data should prepare and follow an analysis plan for analysing routine surveillance information (refer to Annex 3A of this section).

### 3.1 Receive, handle and store data from health facilities

A reporting site is a site which reports about surveillance data to the next level. The routine flow of surveillance data is usually from health facilities to the district level up to the MoH.

This includes all health facilities (Public, Private for Profit and PNFP), standalone laboratories, and PoE. A reporting site also receives and forwards events reports from community surveillance.

At the health facility level, both in-patient and out-patient services are surveillance sites. The information collected from the site is compiled in standard forms (weekly and monthly out patients and in patient HMIS forms, line listing forms etc.), analysed and then forwarded, to the district health management team. Utilizing the eIDSR system, data should be entered using a mobile phone or a computer, and the district health management team can access compiled information from a computer (Refer to Section 9 on eIDSR). Districts merge, aggregate and send their data and reports to the national level through the DHIS2 (the national electronic health database).

Adequate data protection and security must be ensured. Care must be taken not to leave documents containing personal health information related to notifiable conditions on work desks or anywhere they may be visible to unauthorized people. Hard copies of identified notifiable conditions should be stored in a secure location. Data which is stored in a computer should be password protected with appropriate restricted access. Network hardware and any back up or copies of notifiable conditions data must be password protected and stored in a secure location.

#### 3.1.1 Receive data

Make a careful record of all data received from the reporting site. The surveillance team at each level or reporting site where data are received should:

- Acknowledge receipt of the data/report.

- Log into an appropriate logbook any data set or surveillance report received from any

reporting site.

- Record in the log the date the data were received, what the report is about and who the

sender is.

- Verify whether the data set arrived timely or was late.

- Check the completeness of the data set or reports i.e., the number of data sets/reports as

against the number of expected data sets or reports

- Review the data quality;

- Verify whether the form (hard copy or electronic file) is filled out accurately

- Ensure that the form is filled completely (e.g., no blanks)

- Check to be sure there are no discrepancies on the form. Verify from the reporting site (by

phone, e-mail or text message) and correct any discrepancies

- Merge the data and store them in a database

- For electronic receiving of data, refer to the Section 9 on eIDSR

#### 3.1.2 Enter and clean data

At each level where data are received, the data management teams and national programs should always collaborate to extract the priority IDSR diseases from the OPD and IPD registers that are aggregated into HMIS forms from all the health facilities. Troubleshooting and cleaning data prior to analysis is an important data management practice. Disease trends and maps will not be accurate if information about number of cases, time of onset, or geographic location of cases are missing. Use opportunities during supervisory visits to sensitize clinicians and laboratory staff about the importance of quality practices for recording patient information in patient logbooks/register or reporting forms. Emphasize that patient logs are sources of data for reporting public health information and may play a role in detecting an unusual event or otherwise undetected public health problem. Ensure that health facility personnel know the algorithm for reporting including reporting levels and that there are records including rumour logbooks.

Data may be recorded and aggregated either manually or electronically if a computer is available. Regardless of the method, use the following practices:

- Update aggregate totals for each week or month that data was received.

- Record a zero when no cases were reported. If a space which should have been filled in

is left blank/dash/not applicable, the next level may have an incorrect picture of the situation. They will not know if data are missing or if no cases were reported. Zero reporting allows the next level to know that surveillance did not detect a case of the particular disease or condition.

- Ensure that weekly totals include only those cases or deaths actually reported for that

Epidemiological week (Monday-12:00am to Sunday-11:59pm). Late reports from previous weeks should be entered with the relevant week and totals updated accordingly.

- Avoid duplicate entries by using the report or case record unique identifier to prevent,

and also check for, multiple entries of the same records.

- Establish frequent contacts with the health facilities in order to clarify issues of missing

information / errors and address inconsistencies detected in the reporting.

- Ensure consistency and harmonization of data.

- Ensure update of information on laboratory results is done by linking to the respective

case record unique identifier.

Once the data have been received and entered into the aggregate forms, review them carefully to ensure no mistakes were made during entry. Since surveillance data informs decisions about disease control and prevention actions, there are important ethical, social and economic consequences if data are not entered and managed correctly or on time. During an outbreak, ensure data is collected using a line list.

### 3.2 Analyse data by time, place and person

Findings from data analysis may trigger investigations and subsequent actions such as outbreak response. Data should be analysed by time, place and person (refer to Table 3).

Table 3: Types of analysis, objectives, data display tools and methods Method Objective Data Display Tools Type of analysis Time Record summary totals in a Compare the number of case Detect abrupt or long- term table or on a line graph or reports received for the current changes in disease or unusual event occurrence, how many histogram/epidemic curve or period with the number received occurred, the seasonality and sequential maps in a previous period (days, weeks, the period of time from months, quarters, seasons or years) exposure to onset of symptoms.

are Place Identify where cases Plot cases on a spot map of the Plot cases on a map and look for clusters or relationships between district or area affected during occurring (for example, to the location of the cases and the an outbreak.

identify high risk area or Dot density analysis can also locations of populations at risk health event being investigated.

for the disease) be used to depict the number of (e.g., cases near a river, cases near a market) cases by geographic location.

NB: The information can also be presented in a table or a bar chart, but plotting cases in a map will assist in quick assessment and allow prompt intervention Person Extract specific data about the Describe who is at greatest risk Depending on the disease, affected and population for the disease, how it occurred, characterize cases according to the summarize in a table or a bar potential risk factors and reasons data reported for case-based for in chart or a pie chart disease surveillance such as age, sex, changes occurrence.

place of work, immunization status, school attendance, and other known risk factors for the diseases

#### 3.2.1 Analyse data by time

Data from this type of analysis is usually shown on a graph. The number of cases or rate is placed on the y-axis. The time period being evaluated is placed along the x-axis. The graphs will show how many cases and deaths have occurred in a given time. It is easier to see changes in the number of cases and deaths by using a graph, especially for large numbers of cases over a period of time.

Graphs are made with lines (a trend line) or bars (a bar graph or histogram) to measure the number of cases over time. How to make a graph is described in Annex 3B of this section.

Cases -- 2018-2019 1400 - 1200 1000 800 600 400 200 Epidemiologic weeks

**Figure 6: Example of line graph showing trend line of dysentery by Epi-Week, 2018 to 2019, Uganda**

![Figure 6: Trend line of dysentery cases](uganda-idsr-technical-guidelines-assets/figures/figure-06-dysentery-trend-line.png)

Using a histogram Prepare a histogram using case-based data from the case report forms and line lists. Plot cases on the histogram according to the date of onset. As the histogram is developed, it will demonstrate an epidemic curve. The title of the graph should include the name of the geographical location.

You may highlight significant events on the histogram with arrows. For example, the dates when:

- Onset of the first (or index) case

- The health facility notified the district

- The first case was seen at the health facility

- The district began the case investigation

- Laboratory confirmation of the outbreak

- A response initiated

- The district notified the higher level

The results of this analysis allow users of this information to look back at the outbreak and answer questions such as when patients were exposed to the illness, the length of the incubation period, type of the source, duration between detection and confirmation of the outbreak, transmission pattern of the illness and likely time of exposure to the causative agent.

100 40 36 32 Number of Cases 30 19 20 8 10 2 2 10,0 4 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 Week number

**Figure 7: Example of Histogram (Epidemic Curve) showing reported Cholera cases, Bududa District,**

![Figure 7: Histogram epidemic curve for cholera](uganda-idsr-technical-guidelines-assets/figures/figure-07-cholera-epidemic-curve.png)

Epi-Week 1 - 31, 2020 " cases and 2 deaths from same family Laboratory results detect high levels of Aflatoxin in human and food samples Replacement of contaminated maize Investigation team on ground, collection of samples, cases managed at DRRH Number of Suspected Cases 6/3/2016-6/9/2016 7/1/2016-7/7/2016 9/2/2016-9/8/2016 8/26/2016-9/1/2016 5/27/2016-6/2/2016 8/5/2016 - 8/11/2016 5/6/2016 - 5/12/2016 7/8/2016-7/14/2016 7/29/2016-8/4/2016 9/9/2016 - 9/15/2016 8/12/2016 - 8/18/2016 9/16/2016-9/22/2016 9/23/2016-9/29/2016 6/17/2016-6/23/2016 6/24/2016-6/30/2016 5/20/2016-5/26/2016 5/13/2016 - 5/19/2016 9/30/2016 - 10/6/2016 7/22/2016 - 7/28/2016 7/15/2016-7/21/2016 6/10/2016-6/16/2016 8/19/2016 - 8/25/2016 11/4/2016-11/10/2016 · 10/7/2016 - 10/13/2016 10/28/2016 - 11/3/2016 210/14/2016-10/20/2016 11/11/2016 - 11/15/2016 10/21/2016-10/27/2016 Date of Onset of Symptoms

**Figure 8: Cases of Aflatoxicosis by Date of Onset of symptoms, Ankole and Kigezi Sub-Regions,**

![Figure 8: Epidemic curve for aflatoxicosis](uganda-idsr-technical-guidelines-assets/figures/figure-08-aflatoxicosis-epidemic-curve.png)

Uganda, 2016

#### 3.2.2 Analyse data by place

Analysing data by place provides insight about where a PHE is occurring. A spot map of cases can give ideas as to where, how, and why the disease is spreading. The dot density will give the total number of cases per defined geographic area. Use the place of residence on the case reporting forms or line list to plot and describe:

- Clusters of cases occurring in a particular area

- Travel patterns that relate to the method of transmission for this disease

- Common sources of infection for these cases

Use manual methods to create maps to use as part of routine analysis of disease surveillance data. DHIS2 also has a GIS feature which allows users to create maps. Other open-source Software such as Geographic Information System (GIS) may also be utilised. On a map, mark the following:

- Points of Entry, roads, water sources, location of specific communities and other factors

related to the risk of transmission and control. For example, a map for NNT may include locations of traditional birth attendants and health facilities where mothers deliver infants.

- Location of the patients' residences or most relevant geographical characteristic for this

disease or condition (e.g village, neighbourhood, work camp, or refugee settlement). For example, location of a school that cases attend when mapping young patients during a meningitis outbreak.

Please see section 11, for disease specific guidelines/recommendations to analyse data by place.

GHI 1306 5++ ABC + DEF JKL POR STU MNO well health

- market + confirmed case

facility road + suspect case river city, town, 2 forest or village

**Figure 9: Example of District Spot Map Showing Location of Suspected and Confirmed Cases**

![Figure 9: Example district spot map](uganda-idsr-technical-guidelines-assets/figures/figure-09-district-spot-map.png)

#### 3.2.3 Analyse data by person

Analysis by person describes the population with the condition and those at risk. These factors are useful in understanding the disease, why it occurred, how to control it and limiting further spread. Make a distribution of the cases by each of the person variables in the reporting form.

For example, compare the total number and proportion of cases by:

- Age group

- Sex

- Occupation

- Level of education

- Residence: urban and rural

- Vaccination status

- Risk factors

Outcomes Final classification Use disease-specific information in Section 11 to decide which variables to compare and to align your analysis with MoH/WHO standards. For example, for a malaria outbreak, specify the highrisk age groups and high-risk populations targeted by the National Malaria Control Division.

Person analysis is useful in describing population at risk, using case-based data.

Identifying numerators and denominators A simple direct count of cases may not provide all of the information needed to understand the impact of a disease. Percentages and rates are useful for comparing such information. Here, we need to first identify the numerator and denominator.

- The numerator is the number of specific events being measured (such as the actual number

of cases or deaths of a given disease, for example, the number of cases of measles that occurred during the year in school age children)

- The denominator is the total number of people in the population in which the cases or deaths

of a given disease occurred, or the population at risk Using percentages Percentages can be calculated to compare information from populations of different sizes. For example:

Number of measles cases this year in school-age children Health facility 42 B 30 A direct count shows that there were more measles cases in health facility A. Comparing the reported cases to the total number (population) of school-aged children living in each catchment area makes the burden of the situation clearer. Using the number of new cases as the numerator and the number of school-aged children at risk in each catchment area as the denominator we obtain an incidence rate or attack rate. We realise that the incidence of measles is higher in health facility B than in health facility A.

Number of school-aged childrenIncidence (Attack) rate of measles per 100 schoolin the catchment area age children during last 12 months Health facility 4% 1,150 5% 600

#### 3.2.4 Make a table for person analysis

For each disease or condition, use a table to analyse characteristics of cases. A table simplifies organizing and presenting data, for example, for number of cases and deaths over time.

To make a table:

- Decide what information you want to display e.g. measles cases/deaths by age group

- Decide how many columns and rows you will need. Add an extra row at the bottom and an

extra column at the right to show totals as needed. In the example, you will need a row for each age group, and a column for each variable such as age group or cases and deaths.

- Label the rows and columns, including measurements of time. In the example below, the

analysis by year. Analysis of person is also recommended for analysis of outbreak data.

- Record the total number of cases and deaths as indicated in each row. Check to be sure the

correct numbers are in the correct row or column.

Example:

Number of reported measles cases per year Number of deaths per year Age group 40 4 0 - 4 years 1 9 5-14 years 15 years and older 28 Age unknown 5 78 Total

#### 3.2.5 Calculate the percentage of cases occurring within a given age group

When the summary totals for each age group are entered, one analysis that can be done is to find out the percentage of cases occurring in a given age group. To calculate this percentage: 1. Identify the total number of cases reported within each age group from the summary data for which time or person characteristics are known. (For example, there are 40 cases among children 0-4 years of age) 2. Calculate the total number of cases for the time or characteristic being measured. (In this example, there are 50 cases whose age is known.) 3. Divide the total number of cases within each age group by the total number of reported cases. (For example, for children age 0 -4 years, divide 40 by 78 = 0.51.) 4. Multiply the answer by 100 to calculate the percent. (Multiply 0.51 X 100 = 51%.) % of reported cases in each age Number of reported cases Age group group 51 40 0-4 years 12 9 5-14 years 1 15 years and older 28 Age unknown 36 Total 100 78

40 20 15 10 5 10-19 0-4 5-9 40+ 30-39 20-29 Age group

**Figure 10: Example of a bar graph showing Age distribution of Diarrheal Cases During an**

![Figure 10: Distribution of diarrhoeal cases by age](uganda-idsr-technical-guidelines-assets/figures/figure-10-diarrheal-cases-age-distribution.png)

Outbreak in Kasese District, 2019

#### 3.2.6 Calculate the attack rates

The attack rate is the measure of frequency of morbidity (or speed of spread) in a population at risk. It describes the risk of getting the disease in a specific population during a specified period, usually in an outbreak. It is expressed per population at risk e.g 4.5/100000 population.

X constant (such as 100 or No. of new cases during specified period 1,000) Size of population at risk at start of that period Example: 16 cases of cholera in village with a population of 800. Attack rate =16/800 -0.02 0.02 x 100 = 2.0, i.e., 2 cases per 100 population = 2.0 During an outbreak, the data should be updated frequently (often daily) to see if the information being received changes the ideas regarding the causes of the outbreak.

#### 3.2.7 Case fatality rate (CFR)

A case fatality rate helps to:

- Know the proportion of deaths among cases

- Indicate whether a case is identified and managed promptly

- Indicate any problems with case-management once the disease has been diagnosed

- Identify a more virulent, new or drug-resistant pathogen

- Indicate poor quality of care or no medical care.

- Compare quality of care between different catchment areas, cities, and districts

- Assess health seeking behaviours

- Identify underlying conditions to severe diseases e.g., immune deficiency

How to calculate a CFR: Calculate the total number of deaths. (In the example of the measles data, there are a total of 5 deaths.) Divide the deaths by the total number of reported cases. (For example, the total number of reported cases is 78. The number of deaths is 5. So, divide 5 by 78 = 0.06 and multiply the answer by 100 (0.06 X 100 equals 6).

Number of deaths Number of reported cases Case fatality rate Age group 40 10 4 0-4 years 11 1 9 5-14 years 15 years and older 28 Age unknown 5 6 78 Total Please see the disease specific guidelines in Section 11.0 for recommendations about the essential variables to compare for each disease.

### 3.3 Alert and action thresholds for public health action

Thresholds are markers that indicate unusual situation and require that something should happen or change. They help surveillance and program managers answer the question, "When should I take action, and what will that action be?" Information on establishing thresholds is in Section 11.0 of this guide.

These guidelines discuss two types of thresholds: an alert threshold and an epidemic threshold.

Not every disease or condition uses both types of thresholds, although each disease or condition has a point where a problem must be reported and an action taken.

An alert threshold suggests to health staff that further investigation is needed. Depending on the disease or condition, an alert threshold is reached when there is one suspected case (as for an epidemic-prone disease or for a disease targeted for elimination or eradication) or when there is an unexplained increase for any disease or unusual pattern seen over a period of time in weekly or monthly summary reporting.

Action (epidemic) threshold triggers a definite response. It marks the specific data or investigation finding that alerts an action beyond confirming or clarifying the problem. Possible actions include communicating laboratory confirmation to affected health centres, implementing an emergency response such as an immunization activity, community awareness campaign, or improved infection control practices in the health care setting. For rare diseases or diseases targeted for eradication, detection of a single case is an epidemic. This is because these rare or targeted diseases have the potential for rapid transmission or high case fatality rates.

In other situations, a number of cases will trigger a response. For example, the epidemic threshold for bacterial meningitis in countries of the meningitis belt is 10 suspected cases per 30,000 - 100,000 inhabitants per week and under 30,000 inhabitants is 5 suspected cases in one week or doubling of the number of cases in a three-week period (Minimum of 2 cases in one

week), and the alert threshold is 3 suspected cases per 30,000 - 100,000 inhabitants per week and under 30,000 inhabitants is 2 suspected cases per week or an increased incidence compared to previous non-epidemic years (Source: Weekly Epidemiological Record No 51/52, 577-588,, 19 December 2014(http://www.who.int/wer).

The epidemic threshold for malaria in some countries is 3rd Quartile of confirmed malaria cases for the past 5 years; Alert threshold is 2nd quartile/Median of confirmed malaria cases Ministry of Health has provided the thresholds for priority diseases in the SCD booklet.

### 3.4 Draw conclusions from the findings to generate information

Routinely (weekly, monthly or quarterly) health facility management committees should meet to discuss the results of the analysis for action.

Routinely (weekly, monthly or quarterly) gather or present the graphs, maps and tables and meet with the district health team or relevant stakeholders to review analysis results and discuss the findings during performance review meetings.

Systematically review the findings using the analysis plan (see Annex 3A). Correlate the analysis with other reporting mechanisms, other data sources like from animals (domestic or wildlife), or the environment to assist in correct interpretation of your findings. For example, for human rabies, get more information from the vet sector on animal bites, quarantined animals, or rabid dogs.

Consider quality of the data when interpreting results for example:

- Missing data values (completeness per month, per event)

- Inconsistencies (between linked data elements - validation)

- Arithmetic errors (in correlation & aggregation)

- Obvious fluctuations (sharp increase or decrease per month, per event).

It is important in a system where eIDSR has been established, to ensure that there are features to improve data quality and these might include:

- Data input validation

- Maximum and Minimum values

- Validation rules

At a minimum, review the findings to:

- Assess whether the situation is improving or not, and

- Make comparison of the observed data to the expected data

- Consider possible explanations for an apparent increase in cases/deaths

- Has there been a change in the number of health facilities reporting information?

- Has there been a change in reporting procedures or surveillance system?

- Has there been any change in the case definition of a disease or condition?

- Is the increase or decrease a seasonal variation?

- Has there been a change in screening or treatment programs, or a community outreach?

- Has there been a recent immigration or emigration or increase in refugee populations?

- Has there been any change in the quality of services being offered at the facility (for

example, lines are shorter, health staff are more helpful, drugs are available, clinic fees are charged)?

- Is there an increase or improvement in laboratory testing / diagnostic procedure?

- Is there an increase in awareness of disease in the public? E.g., mass vaccination or

awareness campaigns for a particular disease may lead to increase of cases detected

- Backlog of cases being reported which were supposed to be reported earlier?

### 3.5 Summarize and use the analysis to improve public health action

Prepare and share findings with all stakeholders especially affected communities. Give a concise action-oriented summary report of the findings. Use simple tables, graphs and maps, with clear and short description, interpretation, comments and recommendations.

Make statements that describe the conclusions you have drawn from the surveillance data analysis results. Use them to take action to:

- Investigate to find out why there is an increase/decrease in the number of cases.

- Collaborate with specific disease reduction programs to intensify surveillance if an alert

threshold has been crossed,

- Advocate with political, Partners, religious leaders and the community for more resources,

if a lack of resources is identified as a cause for the increased number of cases.

Information sharing is an important surveillance function and a powerful mechanism of coordination. It motivates the staff who send reports and builds partnership through the transparency that information sharing displays. Thus, it is important to share analysis results and provide feedback on time. Please refer to Section 7 and 8 of these guidelines for information and examples about communication and sharing feedback.

For further reading refer to 3,6,12,24,25

### Annexes for SECTION 3

#### Annex 3A: Plan for routine analysis of surveillance information

#### Annex 3B: How to manually make a line graph

#### Annex 3A: Plan for routine analysis of surveillance information

A minimum plan for routine analysis of surveillance information should include the following information which could be presented as tables, graphs and maps.

1. Calculate completeness and timeliness of reporting: Monitor whether surveillance reports are received on time and if all health facilities have reported. This assists in identifying silent areas where health events may be occurring but which are not being reported or health facilities that need assistance in transmitting their reports. It also depicts how representative the data is for the specific level.

2. Calculate totals by week (or by month). Update the total number of reported cases and deaths for the whole year. The summary information helps to describe an annual trend.

3. Prepare cumulative totals of cases, deaths and case fatality rates since the beginning of the reporting period.

4. Use geographic variables (such as hospitals, residence, reporting site, neighbourhoods, village and so on) to analyse the distribution of cases by place. This is the information that will help to identify high risk areas.

5. Analyse disease trends for at least the diseases of highest priority in your district. Monitor the trends for cases, deaths, and case fatality rates to identify any unusual increases or disease patterns.

6. Data validation and quality analysis. Establish a data validation team at all levels. Meetings should be held periodically to review reports. All reports submitted must be checked for consistency with various sources.

Below is an example of a product from an analysis plan for routine surveillance information.

Example of data analysed for cholera in Country A, 2017 Distribution by Time Outcome Total Onset week Case fatality rate Alive Deaths 30 7 26 23 16 5 5 97 27 92 1 1 87 28 88 10 29 21 19 2 11 32 11 9 2 11 18 33 7 17 251 234 Total Distribution by Place Outcome Total District Case fatality rate Alive Deaths 1 1 District 1 7 86 6 92 District 2 7 158 147 11 District 3 7 Total 251 17 234 District Cases Attack rate per Population 51 179888 92 District 1 201 158 District 2 78524 Distribution by Person Outcome Total Case fatality rate Age Group Alive Deaths 5 37 35 2 0-4 years 9 5 55 50 5-9 years 7 2 30 28 10-14 years 23 23 15-19 years 1 4 28 27 20-24 years 8 2 26 24 25-29 years 1 12 30-34 vears 25 2 8 35-39 years 6 2 30 32 40 + years 7 234 17 251 Total Outcome Total Sex Case fatality rate Alive Deaths 7 Female 122 114 7 120 129 Male 9 7 17 251 234 Total

#### Annex 3B: How to manually make a line graph

How to make a line graph Decide what information you want to show on the graph.

Write a title that describes what the graph will contain (for example, Monthly totals for 2 inpatient cases and deaths due to malaria with severe anaemia).

Decide on the range of numbers to show on the vertical axis.

Start with 0 as the lowest number Write numbers, going up until you reach a number higher than the number of cases Chose an interval if the numbers you will show on the vertical axis are large.

4 Label the vertical axis, explaining what the numbers represent.

Label the horizontal axis and mark the time units on it. The horizontal axis is divided into equal units of time. Usually you will begin with the beginning of an outbreak, or the beginning of a calendar period, such as a week, month or year.

Make each bar on the graph the same width.

Mark the number of cases on the graph or histogram. For each unit of time on the horizontal axis, find the number of cases on the vertical axis. Fill in one square for each case, or for some number of cases in the column for the day on which the patient was seen. Show deaths by using a different pattern of lines, or a different colour. If you are making a line graph, instead of making a bar or filled-in squares, draw a cross or make a point where the horizontal and vertical lines cross. Connect the points on the graph to show the trend going up or down over time.

SECTION 4 INVESTIGATE SUSPECTED OUTBREAKS AND OTHER PUBLIC HEALTH EVENTS

## Section 4: INVESTIGATE SUSPECTED OUTBREAKS AND OTHER PUBLIC HEALTH EVENTS

### 4.0 Investigate suspected outbreaks and other public health events

Aim: This section describes what needs to be done when investigating a public health event.

Definition: An outbreak is defined as an increase in the number of cases of a disease or a public health event above what is normally expected within that population, in a given area and over a particular period of time. Other definitions that relate to outbreaks are:

- Endemic: Constant presence of a disease at baseline level within a certain geographical

location or population

- Epidemic: used interchangeably with outbreak however epidemics are usually larger in

scope

- Pandemic: an epidemic spread over multiple countries and or continents

- Cluster: An aggregation of cases or health related condition in a given area over a particular

period regardless of whether the number of cases is more than expected in relation to time, place or both.

When any public health event or condition is detected and reported, there are several steps taken to conduct an investigation (see Error! Reference source not found.). These steps are listed in order, but their order of implementation is often non-sequential. Knowing these steps prepares one to investigate properly, using common sense and logic to determine when, how often, and to what extent the different steps should be implemented in a real investigation.

The results of an investigation events lead to identification and assessment of persons who have been exposed to an infectious disease or affected by an unusual public health event. The investigation provides relevant information to use for taking immediate action and disease prevention activities.

#### 4.0.1 Purpose of an investigation

The purpose of an investigation is to:

- Verify the existence of an outbreak or the public health event.

- Identify and treat additional cases that have not been reported or recognized.

- Collect information and laboratory specimens for confirming the diagnosis.

- Identify the source of infection or cause of the outbreak.

- Describe the epidemiological situation by time, place and person

- Describe mode of transmission and risk factors in the affected populations

- Identify and select appropriate response interventions to control the public health event

- Strengthen control and prevention activities to avoid future reoccurrence of the outbreak

and other public health events.

Step 1: Establish existence of an outbreak: Ask is it an outbreak?

Continue to monitor

- Review data received and determine if an outbreak is occurring

Conduct preliminary data analysis Daily follow up with public health officials and persons reporting Collect additional data over the phone if necessary Verify the outbreak Step 2: Prepare for fieldwork

- Mobilize RRT members, prepare required logistics and assess security and safety needs

Collect additional data/information over phone Communicate to all reporting levels (including community leader) the purpose of the investigation Step 3: Verify and confirm the diagnosis

- Verify diagnosis by reviewing the clinical records

Visit and speak to the ill persons

- Collect samples and review laboratory results

Step 4: Define a case and search for additional cases Develop an operational case definition Find and obtain additional cases as needed and systematically record information about each in a register (age, sex, onset of illness.

length of illness, date of visit to health facility, location, signs and symptoms) Generate a line list of the cases Collect additional samples from new and old patients including food, and water where applicable Safely package and send the additional samples to laboratory with completed investigation forms Step 5: Analyze data and generate hypothesis Analyze data by Person, Place and Time Using descriptive analysis, generate hypothesis for possible determinants of the outbreak Л Step 6: Test and refine hypothesis with analytical study Based on descriptive epidemiology and situation, select appropriate study design Obtain resources to conduct an analytical study Draw conclusion from study Conduct additional studies if necessary Step 7: Implement control measures (Refer to section 6) Step 8: Write report and disseminate findings (Refer to section 7)

- Prepare an outbreak report

- Communicate findings to stakeholders

Step 9: Conduct risk sssessments to determine if the outbreak is a potential PHEIC

- Evaluate the impact of the event and risk of spread or travel restriction (use IHR Decision Instrument-Annex 2)

Step 10: Maintain and intensify surveillance National level should maintain contact with the district for daily updates (cases, deaths, No. admitted, No. discharged, areas affected.

etc.) until end of epidemic Districts should intensify surveillance during and after outbreak Conduct After Action Review and amend tools, strategies, etc based on lessons learnt

**Figure 11: Steps in outbreak investigation**

![Figure 11: Steps in an outbreak investigation](uganda-idsr-technical-guidelines-assets/figures/figure-11-outbreak-investigation-steps.png)

#### 4.0.2 Decision to investigate a reported outbreak or public health event

It is the overall mandate of the Ministry of Health to investigate and respond to outbreaks of national or international concern. In such situation, the MoH will constitute a national investigation team to work with the affected district in the investigation and response process.

The role of the district is to conduct initial investigations for any suspected outbreak either from the health facilities, community or rumors. The DHO should immediately constitute a District Rapid Response Team to investigate and send a preliminary report to MoH. The district may be supported by the regional rapid response team to conduct the investigation.

The District should conduct an investigation when:

- An alert of a suspected outbreak of a notifiable disease is received (birds die off due to

avian influenza, livestock deaths due to anthrax)

- An unusual increase is seen in the number of cases or deaths during routine analysis of

public health surveillance data

- Alert or epidemic thresholds have been reached for specific priority diseases. The initial

trigger for a new epidemic prone disease could be the laboratory

- Communities or social media report rumours of deaths or a large number of cases that are

not being seen in the health facility

- A cluster of illnesses or deaths occurs for which the cause is not explained or is unusual

(for example, an adult death due to bloody diarrhoea, cluster of illness among health care workers, cluster of animals (domestic and/or wildlife) deaths

#### 4.0.3 Verify the reported information

i uny either of are en is a he a pete citat o suggesting a true outbreak or event. To verify the information, consider the following factors:

- Source of information (for example, is the source of the rumour reliable? Is the report from

a health facility or a community or electronic/print media?)

- Severity of the reported illness and use of standard case definition for reporting

- Number of reported cases and deaths

- The age, sex and occupation of reported cases or deaths

- Mode of transmission of suspected pathogen and risk for wider transmission

- Geographical and socio-cultural considerations

#### 4.0.4 Record reported outbreaks, public health events and alerts

Districts should track and keep a record of reported suspected outbreaks, events and rumours.

The purpose for tracking reported outbreaks is to ensure that the report of each suspected outbreak or alert is followed by some public health action. Keeping this record will help to gather information for evaluating the timeliness and completeness of the outbreak investigation and response process. The district should use an outbreak and rumour log for recording and

analysing long-term trends. Refer to Annex 4A for district log of suspected outbreaks and rumours.

### 4.1 Prepare to conduct an outbreak investigation

#### 4.1.1 Mobilize a Rapid Response Team (NRRT/DRRT)

The RRT is a technical, multi-disciplinary team that is available for quick mobilization and deployment to support the field response to a suspected or confirmed outbreak or event. It is advisable to have a database of trained health workers who can be mobilized rapidly to fulfil the following functions:

- Coordination,

- Surveillance

- Laboratory confirmation

- Case management, mental and psychosocial support.

- Infection Prevention Control (IPC)

- Environmental health and sanitation

- Risk Communication and Community Engagement (RCCE) and social mobilization.

- Animal health (as applicable)

- Logistics

Experts that can fulfil more than one function may be co-opted into the RRT.

The composition of the RRT should have at least the following;

- Coordination - Team Lead

- A clinician - to oversee case management and Infection Prevention and Control (IPC)

- Public health nurse

- Surveillance expert/ Epidemiologist /Data manager

- Laboratory expert

- Environmental Health expert

- Animal health expert

- Social mobilization and risk communication expert

- Psychosocial Support (PSS) expert

- Logistic expert

- Others based on specific characteristics of the outbreak (e.g. expert on chemicals).

Section 5 will describe in detail the composition of other teams in responding to an outbreak and other public health events.

Develop terms of reference that define the objectives of the investigation and details of the expected deliverable per section of the RRT so that the essential information will be gathered for investigating the outbreak and implementing the most appropriate and relevant response.

Identify all the relevant stakeholders for the investigation and response. The national and or the

regional level may deploy to support the districts to investigate and respond to the outbreak/public health emergency.

The RRT should take note of the relevant standard guidelines and standard operating procedures/methods (SOPs) to the disease or condition being investigated. For example, SOPs for collecting the correct laboratory specimen, case management guidelines, case investigation forms, line-listing forms. Reference can be made to standard websites in scenarios where the RRT cannot access copies of such SOPs or requires further guidance. Such websites include www.who.int or www.cdc.gov and other such relevant sites.

#### 4.1.2 Specify tasks for the RRT members

Inform RRT members the tasks expected of them during the investigation and the functions each will support. Specify tentative timelines for the assignment. Contribute to the positive motivation for doing the assignment. For example, make sure that the RRT understands the link between the investigation results and the selection of response activities for preventing additional cases and saving lives. Ensure that all medical and non-medical staff have access to and know how to use the required Personal Protection Equipment (PPE) and universal precautions relevant for the possible cause of the suspected outbreak or event.

#### 4.1.3 Define supervision and communication lines

Make a plan on how the teams will communicate during the investigation. Prepare a diagram showing who will report to whom and how information will move both within the investigation team and between the district and other levels, including the most local level. For example, define who will communicate with the Ministry of Health, other sectors, the media and the community. State the methods and frequency of communication during an outbreak to keep officials and other stakeholders informed. Methods may include daily updates (SitReps, line lists etc) by mobile phone, electronic mail or conference calls. Show on the diagram the lines of authority and the roles of each staff on the team. Define the role of non-medical workers and how they should be supervised.

A clear communication procedure is key for ensuring the regular sharing of critical information about identifying and responding to risks associated with the outbreak or event.

#### 4.1.4 Decide where the investigation will take place

Review known information about the suspected illness, including its mode of transmission and risk factors. Use this information to define the geographical boundaries and target population for conducting the investigation. Begin the investigation in the most affected place.

Visit and review records in health facilities in the affected area to actively find cases. Involve the community and local health facility staff in planning and conducting the investigation.

Listen to and seek out information about local customs, culture, and routines that could affect the success of the outbreak investigation.

#### 4.1.5 Obtain the required authorizations

Observe the appropriate authorizations, clearances, ethical norms and permissions that are required to do the investigation. In addition to official authorizations, ensure mutual understanding with community and opinion leaders.

#### 4.1.6 Finalize forms and methods for collecting information and specimens

Select variables needed to identify, record and analyse the disease being investigated. Annex 4E provides a sample linelist with key variables. Depending on staff responsibilities, review how to:

- Record case information on a linelist for later use during time, place and person analysis

- Fill appropriate request forms, label laboratory samples properly and use a unique ID

number for a given case

- Prepare (and update as needed) an epidemic curve

- Construct a spot map showing location of geographic variables such as location of cases

and deaths

- Develop analysis tables for risk factors, age group, sex, immunization status and so on.

#### 4.1.7 Arrange transportation and other logistics

Make travel arrangements for getting to and from the site of the investigation and for travelling during the investigation. Make sure transportation for moving specimens to the appropriate laboratories has been arranged in advance of the team's departure. Other logistics such as medical supplies, vaccines, PPEs should also be available.

#### 4.1.8 Gather supplies for collecting laboratory specimens

Some districts may already have in place a rapid response kit that contains supplies and equipment for carrying out an investigation including laboratory supplies.

If a kit is not available in your district, look at the disease specific program guidelines and talk to laboratory specialists to find out the requirements for laboratory supplies for proper collection, storage, and transport of relevant specimens (refer to Annex 4B). Use of personal protective equipment (PPE) and disinfection materials is strongly recommended (refer to Annex 4C).

Refer to the disease specific guidelines in Section 11.0 for laboratory requirements.

### 4.2 Verify and confirm the outbreak or event

#### 4.2.1 Review the clinical and exposure history

Examine the patient or patients' records to confirm that their signs and symptoms meet the case definition. Do not forget to use the minimum PPE. Ask the patient or a family member who can speak for the patient the following questions:

- Where do you live?

- When did the symptoms begin?

- Who else is sick in your home, school, workplace, village, and neighbourhood?

- To where have you travelled recently?

- Where have you been living prior to onset of symptoms (residence at time of infection)?

- Were you visited by anyone recently?

- Who took care of you when you started feeling sick?

- Have you been in contact with sick or dead animals (both domestic and wildlife) recently

(for zoonotic infections)?

- Have you been in contact with any sick or dead person?

- Has anybody died in the community you lived in recently?

- Did you participate in any burial ceremony (What role did you play?)

- For suspected Adverse Events Following Immunization (AEFI), what vaccines have you

received recently?

#### 4.2.2 Collect laboratory specimens and obtain laboratory results to confirm the

diagnosis Refer to the laboratory requirements in Section 11.0 to determine the diagnostic test and the specimen that is required if the disease can be confirmed by laboratory testing. The disease specific laboratory requirements also describe how to collect, store and transport the relevant specimen, and how many specimens to collect to confirm an outbreak for that particular disease.

See Annex 4H for how to pack samples using a triple packaging technique.

Note that some diseases may require additional food or environmental samples to aid in diagnosis and ensure that these samples are also collected e.g., water samples for cholera outbreaks; food samples for food borne outbreaks.

Review laboratory results with the investigation team, clinicians, and laboratory persons at the health facility. Are the laboratory results consistent with the clinical findings? Seek additional assistance from national level program managers or technical experts if you have any questions about the laboratory results.

### 4.3 Define and search for additional cases

#### 4.3.1 Define a case

It is crucial to define what constitutes a case of a priority disease during an investigation. Standard Case Definitions for IDSR priority diseases in Uganda have been summarised in a booklet and can be a good starting point. We may tailor these IDSR SCDs to suit a specific outbreak so as to capture other details like location, attendance at an event or history of travel. In cases where the RRT encounter a new disease, they should develop an operational case definition. The common elements of a case definition include signs and symptoms, date of onset of signs and symptoms, laboratory results, and elements of person, place, and time.

#### 4.3.2 Isolate and manage cases

Use the case definition to identify (more) cases. Institute appropriate control measures to minimize the related morbidity and/or mortality. One common control measure is isolation of cases. It limits spread of disease and keeps healthcare facilities open and healthcare workers available and safe. Depending on the disease, immediate isolation may be required to protect staff, patients and community members. Ensure the cases in isolation units have access to essentials facilities like food, water, toilet, etc. Use case management guidelines to strengthen infection prevention and control in both isolation and treatment units. Provide the health facility with support and supplies.

N.B: Institute standard precautions for all patients in the health facility and the community, especially during outbreaks of diseases transmitted by contact with contaminated supplies, surfaces and body fluids.

#### 4.3.3 Search for additional cases and contacts

Once the initial cases have been clinically confirmed and treatment has begun, actively search for additional cases should continue.

Search for suspected cases and deaths in the health facility records In the health facilities where cases have been reported, search for additional suspected cases and deaths in the registers. Look for other patients who may have presented with similar signs and symptoms as the disease or condition being investigated. The team should request health workers to search/look put for similar cases in neighbouring facilities where the person could have sought care including drug shops, worship centres and traditional shrines where people could have sought alternative care/cures. Annex 4D of this section provides instructions on conducting a register review. Follow up any cases from the register, meeting the case definition, that have gone home.

Search for contact persons and suspected deaths in the community Identify all areas of likely risk where the patients have lived, worked, eaten from or travelled to, attended parties, family outside the country, visiting wildlife protected areas (zoo and national parks), livestock farm, laboratory, mining or hunting sites. Also talk to other informants in the community such as herbalists, food handlers, school teachers, veterinarians, farmers, community leaders, etc.

The areas for the search may be influenced by the disease, its mode of transmission, and factors of risk related to time, place and person. Visit those places and talk to people who had, or were likely to have had, contact with the patient. Ask if they or anyone they know has had an illness or condition like the one being investigated. Find out if anyone else in the area around the case has been ill with signs or symptoms that meet the case definition. Find out if there were any recent deaths. If they say yes, find out the signs and symptoms of the person(s) that died.

Enquire about the people that took care of these people when they were sick, and also the preparation of the dead before and during the burial ceremony. Collect information that will help to describe the magnitude and geographic extent of the outbreak. Refer newly identified cases to the health facility for treatment.

Annexes 4E and 4F provide examples of forms for recording and following-up on contacts.

#### 4.3.4 Quarantine contacts of highly infectious diseases

Quarantine is recommended for highly infectious novel pathogens such as COVID-19.

Quarantining contacts of cases is done in disease outbreaks which are highly contagious, transmitted through person to person with the aim of interrupting transmission and easy monitoring of the exposed persons. The duration of the quarantine is guided by the incubation period of the disease. During quarantine, monitor contacts for symptom development daily and isolate those that develop symptoms.

### 4.4 Develop a line list

Transfer information collected on cases that fit the operational case definition from the case investigation form into a line list, including the index case. Data may be obtained from either registers or community searches. Where possible include geo-mapping information. The line list will keep track of pertinent basic data for cases and potential cases as they are identified (See Annex 4E for a sample line list). List any contacts on the contact listing form and ensure they are monitored daily for the required time for signs and symptoms of the disease (See Annex 4F and 4G for contact list and contact tracing forms) Record information of all cases on a "case reporting form". At least record the following:

- The patient's name, address, and village or neighbourhood and locating information. If

available, use your phone to record GPS coordinates for these cases. If a specific address is

not available, record information that can be used to contact patients if additional information is needed or to notify the patient about laboratory and investigation results

- The patient's age and sex. This information is used to describe the characteristics of the

population affected by the disease

- The date of onset of symptoms and date the patient was first seen at the health facility

- The status of the patient whether dead or alive. If dead, record date of death.

- Relevant risk factor information such as immunization status if the disease being

investigated is a vaccine-preventable disease; occupation if you suspect occupation is related to that particular outbreak.

- The name and designation of the person reporting the information.

Some diseases have their own more detailed case investigation form. Detailed forms for investigating such specific diseases are found at the end of Section 11.0.

- Complete the case investigation form for any new cases (see Annex 2A) and record the

details on the line list (Annex 4L).

### 4.5 Analyse data about the outbreak

Refer to and use the direction in Section 3 for analysis of outbreak data. Summarize the data to get clues on where it is occurring/moving to, the source such as a meal or a burial, persons at risk of becoming ill (young children, refugees etc). Present the data by time, place and person.

- Make tables of the most relevant characteristics for cases (for example, age group with

vaccination status, sex ratio, occupation in relation to cases etc)

- Draw a histogram representing the course of the disease (an "Epi" curve).

- Plot the cases on a spot map

- Calculate Case Fatality Rates (CFR)

In addition to CFR, also calculate Attack Rates as seen in Section 3.

#### 4.5.1 Interpret results of the analysis

Use the information from the analysis to identify potential risk factors, the causative agent, source of infection, transmission pattern and the control measures to counter the threat. Use a histogram to draw an epidemic curve. Some of the examples of epidemic curves are given below:

Epidemic Curves and Manner of Spread Point source (single exposure) Continuing common source cases 12 6 7 Day Day Intermittent source Propagated spread cases cases 10 12 13 Week Day

**Figure 12: Types of Epidemic Curves and the manner of spread**

![Figure 12: Types of epidemic curves and manner of spread](uganda-idsr-technical-guidelines-assets/figures/figure-12-epidemic-curve-types.png)

Use a map to describe the geographic extent of the problem and identify high risk areas, any clusters or patterns of transmission or exposure, proximity of the cases to likely sources of intection, mobile communities like nomads, migrants or missionaries.

Use person analysis to describe precisely the high-risk group(s) to guide on the interventions.

For instance, if yellow fever occurred in persons less than 15 years, the immunization response might need to target children less than 15 years of age. Below is an example of data analysis by person (age) which shows how the results could be used to plan for interventions.

Table 4: Example: Attack rate by age group during a Malaria outbreak in 3 sub-counties in Nwoya District, Uganda, February-May 2018 Number of cases Attack rate (Per 1000) Population Age group (years) 69 <5 926 13,402 84 5-18 21,533 1,809 > 18 46 25,039 1,144 65 Total 59,974 3,879 The table shows highest rates of disease among persons aged 5-18 years.

Use information from the linelist, starting with the index case, to draw a transmission tree. It will show the contributions of different settings to the disease spread over a given geographical area to regulate transmission, implement control measures and planned interventions. It is updated as information becomes available. A sample transmission tree is given in Annex 4J.

### 4.6 Report writing and dissemination of findings

Prepare Situation Reports (SitReps) of the outbreak and share with relevant stakeholders. If risk factors are already known, draw conclusions and make recommendations highlighting:

- Type of outbreak or public health event

- The population affected and at risk

- Possible causes of the outbreak/public health event, laboratory results, source of infection,

mode of transmission, attack rates, case fatality rates and possible risk factors

- Measures already initiated to contain the outbreak.

During an investigation, the RRT is expected, in addition to daily SITREP, to prepare report not later than 72 hours following the initiation of the investigation. All investigation or outbreak reports (preliminary, interim and final) must be disseminated even if no conclusive risk factors have been identified. Section 7 describes various channels of communication during outbreak.

The district Biostatistician should collate all data on cases, deaths, number admitted/discharged, areas affected, etc. into a SITREP until end of the epidemic to the national PHEOC with the express clearance of the DHO. This helps to avoid parallel reporting.

### 4.7 Implement prevention and control measures

Control measures help in interrupting disease transmission by limiting exposure to the source of infection, targeting specific agents, sources, or reservoirs. The objectives of control measures are:

- Control the source of infection

- Control of further transmission

- Prevention of future outbreaks.

Section 11.0 gives a description of some of the control measures for each priority diseases.

NOTE:

- Control measures should be implemented at the earliest point and concurrently with the

investigation, some being non-specific regardless of the type of disease or source.

- Ensure multi-sectoral engagement throughout response i.e., from community level to non-

health stakeholders key for the particular outbreak. For example, enforcement of by-laws requires assistance from law enforcement agencies like the Uganda Police.

- Public health response may include testing new potential countermeasures including

vaccines and therapeutics. Such biomedical research is an important and discrete component of the response. However, this does not take precedence over the overall Public health response efforts. But, whenever required support the research and ensure that it is

conducted scientifically and ethically, in line with approvals of MoH's Ethical Review Boards and Uganda National Council of Science and Technology (UNCST).

### 4.8 Conduct an assessment to determine if the event is a potential Public Health

Emergency of International Concern (PHEIC) Investigations for priority diseases provide baseline information to support risk assessments by the National IHR Focal Point to address the following questions:

- Is the public health impact of the event serious?

- Is the event unusual or unexpected?

- Is there a significant risk of international spread?

- Is there a significant risk of international travel or trade restrictions?

The NTF supports to conduct the risk assessment using the IHR decision instrument (see Annex 2A) to determine if the event is a potential PHEIC that warrants notification to WHO.

#### 4.8.1 Maintain and intensify surveillance

Maintain contact with all health services delivery points, including those for alternative medicine and neighbouring districts to ensure no spill overs are occurring by sharing information. Where PoEs exist, share with the neighbouring countries through cross-border surveillance committees.

### 4.9 Conducting risk assessments during investigation and after outbreak

confirmation The RRT must conduct a risk assessment within 72 hours of identifying the threat and at each stage of the investigation/outbreak, focusing on control measures. The risk assessment should include;

- Evaluating the susceptibility of the population and potential for spread of the event

- Evaluating the risk of further transmission, morbidity and mortality. Consider factors

such as population size/movement, <5 mortality, seasonality, access to health services, etc.

Risk assessments should be updated as new information becomes available, sometimes by multiple teams giving a composite picture of the risk (e.g. clinical severity, transmission dynamics, and control measures) specially to identify where improvements should be made.

For further reading, refer to 1,3,26-31

### Annexes to SECTION 4

#### Annex 4A: District log of suspected outbreaks and rumours

#### Annex 4B:

Checklist of laboratory supplies for use in an outbreak investigation

#### Annex 4C:

Recommended list of personal protective equipment

#### Annex 4D: How to conduct a register review

#### Annex 4E:

Sample line list

#### Annex 4F: Contact listing sheet

#### Annex 4G:

Contact tracing form (follow-up)

#### Annex 4H: Triple Packaging of samples during an Outbreak

#### Annex 41:

Example of an Analytical study to test hypothesis How to create a transmission tree

#### Annex 4J:

signature and Name Comment taken and results) (include if sample (17) Date received national response District (16) District National Level of the Date Outbreak Notified (15) Interventio n that was Concrete Type of begun (14) interventi specific on began Date (13) case seen at was first facility health Date a (12) threshold Date cluster crossed or first (11) onset Date case index (10) Outbreak Began Date investigation Result of District (Confirmed, Unknown) Ruled Out, or suspected outbreak was district Date investigated by the district was notified Date (Health Locatio Centre) of deaths reported Number initially of cases reported Number initially suspecte outbreak telephon Source of e etc) (newspa Record verbal or written information from health facilities or communities or social media about suspected outbreaks, alerts, or

#### Annex 4A: District log of suspected outbreaks and alerts

reports of unexplained events. Record the steps taken and any response activities carried out.

Condition or Disease or Event

(I)

#### Annex 4B: Checklist of laboratory supplies for use in an outbreak investigation

For using standard safety precautions when collecting and handling all specimens:

Pieces of bar soap for hand-washing bleach for decontamination Supply of PPEs (gloves, mask, gowns, etc.) Triple package and refrigerant for sample transportation, Safety boxes for collecting and disposing of contaminated supplies For collecting laboratory specimens:

Blood Cerebrospinal fluid (CSF) Local anaesthetic Sterile needles, different sizes Sterile syringes Needle and syringe for anaesthetic Vacutainers Antiseptic skin disinfectant Test tube for serum Sterile screw-top tubes, Antiseptic skin disinfectant Cryotube, dry tube, sterile gloves, surgical adhesive bandage, mask, sterile gauze, Tourniquets lumbar puncture needle, Transport tubes with screw-on tops Microscope slides in a box Transport media (Cary-Blair, Trans- Trans-Isolate transport medium Isolate, VTM) Latex kit Blood films (malaria) Gram stain or Sterile May Grunewald Giemsa Kit disposable lancet and cover Glass slides Stool Slide box slips Stool containers Respiratory Rectal swabs specimens Swabs Cary-Blair transport medium Viral transport medium Plague Gram stain kit test Rapid diagnostic Cary-Blair (dipsticks AgF1) transport If health facility has a centrifuge:

Sterile pipette and bulb Sterile glass or plastic tube, or bottle with a screw-on top

For packaging and transporting samples:

Cold box with frozen ice packs or vacuum flask Cotton wool for cushioning sample to avoid breakage Labels for addressing items to lab Labels for marking "store in a refrigerator" on outside of the shipping box Case forms and line lists to act as specimen transmittal form Reagents and supplies for testing Reagents Media (MacConkey, Blood agar, others Appropriate personal protection (PPE) (for all EPR diseases such as VHF, suspected avian influenza, etc.) In some events which present with fever, it might be worthy carrying malaria rapid diagnostic kits (mRDT) if found not available in a nearby health facility

#### Annex 4C: Recommended list of Personal Protective Equipment (PPE)

The following equipment should be available for the personal protection of all staff investigating a suspected case with highly infectious disease e.g., viral haemorrhagic fever, avian influenza etc. (See reference for the guidelines to use and select PPE at the end of the section). The equipment should be held at regional or district level. If the PPE kits are inadequate, preposition of the PPE should be done in high risk regions or districts which are likely to report these specific or which have been identified to be at risk through risk assessment.

WHO Deployment Kit Composition of one set of PPEs 1 surgical gown 100 surgical gowns 1 coverall 100 coveralls 1 head cover 100 head cover 50 pair of goggles 2 pairs of goggles 100 pairs 1 pair of rubber gloves 1 mask N95 200 pieces 1 boot cover* 1 box 50 pairs of examination gloves 800 pairs of examination gloves 1 plastic apron re-usable 20 pieces

20 Gum boots 1 pair of gum boots 2 hand sprayers of 1.5 litres each 1 hand sprayer 1 back sprayer of 10-12 litres 1 Back sprayer Specimen containers 3 rolls Scotch of tapes 3 bottles Anti-fog for goggles Chlorine N.B: chlorine and gum boots can be purchased locally; biohazard bags for PPE/Waste management must be purchased * Not essential

#### Annex 4D: How to conduct a register review

I. Background The purpose of a register review is to collect information on cases admitted to the health facility during a specific period. Explain that the information will be used to determine what caused the outbreak or increase in number of cases. The register should be used for;

- Any inpatient facility with more than 10 hospital beds. Give priority to government

health facilities.

- Large reference or teaching hospitals with paediatric wards because they receive

referrals from other health facilities.

- Small hospitals or health facilities that serve remote areas and high-risk populations. For

example, nomadic groups, refugees, or areas without regularly scheduled health services.

II. Meet with the health facility staff and explain the purpose of the review.

Emphasize that the activity is an information-gathering exercise to assist in determining control measures to prevent other cases from occurring, and is not a review of health worker performance.

III. Arrange to conduct the review.

Arrange a time to conduct the review when staff who will assist with the review are present and available to help or to answer questions.

IV. Identify sources of information.

During the visit, depending on the priority disease or condition or events being investigated, check inpatient registers for the paediatric and infectious disease wards. The inpatient register for the paediatric ward is a good source because it lists all children admitted to the ward. Annual summary reports are not always accurate, and outpatient registers often include only a provisional diagnosis.

Review the system and procedures health workers use to record information in the registers about diagnoses. Make sure that the information needed for investigating any suspected case is available. At a minimum, the register should include:

-- the patient's name and location

- the signs and symptoms

- date of onset of symptoms and outcome (for example, date of death, if relevant)

- immunization status, if appropriate to this disease.

If the health facility does not keep at least the minimum information, talk with senior staff about how to strengthen the record keeping so that the minimum information is collected.

V. Conduct the record review at the scheduled date and time.

Go to the selected wards as scheduled. During the visit, look in the health facility registers for cases and deaths that may be suspected cases of a priority disease. These should be cases or deaths that meet the standard case definition for suspected cases. Find out whether the suspected case was investigated and reported according to the national guidelines.

VI. Line-list the suspected cases that are found.

Record information about the suspected cases in a line list for further case investigation.

VII. Provide feedback to the health facility staff.

Meet with the health facility supervisor and discuss the findings of the activity. Use the opportunity to review any features of case management for the illness that may help health workers in the facility. Emphasise the importance of immediate reporting and case investigation as tools for prevention of priority diseases and conditions, IPC and use of PPE.

VIII. Report any suspected cases to the next level.

Report the suspected cases according to local procedures. Investigate the case further to determine the factors that placed the patient at risk for the disease or condition. Develop an appropriate case response.

Comments Discharge or Death Date of Outcome Treatment given Admission Place Yes/ No Hospitalized Results Specimen Dehydration Yes/No Severe 115 Vomiting Yes/No Yes/No Diarrhoea seen Date HF Onset Date Occupation Age Locality Ward District County

#### Annex 4E: Sample Line List

Name Patient No

Outcome Visit Last date follow-up contac Date of last list Date of Admission:

(1, 2 st Type of Contact all) orDistrict/To Communit wn y leader Chief If hospitalized, Hospital neighbourho of Village/ 116 Head Househol Phone numbe Sex (M/F Chief or Community leader...

Case number (if assigned)..

Province/Region Hospitalized.... / Found in the community....

Health case Relationshi p with the 2 - direct physical contacts with the case (dead or alive) 1 - sleeping in the same household with a suspected 3 - has touched his / her linens or body fluids 4 - has eaten or touched a sick or dead animal Othe Nam Case name.

Surna me

#### Annex 4F: Contacts listing sheet

Contact's' Recording Sheet filled in by Case's Village/neighbourhood Contacts are defined as:

District/Town Date of symptom onset.

112 13 14 15 16 17 18 19 20 21 117 6 17 8 9 110|11 12 3 4 .. Province/Region..

.. Chief or Community leader Contact Date of Day of Follow-up Name Age Sex last Record "X" if the contact has died or developed fever and/or bleeding (complete Case Investigation Form and, if alive, refer to Contact Tracing Form - by Village Team.... Volunteer's name..

District/Town.

Name Record "O" if the contact has not developed fever or bleeding Village...

the hospital)

#### Annex 4G: Contact tracing form (follow-up)

CN Family First

#### Annex 4H: Types of Triple Packaging of samples during an Outbreak

Infectious Substance Absorbent Packing Primary Receptacle Material (for liquids) Leakproof or Siftproof 1 Cross Section of Closed Package Secondary Packaging Leakproof or Siproof Primary Receptacle (e.g. Sealed Plastic Bag) Leakproof or Siftproof Secondary Packaging Leakproof or Siffproof (e.g. Sealed Plastic Bag or other intermediate packaging) Rigid Outer - Rigid Outer Packaging ategory B - Packaging Absorbent Materia Cushioning UN3373 Material Package Mark Name and telephone number of a person responsible. (This information may instead be provided on a written document such as an air waybill) Source: https://www.health.go.ug/covid/wp-content/uploads/2020/04/Laboratory-Manualfor-COVID-19_-Final1-1.pdf

#### Annex 41: Example of an analytical study to test hypothesis

Case control study to determine potential exposures to cholera in Kasese, Uganda in May 201524. The adjusted matched analysis indicates that persons who drank un-boiled /untreated water (Odds ratio (OR) = 4.8; 95% Confidence Interval (C.I) = [1.3; 18]) were at greater odds of having cholera.

Exposure % exposed Num. of participants OR M-H (95% CI) Cases Cases (n = 49) Controls Controls (n = 201) 76 194 153 Drinking unboiled/untreated water 4.8 (1.3-18) 17 32 64 Source of drinking water: River or Stream 34 1.3 (0.57-2.8) 93 48 187 Eating fish 3.4 (0.48-24) 98 Market where fish was bought 35 70 Customs market 12 225 | 0.39 (0.13-1.2) 15 30 28 Mpondwe market 56 1.2 (0.43-3.5) 13 Musyenene market 4.2 (0.69-25) 55 47 Sex (males) | 23 111 0.66 (0.33-1.3) 10 10 20 Education (≤Primary School) 20 2.3 (0.97-5.6) *Adjusted for age group and village, using the Mantel-Hanszel method Excerpt obtained from: https://bmcpublichealth.biomedcentral.com/articles/10.1186/s12889- 017-4589-9#Tab3

#### Annex 4J: Example of creating a transmission tree

Consider the following scenario which describes an outbreak of a respiratory illness, where the investigation team had information on 13 cases.

(1) The first case was a 25-year-old university student with onset of symptoms on 21 March 2012. He was admitted to Kagadi hospital on 4 April 2012 after a week of coughing, fever, and shortness of breath. The patient was diagnosed with pneumonia and pericarditis, and he was soon transferred to the coronary care unit (CCU). As his condition worsened, he was transferred to Hoima Regional Referral Hospital (RRH) for further treatment; he was intubated in ICU the next day and died on 25 April 2012.

Investigators were told that during his illness, the patient was in close contact with his mother (who did not report illness) and two healthcare workers (cases 2 & 3). His illness was later laboratory-confirmed as the novel coronavirus.

(11) The second case was a 30-year-old male nurse in the CCU at Kagadi hospital. His symptoms started about 29 March 2012. He did not travel or have contact with animals in the 10 days prior to his illness, though he was in close proximity to the first case in the CCU. On 8 April, case 2 was admitted to the CCU at Kagadi with shortness of breath and pneumonia and was later discharged with no sequelae from Islamic hospital on 23 April. The patient was in close contact with two household members, including his mother (case 13) and a man that did not get sick (who was also the brother of case 3).

(111) Case 3 was a 40-year-old female nurse in the ICU at Zarqa hospital whose illness was laboratory-confirmed after her death. Her symptoms began on 2 April 2012, and she was admitted to Kagadi hospital ICU after developing pneumonia 7 days later. She was later transferred to ICU at Mubende RRH where she died on 19 April. During her illness, she was in close contact with 4 household members, including another brother who fell ill 10-days post exposure (case 9), and three others that were not affected. One month prior to her illness, her sister visited from Saudi Arabia.

(1V) Case 4 was a 65-year-old male doctor whose symptoms of fever and fatigue started 2 April 2012 and developed into pneumonia. The doctor opted to stay home during his illness and soon recovered. He did not travel or have contact with animals in the 10days prior to his illness. His household members did not report any illness.

(V)

Cases 5 to 13 occurred in the second phase of the outbreak, with the onset of symptoms occurring between 11-26, April 2012. All except case 13 (the mother of case 2), had direct contact with one or both laboratory-confirmed cases. None of the health workers travelled or had contact with animals. Health workers reported that they only used gloves when treating patients to avoid stigmatizing them.

Basing on this information, and a line list, one sketch a transmission tree as follows:

/ Symptomatic 1 4 ] Asymptomatic 2 13 3 Time Footnote: Extract from "Applied Public Health Case Study Scenarios for Training Public Health Professionals. Case studies developed under CDC/AFENET agreement". Transforming Public Health Surveillance. (pages: In press). Location: Elsevier

SECTION 5 PREPARE TO RESPOND TO OUTBREAKS AND OTHER PUBLIC HEALTH EVENTS

## Section 5: PREPARE TO RESPOND TO OUTBREAKS AND OTHER PUBLIC HEALTH EVENTS

### 5.0 Prepare to respond to outbreaks and other public health events

This section will detail preparing a national preparedness plan, implementation of activities in the plan including the roles and responsibilities for the district, regional and national response levels and stockpiling.

A public health emergency or event requires immediate response as stipulated in the IHR (2005) core capacity requirements. Detection, response and management of an outbreak is an essential and primary role of the district. The regional and national levels may provide support in form of human and logistical requirements once the outbreak escalates for the district to require external support.

Rapid and effective response to a public health emergency such as a suspected outbreak or other public health event not only call for an immediate response but is also one of the core capacities required by IHR 2005. Also, being prepared to detect and respond to such an event is an essential role of the district, regional and national levels.

Public health emergency preparedness and response structures should be composed of:

- Permanent functional Public Health Emergency Operations Centre (PHEOC) as a command

and control centre;

- Functional national and district task forces (NTFs and DTFS)

- NTF and DTF pillars

- Rapid Response Teams (RRTs)

Preparations for public health events include:

- Establishment of the Incident Management Team (IMT)

- Testing functionality of the Public Health Emergency Operating Centres (PHEOC) as a

command-and-control centre for coordination of public health emergencies or events at national level, and where applicable at regional levels.

- Development or review of policies, plans and procedures of operation; mapping of

available resources; stock piling; and conducting simulation exercises at various levels to test systems.

- Identifying and training key members of National Task Force (NTF) and Rapid

Response Teams (RRT) pillars

- Preparing or reviewing outbreak preparedness and response plan. The plan should

include the layout of the coordinating structure, the mapping of risks and updating regularly based on prevailing risk. The plan is overarching and should be complemented by a PHEOC plan and an event or Incident Action plans (IAP). The PHEOC plan guides

and coordinates the operations of the command and control center, outlining standard operating procedures of how each of the functional areas operate and work together; and the IAP is a plan developed to address specific emergency or event based on risk analysis and is always annexed to the Outbreak preparedness and response plan.

- Conduct simulation exercises e.g., table top or drills to test systems. If these steps are

carried out in advance of an event, the health system will be able to function promptly, effectively, and efficiently to reduce significantly attributable deaths, sickness or disabilities.

### 5.1 The Public Health Emergency Operations Centre (Command and Control

Centre) Whereas the Office of the Prime Minister (OPM) is responsible for the coordination of all disasters in the country, Public Health emergencies have been delegated to Ministry of Health.

Uganda established PHEOC that acts as a command-and-control centre to enhance coordination and oversee public health emergency preparedness and response activities. The PHEOC feeds into the National Emergency Coordination and Operation Centre (NECOC) to manage escalated events of national magnitude, and acts as a hub for coordination of information and resources to support incident or event management that involve health consequences and public health threats.

The PHEOC has developed the following essential elements to support preparation and response to emergencies:

(i) Plans, manuals and procedures for operations

(ii) Telecommunication technology and infrastructure to enable timely communication (iii) Information system to support informed decision making (iv) Trained human resource.

#### 5.1.1 Importance and Operations of the PHEOC

The PHEOC monitors events; facilitates and improves communication between public health and emergency management personnel, and facilitates coordination with multiple response partners. It is also for effective coordination of response to Public Health Events, resulting in minimising the impact of the event in the community. A PHEOC is a requirement of International Health Regulations (IHR 2005) and acts as a hub for preparedness activities

Operations of the PHEOC

- The PHEOC uses the Incident Management System (IMS) during public health

emergencies, as a standardized approach to manage and coordinate the response by providing a common hierarchy or operating picture for response by staff.

- In the context of IDSR, the IMS is represented by:

ii. Functional NTF iii. IMT RRT iv.

- All response structures should be established at national, regional, district, and community

levels depending on the escalation of the incident.

- During public health emergencies, the PHEOC is activated, and the IMT assemble, the

PHEOC then functions as a centre for decision-making, and coordination of information and resources for strategic management of the public health events and emergencies.

- When inactive, the PHEOC, reduces in size, respective members under various Incident

Management Team and their Subcommittees return to their respective working stations.

The PHEOC hosts the National Task Force (NTF) at national level or the regional/district task forces at the respective levels and coordinates decision making, information and resources for strategic management of public health events and emergencies.

During activation of the PHEOC, the NTF also activates the Incident Management System (IMS) for that event/ emergency. The operational structure of PHEOC can also be scaled up, which is essential for maintaining its effectiveness and it can be modular (i.e., can be partially or fully activated) according to situational needs. At the end of the event, the PHEOC is deactivated; reduces in size (de-escalation), members under various subcommittees / pillars return to their respective work stations.

When deactivated, the PHEOC usually liaises with respective sections or departments to continue with maintaining plans and procedures, conducting trainings and simulation exercises, IBS and EBS activities, as well as maintaining systematic database of the resources available, important contact details (phone numbers, names, emails and other addresses) of important government and non-government officials, international bodies and NGOs.

#### 5.1.2 Functions of the PHEOC

- Centre for decision-making, and coordination of information and resources for strategic

management of public health events and emergencies.

- Monitor events using various sources of data.

- Facilitate and improve communication between public health and emergency management

stakeholders.

- Facilitate coordination with multiple response partners.

- Maintaining plans and procedures.

- Conduct trainings and simulation exercises

- Carry out indicator and event-based surveillance activities.

- Maintain systematic database of resources available, including contact details of important

response personalities such as phone numbers, emails, names and addresses of important government and non-government officials, international bodies and NGOs.

- Serve as a resource center for preparedness and response activities.

- PHEOC should be operational 24 hours

#### 5.1.3 The Incident Management System (IMS)

The IMS is a standardized approach used to manage and coordinate the response by providing a common operating picture or hierarchy for response by staff. The IMS outlines the specific roles and responsibilities of responders during an event, while providing a common framework for government, the private sector, and non-governmental organizations to work seamlessly together. It comprises subject matter experts, analysts, logisticians, and support staff depending on the situation.

Most importantly, IMS should be functional at all levels of the healthcare system delivery. It is important once the IMS is activated during public health emergencies, the NTF regularly meet (at least daily or weekly) to facilitate coordination, communication and information sharing and put in place containment measures and at the same time facilitate deployment of the RRT.

Where the REOC is available, is supports the regional level with basic facilities that support direct coordination of preparedness and response to public health emergencies and facilitate real time communication between various stakeholders at their levels, in consultation with the PHEOC.

At district level, there is a similar coordination structure or mechanism in place that mirrors the National Task Force i.e. the District Task Force (DTF) and the associated subcommittees.

### 5.2 Establishing National and District Task Forces

National and district task forces, once established work together to plan and monitor the implementation of preparedness and response plans. The task forces develop and oversee the implementation of emergency preparedness strategies, response action plans, and procedures.

#### 5.2.1 The National Task Force (NTF)

The NTF is chaired by the Director General Health Services and provides oversight for emergency operations, preparedness and response interventions. The composition of the NTF is multi-sectoral and multi-disciplinary drawing on members from Ministry of Health, other MDAS, health development and implementing partners as well as private sector where applicable.

Functions of the National Task Force

- Develop or review a national emergency preparedness and response plans including

disease outbreaks and other emerging public health events or hazards

- Liaise with NECOC to ensure a multi-sectoral preparedness and response.

- Clearly stipulate, provide and clear deployment of surge capacity needs to respond to public

health emergency at district or national level.

- Map resources available both human (subject matter experts) and materials; logistics

including procurement, storage and distribution, finance etc.

- Periodically review and update the plan in response to any changes in technical, managerial

or epidemiological situation or any other identified risk or threat.

- Ensure coordination and integration of surveillance and response activities across all levels.

- Establish a community communications plan for sharing information with communities

before, during, and after any public health emergency.

- Coordinate community risk mapping activities within the district and ensure all reporting

sites are aware of the use of thresholds for reporting acute outbreaks or events.

- Prepare for, coordinate safe and result oriented research during public health emergencies

that capture incident-based information that can inform future similar incidents and policy.

- Identify and mobilize resources for emergency prevention and control including

procurement, storage and distribution of response and communication supplies.

- Develop mechanisms to monitor use of resources before, during and after the emergency

event.

- Ensure emergency material stockpiles at all levels are monitored, secured and regularly

updated.

- Coordinate training of community, health personnel in emergency preparedness and response.

- Ensure periodic organization of simulation exercises at all levels.

- Coordinate the post-emergency evaluation and disseminate findings to affected communities.

- Ensure provision of efficient administrative and financial management support including

human resource; cash flow by estimating, tracking and approving response-related expenditure; monitors and coordinates funding from all sources

- Ensure the PHEOC communication technology and information system is ready to support

any type of emergency.

- During public health emergencies, NTF will oversee the activation of the PHEOC and

ensure activation of similar coordination structure at district level. There will also be an activation of the IMS structure i.e., formation of subcommittees/ pillars and the deployment of the RRT.

- During non-public health emergencies periods, regular meetings should be held to

strengthen preparedness capacity (e.g., training health care workers (HCWs) Meetings of the NTF When there is no outbreak or any other public health event, NTF meets monthly to:

- Review the emergency preparedness and response plans

- Exchange information on risk monitoring with other relevant sectors. In some events,

human cases can be the first indication of a threat to others sectors.

- Review disease trends based on routine surveillance and update on preparedness steps.

- Review the level of preparedness at the beginning of each epidemic season.

- Monitor and maintain stocks of logistics for event investigation and response.

- Share conclusions and recommendations of these meetings with respective committees.

- Organize trainings and simulation exercises/drills to test the effectiveness and efficiency

of the EPR plans.

During an emergency or outbreak response, the NTF should:

- Hold meeting 6 hours within establishment of an outbreak or event.

- Conduct situational analysis and grade the level of the event

- Activate the PHEOC and similar coordinating structures at district level and deploy RRT

to conduct preliminary investigation and respond to the event.

Activate the NTF and DTF subcommittees

- Assess the need and request for support from higher level to identify and deploy surge

teams.

- Meet at daily at the beginning of an outbreak or event and weekly as the response

continues.

- Regularly review the outbreak response objectives and take action to improve outbreak

control actions as needed.

- Document and communicate outbreak response actions to the next higher level

- Conduct an after-action review to evaluate the response and inform future responses.

#### 5.2.2 The District Task Force (DTF)

Identification of District Task Force Members The DTF comprises multi-sectoral representatives from the public, implementing partners, nongovernmental organizations (NGO) and private sectors to match the functions listed above. For example, in the DTF, participants from the public sector may include:

Regional Police Commander Resident District Commissioner Officer In charge of Prisons Chief Administrative Officer (CAO) Director of Public Health and Environment District police commander (In cities) Local Council (V) Chairperson District environmental officer District Health Officer District health Inspector Medical Officers District Laboratory Focal Person District Veterinary Officer District education officer District community development officer District water officer Influential political, cultural & religious leaders District engineer Wildlife officer Faith Based Organizations Existing University representatives Immigration officer District Health Educator District Internal Security Officer NB: At national levels, an equivalent of the above should be used in order to ensure a more comprehensive multi-sectoral structure. Consider at National level, to include directors from

other key relevant ministries, heads of agencies, National Health Research Institutes (Human and Animal). The members from the IHR National Focal Point should always be part of the National Team Composition.

From non-governmental organizations with health care activities in the area, include representatives from:

- Community health programs and faith-based health facilities

- Red Cross, Red Crescent or similar agencies working in the area

- Local NGOs

- Civil society organizations

- UN organizations

From the private sector, involve participation from:

- A representative from private health facilities

- A representative from private laboratories

- Pharmacists or chemists

- Representatives of business community

- Research and training institutions

- Professional associations

NB: The DTF should be chaired by the Resident District Commissioner (RDC)

### 5.3 Establishing NTF and DTF Subcommittees

The Task Force subcommittees are formed by the NTF and DTF to oversee the day-to-day management of the public health emergencies at national and district level, respectively. They consist of technical and non-technical teams. Their role is to oversee daily management of the event/incident and feed the NTF for decision making.

They are subdivided into teams depending on their functions. See Table 5 below:

Enhance linkages with Community Based Surveillance Village Health Teams to Daily communication through situation report about the evolution of the outbreak Operational support including mobilization and management of resources Design, implement and evaluate control interventions Tracks expenditure, makes payments, and provides administrative services Description of tasks Coordinate all aspects of the operations response, planning and management ensure flow of data for early detection of public health events Ensures appropriate cash flow management, tracking material and human resources Assessment of the options for dealing with the event Responsible for staff wellbeing and security Keeping track of resources.

including: Selecting participating organizations and assigning responsibilities Managing information for public and news media Budgeting and Accounting Partner mapping Co-ordination of NTF/DTF subcommittees and overall liaison with partners Evaluate the situation (information gathering and analysis), Monitoring and maintenance of records.

Identify partner financial and technical resources 129 Chair: PS at National level Chairs of the all subcommittees Members (Experts, Organizations) District level: Chief Administrative Officer District: RDC Chair: DGHS Charge, Laboratorians) Budget Officers and Planning Officer or similar posts) Overall Chair: National: DGHS/Incident Manager Chair: An appointed Government official at the rank of Appointed members from EPR committee Experienced Health Administrators, Technical Staff (e.g., DHO or Medical Officer in Members:

The composition may include:

Logisticians.

Members:

Liaison officer Finance/Accounts Officers, Members:

Coordination sub- Coordination Partner Planning Sub committee Administration Finance and committee Table 5: Functions of Public Health Emergency Management Subcommittees

Verification of suspected cases/ alerts/ rumors in the community community and lower health facilities using the defined referral system Ensure appropriate medical care is being provided to patients Ensure proper collection, packaging, transport and testing of specimens from measures Ensure or make available guidelines and SOPs for case management and ambulances, wards, homes and environments with suspected/ probable/ Ensure logistics such as medication, PPEs, disinfectants, IPC materials etc are confirmed cases/ deaths of an infectious disease surveillance sub-committee Communicate test results to clinical service providers Conduct active case finding, case investigation, contact tracing and follow-up Ensure proper filling of case investigation, contact tracing and follow-up forms Ensure or make available all surveillance guidelines and data capture tools in secured for use isolation facilities and community deaths infection prevention and control in all health facilities epidemiological analysis and reports Conduct trainings on disease surveillance the health facilities and communities suspect/ probable cases/ deaths groups other health facilities Description of tasks

- Develop, adapt, update and ensure the use of the standard case definition

- Collect data from all treatment facilities (if available) and submit to the

- Strengthen isolation facilities and reinforce infection prevention and control

- Conduct risk assessment of health care workers

- Maintain a close linkage with burial, infection control and social mobilization

- Provide ambulance services for collection of suspected cases from the

- Ensure appropriate disinfection of all units handling patients including CTUs,

- Prepare and submit reports to the NTF/DTF

- Training and refreshers training of health workers in the isolation facility and

- Conduct routine public health data management and provide regular

- Prepare and submit reports to the NTF/DTF

- Conduct medically supervised safe and dignified burials of bodies from

130 Persons Biostatistician Health In-charges at POE Records Officer

- DLFP and Laboratory Team

- 

Clinical Medical Officers

- DSFP

Nurses Paramedical Staff

- Immigration Officers

- Lower Health Facility Surveillance Focal

Health, or the district, regional or referral hospital Chair: Physician or physician assistant from Ministry of Example of members at the district level:

Co-chair: Laboratory Focal Person Emergencies Members (Experts, Organizations) National: Commissioner Health Services, Department of District: Surveillance Officer Example of members at the district level:

Chair:

Integrated Epidemiology Surveillance and Public Health

- Pasted Environment Officer

- Physicians

POE and prevention & Case management Surveillance, Sub committee control and infection Laboratory Technical Operations Subcommittees: Chaired by Operations Lead (Coordinates all the activities of the Response

practices and behavior on prevailing public health risks/events activities on mobilizing communities Provide risk communications materials and plans Organize sensitization and mobilization of the communities Conduct rapid assessment to establish community knowledge, attitudes, Provide psychological and social support to suspected/probable/confirmed Prepare bereaved families/ communities for burials Relay concerns of the communities to the Task Force Provide wellness care and psychological support to the response team Serve as focal point for information to be released to the press and public cases; affected families and communities recovered Provide palliative care to the terminally ill Description of tasks

- Liaise with the different subcommittes, local leadership and NGOs involved in

- Prepare communities for reintegration of convalescent cases/ patients who have

- Prepare and submit reports to the NTF/DTF

- Prepare and submit reports to the NTF/DTF

131 Customs Officers Private Sector Representatives Cross-border partners Environmental Officer Local Partners Community Representatives Health Inspectors National Drug Authority Representative POE Security Officers District veterinary Officer District Communication Officer District community development officer Cultural Leaders Technical assistance from the Ministry of Health Inter Religious Council Representative District Education Officer District Health Officer Clinical Psychologists District Political leaders District Partners Religious Leaders Social workers Social Workers Mental Health clinicians Counselors National: Senior medical officer, Mental health Members (Experts, Organizations) District: Psychosocial Coordinator Example of District Members:

District: District Health Educator Health promotion and Communication National: Commissioner Health services, Department of Chair:

Chair Example of members at the district level:

- Counselors

- 

- Heath Educators

Mobilization and Sub committee Psychosocial Engagement Risk Social Community Communication, support

Conduct environmental health risk assessment for the outbreak Ensure vaccine safety through cold chain, monitor and report AEFIs Support investigations of food and water borne diseases handling, social mobilization etc.

Ensure provision of clean water Plan for sanitation improvement campaigns vaccination chain facilities, vaccine delivery and distribution, human resource needs, waste vaccines or therapeutic trials Engagement sub-committee to package appropriate messages relating to Compute the targeted population for vaccination campaigns Plan for improved hygiene practices including hand-washing, food hygiene and sanitation Identify high risk groups during the outbreak that should be targeted for Improved water management at household and community level Description of tasks

- Conduct macro- and micro-planning for all vaccination logistics including cold

- Conduct vaccination campaigns and post vaccination campaign validation

- Work with the Risk Communication, Social Mobilization and Community

- Prepare and submit reports to the NTF/DTF

- 

132 District Disaster Management Team Partners supporting psychosocial services Academia Representative of the Water Department Health Inspectors Partners supporting WASH e.g., UNICEF Technical assistance from the Ministry of Health Scientific and local research organization Vector Control Officers Health facility in-charges Community and District Leaders District Engineer Religious Leaders District Water Engineer Private Sector DSFP Partners supporting vaccination e.g., WHO, UNICEF Reproductive and Child health coordinators Surveillance focal person Pharmacists/Dispensers Laboratory Technicians Political Leaders ADHO (MCH) Uganda National Extended Program for Immunization Cold Chain Members Environmental Health Members at District Level:

Members at the District:

District: Health Inspector or Water engineer District: Child survival, EPI focal point, or National: Commissioner Health services, Department of National: Assistant Commissioner Health services, Members (Experts, Organizations)

- Environmental or Health Inspector

Chair:

(UNEPI)

- 

- 

Therapeutics Sanitation and Vaccination and Sub committee Hygiene Water, (WASH)

Conduct ecological studies to identify possible sources of zoonotic infections & response Authorize procurement of equipment and supplies Arrange for transport and communication systems Maintain adequate stocks of supplies and equipment Liaison with other agencies for logistic support Provide budgetary estimates for epidemic preparedness & response Provide technical guidance on handling to zoonoses Identify potential reservoirs of zoonotic pathogens Establish social, cultural and economic activities that predispose communities Prepare and submit reports to the NTF/DTF to infectious/zoonotic agents Description of tasks

- Provide accountability for all the resources used during epidemic preparedness

- Prepare and submit reports to the NTF/DTF

133 Technical officers from Ministry of Health PREDICT Vector Control Program Partners supporting logistics management Technical assistance from the Ministry of Health Records officer Cultural Leaders Academia Technical assistance from the Ministry of Health Medical/social anthropologists Wildlife wardens

- Veterinary/ animal health workers

- Partners supporting ecological studies e.g., CDC,

Members at District level:

National: Commissioner Health services, Pharmacy Department Members (Experts, Organizations) District: Pharmacist/ Logistics Officer ACHS (Veterinary Public Health) Chair:

Chair:

- 

- 

District: District Veterinary Officer Co-Chair District Level: District Environment

- Pharmacists or dispensers

officer/District Entomologist Members:

- Supplies/ Stores assistants

National:

Members:

Sub committee Ecological/ Logistics studies anthropological

### 5.4 Establishing Rapid Response Teams at all levels

A Rapid Response Team (RRT) is a technical, multi-sectoral, multi-disciplinary team that is readily available to be quickly mobilized and deployed to investigate and respond to emergencies and public health events. The RRT should be established at the district, and national levels.

Composition, roles and responsibilities of the RRT The RRT is expected to:

- Investigate reported outbreaks, verify diagnosis and other public health emergencies

including laboratory testing

- Collect samples from new patients and old ones where necessary (human, animals, food,

water)

- Conduct risk assessment and mapping to determine if the outbreak is a potential PHEIC

- Make a follow up by visiting and interviewing exposed individuals, establish an

operational case definition and work with community to find additional cases

- Assist in generating a line list of the cases, and perform descriptive analysis of data

(Person, Place and Time) to generate hypothesis including planning for a further analytical study

- Propose appropriate strategies and control measures including risk communications

activities.

- Prepare daily situation reports and detailed investigation reports to share with

NTF/DTF.

- Coordinate rapid response actions with national and local authorities, partners and other

agencies.

- Initiate the implementation of the proposed control measures including capacity

building.

- Conduct ongoing monitoring and evaluation of effectiveness of control measures

through continuous epidemiological analysis of the event.

- Contribute to ongoing preparedness assessments and the final evaluation of any

outbreak response.

- Support training and capacity building

- Meet daily during outbreaks, and quarterly when there is no outbreak.

- Participate in training simulation exercises, hot wash, and After-Action Reviews.

### 5.5 Risk assessment and mapping for outbreaks and other public health events

Risk assessment and mapping is used to identify vulnerabilities during preparedness to identify at-risk areas or populations, rank preparedness activities, and also to engage key policy and operational partners. The exercise should consider the identification and mapping across all levels. This process should be ongoing and updated periodically. This is useful when considering supplies, transport and other resource issues necessary for the response.

The WHO Strategic Tool for Prioritizing Risks (STAR) is used to assess a wide range of hazards including the health consequences of natural or human-induced emergencies, the health events covered under IHR (zoonosis, chemical, radio-nuclear, food safety) and also events occurring in neighbouring countries or regions. Refer to the Strategic Tool for Addressing Risk (STAR), WHO, DRAFT Version 3.3.1 (2017/07/27).

### 5.6 Resource Mapping

In preparing for outbreaks, conduct resource mapping to identify the available resources in every geographical area; promptly mobilize and distribute resources including material and human resources from all sectors, the district, development partners and NGOs.

### 5.7 Prepare an Emergency Preparedness and Response plan

Develop and update multi-hazard emergency preparedness and response plans for national, and district levels. The purpose of this plan is to strengthen the ability of the national and district levels to respond promptly to an outbreak public health event.

The plan should:

- Be based on risk assessments done in a multi-sectoral approach, and should specify the

resources available for emergency preparedness and response.

- Take into consideration diseases with epidemic potential in the country, region, district,

and neighbouring countries.

- Consider all other events (All hazard approach) and cover the IHR core capacity

requirements of ANNEX 1 A. Core capacity requirement for surveillance and response (IHR 2005).

- Consider Point of Entry activities for strengthening surveillance and response.

- Lay out concept of operations (CONOPS) including clear lines of accountability,

decision making authorities and processes, procedures for activation /deactivation, call for assistance etc.

- Consider medical counter measures (legal policy for donations).

- Describe the surge capacity to respond to PHEs of national, regional, and district

concern.

- Provide estimates of population at risk for epidemic-prone diseases and other PHES.

- Clearly indicate for each suspected outbreak which reference laboratory will be used for

confirmation.

- Provide estimates of needed quantities of medicines, vaccines, supplies, laboratory

reagents, and consumables for each epidemic-prone disease likely to occur.

- Identify training needs, and develop a training plan for all staff RRTS.

- Describe the procedures and plans to relocate or mobilize resources to support response.

- The plan should be tested before implementation and periodically through simulation

exercises.

This plan lays out concept of operations (CONOPS) including clear lines of accountability, decision making authorities and processes, procedures for activation /deactivation, call for assistance etc.

NB: The plan should be updated and tested through periodic simulation exercises before implementation. The plan should also include how to institutionalize health facility and community resilience building, and preventive interventions based on risk assessment and mapping.

Table 6: Elements/Sections of Emergency Preparedness and Response Plan Key sections of the emergency preparedness and response plan should include:

1.

Country profile and context 2.

Risk Mapping Situation analysis 3.

4.

Designated coordination structures, including committees Matrix of key stakeholders and partners supporting health activities [humans, animals (domestic, livestock and wildlife), environment, etc.) and roles and responsibilities 6.

Epidemiology and surveillance activities, including health information management Steps for carrying out a risk communication strategy including social mobilization 8.

Operational actions according to expected phases of the epidemic, including laboratory specimen collection, handling, transportation, processing and information management 9. Case management, including treatments (anti-viral, antimicrobial, decontamination, disinfection or others as indicated), infection prevention and control, isolation facilities, management of a mass casualty event 10.

Pre- and post-exposure prophylaxis treatment 11.

Immunization strategies 12.

Rapid containment activities and additional methods if rapid containment fails 13.

Psychosocial support for all affected, including community members and responders Risk communication and social mobilization 14.

15. Capacity building including required training, sensitization meetings and simulation 16. Logistics including supply lists 17. Environment, water and sanitation 18. Decontamination of patients and environment, including management of dead bodies 19. Monitoring of the outbreak or event 20. Resource mobilization and procedures to relocate or mobilize resources to support response 21. Monitoring and Evaluation for the plan 22. Costed budget

### 5.8 Set up stockpiles of medicines, vaccines, reagents and supplies

Outbreaks and other public health emergencies require the rapid mobilization of resources such as vaccines, medicines and laboratory supplies. Map out resources available so as to get the status of the stockpile with respect to pharmaceuticals, Personal Protective Equipment (PPEs) and other equipment to establish and preposition stockpiles of materials before an emergency occurs. Map commodities at global, national, regional and district level which can be tapped into during an outbreak. Deploy and preposition tracer commodities at regional nodes.

Ensure that, there are quick mechanisms of deploying supplies from central level to the subnational levels. Regularly and carefully monitor the contingency stock in order to avoid shortages and expiry of medicines, vaccines, reagents and supplies. Use the Electronic Emergency Logistics Management Information System (eELMIS) to order, acquire, and monitor usage of emergency commodities.

A suggested list of contingency medicines and supplies is available in Annex 5A.

#### 5.8.1 Conduct stock management for outbreak response

Maintain a reliable supply of supplies and materials for responding to an outbreak or public health event. Use an inventory checklist such as the one in Annex 5B to assess which supplies are already available for use during a response activity. If the supplies are already available, determine if they can be set aside for use during a response. If they are not available, establish if they can be purchased or requested through the Permanent Secretary and DGHS of the Ministry of Health.

Periodically, for example, every 4 months, make sure the supplies are dry, clean, not expired, not deteriorated and ready to be used and mechanisms to assess them are readily available.

At a minimum, carry out the following tasks (relevant to each level) to forecast necessary supplies, inventory of what is available, and plan to procure essential items for use in response.

i. List all required items for carrying out surveillance, laboratory and response necessary for detecting and responding to priority diseases, conditions and events. Consider:

- Availability of case definition posters, registers, line lists, templates, reporting

forms, case investigation forms, laboratory investigation forms, situation report template as well as required reporting forms/referral forms.

- Availability of laboratory, and diagnostic reagents and supplies, as well as test kits

etc.

- Specimen collection, storage and transport kits including Triple Package

containers.

- Availability of various guidelines for surveillance and response of specific

diseases including laboratory SOPs

- Availability of case management guidelines, medicines, supplies and other field

intervention materials, including PPEs ii. Make an inventory and note the quantity of each item that is available.

iii. Complete and regularly update a stock balance sheet for each item.

iv. Observe expiry dates and practice best logistical practices for packing, shipping, storing and disposing of supplies and materials.

v. Establish a critical or minimum quantity for each item that would need to be on hand for an investigation or response activity. Consider logistic and epidemiologic factors in establishing minimum quantities.

vi. Monitor the stock balances against the critical quantity established.

vii. Report regularly on the IDSR stock situation. Use Annex 5C for an example.

#### 5.8.2 Update human resource available for response as well as other logistics support

for response of public health events at all levels

- Update roster of public health emergency rapid response teams and experts annually

- Map laboratories that have sufficient quality control standards and meet the required

standards to ensure reliable results, including availability of SOPs which defines biosafety procedures for collecting, packaging, labelling, shipping, manipulating and discarding samples.

- Map also the specimen referral/transportation network including schedules, and if not

create the mechanism to ensure prompt referral of specimen is done once an outbreak is suspected

- Map and update isolation wards for the management of patients with highly infectious

diseases including contact details, location, bed capacity, level of expertise, and type of patients/diseases that can be treated

- Develop a patient referral system for highly infectious diseases, including transportation

mechanisms

- Take stock of risk communication SOPs at the different levels.

For further reading, refer to 32-36

### Annexes to SECTION 5

Annex SA: Essential stock items for responding to outbreaks

#### Annex 5B: Stock situation report

#### Annex 5C: IDSR stock item transaction and balance sheet

#### Annex 5D:

Assignments for the committee to develop the Epidemic Preparedness and Response plan

#### Annex 54: Essential stock items for responding to outbreaks

Essential Stock items for Responding to Outbreaks Disinfectants, Equipm Vaccines Medicines Insecticides and Supplies ent Rodenticides Meningitis vaccines AC, ACW135/ A, C, Y, W135, Meningococcal Conjugate PPE Benzyl Penicillin Auto-disable syringes Disinfectants Vaccine (MACV), Meningitis vaccines Conjugated Bed nets 2% Chlorine Ceftriaxone Cholera vaccines Body Bags Personal Protective Bleach Buckets Tetanus antitoxin Ciprofloxacin Calcium Laboratory supplies Yellow fever vaccines Diazepam Camping kits hypochlorite (see Annex 4B) Nasogastric tubes Rabies vaccine and Candles Cresol Doxycycline

### 2.7 mm OD, 38

immunoglobulin cm Sodium Medicines for Nasogastric tubes 5.3 Other vaccines e.g., Flu Computer vaccine supportive care mm OD, 50 cm hypochlorite Containers Pesticides Erythromycin Needles and syringes Intravenous giving sets Cook-ware Nalidixic acid Cypermethrin different sizes) Diesel Malathion Tea spoons Oily chloramphenicol Sprayers (pump and Permethrin Front lamp Oral rehydration salts fogger) GPS Receiver Paracetamol Rodenticides Kerosene lamp Penicillin V Brodifacom Bromadion Lab: See annex Rehydration fluids:

4b Ribavirin Lamps Maps Ringer lactate Paraffin and Streptomycin Tetracycline Phones Trimethoprim- Plastic sheets sulfamethoxazole Oseltamivir Power generator Radio NB: Detailed laboratory list also available in Annex 4B

decisions and Observations, recommendations Stock Balance issued Quantity Total Stock Quantity received District: _ Stock Reporting period:

Opening Item Description Reporting site name:

Year:

Surveillance and Emergency Preparedness and Response: Stock Situation Report Report day (day/mm/yyyy):

Title, Name and function of Responsible Officer:

#### Annex 5C: IDSR stock item transaction and balance sheet

#### Annex 5B: Stock situation report

Country

Remarks Inventory Observations/ and function) Signature (Name Stock Balance Destination Beneficiary Quantity issued Donor eceived Juantit (Day/Month/Year) Transaction Date (USD) operations cost 141 nipment e ampe Allotment Airway bill Location in store IDSR Stock Item Transaction and Balance Sheet Batch number Manufacturer Expiry date Use one sheet by stock item, and update the sheet every time any transaction takes place of purchase) Presentation (Unit Item Description Warehouse Name Laboratory or

#### Annex 5D: Assignments for the committee to develop the EPR plan

Task Assigned member(s) from the committee Designated coordination structures, including committees Organizational framework of key stakeholders and partners supporting health activities (human, animal, environment, etc.) and roles and responsibilities Epidemiology and surveillance activities, including health information management Define roles and responsibilities of members during an outbreak Develop the risk mapping Steps for carrying out a risk communication strategy including social mobilization Operational actions according to expected phases of the epidemic Laboratory specimen collection, handling, transportation, processing and information management Case management, including treatments (anti-viral, antimicrobial, decontamination, disinfection or others as indicated), infection control, isolation facilities, management of a mass casualty event Pre- and post-exposure prophylaxis treatment Immunization strategies Rapid containment activities and additional methods if rapid containment fails Psychosocial support for all affected, including community members and responders Risk communication and social mobilization Capacity building including required training, sensitization meetings and simulation Logistics including supply lists Environment, water and sanitation Decontamination of patients and environment, including management of dead bodies Monitoring of the outbreak or event Resource mobilization and procedures to relocate or mobilize resources to support response

Annex SE: Tool for assessment of surveillance and response at the district level Districts can use the assessment tool developed by WHO/AFRO to assess their national surveillance, epidemic preparedness and response systems and to identify where improvements are needed. The assessment provides results that can be used to solve problems with resources, the quality and timeliness of surveillance data, and how the information is used. The national strategic plan could also be used as reference while preparing a district specific action plan.

The integrated disease surveillance and response (IDSR) is not proposing establishment of a new system, but is providing guidance on how to prepare to conduct surveillance and response activities. However, if the district has the resources and skills to assess the district to document the situation of surveillance and response activities within the district or wishes to update the district profile, it may use the checklist below after adapting it to the local context. This tool could help to identify where districts can identify activities to improve their performance and capacity for disease surveillance and response.

Case and event identification:

1. Determine availability and knowledge of standard case definitions for reporting suspected priority diseases and conditions including events of public health concern.

2. Define the sources of information about health events in the district, including points of contact the community has with health services. For example, list the following sources on a list of district reporting sites:

a. Health facilities and hospitals b. Point of Entry c. Community health workers d. Birth attendants e. Traditional healers f. Rural community leaders who have knowledge of health events in the community (for example, the village elders, traditional healer, school teacher, leaders of faith- based communities, etc.) g. Public health officers h. Private sector practitioners i. Public safety officers such as fire, rescue or police departments j. Animal health and veterinary structures and services k. Industry, food safety and environmental health laboratories 1. Mass media, web sites and health news search applications m. Others including NGOs Identify surveillance focal points for each source of information. Identify and specify the opportunities for community involvement in surveillance of health events.

Reporting 1. Specify the priority events, diseases and conditions for surveillance within the district and those directed by national policy. List diseases that are:

a. Epidemic-prone b. Diseases targeted for eradication and elimination c. Other diseases of public health importance including non-communicable diseases 2. For each priority event, disease or condition, review the minimum data element that health facilities and other sources should report. State when it should be reported, to whom and how. State the information that should be reported from in-patient sources and outpatient sources. For example, a minimum requirement would be to report all cases and deaths for the selected diseases and conditions a. State the diseases or conditions that require immediate reporting and communicate the list to health facilities in the district.

b. Define the means for reporting data to the district (by phone, by form, by voice).

If there is electronic reporting, do all facilities have access to computers and modems?

c. Define how often the required data should be reported.

3. Define the data management tools available in the district and how they should be used in an integrated system a. Case-based surveillance reporting forms b. Lab-specimen-based surveillance reporting forms c. Line lists for use in outbreaks d. Tables for recording summary totals e. Routine weekly reporting forms f.

Routine monthly reporting forms g. Routine quarterly reporting forms h. Graphs for time analysis of data i. Maps for place analysis of data j. Charts for person analysis of data 4. Periodically update the availability of relevant supplies at each reporting site for conducting surveillance. (Note: If a reporting site has the capacity for electronic reporting, there should be an electronic format that is compatible with the methods used at the district, region and national levels. (If electronic reporting is not available, ensure that the focal points who are required to manage data have a reliable supply of data collection forms, paper, coloured pencils, graph paper, and log books).

Data analysis 1. Define the data management requirement for each reporting site. For example, develop and disseminate the procedures including deadlines so that reporting sites know that they

must report each reporting period (e.g., month).

a. Tally, compile and report summary totals b. Check data quality and eventually clean them c. Analyse data: produce weekly/monthly/Quarterly/Annual summaries in tables, graphs or maps d. Provide some interpretation to the next higher level.

e. Submit data to the next level (SMS, e-mail, fax/case-based forms, and line-list).

f. File and secure back-up copies of the data Provide feedback to the community and to all relevant Reporting Sites 2. Decide if current forms address the priorities of integrated disease surveillance and response. For example, do current forms provide the information necessary for detecting problems and signalling a response to the priority integrated disease surveillance diseases?

3. Gather and present relevant data about your district that can be used to advocate for additional resources for improving surveillance and response activities. (Example:

Health workers are able to document an increase in malaria cases; they know that an effective response is available with insecticide-treated bed nets. The district surveillance officer used data to show the expected reduction in malaria cases if some of the community's bed net cost could be supported by local businesses).

Investigation and confirmation of suspected cases, outbreaks or events:

Describe the laboratory referral network for confirming priority diseases and conditions in the district. For example, list the following:

a. Public, private or NGO district facilities with reliable laboratory services for confirming priority diseases.

b. Prevention, control or special surveillance activities in the district with laboratory access (for example, any HIV sentinel surveillance sites in the district) Preparation for response and Response to outbreaks and other public health events 1. Update the policies of the district rapid epidemic response team so that assessing preparedness is a routine agenda item of the team. Specify and disseminate schedules a. Meeting to routinely assess preparedness for response and discuss current problems or activities b. Outbreak response meetings 2. For each priority event, disease or condition selected, state the available public response activity.

3. For each disease or condition that the district can respond to, specify the target, alert threshold or analysis results that would trigger an action.

Communication and Feedback

1. Define methods for informing and supporting health workers in the implementation of integrated disease surveillance. For example:

a. List the current opportunities for training health workers in surveillance, response or data management in the district.

b. Coordinate training opportunities between disease programs that take advantage of overlapping skills between programs such as supervision, report writing, budgeting, data analysis, and using data to set priorities.

c. Define the training needs for each category of health workers for either initial training in surveillance and response skills or refresher training in how to integrate surveillance activities.

2. Describe how communication about surveillance and response takes place between the district and the surveillance focal points. Include methods such as monthly meetings, newsletters, telephone calls and so on. Update the description periodically.

3. Review and update feedback procedures and methods between the district, health facilities and community as well as between the district and higher levels. Specify the feedback methods and update as necessary:

a. Bulletins summarizing data reported by health facilities to the district b. Periodic meetings to discuss public health problems and recent activities c. Supervisory visits 4. Describe the communication links between the community and health facilities with the epidemic management committee that can be activated during an outbreak and for routine activities.

Evaluation and improvement of the surveillance system 1. Decide if additional indicators will be evaluated and plan how to monitor and evaluate timeliness and completeness of reporting.

2. State three or more objectives you would like to achieve for improving surveillance in your district over the next year.

SECTION 6 RESPOND TO OUTBREAKS AND OTHER PUBLIC HEALTH EVENTS

## Section 6: RESPOND TO OUTBREAKS AND OTHER PUBLIC HEALTH EVENTS

### 6.0 Respond to outbreaks and other public health events

The goal of disease surveillance is to use data for public health action. Response to outbreaks and other public health events is one such public health action.

This section describes steps for declaring an outbreak and activating the response structures, conducting a public health response and provides general directions for immediate response actions for priority diseases, conditions and events.

When an outbreak, acute public health event or condition is detected, an investigation should take place as described in section 4 and the results should guide the response. Successful responses are carried out with community involvement through community education and behaviour change.

Effective coordination of response activities is critical, as many actors/stakeholders will be involved.

It is essential that all actors/stakeholders be identified in advance including their areas of support, roles and responsibilities. The PHEOC ensures such coordination, command and control at national level, once activated by the NTF and the DTF at district level (see Section 5).

### 6.1 Declaring, notifying an Outbreak and Activating the Response Structures

Once an epidemic threshold of a priority disease is exceeded, the NTF activates the PHEOC for national coordination including relevant parties the affected and neighbouring districts. The NTF will support the IHR-NFP to assess for a potential PHEIC using the IHR (2005) decision instrument and notifies WHO through the Director General Health Services (DGHS). The Minister of Health will decide to declare the outbreak based on this risk assessment.

### 6.2 Mobilize Rapid Response Teams (RRT) for Immediate Action

The composition, roles and responsibilities of RRT are detailed in Section 5 of these guidelines.

### 6.3 The District Task Force (DTF)

Once an outbreak or event is confirmed, the DTF convenes a meeting to assess and implement the response. The following further steps should take place:

- Develop a District Rapid Response plan

- Request for funds to respond to the outbreak or event based on the response plan

- Assign clear responsibilities for specific response activities to guide the DRRT

- Provide orientation or training and adequate relevant supplies for the DRRT and affected health

facilities or communities

- Review existing resources as defined in the response plan and determine what additional

resources are required

- Request emergency stock of Infection Prevention and Control supplies, required

medicines/vaccines and other medical supplies such as specimen containers

- Provide laboratory or diagnostic support for confirmation of pathogens responsible for the

epidemic. If the district does not have the capacity to safely collect, package and ship the specimen, contact the PHEOC for assistance.

- Mobilize logistical support (travel of RRT, accommodation, communication, other essential

equipment)

- If supplies are not available locally:

Request the PHEOC at national or regional level for additional supplies Collaborate with other implementing partners, non-governmental organizations or private pharmacies/laboratories in your area

- Identity practical low-cost substitutes

- Ensure clear lines of communication and appoint a spokesperson (the RDC at district level)

### 6.4 Select and Implement Appropriate Public Health Response Activities

Review investigation results and recommendations of the RRT to select appropriate response activities to contain the confirmed outbreak or public health event. The success of the response relies on implementing the response activities as seen in Section 11. Others include the following:

#### 6.4.1 Build the Capacity of Response Staff

Conduct pre-deployment orientation and capacity building for response staff based on the role of each member of the response team. Give clear and concise directions to health workers and other staff taking part in the response. Provide them with appropriate PPE and IPC supplies, necessary vaccinations and equipment.

Orient the DTF, DRRT, and other health and non-health personnel on outbreak management based on the current outbreak. Provide on-the-job training and closely mentor the health workers, and monitor participant performance and review skills as needed.

#### 6.4.2 Strengthen Case Management and Infection Prevention and Control (IPC) measures

- Take steps to support improved clinical practices in the district as recommended in Annex

6A and Section 11.0 while treating cases of different diseases during an outbreak.

- Train and equip health workers at the district level to undertake the following measures:

- Ensure that clinicians receive results of laboratory confirmation where necessary

- Ensure health workers record all patients in a standardized line list

- In an epidemic with large number of cases, ask Facility In-charges to designate an area

to accommodate a large number of patients at their health facility

- Provide Standard Operating Procedures (SOP) and IPC guidelines (See Annex 6G):

- Ensure the necessary treatment guidelines, medicines and supplies are available

- Review the SOPs for patient referral

- Link cases and affected staff to psychosocial support teams

- Ensure that there is a protocol for management of responders that may get infected and

affected by the outbreak

#### 6.4.3 Enhance Surveillance During the Response

- Search for additional cases meeting the outbreak case definition and evacuate them to treatment

centres. Where institutional isolation is not feasible, isolate and manage the patients at home.

Ensure they have access to consistent/adequate food, water, and non-food items (i.e., soap, chlorine, firewood, medicines, sanitary pads, etc.)

- Ensure timely provision of laboratory information to the team

- Update the line list, analyse data by time (epi-curve), person (age and sex) and place (mapping

of cases)

- Report regularly and update on the progress of the epidemic

- Actively trace and follow up contacts (See Section 4 on contact tracing)

- Monitor the effectiveness of the outbreak response activities

#### 6.4.4 Enhance Surveillance with Neighbouring and Cross Border Districts

During response, work closely with neighbouring districts to ensure the outbreak does not spill to another district. For border districts, maintain contact with the neighbouring country using official channels. Share information in real time and plan for joint surveillance and response activities through:

- Established cross-border disease surveillance and response zones/committees. These are platforms

for sharing surveillance data and other information related to the outbreak.

- Co-opting experts and other members depending on the disease profile and the disease

outbreak/public health emergency they are handling.

- Activating regional meetings for high risk districts

#### 6.4.5 Engage Community During Response

Community Based Surveillance focal persons (see Introduction section, Annex D) are usually the first responders and take steps to make the situation as safe as possible for the community. Some of the immediate actions they can do include the following:

- Engaging and informing community leaders on the situation and mitigation actions

- Providing first aid and call or send for medical help

- Keeping people away from the 'risk' area

- Isolating anyone with a potentially infectious discase paying particular attention to cultural

sensitivities

- Quarantining animals, market closures, etc.

- Supporting community education including specific actions to protect the community

- Engage in IPC and hygiene promotion in coordination with any efforts at strengthening the

availability of materials/infrastructure for IPC and hygiene

- Identify locally effective channels for delivery of the information to the community

- Organize door-to-door campaigns utilizing trusted individuals to reach every household within

the catchment area to promote the prevention of the spread of the public health event

- Promote self-reporting and health-seeking behaviour among people who have had contact with

a suspect case or a public health event It is important to engage community members as stakeholders and problem solvers, not as merely beneficiaries.

#### 6.4.6 Inform and Educate the Community

Risk communication is an essential element of managing public health events. It creates trust between responders and the community by communicating advice and guidance to manage risk.

NB: See section 7 for more guidance. Sample community education messages are in Annex 7C.

#### 6.4.7 Conduct Mass Vaccination Campaigns

For Vaccine Preventable Diseases the MoH may conduct a supplemental mass vaccination campaign. Annex 6C gives a worksheet useful for "Planning a mass vaccination campaign".

Annex 6D gives details for "estimating vaccine supplies for vaccination activities". Annex 6F describes recommended vaccination practices during vaccination campaigns.

Other control measures include improving food handling practices, reducing exposure to infectious or environmental hazards and safe and dignified burial and handling of dead bodies.

#### 6.4.813 Ensure Appropriate and Adequate Logistics and Supplies

Monitor the effectiveness of the logistics system and delivery of essential supplies and materials using a logistics plan deployed by a dedicated logistics management team for transport, reliable communication equipment and any other additional support.

### 6.5 Regular Situation Reports and documenting the response

Reporting and documentation during the outbreak (Annex 6F) is a core deliverable of the district biostatistician. SITREPs provide information such as;

- Details on the response activities and effectiveness of the response like CFR

- Dates, places, and individuals' roles in the response; person, place and time analyses

- Any changes/updates since the last report implemented by the DTF

- Operational challenges, gaps and recommended changes to improve outbreak response

The situation reports are important for evaluating the response and developing a final report at the end of the outbreak. The biostatistician should therefore ensure that they collect and store all documents including meeting minutes, activity reports and other relevant documents for key outbreak response milestones (see Annex 61). This may include preparing a coversheet listing all the above documents as essential sources of data for evaluating the response.

For further reading, refer to 13,19,28,29,37-40

### Annexes to SECTION 6

#### Annex 6A: Treat cases during an outbreak

#### Annex 6B:

Preparing disinfectant solutions from ordinary household products

#### Annex 6C: Planning an emergency immunization campaign

#### Annex 6D: Estimating vaccine supplies for immunization activities

Recommended immunization practices

#### Annex 6E:

Outbreak communication

#### Annex 6F:

#### Annex 6G:

Key IPC Measures

- Donning and Doffing

- Guide for Hand washing

- Guide for CTC Cholera establishment

#### Annex 6H: Response to chemical and radio-nuclear events

#### Annex 61: Documenting key outbreak response milestones

#### Annex 6A: Treat Cases During an Outbreak

Use appropriate drugs and treatments for managing cases during an outbreak. Below are treatment recommendations for use in an outbreak situation for:

1. Cholera 2. Bacterial meningitis.

1. Treat cholera in an outbreak situation Source: WHO guidelines for management of the patient with cholera, WHO/CDD/SER/91.15 Assess the patient for signs of dehydration. See assessment guide below.

2.

Give fluids according to the appropriate treatment plan (see next page).

Collect a stool specimen from the first 5 suspected cholera patients seen.

Give an oral antibiotic to patients with severe dehydration.

Assess the patient for signs of dehydration Look at patient's general condition: Is the patient lethargic, restless and irritable or unconscious?

Are the patient's eyes sunken?

Offer the patient fluid. Is the patient: not able to drink, or drinking poorly, drinking eagerly, thirsty?

Pinch the skin of the abdomen. Does it go back very slowly (longer than 2 seconds?) or slowly?

Decide if the patient has severe, some or no signs of dehydration and give extra fluid according to the treatment plan If two of the following signs are present:

lethargic or unconscious SEVERE DEHYDRATION* sunken eyes

- .

not able to drink or drinking poorly Give fluid for severe dehydration (Plan C) skin pinch goes back very slowly *In adults and children older than 5 years, other signs for severe dehydration are "absent radial pulse" and "low blood pressure".

If two of the following signs are present:

SOME DEHYDRATION restless, irritable sunken eyes Give fluid according to "for some dehydration" (Plan drinks eagerly, thirsty skin pinch goes back slowly If there are not enough signs to classify NO DEHYDRATION as some or severe dehydration Give fluid and food to treat diarrhea at home.

(Plan A)

Give antibiotics recommended for treatment of severely dehydrated cholera patients Adults Children Antibiotic Doxycycline: one single dose 300 mg 500 mg 12.5 mg per kg Tetracycline: 4 times per day for 3 days TMP 5mg/kg and TMP 160 mg and SMX 800 mg Trimethoprim-sulfamethoxazole (TMP-SMX) 2 times a day for 3 days SMX 25mg/kg2

### 1.25 mg per kg

Furazolidone: 4 times per day for 3 days 100 mg Erythromycin* adults: 4 times per day for 3 days 10 mg per kg children: 3 times per day for 3 days 250 mg

- If the patient vomits while taking fluid, wait 10 minutes. Then allow the patient to resume

feeding, but more slowly.

- Continue monitoring the patient and replacing fluid until the diarrhea stops.

- When the patient is ready to leave the facility, counsel the patient on treating diarrhea at

home.

- Refer to IMCI guidelines for treating children under 5 years of age and to national guidelines

for further information on treating acute watery diarrhea and confirmed cholera.

- Tetracycline should be avoided in children under 8 years of age and pregnant women.

Plan A: Treat diarrhea at home If patients show no signs of dehydration when they were first assessed, they may be treated at home.

Give a 2-day supply of ORS and explain how to take the ORS solution according to the following schedule: Advice the mother to give extra fluid; give zinc supplements and continue feeding.

2 TMP-SMX is WHO's antibiotic of choice for children. Tetracycline is equally effective. However, in some countries, it is not available for paediatric use.

3 Furazolidone is WHO's antibiotic of choice for pregnant women.

Amount of solution after Provide enough ORS packets Age each loose stool for preparing:

50 to 100 ml after each loose stool 500 ml per day Up to 2 years 100 to 200 ml after each loose stool 1000 ml per day 2 years up to 10 years As much as the patient wants 10 years or more 2000 ml per day Plan B: Treat some dehydration with ORS In the clinic, give the recommended amount of ORS over a 4-hour period. Determine the amount according to the patient's weight. Use the patient's age only when the weight is not known.

Determine the amount of ORS to give during the first 4 hours ACE 12 months up or to Up to 4 5 years up to 15 years and 4 months up 2 years up tol2 months more months WEICHT 14 years to 5 years 2 years Weight 12 - < 19 kg < 6 kg 10 - < 12 kg 30 kg and more 19 - 30 kg 6 - < 10 kg in kg this Give 2200-4000 ml 700- 900 ml 400 - 700 ml 200 - 400 ml 1400-2200 ml 900 -400 ml amount ofORS

- If the patient wants more ORS than shown, give more.

- For infants below 6 months who are not breast-fed, also give 100-200 ml of clean water

during this period.

- Give frequent small sips from a cup.

- If the patient vomits, wait 10 minutes. Then continue giving fluids, but more slowly.

- For infants who are breast-feeding, continue breast-feeding whenever the infant wants.

- Assess patients every 1-2 hours to make sure they are taking ORS adequately and to monitor

fluid loss. Completely reassess the patient's dehydration status after 4 hours, and follow the appropriate treatment plan for the patient's dehydration cl a s s i fic a t i on.

Plan C: Treat severe dehydration quickly Start intravenous fluids immediately. If the patient is a child and can drink, give ORS by mouth while the drip is set up. Give 100 ml per kg of Ringer's Lactate Solution divided as follows:

For giving IV fluids:

Then:

First:

For adults (and patients 1 year and Then, give 70 ml the per kg during First, give 30 ml/kg as rapidly as older), give 100 ml per kg IV within next 2 ½ hours possible within 30 minutes 3 hours as follows:

For patients less than 1 year, give Then, give 70 ml per kg in the First, give 30 ml per kg in 100 ml per kg IV in 6 hours as next 5 hours the first hour* follows:

* Repeat once if radial pulse is still very weak or not detectable after the first 30 ml per kg is given.

2.

Reassess the patient after the first 30 ml per kg, and then every 1 to 2 hours. If hydration status is not improving, give the IV drip more rapidly.

3.

Also give ORS (about 5 ml per kg per hour) as soon as the patient can drink. This is usually after 3 to 4 hours for infants and after 1 to 2 hours for patients older than one year.

4.

Reassess the patient after 6hrs (for infants) or 3hrs (for one year and older). Classify dehydration. Choose the appropriate plan (Plan A, Plan B, Plan C) to continue treatment.

Give antibiotics recommended for treatment of severely dehydrated cholera patients. See the schedule on the next page.

6.

Give patients information about home care before they leave the health facility.

- If the patient vomits while taking ORS, wait 10 minutes and then continue giving

fluids more slowly.

Continue breast-feeding of infants and young children.

Return for treatment if patient develops increased number of watery stools, eating or drinking poorly, marked thirst, repeated vomiting, fever or blood in the stool 2. Give appropriate antibiotic for bacterial meningitis cases during an outbreak Source: Control of epidemic-prone meningococcal disease, WHO practical guidelines, 2nd edition 1998, WHO/EMC/BAC/98.3 1. Admit patient to a health facility for diagnosis and treatment.

2.

Start an antibiotic immediately. Intra-muscular injectable oily chloramphenicol is best choice during an epidemic. It is very effective and a single dose is usually effective. If injectable treatment is not possible, give oral amoxicillin or cotrimoxazole or treat with an antimicrobial recommended by national treatment guidelines for meningitis.

3. Patient isolation is not necessary. Provide good supportive care and simplify case management.

Give a single dose of oily chloramphenicol INTRAMUSCULAR OILY CHLORAMPHENICOL 100 mg per kg in a single dose, If the patient has not improved, give a second dose 24 to 48 hours later.

ACE Dose in grams Dose in millilitres 12 ml 3.0 g Adult: age 15 years and older Child: 10 to 14 years 2.5 g 10 ml 8 ml 6 to 9 years 2.0 g 1.5 g 6 ml 3 to 5 years 1.0 g 4 ml 1 to 2 years 2 to 11 months 0.5 g 2 ml 1 ml 1 to 8 weeks 0.25 g Other recommended antibiotics to treat meningitis Duration of Route treatment Dose for adults Dose for children Agent 4 days IV 3-4 MU daily, every 4-6 hours Penicillin G 400 000 Units/ kg 4 days 250 mg per kg Ampicillin or Amoxicillin IV 2-3 g daily every 6 hours 2-3 g every 6 hours 250 mg per kg 4 davs Moxicillin Oral IV Chloramphenicol 4 days 1 g every 8-12 hours 100 mg per kg Cefotaxime IV 4 days 2 g every 6 hours 250 mg per kg Ceftriaxone IV 1-2 g over 12-24 hours 4 days 50-80 mg per kg Ceftriaxone IM 1-2 days 1-2 g single dose 50-80 mg per kg

#### Annex 6B: Preparing Disinfectant Solutions from Ordinary Household Products

During a response to an outbreak of any disease transmitted through direct contact with infectious body fluids (blood, urine, stool, semen, and sputum for example), an inexpensive system can be set up using ordinary household bleach.

The following table describes how to make 1:10 and 1:100 chlorine solutions from household bleach and other chlorine products.

Use this chlorine To make a 1:10 solution for To make a 1:100 solution for disinfecting:

disinfecting:

product Gloved hands Excreta Bare hands and skin Cadavers Floors Spills of infectious body Clothing Fluids Equipment Bedding Household 100 ml per 10 litr6.5 Document 1 litre bleach per 10 bleach 5% litres of water the Response es of water, or 1 active litre of 1:10 bleach solution per chlorine 9 litres of water 7 grams or ½ tablespoon Calcium hypochlorite 7 grams or ½ tablespoon per10 litres of water per 1 litre of water powder or granules 70% Household 16 grams or 1 tablespoon per 1 16 grams or 1 tablespoon per 10 litre of water bleach 30% litres of water active To disinfect clothing:

- Promptly and thoroughly disinfect patient's personal articles and immediate

environment using one of the following disinfectants:

Chlorinated lime powder 1% chlorine solution 1% to 2% phenol solution

- Promptly and thoroughly disinfect patient's clothing:

Wash clothes with soap and water Boil or soak in disinfectant solution Sun dry Wash utensils with boiling water or disinfectant solution Do not wash contaminated articles in rivers or ponds that might be sources of drinking water, or near wells

Using Market/Shelf liquid bleach to prepare the desired % of chlorine % Chlorine in bleach (Market/Shelf) minus 1 = Parts of water for each part of bleach % Chlorine desired Example: To make a 2% chlorine solution from 5% bleach, minus 1 = (2.5) minus 1 =1.5 parts water for each part of bleach Thus, to make 2% chlorine solution add 1 part bleach to 1.5 parts water

#### Annex 6C: Planning an emergency immunization activity

1. Review with health workers the need to plan vaccination campaigns and specify the target population for the immunization activity 2. Estimate the necessary amounts of vaccine, diluent, and immunization supplies such as sterile syringes and sterile needles, cold boxes, vaccine carriers and safety boxes Coordinate with UNEPI, WHO country office and UNICEF offices to arrange for provision of necessary vaccines and supplies ii.

A list of pre-qualified WHO vaccines is available at:

http://www.who.int/immunization_standards/vaccine_quality/PQ_vaccine_list_en/en/.

If a country has already an ICC, agree on the type of vaccine to be given, who to give and the methodology to be used İii.

Contact the national level to request for vaccines. If a national reserve stock is not available, UNEPI program manager will request for an emergency supply from WHO.

3. Choose the immunization sites and inform the communities.

i.Coordinate with the District EPI Focal Person and or DSFP to identify sites for conducting the immunization activity.

ii.Identify the facilities that can participate in the activity iii. Identify a mobile immunization team, if needed.

iv.Determine if there are any hard-to-reach areas, e.g. a transient workers' camp. Identify a mobile immunization team to reach these areas.

v.Contact the facilities and schedule the immunization dates.

vi.Make sure there is enough capacity to store extra amounts of the vaccine during storage and transportation to the immunization site.

4. Conduct a comprehensive micro planning for the campaign. A micro plan is the operational plan for a campaign at the national or district level. Ensure the plan has at least the following:

i.

Estimate of the number of vaccination teams required and their composition including roles and responsibility of team members, as well as number of supervisors and monitors ii.

List of supervisors and their contact numbers iii.

Travel plan for teams and supervisors including transportation requirements iv.

Map the coordination with other partners and regions/districts local partners like NGOs, faith-based and civic organizations etc.

V.

Maps of the targeted area vi Cold chain requirements and maintenance vii Plan for distribution of logistics Vili.

Plans for disposal of waste from campaign ix.

Social mobilization plan with community leaders mapped and engaged X.

Training schedule xi.

Budgetary estimates for the various campaign components including training and planning prior to implementation and waste disposal following implementation

5. Select immunization teams. For every 100 to 150 people expected at the immunization site, the followed staff is required:

i.One to two vaccinators to give immunizations ii. One recorder to record on immunization cards ili. Community health workers (VHTs) if already exist or an identified community volunteer to verify age and immunization status.

6. Work with your District EPI/ team to conduct refresher training for vaccinators on recommended immunization practices. Ensure instructions are given for the use of safe injection techniques.

7.Mobilize the community. Inform the public about the emergency immunization activity while ensuring that; There is a clear communication plan that includes easy to understand information about:

i. the need for the campaign There is a clearly defined target group for the campaign İİi.

There is a clear understanding of the dates of the campaign iv.

The communication plan has mechanisms for rapidly identifying and addressing rumours that may arise during the campaign V.

There is a single point of contact well versed in risk communications and the local culture Vi.

There is a clear plan for monitoring any adverse events 8. Arrange staff transportation to the immunization site.

i.

Plan their transportation to and from the site i1.

Schedule vehicles and plan for fuel and other costs İii.

Estimate per diem costs and make necessary arrangements for lodging if the site is away from the health worker's usual station.

9.Monitor the overall campaign process and the number of doses of vaccine given.

i.

Collect daily summary sheets from teams ii.

Calculate the quantity of remaining stocks and supplies necessary for the next day iii.

Estimated number of individuals vaccinated should be followed daily and tracked against target population iv.

Follow up visit plans should be made for missed individuals based on tally/summary sheet information Document any missing houses/individuals who should be followed up on subsequent days VI.

Review the teams available at sight and if necessary, allocate/deploy the teams to other sites basing on the workload Vil.

Conduct brief feedback sessions at the end of each day with vaccination teams and make necessary mid-course corrections NB: A rapid guide to common SIA problems and potential quick fixes is available at:

http://www.polioeradication.org/Portals/0/Document/Resources/PolioEradicators/1c. QuickFi xesforSIA20100914.pdf

#### Annex 6D: Estimating vaccine supplies for immunization activities

Outbreak:

_ Date confirmed:

Children age 0 - 5 years Target population:

Children age 9 months up to 14 years Children and adults age 0 up to 30 years Women of childbearing age 15 years up to 45 years All adults and children in the general population 1. Calculate the size of the target population. If the activity only targets a proportion of the general population, estimate the size of the target population. Multiply the general population times the percentage of children or adults in the target population. If you do not know the exact age distribution rates in your area, use recommended estimates such as the following:

20% children age 0 up to 5 years 45%

- children age 9 months up to 14 years

70%

- children and adults age 1 up to 30 years

- women of childbearing age 15-45 years

20% 2. Find out how many doses each person should receive. Record the number below as "number of doses recommended." 3. Allow for wastage. Use a wastage factor of 20%. Multiply the size of the target population (see step 1) times the number of doses times 1.20.

× 1.20 = Number of doses Number of Size of target population wastage recommended doses to order including wastage NB: It is recommended that the wastage factor of 20% should be used only at the national level to estimate vaccine requirement during an outbreak. At the sub-national and district levels use 15% wastage factor and health facility level use wastage factor of 10%.

4. Allow for a contingency stock. Use a reserve factor of 25%. Multiply the estimated number of doses including wastage times 1.25 to obtain the total estimated number of doses.

1.25 Total Number of doses Contingency factor number of estimated doses including wastage NB: It is recommended that the contingency stock is kept only at the national level. However, if a sub national level has adequate capacity for vaccines storage, then this level can also keep contingency stock

5. To obtain the total number of vials of vaccine to order, divide the total number of estimated doses by the number of doses that are contained in the vial. (This is usually printed on the label and may be one dose, two doses, five doses, ten doses or twenty doses).

Total number of Total number of vials Doses per vial estimated doses required 6. If the vaccine requires a diluent, multiply the number of milliliters of diluent per vial times the total number of vials required.

Total diluent to order Total number of vial Diluent required per vial 7. Estimate the number of sterile needles and syringes that will be needed to carry out the activity.

If single-use needle and syringes are used, order the same amount as for the estimated number of doses in Step 4.

8. In addition, estimate the number of dilution syringes necessary for preparing the vaccine.

Source: Field Guide for Supplementary Activities Aimed at Achieving Polio Eradication, World Health Organization, Geneva 1997. District guidelines for yellow fever surveillance, Division of Emerging and other communicable disease surveillance and control, World Health Organization, Geneva 1998.

9. Estimate the number of safety boxes required

#### Annex 6E: Recommended Immunization Practices

Work with your EPI team to give refresher training to the vaccinator teams that will conduct the emergency immunization activity. As a minimum, make sure vaccinator teams know how to:

1. Reconstitute the vaccine correctly:

Determine the appropriate quantity of diluent to reconstitute the freeze-dried vaccine.

Use a sterile syringe and sterile needle for each dose.

- Using the dilution syringe, draw up and expel the diluent several times in the

vial that contains the vaccine so as to mix the reconstituted vaccine well.

2. Wrap the vial in silver foil or cover it with a dark cloth. This will protect the vial from sunlight.

3.

In a field situation, protect the vaccine and diluent from contamination. Cover the open top of the vial with foil to keep out dirt and flies.

4.

Place reconstituted vaccine vials and opened liquid vaccine vials immediately stand them on chilled ice, or stand them on an ice pack. Keep the ice and vaccines in the shade.

5.

Follow multi dose vial policy as applicable e.g., for measles and polio.

6.

Record the dose on an immunization card for each person immunized.

Collect data for monitoring the activity. For example, record the number of doses given on a tally sheet so that coverage from the campaign can be calculated.

8.

Remind health workers about the risk of getting blood-borne diseases from an accidental needle stick. Review safe practices for handling and disposing of sharp instruments and needles using a sharps box.

9. Arrange for safe disposal of used injection materials at the end of the activity. They can be burned or buried in a pit according to medical waste disposal guidelines.

#### Annex 6F: Outbreak Communication

Introduction Following confirmation and verification of the event, the primary health and the district level authorities should liaise with the national level authorities to communicate and receive guidance on common positions to be delivered to the media.

From first announcement throughout the outbreak, communication from the district level should follow the directions and the key messages developed at national level in consultation with the field team, in order to ensure consistency and speaking with one voice. Even though communication should be centrally coordinated by the national level, media would approach local and district public health response level to obtain first-hand information from direct sources. In addition, the DHO should support the communication and provide scientific expertise as evidence for intervention.

Actions at the district level

- Identify a spokesperson at district level (political or technical)

- Liaise regularly with the national level to provide them with first-hand information

(received at the community local level, the media, local stakeholders)

- Be regularly in contact with the national level to receive updated messages including

guide and answers for frequently asked questions to feed the local media

- Be available for interviews by local media upon request to provide accurate, transparent

and updated information following directions from national level in simple clear key messages

- Organize press briefings to provide regular information to local media, following

directions from national level

- Develop good relationships with local media to partnership for delivery of accurate,

transparent, timely messages to the population

- Use Information Education and Communication materials developed at the national

level with clear consistent messages to provide guidance to the population

- Identify local powerful channels for the delivery of information to the population

- Meet regularly with local stakeholders to disseminate correct message of prevention and

surveillance to the population

- Organize preventive house-to-house campaigns to reach the remote rural areas and

promote prevention and surveillance, following directions from national level

#### Annex 6G: Guide to Infection Prevention and Control Measures

Hand Washing Purpose: To protect the patient, staff and care givers from cross infection Responsibility: Clinicians, Environmental health practitioner, care giver Steps in hand washing

- The hands are washed thoroughly for a minimum of 10-15 seconds with soap (plain or

antimicrobial) and running water (tap or run to waste method)

- Remove jewellery (rings, bracelets) and watches before washing hands, ensure that the nails

are clipped short (do not wear artificial nails), roll the sleeves up to the elbow.

- Wet the hands and wrists, keeping hands and wrists lower than the elbows (permit the water

to flow to the fingertips, avoiding arm contamination).

- Apply soap (plain or antimicrobial or ash) and lather thoroughly.

o Use firm, circular motions to wash the hands and arms up to the wrists, covering all areas including palms, back of the hands, fingers, between fingers and lateral side of the fifth finger, knuckles, and wrists.

- Rub for minimum of 10-15 seconds.

- Repeat the process if the hands are very soiled. Clean under the fingernails.

- Rinse hands thoroughly, keeping the hands lower than the forearms. If running water is not

available, use a bucket and pitcher.

o Do not dip your hands into a bowl to rinse, as this re-contaminates them. Collect used water in a basin and discard in a sink, drain or toilet.

o Dry hands thoroughly with disposable paper towel or napkins, clean dry towel, or air dry them. Discard the towel if used, in an appropriate container without touching the bin lids with hand. Use a paper towel, clean towel or your elbow/foot to turn off the faucet to prevent re-contamination.

Different types of antiseptic disinfection:

Using antiseptics, hand rubs gels or alcohol swabs for hand antisepsis o Apply the product to the palm of one hand. The volume needed to apply varies by product.

o Rub hands together, covering all surfaces of hands and fingers, until hands are dry o Do not rinse.

NB: When there is visible soiling of hands, they should first be washed with soap and water before using waterless hand rubs gels or alcohol swabs. In situations where soap is not available, ash can be used for washing hands Hand Hygiene Techniques This is a process, which mechanically removes soil and debris from skin and reduces the number of transient microorganisms. Hand washing with plain soap and clean water is as effective in cleaning hands and removing transient microorganisms as washing with antimicrobial soaps and causes less skin irritation.

Steps:

Handwashing Technique with Soap and Water

- Thoroughly wet hands.

Apply a hand-washing agent an soap); (liquid antiseptic agent is not necessary.

apply enough soap to cov Wet hands with water rub hands palm to palm all hand surface of areas rub all

- Vigorously

hands and fingers for 10-15 average seconds (tip:

breaths), paying close attention backs of fingers to opposing palm to palm with fingers to fingernails and between with interlaced fingers and palms with fingers interlocked fingers.

- Rinse hands thoroughly with

clean running water from a tap rolanonan rubbing, backwaros rinse nands win water or bucket.

rotational rubbing of left and forwards with clasbed thumb clasped in right palm angers or rignt mand in len and vice versa palm and vice versa

- Dry hands with paper towel or a

clean, dry towel or air-dry them.

O 10.60 =

- Use a paper towel or clean, dry

towel when turning off water if ...and your hands are safe dry thoroughly with a single use towel to turn off faucet there is no foot control or use towel automatic shut off.

Modified according to EN1500 Source: World Health Organization (WHO) 2005.

Note:

- If bar soap is used, provide small bars and soap racks that drain.

- Use running water and avoid dipping hands into a basin containing standing water; even

with the addition of an antiseptic agent, microorganisms can survive and multiply in solutions.

- Do not add soap to a partially empty liquid soap dispenser. This practice of "topping

off' dispensers may lead to bacterial contamination of the soap.

- When soap dispensers are reused, they should be thoroughly cleaned before filling.

- When no running water is available, use a bucket with a tap that can be turned off to

lather hands and turned on again for rinsing, or use a bucket and pitcher.

- Used water should be collected in a basin and discarded in a latrine if a drain is not

available.

leuosJed Appnq LOT

Steps to Doff WHO PPE using coverall (19 Steps to take off personal protective equipment PE) including gown steps) 3 Remove apron 4 Perform hand 1 Always remove PE under 1. Always remove PPE under the guidance and hygiene on gloved the guidance and supervision leaning forward and hands.

taking care to avoid of a trained observer supervision of a trained observer (colleague) contaminating your (colleague). Ensure that 2. Enter decontamination area by walking through 5 Remove outer pai hands. When infectious waste containers of gloves and chlorine tray.

removing disposable are avalable in the doing dispose of them apron, tear it off area for safe disposal 3. Perform hand hygiene on gloved hands (0.5% safely.

at the neck and rollit of PE. Separate containers chlorine).

Use the technique down without should be available for shown in Step 17 4. Remove apron taking care to avoid reusable tems.

touching the front contaminating your hands by peeling it off.

6 Perform hand are. Then untie the 2 Perform hand hygiene on back and ol the 5. Perform hand hygiene on gloved hands (0.5% hygiene on gloved hands.

gloved hands.

apron forward.

chlorine).

6. Remove hood or bonnet taking care to avoid | 9 Remove the 7 Remove head and neck covering taking care to avoid contaminating your face.

gown by untying contaminating your face by starting from the bottom of the hood in the back and rolling from back to front the knot first, 7. Perform hand hygiene on gloved hands (0.5% and from inside to outside, and dispose ofit safely.

then pulling chlorine).

from back 8. Remove coverall and outer pair of gloves.

to front olling 9. Tilt head back to reach zipper, unzip completely it from inside to outside without touching any skin or scrubs, remove and dispose coverall from top to bottom.

of it safely.

10. After freeing shoulders, remove the outer gloves while pulling the arms out of the sleeves.

11. With inner gloves roll the coverall, from the waist down and from the inside of the coverall, 8 Perform hand hygiene on gloved hands.

10 Perform hand hygiene on gloved hands down to the top of the boots.

13 Remove the mask from 11 Remove eye protection by pulling the string 12. Use one boot to pull off coverall from another from behind the head and dispose of it safely.

behind the head by first boot and vice versa, and then step away from the untying the bottom string coverall and dispose of it safely.

above the head and leaving it hanging in front 13. Perform hand hygiene on gloved hands (0.5% and then the top string chlorine) next from behind head 14. Remove the goggles or face shield from behind and dispose of it safely the head (keep eyes closed).

15. Perform hand hygiene on gloved hands (0.5% chlorine) 14 Perfom hand hygiene on gloved hands.

16. Remove mask from behind the head (keep eyes 17 Remove gloves careful with appropriate closed).

technique and dispose of them sately.

12 Perform hand hygiene on gloved hands.

17. Perform hand hygiene on gloved hands (0.5% chlorine).

15 Remove rubber boots without touching them (or 18. Remove inner gloves with appropriate technique overshoes f wearing shoes. If the same boots and dispose of safely.

are to be used outside of the high-risk zone, keep them on but clean and decontaminate appropriately 19. Decontaminate boots appropriately and move to before leaving the doffing area?

lower risk area one foot at a time and Perform 16 Perform hand hygiene on gloved hands.

18 Perform hand hygiene.

hand hygiene (0.05% chlorine).

- Wile wig the patent are, ode gloves shout be changed be en patients and tor to eating change the seing he last patient

- World Health

1 Appropriate decontamination of bots Includes stepping to a tubath with 0.5% chlorthe solution (and reowing dirt with toilet brush I hear Organization oy saling a 5% chare solution for 30 mil, the fred and dred.

All reasonable precautions have been taken by the World Health Organization to verify the information contained in this publication, Howerer, the published materiali being distributed without wartnty of any lind, either expressed or implied. The resporably for the intepretation and use of the material lies with th eader, In no event shall the Word Health Orgariation be liable for darnages aring from is use.

Setting up a Cholera Isolation Unit/Cholera Treatment Unit a. Site management There are different recommendations for different situations/circumstances:

In urban settings and refugee camps:

Establish CTU + several Oral Rehydration Points (ORPS) Ideally, the CTU should be located inside the existing hospital premises but clearly separated and isolated from the other departments to avoid spread of infection to non-cholera patients. If the hospital premises are not suitable, another site must be found. In urban/camp settings, it is preferable to have one single CTU and several ORPs rather than setting up multiple CTUS, thereby increasing potential sources of infection. When affected areas are too far from the CTU, access can become a problem. Ambulances can be provided for referral, or a CTU may be established as an intermediate structure. Use of taxis/buses should be discouraged given the high contamination risk during the journey.

In rural settings:

Establish Cholera Treatment Units (CTU) The CTU should be located inside the health facility, or close to it. If this is not possible, other existing structures may be used. CTUs may paralyses routine health services as adequate case management is labour-intensive and other health services may suffer from staff shortage. In areas that are far from any treatment facility, it may be possible to decentralize the CTU to the level of the affected villages.

Oral rehydration Points (ORPs) ORS points have two objectives: to treat patients, and to screen off and refer severely dehydrated patients to CTU(S). They reduce pressure on overburdened CTUS. They can be decentralized to the community level. The community health worker should receive quick training and regular supplies, to be able to achieve given objectives.

Design of a CTU Selection criteria: Consider the following when selecting a site for a CTC:

- Proximity to the affected area.

- Easy accessibility for patients and supplies.

- Adequate space Protected from winds (there should be wind breaks)

- Compatibility with adjacent existing structures and activities

- Availability of adequate potable/safe water supply within a minimum distance to avoid

contamination.

- Good drainage from the site

- Provision of waste management facilities (clinical and general waste)

- Availability of sanitary facilities (temporary)

- Provision for extension of CTU (basing on estimation given by epidemiologist)

Setting up a temporary Cholera Treatment Unit (CTU)

- In setting up a CTU, you can use an existing building or set up tents.

- It is important to consider safety of patients and ventilation as high temperatures contributes

to dehydration of the patients.

- The cholera camp should operate 24 hours a day independently of the other health facilities

and therefore the necessary staff has to be recruited.

- It should be supplied with the medical material specifically for the centre.

- An enclosure should be provided around the cholera camp.

- The various workstations should be clearly labelled and directions provided.

- The CTU must be a "closed system" where contamination is introduced through patients,

and must be destroyed inside the structure. Under no circumstances should any contamination come out (through patients, water, material, solid and liquid waste etc.).

- General rules for a good design:

- Strict necessary movement for staff and patient

- Each zone is a "closed box"

Systematic disinfection between zones Discipline and mutual control for the patient, attendant and staff on hygiene Good infection control means anything coming out is free of contamination The diagram below is a layout of Cholera Treatment Unit.

WATCH MAN DRINKING WATER POINT E1 0 05% CHLORINE SOLUTION DEJECTION PIT DRAIN AGE OBSERVATI ON NEUTRAL AREA PITAKAWAY WATER POINT SHA WER FENCE HOSPITALISATION BACK HOME CONVALESCENCY PROVISION FOR EXTENSION

Triage and Observation

- Patients are examined by health workers for screening. If cholera, admit; otherwise send to

normal dispensary.

- Patients are admitted with 1 attendant (caregiver) if necessary.

- Patients who are admitted are registered in the cholera line list.

- A foot bath should be provided at the entrance

- Toilets and water should be easily accessible for patients.

- Shower facilities should be provided for the patients.

- A disinfection area should be provided for the transporting vehicles and contaminated

articles for the patients.

- Tables, chairs, water containers fitted with taps, refuse receptacles should be provided in

these areas.

- Provision of safe water

- Establish an ORP corner

Admissions area

- Patients with severe dehydration and/or uncontrollable vomiting must be hospitalized for

immediate rehydration.

- Each patient lies on a Cholera bed with 1 bucket for stool collection underneath the hole in

the bed and 1 bucket for vomit besides the bed. The following should be put in place or provided in the admissions area;

- Separate rooms/tents for males and females where possible

- Separate rooms for children, the old and pregnant women as risk of abortion increases

with cholera

- A foot bath and hand washing facilities (with disinfectant) at the entrance

- Provision for disinfection of soiled linen and clothing

- Patients should have access to toilets and washing facilities (with disinfectant) or

showers (should be provided where possible)

- Cholera beds with receiving buckets, buckets for those who vomit and water containers

for patients

- Tables and chairs for staff

- Refuse receptacles

- Patients should be screened by medical staff and categorized according to their status.

A Convalescence/Recovery Area

- The convalescence or recovery area is meant for oral rehydration after hospitalization when

less surveillance is required. Patients can stay on mats or benches, as in the observation area.

- The patients who are no longer vomiting nor have diarrhoea and requiring less medical

attention can be put in this ward.

- Separate rooms/tents should be provided for males and female.

#### Annex 6H: Response to Chemical and Radio-nuclear Events

Response to Radiological Events If an accident is suspected;

- Prevent inadvertent ingestion of contamination (e.g., wear gloves, do not smoke or eat)

- Perform life saving measures and provide first aid for serious injuries immediately, before

conducting radiological monitoring

- Keep people away from any potential source of exposure (at least 10 m from the public)

- Arrange to transport seriously injured people to local medical facility.

- Wrap them in a blanket to control the spread of contamination. Inform the Emergency Medical

Services (EMS) and team the receiving medical facility that the person may be contaminated and that the risk to those treating such a patient is negligible but care should be taken to prevent inadvertent ingestion of contamination.

- Identify and register potentially exposed/contaminated individuals. Gather information that could

be useful in reconstructing their dose to include medical symptoms and o description of events.

- Report to appropriate officials and obtain instructions.

- If not seriously injured, remain in the area until monitored.

Respond to Action Threshold:

If an accident is confirmed;

- Reassess and review with relevant departments and agencies medium to long term

- protective actions such as food chain restrictions.

- Provide the population with useful, timely truthful, consistent and appropriate

- information as to the likely health effects of the emergency by reference to existing

- knowledge.

- Arrange for detailed clinical and radiological review of affected persons.

- Establish and maintain an appropriate disease surveillance programme.

- Establish a registry of persons to be tracked and to receive long-term follow-up.

- Base inclusion in the registry on objective criteria that indicate potential for an increase in the

incidence of radiation induced cancer.

- Begin surveillance of any identified groups at risk, e.g., screening for thyroid disease in children in

an area affected by radioactive iodine release.

- Assist Government authorities in planning a return to normal life for the population

- affected.

External contamination

- Use instrumental contamination monitoring. Use cotton swabs for skin, nostrils, ear canals, wounds

or any contaminated object. Each swab should be placed in a labelled test tube for counting.

Internal contamination o Use instrumental detection methods such as whole-body counting, gamma camera, thyroid counting. Radionuclides may be in the blood or excreted in the faeces or urine. Excreta should be

placed in appropriate containers and blood samples in test tubes for counting.

Decontamination Procedures o Materials: Lukewarm water, soap or ordinary detergent, soft brush, sponges, plastic sheets, tape, towels, sheets, iodine tablets or solution.

- Procedural priority: Remove all clothing and place in plastic bags. Carry out life saving

measures first. Identify contaminated areas, mark clearly and cover until decontamination takes place.

Start with decontamination of wounds when present, and move on to the most contaminated area of the body.

Local contamination:

- Cover uncontaminated area with plastic sheet and tape edges. Soak the contaminated area,

gently scrub with soap, and rinse thoroughly. Repeat the cycle and observe changes in activity.

One cycle should not last longer than about 2-3 min. Avoid vigorous scrubbing. A stable isotope solution may facilitate the process.

- For wounds, irrigate with normal saline solution repeatedly. Surgical debridement might be

considered in some instances. Eyes and ears may be irrigated gently with isotonic saline solution.

Extensive contamination:

- Shower those not seriously injured. Bathing may be done on the operating table or stretcher for

the seriously injured.

- Soak- scrub-rinse cycle should also be observed.

Inhalation: Irrigate nasopharynx and mouth.

Ingestion: Administer cathartics for insoluble materials. Administer diuretics by forcing fluids for soluble contaminants.

Prophylactic measures

- Cover areas still contaminated with plastic sheet and tape edges. Gloves can be used for hands.

o Repeat washing after allowing the skin to rest.

Treatment

- Erythema and dry desquamation can be treated symptomatically. Lotions or sprays containing

hydrocortisone can be used to relieve the symptoms associated with severe erythema accompanied by oedema. To treat moist desquamation, daily dressings and bathing of the affected skin in antiseptic solutions is helpful. Antibiotic creams can also be used.

- For ulceration, isolation of the limb in a sterile environment or daily dressing and bathing of the

ulcer in antiseptic solutions is recommended. Analgesics or stronger opioids may be necessary.

In the event of suspected or verified secondary infection, topical or systemic antibiotic therapy should be considered.

o For necrosis, only surgical treatment is effective. Surgical toilet is indicated. Excision of deep necrosis followed by skin grafts or other kinds of grafting may be conducted when indicated.

o Indications for amputation include very severe lesions with destruction of underlying tissues, including vascular damage, intractable pain and lack of infection control.

Expected outcome

- Radionuclide activity is no longer detectable or is decreasing.

Response to Chemical Event/Attack Components of rescue and medical services:

- Search and rescue teams

Emergency medical teams used for day-to-day emergencies (Medical officers, nurses, first aiders, ambulance) o Field medical services (field medical teams and posts)

- Medical emergency response plans and procedures

- Personnel and equipment to reinforce the resources available for day-to-day emergencies

A transport service for medical evacuations

- Hospitals with casualty and surgical units

At the emergency site:

Operate as close as possible (but within safe distance) to the emergency site.

- Collaborate closely with different rescue teams (engineering, fire fighters, decontamination and

human rescue groups).

- Ensure all rescue workers don appropriate PPEs.

Assess the situation to determine that there is no eminent danger Rescue teams should locate casualties and remove them from danger.

Rescue team should do primary medical assessment to identify and manage life threatening conditions. Assess:

Airway

- Breathing

Circulation

- Rescue team should provide First Aid and record details of first aid provided before forwarding

casualties to field medical teams.

o Field medical services post/s: Establish field medical post/s.

o Field medical teams perform primary/secondary medical assessment.

Assign triage category to casualties based on the medical assessment.

Initiate appropriate treatment.

- Prepare casualties for evacuation to hospital according to triage category.

Continue documentation of casualties.

- Provide surveillance of casualties awaiting evacuation.

Liaise with casualty transport service.

Evacuate casualties to appropriate medical facilities according to priorities.

o Ensure continuity of medical care for casualties along the whole length of the chain from the emergency site to the hospital.

- Provide information to receiving medical facilities as necessary.

- Treat minor injuries not requiring hospitalization.

Hospital services:

- Prepare for casualty reception.

- Do a medical assessment to identify and manage life-threatening conditions.

o Assign triage category based on assessments.

- Provide appropriate treatment according to triage priorities and available hospital resources.

- Continue medical documentation of casualties.

- Undertake surgical procedures where necessary.

o Provide post-operative care and release casualties.

Recognizing and Diagnosing Health Effects of Chemicals in Chemical Events Initial Effects Agent Name Any unique Agent /Type Characteristics Nerve Miosis (pinpoint pupils) Calobenel sarin Miosia (pinpoint pupils) Copious secretions Blurred/dim vision Sarin (GB) Muscle Headache Soman (GD) twitching/fasciculation Nausea, Vomiting Tabun (GA) VX Diarboea Copious secretions Sweating Muscle twitching/fasciculation Breathing difficulty Seizures Possible frostbite Possible cherry red skin Cyanogen chloride Atyphsiant Blood- Confusion Arsine Possible cyanosis Hydrogen cyanide Nausea Patient may gasp for air similar to asphyxistion but more abrupt onset Seizure prior to death Eye and skin irritation Chlorine Choking Pulmonay Chlorine is a greenish Airway irritation Hydrogen chloride yellow has with pungent damaging Dysprosa, cough Nitrogen oxide Sore throat Phosgene gas smells like Phosgene very newly mown hay or Chest tightness grass Possible frostbite Mustard/Sulfur immediately Possible pulmonary oedema Blistering Vesicant Mustard (HD, H) decontaminate skin; flush Mustard has an asumptomatic Mustard(gas) eyes with water or normal latent period Nitrogen musard saline for 10-15 minutes There is no antdocte or treatment Lewisite (L) for mustard if breathing difficulty, Lewisite has immediate buming give oxbygen pain, blisters later any supportive care Specific antidote British Anti Lewisite (BAL) may decrease gyatemic effects of Lewisite May cause death Agent 15/BZ May appear as mass drug incapacting intoxcation with ecastic Dry mouth and skin behaviour-altering Initial tachycardia behavior, distint hallucinations and Altered consciousness, confusion delusiona, denial of illness, beligerence Hyperthemia Hyperthemia Ataxia (lack of coordination) Mydri asiasia (dilated Hallucinations pupils) Mydriasis (dilated pupils)

Decontamination and Treatment Decontamination First Aid Access Agent Type Other patient consideration ABCs Nerve Remove clothing Onset of symptoms from dermal Atropine before other measures immediately contact with liquid forms may be delayed Gently wash skin with soap Pralidoxime (2P AM) and water Repeated antidote chloride Do not abrade skin administration may be necessary For eyes For eyes, flush with plenty of water or normal saline Asyphxiant Blood Rapid treatment with Arsine and cyanogen chloride Remove clothing Arsine immediately - if no frostbite oxygen may cause delayed pulmonary Gently wash skin with soap Forcyanide, use pedema antidotes (sodium and water nitrite and then sodium thiosulfate) Fresh air Choking Pulmonary May cause delayed pulmonary Remove clothing Forced rest pedema, even following a immediately if no frostbite damaging Semi upright Gently wash skin with soap symptom free period that varies I duration with the amount and water If signs of respiratory Do not abrade the skin distress are present, For eyes, flush with plenty of oxygen with or water or normal salimne without positive airway pressure may be needed Other supportive therapy as needed Immediate Immediate decontaminate is Blistering/Vesicant Possible pulmonary pedema decontaminate akin] Mustard has an asymptomatic essential to minimize damage flush eyes with water latent period, there is no antidote Remove clothing or normal saline for for mustard immediately 10-15 minutes Lewisite has immediate buming Gently wash skin with soap and water pain, blisters later Do not abrade skin Specific antidote British Anti Lewisite (BAL) may decrease For eyes, flush with plenty of water or normal saline systemic effects of Lewisite Phosgene oxine causes immediate pain Remove heavy Incapacting/ behaviour- Hyperthermia and self-injury are Remove clothing clothing targets risks immediately altering Evaluate mental Hard to detect because it is an Gently wash skin with water status odorless and non-irritating or soap and water substance Do not abrade skin Use restraints as needed Possible serious anthymias Monitor core Specific antidote (physostigime) temperature carefully may be available Supportive care

Antidote Recommendations Following Exposure to Cyanide Severe Mild Other treatment Patient (Unconscious) (Conscious) For sodimu nitrite- Sodium nitrite: 12- Child Antidotes may not induced orthosatic 0.33ml/kg, not to be necessary exceed 10ml of 3% hypotension, normal saline infusion and solution. Slow IV no supine position are less than 5 minutes, recommended or slower of hypotenison If still apnoeic after develops antidote Sodium thiosulfate:

administartauon, consider sodium 1.65ml/kg of 25% solution IV over 10bicarbonate for severe 20 minutes acidosis Sodium nititie: 10- Adult Antidote may not be 20ml of 3% solution necessary slow IV over no less than 5 minutes, or slower if hypotension develops and Sodum thiosulfate:

50ml of 25% solution IV over 10- 20 minutes Note:

1) Victims whose clothing or skin is contaminated with hydrogen cyanide liquid or solution can

secondarily contaminate response personnel by direct contact or through off-gassing vapours.

2) Avoid dermal contact with cyanide contaminated victims or with gastric contents of victims

who may have ingested cyanide-containing materials.

3) Victims exposed only to hydrogen cyanide gas do not pose contamination risks to rescuers. If

the patient is a victim of recent smoke inhalation (may have high carboxyhaemoglobin levels), administer only sodium thiosulfate.

4) If sodium nitrite is unavailable, administer amyl nitrite by inhalation from crushable

ampoules.

5) Available in Pasadena Cyanide Antidote Kit, formerly Lilly Cyanide Kit.

#### Annex 61: Documenting Key Outbreak Response Milestones

Outbreak Timeliness Metrics Date Definition Outbreak Milestones Date when the occurrence of the outbreak was Predict Date predicted, where applicable Date when initial preventive and preparedness Prevent Date measure were implemented Date of symptom onset in the primary case or earliest Outbreak Start epidemiologically-linked case Date when the primary case first came into contact with the health system or when the outbreak or disease-related event is first Outbreak Detection recorded by any source or in any system or Date the outbreak is first reported to the next Outbreak Notification level Earliest date of outbreak verification through a Outbreak Verification reliable verification mechanism Laboratory Earliest date of laboratory confirmation for the Confirmation initial case Earliest date of any public health intervention to control the outbreak Outbreak Response Date of first official release of information to Public Communication the public from the Ministry of Health Date that outbreak is declared over by the Outbreak End Ministry of Health

SECTION 7 RISK COMMUNICATION

## Section 7: RISK COMMUNICATION

### 7.0 Risk Communication and Community Engagement

Risk communication and community engagement (RCCE) are essential elements of disaster and emergency preparedness and response and are the core capacities in the International Health Regulations 2005 (IHR 2005). Risk communication refers to the exchange of real-time information, advice and opinions between experts and people facing threats to their health, economic or social well-being 41. Its ultimate purpose is that everyone at risk is able to take informed decisions to mitigate the effects of the threat (hazard) such as a disease outbreak and take protective and preventive action.

Risk communication uses a mix of two way and multi directional communication and community engagement strategies and tactics, including but not limited to, mass media communications, social media, dialogue meetings, mass awareness campaigns, health promotion, stakeholder engagement, social mobilization and community engagement.

The current 21st century has witnessed an exponential growth in travel, trade and migration, coupled with communication technology revolution providing massive access to a variety of means of communication and information. The public and communities have been exposed to a variety of dynamic, fast-changing, formal and informal media, social media and complex social networks that influence how risk is communicated, perceived and acted on. The latest evidence shows that the practice of risk communication is a complex task that is a core public health intervention in any response to disease outbreaks/epidemics, pandemics and other health emergencies* It is therefore important for risk communication to be conducted effectively, so as to promote public health goal of rapid outbreak containment, preventing avoidable death and disease with the least possible disruption to economies and society. During epidemics and pandemics, humanitarian crises and natural disasters, effective risk communication allows the people who are most at risk to understand and adopt protective behaviours. It allows authorities and experts to listen to and address people's concerns and needs so that the advice they provide is relevant, trusted and acceptable.

This section describes how to conduct risk communication before, during and after an outbreak. Effective communication provides those at risk with the knowledge to make informed decisions for protective action when linked to functioning service. It also provides decision makers with summary information especially if there was an outbreak response, allowing them to review how resources were applied to contain the event.

#### 7.0.1 Importance of effective risk communication:

- Promotes rapid outbreak containment, preventing diseases and avoidable deaths and

reduces the possible disruption to economies and society

- Allows people most at risk to understand and adopt protective behaviours during epidemics,

pandemics, humanitarian crises and natural disasters

- It allows authorities and experts to listen to and address people's concerns and needs so that

the advice they provide is relevant, trusted and acceptable

- When the public is at risk of a real or potential health threat, direct interventions may take

time to organize and resources may be few. Communicating advice and guidance, therefore, often stands as the first and most important public health tool in managing a risk

- Pro-active risk communication encourages the public and service providers to adopt

protective behaviours when these are linked to functioning systems and services

- It facilitates heightened disease surveillance, reduces confusion, and minimizes

miscommunication and falsehoods (and rumours) in relation to the cause, transmission of a disease and proven effective protective actions

- It allows for a better use of resources - all of which are necessary for an effective response

### 7.1 Risk Communication in the context of IDSR

Integrated Disease Surveillance and Response (IDSR) strategy is an approach for improving public health surveillance and response for priority diseases, conditions and events at community, health facility, district and national levels. Since the IDS system has the potential of ensuring that there is a reliable supply of information to the national level to fulfil IHR requirements, risk communication should be integrated in all the IDSR core functions and activities.

The IDSR core functions and activities for each level of the health system are well illustrated in the Introduction section of this guideline. Effective risk communication is therefore needed to achieve the objectives for IDSR.

If risk communication is well planned and integrated in IDSR, it can improve decision making and adoption of recommended behaviours by communities and contribute to the prevention, control and response to priority diseases and other public health events. Such communication needs to be carefully planned and implemented as well as properly integrated with emergency management activities and operations at community, district, region and national levels to support all the relevant core IDSR functions and related activities at that level.

#### 7.1.1 Benefits of Risk Communication

When risk communication is effectively carried out, it promotes the primary public health goal of rapid outbreak containment, preventing avoidable death and disease, and with the least possible disruption to economies and society.

The literature on the purposes of risk communication generally takes a management perspective. Accordingly, risk communication may serve to:

- Raise awareness;

- Encourage protective behavior;

- Inform to build up knowledge on hazards and risks;

- Inform to promote acceptance of risks and management measures;

- Inform on how to behave during events;

- Warn of and trigger action to impending and current events;

- Reassure the audience (to reduce anxiety or 'manage' outrage);

- Improve relationships (build trust, cooperation, networks);

- Enable mutual dialogue and understanding;

- Involve actors in decision making

#### 7.1.2 Target audiences for risk communication

- Community members: All people at risk of acquiring disease or in need of health

services within the context of the public health event including children.

- Health-care providers and first responders

- Private hospitals and clinic staff

- Surveillance Officers

- Laboratory staff

- Point of Entry staff

- Airlines staff

- Immigration officers

- Travelers

- Stakeholders (policy-makers, government ministries and MDAs, maternal and child

health organizations, partners, community organizations, etc.)

- Media houses

- Learning institutions

- Workplaces

- Political, traditional and religious leaders

- Cultural institutions

- Security agencies

- Trade unions

- Opinion leaders and elders

#### 7.1.3 Approaches for Risk Communication

The components of risk communication which are needed for effective emergency response include:

a. Health education

b. Social mobilization c. Community engagement d. Mass media (print and electronic) e.

Social media Outbreak communication f.

Crisis communication gh. (Information Education and Communication (IEC) 1.

Behaviour Change Communication (BCC)) j. Rumour monitoring and managing k. Advocacy

### 7.2 Community engagement and its importance in public health emergency

preparedness and response Community engagement is the process of working collaboratively with and through people affiliated by geographic proximity, special interest, or similar situations to address issues affecting the wellbeing of those people* In conducting risk communication, community engagement is an important key. The emphasis during community engagement is on building trust.

#### 7.2.1 Steps for community engagement

The steps for community engagement involve:

- Determining the goals of the community engagement

- Identifying the target audience

- Developing engagement strategies

- Identifying the activities

- Prioritizing those activities

- Creating an implementation plan

- Monitoring the progress

#### 7.2.2 Importance of effective community engagement:

Effective community engagement helps you to:

- Know the community (problem and needs)

- Understand the existing health beliefs, attitudes and practices

- Listen to the community carefully

- Analyse community dynamics

- Involve the community in all aspects of the response right from the planning stages

- Provide feedback to the community

#### 7.2.3 Effective community entry

Community entry is the process of entering community space with the intention of meeting the community members where they are most comfortable or where they can speak out their ideas, needs and aspirations. Community spaces are created according to culture, value and processes. Community entry is a prerequisite of any meaningful participatory process.

Some of the principles that guide community entry are: Respectful dialogue- be always ready to learn; Sensitivity to needs and Historical perspectives The goals of community entry include:

- Contextual grounding - having a better understanding of the community

- Build trust and confidence

- Generate support

- Obtain genuine information

Critical actions in community entry:

- Identify the community by gathering information through formal and informal means

- Identify the leadership

- Talk to knowledgeable people

- Read available literature

### 7.3 Integrated Risk Communication Model

Since risk communication is a complex activity involving different audiences, having an integrated approach in risk communication is very crucial. The key components for integrated emergency risk communication are indicated in the figure below. This model allows for the successful design and implementation of an effective communication strategy. The model highlights the necessity of a collaborative approach between different target audiences across the board.

**Figure 13: An integrated model for risk communication**

![Figure 13: Integrated model for risk communication](uganda-idsr-technical-guidelines-assets/figures/figure-13-integrated-risk-communication-model.png)

An integrated model for emergency risk communication Adapted from new IHR external assessment tool - WHO Strategies, plans, SOPs, structures, resources, and simulation exercises to Media and social media Risk communication test systems Systems surveillance, partner, stakeholder, community feedback, emergency Mechanisms at anthropology KAP studies, national, local, other social science tools international levels with stakeholders Internal & partner Dynamic listening and (health care communication & rumour management workers, NGOs, coordination volunteers, civil society, etc.) Directly or through influencers, including awareness campaigns, community radio, interpersonal Media, social media, Communication web, IEC materials, communication, using existing Public communication engagement with social mobilization, etc.

community engagement affected communities mechanisms

### 7.4 Principles for Effective Risk Communication

There are 8 key principles for effective risk communication as outlined below:

Building and Maintaining Trust Building and maintaining trust is arguably the most important function of an effective communication during an outbreak or a public health event and should include:

- Timely, transparent information regarding the nature of the threat

- The response to the event and

- Actionable advice on protective actions people can take, linked to functioning services to

increase self-efficacy Trust is considered the most important requirement for effective risk communication.

According to the latest evidence, risk communication in health emergencies should include genuine participation of the population taking account three key elements:

- The understanding of that population's specific context, concerns, beliefs, practices and

traditions so as to shape scientific and logistic information, explanations that address community concerns (social science intelligence)

- Provision of understandable and trusted advice that they are likely to follow to save lives

and bring the outbreak under control in the shortest possible time, in their own languages adapted to their educational levels and preferences (i.e., oral or visual), on trusted channels and through interlocutors of their choice, (translational communication)

- Meaningful community engagement and the participation of their trusted

interlocutors/messengers (means of dissemination) Trust is thus the currency for all public health interventions, and has, in an era of information overload, emerged as the critical element for effective risk communication (i.e., the expert advice is acted on by key stakeholders, the affected and at-risk populations).

Risk communication should therefore aim at building, maintaining and restoring the trust of the public in those charged with the responsibility of managing the risk.

The latest evidence from 21s century epidemics highlights that to build trust, risk communication interventions should; Be linked to functioning and accessible services

- 

Be transparent and timely

- Be easy to understand for target populations (i.e., in their preferred oral or visual

forms; and in their own languages or dialects, targeted to their educational levels and cultural references) Acknowledge and communicate uncertainty (don't over reassure, don't speculate; but communicate frequently so that the evolution of an event and our understanding is transparent and not a cause of destroying trust) Link to self-efficacy (can people really do what you ask them, do they have the ability, equipment, services, education they need to adopt our advice?) Be disseminated using multiple platforms, methods and channels Identify, involve and collaborate with people that the community trusts in decision-making and not just in information dissemination. This ensures that interventions and the communication about them are contextually appropriate and community-owned.

i.

Timely announcements and transparency:

In most cases, public response to a health threat depends on the way the first and subsequent announcements are made. This necessitates announcing an event or threat as and when it emerges, even when the information is incomplete or changing fast. This in turn implies that communicating uncertainty is a cornerstone of risk communication. Communication by authorities, response managers or front-line personnel must include;

- Information about the uncertainties associated with the risk, event and interventions

- Indicate what is known and not known at a particular moment in time

- A commitment, and follow up to keep people frequently informed and updated with

the changing, uncertain situation

- Multiple platforms, mechanisms and trusted interlocutors to ensure that consistent

and coordinated information reaches stakeholders and the population ii.

Listening to, understanding and respecting public concerns Understanding public perceptions, concerns, fears and expectations is as critical for risk communication as understanding the risky practices and behaviours that affect risk. The understanding of communities must start before an emergency, as well as during an emergency. There are many ways to better listen to community concerns and understand their contexts that influence if the advice for corrective or preventive practices given to them will actually be accepted and acted upon. These include Knowledge, Attitude, Practice (KAP) surveys or mini-surveys; community walk-throughs, focus group discussions, key informant interviews, getting feedback from stakeholders, social media and media monitoring, etc. A serious attempt must be made to make health interventions and health advices, based on evidence gathered using these methods and other social science approaches.

Advance Planning and using integrated approaches Risk communication is most effective when it is integrated with emergency preparedness, risk analysis and response (risk management). This means that a risk communication plan must be prepared during the preparedness stage. Emergency risk communication planning must occur in advance and be a continuous process with a focus on preparedness and prevention as well as response. Planning should be sensitive to stakeholders' needs. It should be participatory, responsive to the context and incorporate feedback from affected groups.

Ensuring Equity:

All citizens have a right to appropriate information about health risks, including what needs to be done in response to threats to their health. Unfortunately, large segments of society are excluded from routine communication about threats to health. Risk communication must therefore ensure equitable sharing of information to the public and avoid exclusion of marginalized members of society from health action. This means paying attention to the reach of communication, using trusted channels and interlocutors, not using jargon or technical language, use of people's own languages and dialects, adapting messages to people's levels of understanding and education; and ensuring that the actions promoted are those that people can realistically change. Special attention should be paid to analysing power dynamics in communities and taking special measures to reach those hardest to reach (women, minorities, the very old and young, people with disabilities, the poor, migrants and refugees, etc.) Coordinate V.

Proactive internal communication and coordination with partners before, during and after an emergency is crucial to ensure effective, consistent and trustworthy risk communication that addresses both information and public concerns vi.

Be proactive in public communication All public communication, including media outreach and via other preferred channels to the affected populations and stakeholders (even with incomplete info) prevents rumours, misinformation while demonstrating transparency and sincerity vii.

Build national capacity, support national ownership Strengthening policies, plans, trained personnel, platforms, processes, etc. of key stakeholders, including government, NGOs, civil society, journalists and other key national and international players is key to preparedness for effective risk communication for health emergencies

### 7.5 Create an enabling environment for effective risk communication

(i) Establish risk communication systems and structures at the community, district,

regional and national levels.

If not present, then establishing multi-sectoral communication committees/ structures across all levels. ToRs can be expanded depending on the pre-outbreak, outbreak and post outbreak phase in line with each function (See Annex 7B).

(i1) Ensure the communication system has a link to the community leadership structure as they have a strong impact on the community.

A quick assessment of the framework for public health emergency risk communication can be made and this can include:

- Conduct a risk profile

- Identify risk communication needs

- Conduct risk communication stakeholders mapping at all levels and develop

database

- Conduct resource mapping for risk communication plan

(iii) Conduct mapping of languages and dialects; Religions; preferred and trusted means/channels/ and interlocutors (sources) for communication; traditional practices that are relevant for the top priority health risks and use this intelligence to shape risk communication strategies and plans. If not available, then at district, regional level, identify a government spokesperson and ensure he/she is trained in procedures for public communication (iv) In addition to risk communication personnel, all frontline personnel should receive basic training in risk communication (surveillance, contact tracing, case management, social mobilization, community engagement, burial teams, health personnel, volunteers).

(V)

Develop a Risk Communication Plan for Public Health Emergencies at the district as well as regional and national level and ensure key stakeholders are oriented on the procedures for Risk Communication. A sample risk communication implementation plan is shown in Table 10 (Vi) Develop a coordination platform and mechanisms for internal and partner communication for engaging key stakeholders including media outlets; community radio networks; including roles and responsibilities (vii) Have detailed budgets and advocate strongly for resources mobilization, and multisectoral collaboration to implement public health emergency and risk communication activities.

(viii) Create a system for dynamic Listening and Rumour Management Table 7: Template of a risk communication implementation plan Timelines Materials Needed Broad Implementers Indicators Budget Strategy Activities Indicate Indicate Indicate level Indicate the Indicate materials Activity 1 Advocacy and total cost bench mark date/period needed to support of used to measure of activity implementation implementatio the activity activity n partners Activity 2 etc.

Social Indicate level Indicate the Indicate Indicate Indicate materials Activity 1 Mobilization and total cost bench mark date/period needed to support implementation of implementatio used to measure of activity activity the activity n partners Activity 2 etc.

Indicate level Indicate the Indicate materials Indicate Communicati Activity 1 Indicate total cost on activities and bench mark needed to support date/period implementation implementatio of used to measure of activity the activity n partners activity

### 7.6 Communicating before, during and after the public health event

#### 7.6.1 Pre-Outbreak/Routine Risk Communication

A big proportion of communication activities should be implemented in the pre-emergency phase for better preparedness. People managing communication activities should take advantage of the absence of an emergency to build the country's communication capacity and develop communication plans and tools to bring the nation to a high level of communication preparedness. The pre-emergency phase should also be used to develop the necessary sparedness. The pre-emergency communication messages and materials and promote practice of behaviours that can prevent the risk.

Before an outbreak, the following should take place:

- Constitute a Risk Communication Sub-Committee that consists of government and

non-government stakeholders engaged in communication and community engagement.

The Sub Committee should meet routinely to:

- Review past emergency communication interventions to draw lessons learned,

build on successful practices and avoid negative ones

- Collect and analyse epidemiological and social data about periodic disasters and

outbreaks; outbreak seasons of common diseases; expected at-risk communities/populations; as well as accessible and credible channels of communication

- Review or develop the risk communication plan and required risk

communication materials/logistics

- Build capacity of all stakeholders in risk communication and identify/train a

spokesperson to be ready when an outbreak occurs.

- discuss the implementation of risk communication activities and findings from

the community level.

- Alert all relevant entities and notify them on their role/s in case the expected outbreak

occurs.

- Ensure that messages and materials have been developed, pre-tested, approved, and are

ready for production and dissemination.

- Ensure that all required training modules, guidelines and monitoring checklists are

developed and updated.

- Develop and share standard operating procedures (SOPs) for social mobilization and

community engagement and ensure integration of risk communication in the overall emergency response plan.

- Identify and prepare database of stakeholders and partners, such as groups or

organizations that focus on youth or women; schools, religious institutions, CSO,

theatre groups and other community groups that can disseminate messages at the grassroots level and involve them in preparedness activities

- Identify all the channels of communication available to spread the message and assess

the reach and credibility of these channels.

- Produce a 'Response Kit' which includes key frequently asked questions, media briefs,

training manual, micro-planning tools, monitoring checklists/tools, communication plan templates and key IEC messages/materials for rapid distribution. This kit is for the use of communication practitioners at all levels.

- Establish communication lines with media; journalists, radio/TV stations; train them

and keep them continuously up-dated.

- Pre-arrange activities with theatre groups, musicians and traditional community

entertainers.

- Identify and train community health workers, community leaders, religious leaders,

influential people, women's groups, youth groups and other social mobilizers in SBCC and risk communication

- Identify mechanisms for communicating with hard-to-reach and vulnerable populations

(older persons, persons with disabilities, children, the nomadic) and with people who are isolated, in order to ensure that they will have access to health protection information and assistance

- Define communication channels to be used to reach vulnerable groups.

- Disseminate messages that describe actions that the government is taking to protect the

public and health care workers, promote awareness of the coming health threat and preventive behaviours and actions that individuals, families and communities can take to reduce the risk and this can be done through mass media e.g., local community radios, public health address, community drama groups, television, print media, social media (such as Facebook, WhatsApp, Twitter), and websites etc.

- Conduct community engagement activities and build trusted relationships between

those in authority and communities through training, dialogue, consultations, capacity building. It is important to note that effective community engagement relies on having trusted relationships between those in authority and communities, so use every opportunity to strengthen these relationships in the pre-emergency phase.

- Use ongoing health education, health promotion and other means to create, test and

build trust in the systems, panellists that can be used in emergencies for risk communication.

- Set up a call centre, which can be started immediately when the emergency occurs.

- Establish a media monitoring team to monitor the news and social media

- Maintain and update list of media houses

- Establish a pool of risk communicators to deploy during an emergency response

- Develop plans for routine monitoring of misinformation and rumours and set up a media

monitoring system for keeping track of behaviours and practices related to the emergency

Communication/dissemination of public health information when there is no outbreak

- Conduct community sensitization and public awareness using community drama

groups, public addresses, meetings, social media and local community radios

- Conduct ongoing health education

Note that:

- It is important to integrate to the extent possible, social science data that should be

gathered too. Data on the context, socio-cultural information (including education, traditional practices, health seeking and health care giving behavior, and beliefs) relevant to priority hazards and epidemic prone disease should also be obtained. This will help epidemiological data to be contextualized and for real intelligence, be created basing on the risks and shape possible health interventions.

- It is important to organize periodic interactions with stakeholders who will be involved

in risk communication for prevention and preparedness or in response should an event or emergency occur. This includes local, regional or national media, community radios, civil society and stakeholders from other sectors for example, involve the animal health sector where a zoonotic influenza is a priority threat.

#### 7.6.2 Risk communication during outbreak response

During an outbreak response, and when the public is at risk of a real or potential health threat, treatment options may be limited and direct interventions may take time to organize since resources may be few.

Communicating advice and guidance, therefore, often stands as the most important public health tool in managing a risk. The focus of outbreak communication is to promote outbreak control and mitigate disruption to society by communicating with the public in ways that build and maintain trust.

Pro-active communication encourages the public to adopt protective behaviours, facilitates heightened disease surveillance, reduces confusion and fear and allows for a better use of resources, all of which are necessary for an effective response. Pro/active communication also shows that health authorities are in control of the situation and care about the public and build trust between them and the community at large.

People have a fundamental right to information and to participation. In addition to the public health objectives, remember that people have a right to information on protective actions and they have a right to participate in and shape interventions that are acceptable to them.

Figure 14 illustrates a typical epidemic curve which tracks number of cases over time that could occur during an infectious disease outbreak. The yellow area represents the number of cases which could be avoided with the control opportunity of a rapid response to the threat.

The blue arrow indicates the point at which proactive communication plays a crucial role in supporting such a rapid response. By alerting a population and partners to an infectious disease risk, surveillance of potential cases increases, protective behaviours are adopted, confusion is limited and communication resources are more likely to be focused. Effective communication can help limit the spread of a disease and ultimately save lives. It also minimizes damage to societies and economies and can help communities recover faster from a health event or emergency

**Figure 14: Epidemic curve illustrating the importance of proactive communication**

![Figure 14: Importance of proactive communication during an epidemic](uganda-idsr-technical-guidelines-assets/figures/figure-14-proactive-communication-epidemic-curve.png)

FIGURE 1 World Health Proactive Communication Organization in Infection Control Rapid public health response, including proactive communication 190 of real or potential risk 70 60 CASES Opportunity 40 DAY Identify and coordinate partners and other stakeholders during an outbreak Outbreaks usually create fear in the community. Involvement of several different stakeholders sometimes leads to uncoordinated and duplication of effort. Provision of timely and accurate information through a well-coordinated mechanism is important.

Internal coordination of communication among national stakeholders is key during an emergency. The Risk Communication and Social Mobilization Subcommittee has the responsibility of ensuring that there is an internal communication system among national stakeholders to ensure information flows to different government sectors on time.

Partner coordination is another key element during outbreak and event response and is aimed at fostering ownership, effective participation of key players and efficient use of resources. It establishes routine communication structures among health workers, community and partners.

It helps ensure that this vital link is available and functional during an emergency. If a district, national level has a Risk Communication Plan, these would have been addressed in the Plan.

Coordination helps ensure that messages reaching the population are consistent and not contradictory or confusing and thereby promote trust and the likelihood that expert advice will be followed.

The IMT through the PHEOC or through a similar coordination structure at national level may take responsibility for ensuring communications are consistent and reflect the data that has been analysed. Ensure the focus of the communication activities are transparent and accurate, and take into account community experiences and expectations regarding the outbreak.

Distinguish between communication with stakeholders who are experts and those who are part of the response and require a more layman's description and explanation. They and other important interlocutors/panellists such as the media and civil society (and the general population) will require targeted and adapted products and messages. This means that carefully segmenting and targeting audiences, adapting materials, messages and mechanism to suit each of them is essential.

Communicate with the affected community and stakeholders Communication with affected communities and stakeholders, including the media is essential during outbreak and event response. Thus, establishing routine communication structures and processes between the health and community partners helps to ensure that this vital link is available and functional during an emergency.

Options for communicating between the various partners can range from press releases, press conferences, television and radio messages, meetings (health personnel, community, religious, opinion and political leaders), IEC materials (posters, fliers), multi-media presentations (for example, films, video or narrated slide presentations) at the markets, health centres, schools, women's and other community groups, service organizations, religious centres, local community media, Social media (Facebook, Twitter, WhatsApp, etc.), SMS, telephone, handcarried message, Community drama groups/play group; site visits;, email updates and exchanges of communication materials to more formal decision-making committees.

Regardless of the mechanism, ensure that the focus is on transparent and trustworthy communication that considers community experiences.

Ensure the messages:

- Are clear and understandable to the audience: What, why and how it is happening?

What threats to health exist or are likely to occur? What should the public do? Where can people get services or information? What assurances can be given? Are the messages written in an understandable language and to the levels of understanding of the audience? Research shows that risk should not be explained in technical terms.

- Consider these factors: Who is your audience? What do you want your audience to do

after provision of this message? Do they have the enabling environment to do as advised? Are there functioning and accessible services that enable them to follow the

- Promote dialogue: promote two-way communication exchange; listen to audience's

concerns and respond appropriately rather than just informing.

- Demonstrate empathy and care: Are you showing empathy for their suffering? Are

you being too cold and clinical? Are you respectful?

- Are harmonized and consistent: ensure that consistent messaging goes to the public

notwithstanding the different partners involved in dissemination of information. Use message maps and other tools to keep the same frame and logic for the messaging but allow partners to adapt to the context of more segmented audiences. Are messages consistent regardless of who is issuing them? Inconsistent or conflicting messages create confusion and destroy trust in the response and authorities.

- Establish a mechanism of continuous collation of facts and figures of the public

health event NB: Consider pre-testing the messages from similar settings before dissemination In case of rumours, quickly respond to them and any inaccuracies in general and especially within the specific audience where they have occurred. Consider setting up a rumour monitoring system. Widespread damaging rumours should be counteracted through public statements or press conferences. Provide comprehensive information to prevent rumours being generated from your response.

On a regular basis, district and regional responders should meet with the local leadership to give:

- Frequent, up-to-date information on the outbreak and response

- Clear and simple health messages for the media

- Clear instructions to communicate only the information and health education

messages from the IMT by the media Develop and strategically place and disseminate IEC materials e.g. fact sheets, posters, flyers Fact sheets are brief summaries of 1 to 2 pages. They are usually prepared by health staff for consumption by the general public and deal with a single topic or message. For example, a fact sheet on a Cholera outbreak in a district may contain the following information for the community; the cause of Cholera, how it is transmitted, steps for prevention and updates on the number of cases and deaths. The fact sheets could be posted on a bulletin board or distributed to community groups that are planning health education campaigns. Where possible transform the fact sheets into audio products (audio files, short audio recordings on a phone, or scripts), and into visual products (like posters or infographics). These can be used depending on the preference of the audience for audio (oral or visual/written/illustrated communication). See attached sample in Annex 7A.

Distribute also other IEC materials, which have been prepared. Ensure they have been pretested with the target audience to ensure comprehension and meaning.

Develop and distribute public health situation reports during outbreaks In Uganda, public health bulletins are published at national and district level, but during outbreaks, these situation reports (Sitrep) will be produced more regularly and describe the outbreak. These sitreps have a wider audience than just the health staff in a particular district or health facility. They are usually brief (<10 pages) are seen by policy makers, legislators and other decision-makers, and are valuable channels for reaching technical and development partners.

The bulletins/Sitreps contain at least:

- A summary table showing the number of reported cases and deaths to date for each priority

disease

- A commentary or message on a given disease or topic

- Inclusion of any relevant social science data on risky practices, behaviours and other factors.

If a national public health situation report is sent to the district office, display it where everyone can see it. Make copies and distribute to health facility staff. Take a copy of the report with you on your next supervisory visit to show health workers how data produced during outbreak contributes to public health.

Communicating to media The media is a major influence and should be seen as a partner in risk communication.

However, the media is often associated with political or private interests and can therefore have biases of their own. They are also able to find and report on people's concerns, sensationalize stories and may not always be based on facts and evidence. Therefore, it is essential to meet regularly with, brief and educate the media on priority hazards and on response systems and provide them with appropriate information so as to cultivate a respectful and trusted relationship with them. Media will enable a wider dissemination of messages on radio or other appropriate means.

As part of your risk communication plan, determine how you will announce news of the outbreak and then how you will keep the media regularly informed. Often, regular press releases and media briefings are appropriate tools for communicating with the media. If the emergency is complex, convening a workshop with targeted media is helpful to ensure correct information is disseminated, as most journalists have not been trained in medicine or public health.

In addition, it is good to develop media kits which could include fact sheets and community messages about the priority diseases and events.

Ensure prior to the outbreak you have reached out to media and identified the key outlets you will need to work with during an outbreak. Prior to an emergency it is also good, to identify the clearance process for media products and appreciate the following:

- Ensuring prompt and frequent access to experts, officials and spokespersons who will

speak authoritatively and credibly on the issue at hand.

- Provide media training for spokespersons

- Spokespersons must be the ones who speak in lay (understandable) language and explain

scientific ideas and terms well, those who do not speak in jargon and those who illustrate the information with easy-to-understand stories or examples. Talking points could be used with messages as simple as possible and should have latest information. Please ensure that spokespersons identified could also communicate the uncertainty in an evolving event well and admit when they don't know something. Community case definitions and talking points will aid the spokesperson to deliver correct messages.

- Promptly answering journalists' calls as a show of respecting them

- Give them accurate and well explained information.

- Give exclusive stories and interviews to provide a different perspective

- Provide human interest stories

- Give them clear easy to use handouts (written, audio, visual or audio-visual)

- Use examples from the affected communities

NB: Release information to the media only through the spokesperson to make sure that the community receives clear and consistent information.

Ensure monitoring the media daily to see how the outbreak is being reported. Include social media in your monitoring strategy. If you feel that the wrong messages are being disseminated, devise a strategy for how to correct this misinformation.

Communicating to health workers Ensure you communicate regularly with the health workers by providing correct information pertaining the outbreak. It is important to communicate with health staff from different levels about the data sent (including any gaps), results of the analysis of these data and measures that are taken to respond to the potential public health event which they have reported.

Communication can also include providing participating healthcare workers with any outbreak or event response reports for future reference.

Make sure that health workers provide correct information about number of cases (confirmed, in isolation, admitted, recovered, discharged) and any death that has occurred. Also, ensure you provide any changing information regarding case management or any other response intervention Encourage health workers to keep updated, and to update them real-time during an event or emergency using reliable sources such as daily situation reports, press briefs from Ministry of Health, PHEOC, WHO's knowledge transfer platform (www. OpenWHO.org) on common, reemerging and emerging epidemic-prone disease and on risk communication.

Increasingly during emergency response to disease outbreaks, Ministry of Health, WHO and other partners will provide real-time online, off-line or face-to-face training to update healthcare workers and response teams. These provide an opportunity for knowledge and skills updating or for acquiring new knowledge or skills.

- repitition

#### 7.6.3 Risk communication after outbreak response

Prepare an outbreak or event response report After an outbreak or event response has taken place, the response team who led the investigation should prepare a report. The purpose of the report is to document how the problem was identified, investigated, responded to, what the outcome was, decision taken and recommendations made. Make sure that the health unit that reported the initial cases receives a copy of the report.

Evaluate lessons learned in order to strengthen appropriate public responses to similar emergencies in the future.

(a)

Assess the effectiveness of IEC materials

(b)

Assess the effectiveness of the communications team in each phase and area of work.

(c)

Assess the effectiveness of meetings.

(d)

Assess the effectiveness of the internal flow of communications.

(e)

Assess the monitoring of communications and of the media.

Assess the response of the communications media.

(g)

Assess the outputs and outcomes of risk communication and community engagement Periodic testing of the Risk Communication Plan Carry out simulations to test risk communication plan in order to detect possible weaknesses or gaps that need to be corrected before an emergency. Revise the plan based on lessons learnt from the simulation exercise, after action review (AAR) or other assessments done.

WHO provides ready-made desk top and other simulation exercises on www. Open WHO.org For further reading, refer to 1, 14,27,31,44-47

### Annexes to SECTION 7

#### Annex 7A: Sample Fact Sheet

#### Annex 7B: Terms of Reference for risk communication and community engagement

#### Annex 7C: Sample messages for community education

- Hand-washing

- Safe handling of food

- Safe disposal of human waste

- Clean drinking water and storage

- Safe burial of bodies

- Reducing exposure to mosquitoes

#### Annex 7D:

Sample District Outbreak Report

#### Annex 7A: Sample Fact Sheet-Influenza A Virus

Influenza A Virus General information about Avian Influenza A Virus Infections in Humans (Reference http://www.who.int/influenza/human_animal_interface/faq_H7N9/en/) Influenza A H7 viruses are a group of influenza viruses that normally circulate among birds.

The influenza A (H7N9) virus is one subgroup among the larger group of H7 viruses. Although some H7 viruses (H7N2, H7N3 and H7N7) have occasionally been found to infect humans, no human infections with H7N9 viruses have been reported until recent reports from China.

What are the main symptoms and signs of human infection with influenza A (H7N9) virus?

Thus far, most patients with this infection have had severe pneumonia. Symptoms include fever, cough and shortness of breath. However, information is still limited about the full spectrum of disease that infection with influenza A (H7N9) virus might cause.

Why is this virus infecting humans now?

We do not know the answer to this question yet, because we do not know the source of exposure for these human infections. However, analysis of the genes of these viruses suggests that although they have evolved from avian (bird) viruses, they show signs of adaption to growth in mammalian species. These adaptations include an ability to bind to mammalian cells, and to grow at temperatures close to the normal body temperature of mammals (which is lower than that of birds).

What is known about previous human infections with H7 influenza viruses globally?

From 1996 to 2012, human infections with H7 influenza viruses (H7N2, H7N3, and H7N7) were reported in the Netherlands, Italy, Canada, United States of America, Mexico and the United Kingdom. Most of these infections occurred in association with poultry outbreaks. The infections mainly resulted in conjunctivitis and mild upper respiratory symptoms, with the exception of one death, which occurred in the Netherlands. Until now, no human infections with H7 influenza viruses have been reported in China.

Is the influenza A (H7N9) virus different from influenza A (H1N1) and A (H5N1) viruses?

Yes. All three viruses are influenza A virus but they are distinct from each other. H7N9 and H5N1 are considered animal influenza viruses that sometimes infect people. HIN1 viruses can be divided into those that normally infect people and those that normally infect animals.

How did people become infected with the influenza A (H7N9) virus?

Some of the confirmed cases had contact with animals or with an animal environment. The virus has been found in a pigeon in a market in Shanghai. It is not yet known how persons became infected. The possibility of animal-to-human transmission is being investigated, as is the possibility of person-to-person transmission.

How can infection with influenza A (H7N9) virus be prevented?

Although both the source of infection and the mode of transmission are uncertain, it is prudent to follow basic hygienic practices to prevent infection. They include hand and respiratory hygiene and food safety measures; Hand hygiene; Wash your hands before, during and after you prepare food; before you eat; after you use the toilet; after handling animals or animal

waste; when your hands are dirty; and when providing care when someone in your home is sick. Hand hygiene will also prevent the transmission of infections to yourself (from touching contaminated surfaces) and in hospitals to patients, health care workers and others. Wash your hands with soap and running water when visibly dirty; if not visibly dirty, wash your hands with soap and water or use an alcohol-based hand cleanser. Respiratory hygiene. Cover your mouth and nose with a medical mask, tissue, or a sleeve or flexed elbow when coughing or sneezing; throw the used tissue into a closed bin immediately after use; perform hand hygiene after contact with respiratory secretions.

Is it safe to eat meat, i.e. poultry and pork products?

Influenza viruses are not transmitted through consuming well-cooked food. Because influenza viruses are inactivated by normal temperatures used for cooking (so that food reaches 70°C in all parts— "piping" hot — no "pink" parts), it is safe to eat properly prepared and cooked meat, including from poultry and game birds. Diseased animals and animals that have died of diseases should not be eaten. In areas experiencing outbreaks, meat products can be safely consumed provided that these items are properly cooked and properly handled during food preparation.

The consumption of raw meat and uncooked blood-based dishes is a high-risk practice and should be discouraged.

Is it safe to visit live markets and farms in areas where human cases have been recorded?

When visiting live markets, avoid direct contact with live animals and surfaces in contact with animals. If you live on a farm and raise animals for food, such as pigs and poultry, be sure to keep children away from sick and dead animals; keep animal species separated as much as possible; and report immediately to local authorities any cases of sick and dead animals. Sick or dead animals should not be butchered and prepared for food.

Is there a vaccine for the influenza A (H7N9) virus?

No vaccine for the prevention of influenza A (H7N9) infections is currently available. However, viruses have already been isolated and characterized from the initial cases. The first step in development of a vaccine is the selection of candidate viruses that could go into a vaccine.

WHO, in collaboration with partners, will continue to characterize available influenza A(H7N9) viruses to identify the best candidate. These candidate vaccine viruses can then be used for the manufacture of vaccine if this step becomes necessary.

Does treatment exist for influenza A (H7N9) infection?

Laboratory testing conducted in China has shown that the influenza A (H7N9) viruses are sensitive to the anti-influenza drugs known as neuraminidase inhibitors (oseltamivir and zanamivir). When these drugs are given early in the course of illness, they have been found to be effective against seasonal influenza virus and influenza A(H5N1) virus infection. However, at this time, there is no experience with the use of these drugs for the treatment of H7N9 infection.

Is the general population at risk from the influenza A (H7N9) virus?

We do not yet know enough about these infections to determine whether there's a significant risk of community spread. This possibility is the subject of ongoing epidemiological investigations.

Are health care workers at risk from the influenza A (H7N9) influenza virus?

Health care workers often come into contact with patients with infectious diseases. Therefore,

WHO recommends that appropriate infection prevention and control measures be consistently applied in health care settings, and that the health status of health care workers be closely monitored. Together with standard precautions, health care workers caring for those suspected or confirmed to have influenza A(H7N9) infection should use additional precautions Does this influenza virus pose a pandemic threat?

Any animal influenza virus that develops the ability to infect people is a theoretical risk to cause a pandemic. However, whether the influenza A(H7N9) virus could actually cause a pandemic is unknown. Other animal influenza viruses that have been found to occasionally infect people have not gone on to cause a pandemic.

Preventing Human Infection with Avian Influenza A Viruses The best way to prevent infection with avian influenza A virus is to avoid sources of exposure.

Most human infections with avian influenza A viruses have occurred following direct or close contact with infected poultry.

Seasonal influenza vaccination will not prevent infection with avian influenza A virus, but can reduce the risk of co-infection with human and avian influenza A virus.

Because rare episodes of limited, non-sustained human-to-human transmission of HPAI H5N1 virus has been reported, persons should avoid sick patients who have suspected or confirmed HPAI H5N1 virus infection. Health care personnel caring for patients with suspected or confirmed HPAI H5N1 virus infection should wear recommended personal protective equipment and follow recommended infection control measures (standard, droplet, contact, and airborne precautions).

#### Annex 7B: TOR for Risk Communication and community engagement

- Provide risk communication materials and plans

- Conduct rapid assessment to establish community knowledge, attitudes, practices and

behavior on prevailing public health risks/events

- Organize sensitization and mobilization of the communities

- Serve as focal point for information to be released to the press and public

- Liaise with the different subcommittees, local leadership and NGOs involved in

activities on mobilizing communities

- Relay concerns of the communities to the Task Force

- Prepare and submit reports to the NTF/DTF

#### Annex 7C: Sample Messages for Community Education

Improve hand washing Hand-washing with clean water and soap may be the most effective way to prevent transmission of some organisms causing infectious diseases. For that reason, promote hand-washing in every family. Hand-washing is particularly important after defecation, after cleaning a child who has defecated, after disposing of a child's stool, before preparing or handling food and before eating.

Hand-washing is practiced more frequently where water is plentiful and within easy reach. If possible, water for washing should be stored separately from drinking-water. During an epidemic, soap should be provided to those without it. If soap is not available, wood ash or alcohol hand rub can be used to scrub the hands. Do not dry washed hands with dirty cloths.

Air-dry wet hands.

Message:

ARE YOU PROTECTED FROM DYSENTERY (bloody diarrhoea)?

Washing your hands protects yourself and others from disease.

Always wash your hands:

after cleaning a child who has defecated after disposing of a child's stool Message:

ARE YOU READY FOR HANDWASHING?

Do you have

- Clean water and soap (or if you do not have soap, use ash or earth to scrub your hands)

- Clean cloth for drying.

DO YOU PREPARE FOOD SAFELY?

Cooking kills germs

- Thoroughly cook all meats, fish and vegetables

- Eat cooked meats, fish and vegetables while they are hot.

Washing protects from disease Peeling protects from disease

- Only eat fruits that have been freshly peeled (such as bananas and oranges)

KEEP IT CLEAN: COOK IT, PEEL IT, OR LEAVE IT.

Five Ways to Safe Guard Food Keep yourself clean

- Separate raw and cooked food

- Cook food thoroughly

- Keep food at safe temperature

- Use safe water and raw materials

Five keys to safer food 1. Keep Clean The 2. Separate raw Five and cooked Keys 3. Cook food to thoroughly Safer 4. Keep food at safe temperatures Food 5. Use safe water and raw materials Department fod ael and onses (1) pitalin

Safe disposal of Human Waste High priority should be given to ensuring the safe disposal of human waste at all times, and especially during epidemics of diarrhoea. Sanitary systems appropriate for local conditions should be constructed with the cooperation of the community.

Community messages should emphasize:

- Everyone should use latrines properly, including children

- Transfer children's excreta with a scoop or shovel to the latrine or bury in a hole.

- Avoid defecating on the ground, or in or near the water supply.

- Treat or boil all drinking water

When large groups of people congregate, as at fairs, funerals, or religious festivals, ensure the safe disposal of human waste. If there is no latrine, designate areas for defecation and provide a shovel to bury the excreta.

Message:

ARE YOU PROTECTED FROM DYSENTERY (bloody diarrhoea)? DO YOU USE A TOILET OR LATRINE?

Germs that cause dysentery live in faeces. Even a person who is healthy might have dysentery germs.

- Always use a toilet or latrine. If you don't have one - build one!

- Keep the toilet or latrine clean

- Wash your hands with soap (or ash) and clean water after using the toilet or latrine.

KEEP IT CLEAN: USE A TOILET OR LATRINE Clean drinking water and storage

- Community drinking water supply and storage

1. Piped water. To maintain safety, properly chlorinate piped water. To prevent entry of contaminated groundwater into pipes, repair leaking joints and maintain constant pressure in the system.

2. Closed wells. Equip with a well-head drainage apron, and with a pulley, windlass, or pump.

3. Trucked in. If locally available water is likely to be contaminated, drinking water should be supplied by tankers or transported in drums, if it is adequately chlorinated and a regular supply can be ensured. The trucking of water, however, is expensive and difficult to sustain; it is usually considered a short-term measure until a local supply can be established.

- Home drinking water storage and treatment

When the safety of the drinking water is uncertain, it should be chlorinated in the home or boiled.

To prevent contamination of drinking water, families should store drinking water using one of the following types of containers:

1. Covered containers that are cleaned daily and kept away from children and animals.

Water should be removed from the containers using a long-handled dipper, kept especially for this purpose.

2. Narrow-mouthed containers with an opening too small to allow the insertion of a hand. Water should be removed by pouring from the opening or spout.

Water used for bathing, washing and other purposes other than drinking need not be treated and should be stored separately from drinking water.

Safe disposal of bodies The body fluids of persons who die due to diarrhoea or a viral haemorrhagic fever are still infectious. Use extreme caution when preparing the bodies of suspected cholera or viral haemorrhagic fever patients. Encourage safe funeral and burial practices Reducing Exposure to mosquitoes Mosquito control is the main intervention for reducing malaria transmission. It can reduce malaria transmission from very high levels to close to zero. In high transmission areas, mosquito control can significantly reduce child and maternal deaths. Personal protection against mosquito bites represents the first line of defence for malaria prevention.

#### Annex 7D: Sample District Outbreak Report

Sample district outbreak report Title/Description (include disease/condition investigated) Period _ Place (Village, Parish, Subcounty District,) Executive summary:

I. Introduction:

- Background

- Reasons for investigation (public health significance, threshold met, etc.)

- Investigation and outbreak preparedness

II. Methods:

- Dates of investigation

- Site(s) of investigation (health care facilities, villages, other)

- Case finding (indicate what was done regarding case finding, e.g., register review, contact investigation,

alerting other health facilities, other)

- Laboratory specimen collection

- Description of response and intervention (include dates)

- Data management

III. Results:

- Date and location of first known (index) case

- Date and health facility where first case was seen by the health care system

- Results of additional case finding

- Lab analysis and results

- With text, describe key features of results of time, place, and person analysis

- Detailed results by time (epi curve), place (map), and person characteristics (tables) and line lists

- Results of response and evidence of impact

IV: Self-evaluation of the timeliness and quality of preparedness, outbreak detection, investigation, and response Epidemic Preparedness Indicator Yes No Were adequate drugs and medical supplies available at the onset of the outbreak Were treatment protocols available to health workers?

Does the District Task Force regularly meet as part of epidemic preparedness?

Outbreak Detection Date Date Inter Indicator 1 2 val Interval between onset of index case (or occurrence of an unusual cluster at the community level) [date 1] to arrival of first outbreak case at the health facility [date 2] (Target: <3 days)

Interval between initial outbreak case seen at the health facility (or date of outbreak threshold crossing at the health facility) [date 1] and reporting to the district health team [date 2] (Target: within 24 hours) Cumulative interval between onset of index case (or occurrence of an unusual cluster at the community or health facility) [date 1] to notification to the district [date 2] (Target: <7 days) Outbreak investigation Y Indicator No es Were case forms and line lists completed?

Were laboratory specimens taken (if required)?

Interv Date Date Indicator 2 al Interval between notification of district [date 1] and district field investigation conducted [date 2] (Target: within 48 hours) Interval between sending specimens to the lab [date 1] and receipt of results by the district [date 2] (Target: 3-7 days, depending on type of test) Outbreak response:

Date Date Interv Indicator 2 al Interval between notification of outbreak to district [date 1] and concrete response by the district [date 2] (Target: within 48 hours of notification) Evaluation and Feedback:

Date Inte Date Indicator rval 1 2 Interval between end of the outbreak [date 1] and finalization of outbreak report with case forms/line list sent to national level [date (Target: 2 weeks) Yes No Indicator Did the DTF meet to review investigation results?

Was feedback given to health facilities and community?

Evaluation of other aspects of the response:

V.

VI. Interpretations, discussion, and conclusions:

VII. Recommended public health actions:

Comment on the involvement of the following levels/stakeholders: community, health facility, district, partners, Regional, and national.

District Task Force Chairperson:

Name_ Signature_ District Health Officer:

Signature Name Date report completed:

SECTION 8 MONITOR, SUPERVISE, EVALUATE AND PROVIDE FEEDBACK TO IMPROVE SURVEILLANCE AND RESPONSE

## Section 8: MONITOR, SUPERVISE, EVALUATE AND PROVIDE FEEDBACK TO IMPROVE SURVEILLANCE AND RESPONSE

### 8.0 Monitor, supervise, evaluate and provide feedback to improve the surveillance

and response system Monitoring of surveillance and response systems refers to the routine and continuous tracking of planned surveillance activities (for example, reports are received on time), while evaluation is done periodically (for example annually) assesses whether surveillance objectives have been achieved.

During support supervision, supervisors and health professionals work together to review progress, identify gaps/challenges, potential causes and develop feasible solutions to address them. Sustainable supervision and feedback, contributes to improved performance of disease surveillance systems.

Benefits of routine monitoring and evaluation of IDSR system include:

Evaluation Monitoring

- Tracking progress of implementation of

- Ensures that the surveillance system

planned activities and ensuring that meets the objectives for which it was planned targets are achieved in a timely formulated;

- Documents the status of, and any

manner Tracking progress of targeted indicators change in the performance of the of the quality and attributes of the system.

system; Identifying problems in the system in Provides evidence, based on which order to institute corrective and surveillance objectives, preventive measures in a timely manner; implementation strategy and planned Ensure that all implementers of the activities can be implemented and/or systems are held responsible and modified; resource accountable for their defined activities.

Enables planning of

- Other stakeholders can receive

allocation;

- Provides explanations

for information on the performance of the achievements and failures in the surveillance system.

system;

- Provides specific recommendations

for improving the system.

Monitoring and Evaluation of the surveillance system enables identification of problems, finding their solutions and also enables feedback measures to take place.

Questions to help evaluate include:

- Are surveillance objectives for existing activities being met?

- Was surveillance data used for taking public health actions?

- Did surveillance, laboratory and response activities have an impact on the outcome of

health events in the facility / district?

### 8.1 Identify targets and indicators

Using indicators can be helpful in measuring the extent of achievement for a particular program or activity. Indicators are signs of progress - they are used to determine whether the programme/intervention is on its way to achieving its desired objectives and goal. This achievement is then compared to the overall recommended performance standards. Some disease-specific surveillance indicators also exist and can be used to monitor quality of the surveillance system e.g., AFP and Measles.

Indicators are also used to assess the performance of surveillance system, whether it is reaching its targets and objectives. For example, a district may have an objective of reaching 100% completeness of reporting on a weekly basis. An indicator can be developed to measure the proportion or percentage of facilities that are reporting. This proportion is then compared with the desired objective or target, and can be used to evaluate progress and, therefore, the quality of the service or activity.

#### 8.1.1 Use indicators in accordance with national goals and specific plans

Use indicators according to national goals and specific plans to improve IDSR activities in the district. Select the indicators that are most relevant to the district's plan for improving surveillance this year and that will provide information that the district can use.

Select data for measuring the indicators After you have selected relevant indicators, specify the numerator and the denominator. For example, if a district's objective is for all health facilities to keep trend analysis (lines) for selected priority diseases, the numerator and denominator are defined as follows:

Indicator: the proportion of health facilities in the district that have the current trend analysis for priority diseases.

Numerator: the number of health facilities that have current trend analysis for priority diseases Denominator: the total number of health facilities in the district Ensure sources of data are available Each level should make sure that the level it supervises has the following sources of data available. For example, the national level has data available from the district and regional level to conduct the required monitoring activities.

Table 8: Types of sources of data at various levels Community Health Data source District Regional National Level Facility Monitoring chart for tracking indicators (Sample charts are in Annex &A.) Outpatient register Inpatient register Laboratory register Health facility reporting forms Case-based and/or line listing reporting forms Outbreaks investigations reports Log of suspected outbreaks and rumours Supervisory reports from health facility, district, /region, national Laboratory reports/results received

### 8.2 Monitor the core functions for IDSR at district level

The indicators related to the core functions measure the processes and outputs from the surveillance system. This sub- section will highlight the key indicators at various health system levels as regard to the core functions. The core functions and their indicators are described in detail from Annex &A-D and also in the IDSR matrix (Annex A of the introduction section) The core functions are;

(i) Identify cases and public health events

Case detection is the process of identifying cases and outbreaks. Some indicators include proportion of health facilities using Standard Case Definitions (SCD) to identify IDSR priority conditions.

(i1) Report Cases and Events Reporting refers to the process by which surveillance data moves through the surveillance system from the point of generation to the next level. It also refers to the process of reporting suspected and confirmed outbreaks as well as notifying under the IHR 2005 using the decision instrument in Annex 2A. Indicators include Proportion of complete surveillance reports submitted to the next level (ili) Data analysis and interpretation Data analysis is the systematic process of examining data to generate relevant information for timely and appropriate public health action to be taken. Examples of indicators here could be Proportion of priority conditions/diseases for which a current line graph is available.

(iv) Investigate and confirm suspected cases/outbreaks Examples of indicators for monitoring this core functions include Proportion of suspected outbreaks of epidemic prone conditions/disease notified to the next level within 24 hours of crossing the epidemic threshold and Proportion of investigated outbreaks with laboratory results

(v) Prepare

Epidemic preparedness refers to the existing level of preparedness for potential outbreak and includes availability of preparedness plans, stockpiling, designation of isolation facilities, prepositioning of resources for outbreak response. Examples of indicators include Proportion of health facilities with stock of key items (for example PPE, specimen collection kits, caseinvestigation forms, I.V fluids, treatment kits) that are important in response and Proportion of districts with emergency preparedness and response plans (vi) Respond Examples of indicators for monitoring response include Proportion of districts with functional District Task Force (DTF) (vii) Provide Feedback Feedback is a process in which the effect or output of an action is returned (fed-back) to modify/guide the next action. Some examples of indicators for feedback include Proportion of districts producing regular epidemiological bulletins/reports and Proportion of health facilities with at least one IDSR technical support supervision visit in the previous quarter.

NOTE: While all indicators for the IDSR core functions are important, WHO AFRO will measure the overall performance of core functions of IDSR in the countries, by using 16 key performance indicators explained in Annex 81.

### 8.3 Monitor the quality of IDSR activities at district Level

The quality of the surveillance system is defined by attributes such as the ones highlighted in the figure below.

**Figure 15: Attributes/Qualities of a Surveillance System**

![Figure 15: Attributes of a quality surveillance system](uganda-idsr-technical-guidelines-assets/figures/figure-15-surveillance-system-attributes.png)

Completeness Timeliness Reliability Usefulness Acceptability Quality of Sensitivity Surveillance System Flexibility Data quality Simplicity Representativ Specificity eness Periodically the quality of the surveillance system should be assessed based on these attributes.

Surveillance attributes can be evaluated using both quantitative and qualitative methods.

#### 8.3.1 Monitoring other attributes for assessing the quality of the IDSR system

Some other key important attributes are summarized in the table below and can be used to assess the quality of surveillance system during periodic evaluation assessments (Table 9).

Table 9: Summary of other attributes for assessing quality of surveillance system.

Attribute Examples of some questions to assist in Definition assessment Describes if the surveillance Usefulness Is the system e.g., the early warning system able to detect outbreaks carly?

system has been able to contribute to the prevention and control initiatives or has been useful in Example: A useful system over time must contribution to the performance measures demonstrate that a certain intervention which has been instituted has worked. In a malaria program, e.g., Usefulness of surveillance data collected over time might show if ITN has data in an early warning system been useful in reducing incidences of malaria among children under five Is the system simple? e.g. is the standard case Simplicity refers to the structure Simplicity definition understandable?

of the system and the ease of implementation from the end user to those at higher levels Does it have multiple reporting structures?

Example: A health worker has to report maybe to the district as well as to another vertical program if a disease is under that program Acceptability of a system is a Acceptability How is the participation rate of health facilities?

reflection of the willingness of the surveillance staff to implement the How is the completeness of reports? Example:

system, and of the end users to number of health facilities submitting reports on accept and use the data generated time through the system Representativeness Representativeness refers to the Is the system covering all geographical areas to degree to which the reported cases ensure accurate capture of cases?

reflect the and occurrence distribution of all the cases in the NB: A good system should be able to cover all population under surveillance population even those who are marginalized the Data For completeness one can examine the reflects quality Data quality percentage of "unknown" or "blank" responses to completeness and validity of the items on surveillance forms data recorded in the public health surveillance system.

NB: The validity depends on the quality of data.

Error-prone systems and data prone to inaccurate measurement can negatively affect detection of unusual trends.

For further information on the other unmentioned attributes above, please refer to Centres for Disease Control and Prevention (CDC) (2001). Updated guideline for evaluating public health surveillance systems. MMWR: 50 (RR-13); 1-35.

### 8.4 Timeliness of Reporting

The single most important measure of timeliness is whether data are submitted in time to begin investigations and implement control measures. Timeliness of reporting should be measured against standards developed by each country in accordance with the timelines set by WHO AFRO. Important aspects of timelines of reporting in a communicable disease surveillance system include:

- timeliness of immediate notification, i.e., within 24 hours

- timeliness of weekly reporting

- timeliness of monthly reporting

#### 8.4.1 Monitor timeliness of detection and notification of immediately reportable

diseases Monitor how well the system is able to detect immediately notifiable diseases, conditions or events. Monitor the interval between symptom-onset of the first known case and when the case was seen in the health facility. If this interval is too long, it will seriously affect the health outcome of individual patients and will alter the spread of the outbreak.

Intervals to monitor for detection of immediately reportable diseases include monitoring disease detection timeliness from the community to the health facility (within 24 hours of onset of illness) and the health facility to the next level (district-within 24 hours of onset of illness), and from the district to the national level (within 24 hours).

Timeliness in notification of events will involve monitoring reporting timeliness from the community to the health facility (within 24 hours of disease detection/identification), from the health facility to the next level (district-within 24 hours of disease detection) and from the district to the national level (within 24 hours). Mounting a concrete response will be assessed from the time the threshold is reached (within 48 hours).

#### 8.4.2 Monitor the timeliness of weekly reporting

An important indicator of a quality reporting system is the timeliness and completeness of reporting at each level. When reports are sent and received on time, the possibility of detecting a problem and conducting a prompt and effective response is greater. If they are incomplete, then the information cannot effectively describe the problem. If reports are late, or are not submitted, the aggregated information for the district (or other administrative area) will not be accurate. Outbreaks can go undetected, and other opportunities to respond to public health problems will be missed

#### 8.4.3 Monitor the timeliness of monthly reporting

Routinely monitor the receipt of reports against the reporting timelines to evaluate the timeliness of reporting. A sample monitoring tool (Annex 8G) may be used. For example, use the record of reports received to: Measure how many health facilities submitted reports for a given month

against the number of units expected to report; Identify which health facilities have reported; Measure how many monthly reports were timely.

### 8.5 Completeness of Reporting

Completeness in surveillance can have varying dimensions and may include the following:

#### 8.5.1 Completeness of health facilities submitting surveillance forms

Completeness of reporting refers to the proportion of health facilities that submitted the surveillance report irrespective of the time when the report was submitted. Computing completeness of health facility surveillance reports can:

- Provide a trend analysis on completeness of reporting for each of the surveillance reports

over a period of time; and assist in identifying each health facility performance.

- It can also further trigger investigation for reasons for poor performances and possibly

help to identify solutions to improve poor performance.

#### 8.5.2 Completeness of case reporting

Completeness of case reporting refers to the match between the number of cases reported and the actual number of cases detected. This can be obtained by comparing the number of the reportable conditions reported to the next higher level over a period with the number of cases recorded in the patient register over the same period.

#### 8.5.3 Completeness of surveillance data

Completeness of surveillance data is the match between the expected data requirement and what is reported. The following questions are useful in determining completeness of surveillance data and its implications on public health actions.

- Are all the data on each of the required variables in a surveillance form collected,

registered, validated and compiled?

- If not, which variables are not routinely collected and what could be the challenge?

- What is the implication of the missing data on the quality of the surveillance data?

- How can this problem be resolved?

### 8.6 Report timeliness and completeness to other levels

When routine reports or line-listed records of the number of cases are sent to the regional or national level, also send the necessary data for timeliness and completeness. This will help the other levels understand the situation more clearly and evaluate the quality of the data that is being sent. For example, if the report to the national level states that two cases of measles were detected during the week/month, it should also include information about the number of health facilities that have reported. It will make a difference to the other levels when they evaluate the information if the two cases occurred with only 20% rather than 100% of the facilities reporting.

#### 8.6.1 Identify problems and take action

If the monitoring information shows that a health facility has not provided a report, or if the report is not on time, contact the surveillance focal point at the facility. Work with the designated staff to identify what has caused the problem and develop solutions together (for example, find out if a reliable supply of forms or other reporting method such as text messaging is available). Explain to the facility staff the benefits of collecting good quality data and reporting it in a timely manner. For example, this can help them to detect outbreaks, improve medicines and supplies forecasting, and improve overall health facility management.

Additionally, ask if the facility has a new staff and is yet to receive orientation on the procedure for reporting. Or find out if health facility staff receives feedback about case reports they have generated and/or whether resources are available to take action as a result of the information.

Make plans with the health facility to find solutions for improving the situation. Explain that, when information is complete, the district can assist health worker more efficiently with planning and responding to outbreaks. For example, if lack of supplies is a problem, the district can use the reporting information to advocate with higher levels in the system.

### 8.7 Monitor the quality of surveillance activities at community level

Monitoring CBS system is equally important as monitoring health facility, districts and regions.

Community health workers/community focal persons/Village Health Teams (VHTS) involved in the system must understand the benefit of the system, and that their input is valued and can assist in improvement or adaptation of the system to work better for the community.

Qualitative feedback from VHTs and the community is an essential part of contextualizing and understanding quantitative CBS data. A system should be in place from the beginning to capture community and VHTs' feedback and this may involve one or more of the following approaches;

- Open and regular community meetings where all issues are noted and acted upon.

- Focus group discussions with VHTs and/or community leaders.

- Suggestions and complaints box (es) for use in the community.

- Appointment of a community representative(s) to gather feedback and complaints.

- Feedback platforms such as mobile phones can be used by the VHTs to give feedback

There should also be community driven reporting and data analysis, whereby the communities are supported to report and undertake their own data analysis. Communities can be provided with basic materials to record the type of occurrences they report and the resulting actions, as well as recording outbreaks or events that occurred but did not trigger an alert so that triggers can be adjusted. Some performance indicators listed below (table 8.3), are examples of indicators for CBS.

Table 10: Indicators for community-based disease surveillance Definition Indicator Data source CBDS Number of An alert is unofficial information about a disease, condition or event of public health importance which may be true or reports alerts/signals detected invented CBDS Proportion of Numerator: Number of alerts responded to within 24hr- 48hr reports and alerts/signals response responded to within Denominator: Total number of alerts detected from CBDS 24hr-48hr reports focal person NB: responding to a signal/alerts is defined as visit by the nearby health facility/community health worker to verify if signal/alert is true, for case investigation, case management, health promotion, community sensitization and distribution of materials (Must be defined according to response plan) CBS and Numerator: Number of true events detected Proportion of response alert/signals which Denominator: Total number of signls/alerts reported are true events reports

### 8.8 Support supervision for improving IDSR activities

Support supervision is a process of helping to improve work performance continously.

Supervision is not an inspection. Rather, good support supervision aims to sustain good quality services rather than finding things that are wrong. In a good support supervision system, supervisors and health workers work together to review progress, identify problems, decide what has caused the problem and develop feasible solutions.

#### 8.8.1 Steps for conducting supportive supervision:

(a) Ensure availability of terms of reference and Standard Operating Procedures

(SOPS) for surveillance focal persons Terms of reference and SOPs are the basis for conducting supervision and assessing performance.

Review the terms of reference and SOPs of surveillance focal persons who have a role in the surveillance and response system. Make sure that the terms of reference state: the surveillance tasks to perform, Whom the focal person reports to and a defined scope of work and ensure that SOPs are adhered to in practice

(b) Prepare a supervision plan

Include surveillance and response targets in the overall plan for supervision in your district.

Districts should monitor health workers performance through conducting supervisory visits at least once quarterly for each health facility.

Ask health facility in-charges to make a schedule of the supervision they will conduct over the next year in their own facilities and to any community sites that report to the facility.

Make sure that transport is available for supervision and for surveillance activities that require transportation. For example, coordinate travel or logistics for surveillance supervisory visits with visits made by other programs or activities.

Include other health facilities in supervision of district surveillance activities such as private health facilities, pharmacies, drug-shops, and community health facilities in the overall plan.

(c) Use a supervisory checklist

Each health facility has unique problems and priorities that require specific problem solving and corrections. To maintain the positive motivation of the health facility, staff for making the improvements, consider developing a graduated checklist to guide the supervisory visit. The items listed in a graduated checklist (such as the one in Annex 8H) are some of the examples of achievements that a health facility can be evaluated on. Always refer to Annex (8 A-D) and look for additional examples to evaluate for each core surveillance function at the health facility level. Revise the supervisory checklist accordingly. Use it during future visits to help health worker monitor their activities and progress towards an improved system.

During the visit, use a checklist to monitor how well health workers are carrying out the recommended surveillance functions. For example, a district surveillance focal person visiting a health facility for a supervisory visit should verify the following:

Check the health facility register to see if the case diagnoses correspond to Identify the recommended standard case definition Check the register to see if all the columns are filled out correctly Register cases Confirm cases Compare the laboratory records for priority diseases/ conditions with the number of cases seen in the clinic for the same period of time.

Review reports for the most recent reporting period. Compare the number Reporting of cases of priority diseases/conditions that were reported with the number recorded in the register.

Check the date on which the case report was sent against the date recommended for sending the report.

Check the reports to make sure they are complete and accurate.

Review and Verify that trend lines are prepared and kept up-to-date for priority diseases/ conditions. Ask to see the "Health Facility Analysis Book,"/ analyse data charts or the electronic health facility data in your district. Look to see if the trend lines for selected diseases are up to date.

Preparedness Look at the stocks of emergency drugs, supplies and PPE to be sure there is an adequate supply.

NB: The questions to be answered during the supervisory visit can be adapted or modified to meet the specific concerns and extent of progress towards an integrated surveillance system within the health facility

(d) Conduct supervisory visits

Conduct regularly scheduled supervision at all levels to ensure that:

Appropriate supplies (e.g., forms, job aids etc.) and required standard case definitions/ guidelines are available.

Health workers know how to identify and use standard case definitions to record suspected cases of priority diseases seen in their health facility.

Priority diseases are recorded in the case register according to the standard case definition.

Data is analysed in the health facility to identify thresholds to take action both for routinely reported priority diseases (diseases of public health importance) and case-based diseases (epidemic-prone diseases, and diseases targeted for eradication or elimination).

Reported cases of diseases, conditions, or events for which a single case is a suspected outbreak or public health emergency are investigated promptly (for example a single confirmed case of Ebola, cholera or polio, maternal death, MDR/XDR TB).

Response takes place when outbreaks or other public health events are confirmed, or when problems are identified in routine reporting.

Response actions are monitored and action is taken by the health facility to improve surveillance and readiness for outbreak response.

Make sure during the visit to:

Provide feedback to health workers. Let the health workers know what is working and what is not working. Also give feedback on how the data reported previously was used to detect outbreaks and take action to reduce illness, mortality and disability in the district. If improvements are needed, discuss solutions with the health workers.

Provide on -job training as needed if a problem is identified.

Follow up on any request for assistance such as for emergency response equipment or supplies.

If a solution to a pre-existing problem was identified in a previous visit, check to see how well the solution has been implemented. Find out if problems are still occurring and modify the solution if necessary. Ensure that both the supervisor and supervisee sign the supervision reports and also provide dates when the supervision was done.

(e) Write a report of the supervisory visit

Report achievements that were identified during the visit. Also state the follow-up actions that were planned with the health worker and any requests for additional resources, funds or special problems.

(1) Use supervisory visits to improve surveillance activities in the district Visits of surveillance supervisors and regional or district disease control programs are good opportunities to discuss and improve disease control in your district. For example, if a national Malaria Control program person visits the district, you might discuss why the inpatient malaria

deaths have not been declining. You can ask about additional ideas or resources that the malaria control program can provide.

### 8.9 Providing feedback for improving IDSR activities

In most cases, health facilities and districts reliably report surveillance data to the next level as required. When the district or regional or central staff receive data, they should respond to the health facilities that reported it. The purpose of the feedback is to reinforce health workers effort to participate in the surveillance system. Another purpose is to raise awareness about certain diseases and any achievements of disease control and prevention projects in the area.

Feedback is classified as supportive when it reinforces and acknowledges good performance, and (ii) corrective when a change in behavior and improvement is required. It also strengthens the communication and spirit of team working. The feedback should be both vertical and horizontal targeting different audiences as provided by different levels in the health system.

Effective feedback should be;

- Specific to ensure the recipient understands the subject of the feedback

- Should be based on the report submitted or the actual events and activities observed in

the field

- Be given as soon as possible after receiving the report or field visit, so that the recipient

will remember the activities that should be either sustained or corrected If the facility does not receive information from the next level about how the data were used or what the data meant, health workers may think that their reporting is not important. As a result, future reporting may not be as reliable because health workers will not know if the information they sent to other levels was important or necessary. They will have a good understanding of the health situation at their own level, but they will not have the information they need for characterizing the situation at a district or national level. At the community level, feedback includes building relationships, communicating and coordinating with other community key informants, resource persons and existing formal and informal networks for information dissemination and reporting.

Feedback may be written, such as a monthly newsletter/bulletin, emails, WhatsApp, SMS or periodic official information like publications or it may be given verbally through telephone call or periodic meetings. Although this section focuses on district level feedback, this can also be applied in health facility and national levels. Feedback may also be given during supportive supervision carried out by Districts to health facilities, or Region to Districts or National to districts and regions. The supervision can be on performance of health programs and feedback can be provided during these visits.

#### 8.9.1 Develop and disseminate routine epidemiological bulletins

Feedback should also be given periodically on IDSR priority diseases/ conditions, and this can be through weekly, monthly or quarterly epidemiological bulletins. The bulletins provide information on disease patterns and achievement of program objectives in the country. They are usually brief and are important for reaching policy makers, legislators, development partners, program technical staff and stakeholders. As a minimum, they contain:

- A summary table with the number of reported cases and deaths to date

- Community/health facility signals (alerts) reported and responded to

- A commentary or message on a given disease or topic

- Any relevant social, economic or cultural information or data on the context that can

lead to the creation of real intelligence regarding an event.

A sample of a public health bulletin is shown in Annex 8J of this TG.

#### 8.9.2 Develop information summary sheets

An information summary sheet is a report that presents data and its interpretation in a table or other graphic format. For example:

At a staff meeting, or during a supervisory visit, give a verbal report or comment about the data that were reported by the health facility during a given period.

- 

Display the data in a simple table. Sit with the health worker and show them the data.

Talk together about the likely conclusions that can be drawn. Consider conclusions not only for the health facility, but also for the district as a whole.

Prepare a single sheet with a simple table that shows how the data reported for this period are different from the data reported for some other period or target population. For example, show the number of cases of diarrhoea with dehydration in children less than 5 years of age from the same period last year. Compare them with a corresponding period this year, after a safe water project was implemented in a high-risk area, for example, use the summary sheets to support requests made to higher levels for additional funds, supplies and resources.

#### 8.9.3 Develop district newsletters

The purpose of a district newsletter is to provide shorter updates than those provided in a more detailed feedback bulletin. The district newsletter is useful for informing and motivating health workers. The target audience for a newsletter could be health workers in the district. The newsletter can be 2 to 4 pages long and produced simply.

Examples of articles that could be carried in a newsletter are:

- Summary of national or district data for a given priority disease

- Report of progress towards a specific public health target

- Report of a specific achievement towards public health by an individual or group of health

workers

- Description of special events or activities (for example, a change in market day)

### 8.10 Evaluate effectiveness of the performance of IDSR strategy

The purpose of evaluation of a surveillance system is to assess its effectiveness in terms of timeliness, quality of data, preparedness, case management, overall performance and using the indicators to identify gaps or areas that could be strengthened. A comprehensive evaluation should, thus, include the surveillance system and if already available the IDSR Implementation Plan. The evaluation of the surveillance system should:

- Show to what extent the desired outputs and outcomes are achieved;

- Provide explanations for achievements, disparities and failures;

- Document the quality of system and demonstrate any changes in its performance;

- Demonstrate the extent to which the overall surveillance objectives are achieved.

Depending on the development status of surveillance in a district, select indicators for evaluation that will provide information that relates to the district's priorities and objectives for the year. If there is already an IDSR implementation plan with clearly defined objectives, then it is appropriate to conduct mid-term and end-of-term evaluations. Otherwise, surveillance systems should be evaluated every 2, 3 or 5 years.

#### 8.10.1 Key steps in evaluation

Define your objectives Objectives should be simple, measurable, attainable, realistic, and time-bound (SMART).

Development of evaluation indicators Indicators should be identified for each of the evaluation objectives, and should be harmonized as much as possible with the monitoring indicators.

Development of evaluation methods and tools Based on these indicators, an evaluation protocol should be developed describing how the evaluation will be conducted, methods, target group, data sources, data collection methods, and plan for data analysis and utilization Identify people to conduct the evaluation Determine who will be the evaluators; people within the districts, people outside the district, or a mixture including partners. Depending on the scope of the evaluation, its purpose and the available resources, a decision should be made during the planning stage on who should undertake them.

To ensure objectivity and transparency during the evaluation process, a blend of self/ internal evaluations and external evaluations should be conducted periodically.

#### 8.10.2 Conducting the evaluation

Compile and organize monitoring data and other results The district health office should summarize the surveillance data received from all health facilities in the catchment area, and submit the compiled report to the national and regional as appropriate. The submission of the report should not be delayed by late reports. Late reports may be submitted when they arrive. Follow up with health facilities who did not report or who consistently provide late reports.

Help the health facility to solve any problems that prevent them from submitting their summary reports on time. Provide feedback to health facilities about the indicator results on a regular basis.

The Community Health Department in the regional referral hospital should compile and submit the EPI/IDSR quarterly reports to the national level.

The national level should compile the surveillance data received from all the regions. The national level should look for epidemics that were not identified by the districts. Follow up with areas where reporting continues to be unreliable or does not happen at all. Support the regions in providing assistance to the districts when they evaluate the measurements and take action to improve the situation. Provide feedback to each of the levels about the national, provincial/regional, district and health facility levels.

Use a monitoring chart such as the one on the next page to monitor performance of the indicators at your level. Share these results with the staff in your catchment level. Acknowledge successes and help health worker to maintain the positive progress. When problems occur, talk together about what is causing the problem and how it can be solved. Seek assistance of the next level as needed for obtaining additional help or resources.

Gather data from several sources. For example:

- Review the objectives for the year listed in the district's annual plan for improving

surveillance and response.

- Gather the monthly summaries of cases and deaths reported to the district, spot maps,

and other analysis results performed by the district.

- Collect any results from special surveys or studies that were done in the district over the

last year.

- Include case investigation forms and reports of outbreak response activities that took

place in the district.

- Gather summary information from the community and also from health worker

Analyse data As you evaluate the summary data for the year, consider:

- Were the reports complete, on time and accurate?

- What were significant changes in disease or event trends during the year? If an increase

occurred, was the problem identified?

- If additional cases are still occurring, why are they occurring? Where are they occurring?

- Were appropriate and timely actions taken in response to the surveillance data?

- Were supervisory visits conducted and follow up tasks carried out as planned?

- Did the community feel that response activities were successful?

- Were any actions taken to address health worker requests or suggestions about services

or surveillance?

- Were appropriate measures taken to prevent similar events?

Identify problems and their causes If expected targets or level of performance against any indicator were not met, identify the cause. Together with the district team and facility staff suggest possible solutions.

Update plans for improvements of the IDSR system Include in the district plan successful activities that should continue. Also include feasible solutions selected as a result of analysis of the year's annual evaluation. For example:

- State the new activity and its objectives.

- Specify the personnel who will carry out the activity.

- Estimate the cost of the activity.

- Develop a timetable for the activity. Define the sequence of activities in a logical order.

- Specify the logistics for the new activity (equipment, personnel, transportation, resource

allocation).

Provide feedback to health facilities about the evaluation Provide a report and give feedback to health facilities and other stakeholders in the district about the results of the evaluation activity highlighting:

- What the objectives were for the year.

- Achievements

- Likely reasons for variation between what was planned and what was achieved.

- Recommended solutions and prioritized activities for improving surveillance and

response in the district.

For further reading, refer to 2,455,7,8,34

### Annexes to SECTION 8

Annex &A: Indicators for monitoring IDSR core functions at the health facility level

#### Annex 8B: Indicators for monitoring IDSR core functions at the district level

#### Annex 8C: Indicators for monitoring IDSR core functions at the regional level

#### Annex 8D: Indicators monitoring IDSR core functions at the national level

#### Annex 8E: Monitoring Chart for performance of IDSR indicators at health facility level

#### ANNEX 8F: Monitoring chart for performance of IDSR indicators at district, regional level

#### Annex 8G: Sample form for recording timeliness and completeness of weekly / monthly

reporting from the health facility to the district

#### Annex 8H: Checklist for monitoring IDSR activities at the health facility

#### Annex 81: Indicators for monitoring the performance of IDSR at Member State level

#### Annex 8J: Sample Public Health Bulletin

When to be Weekly done Quarterly Weekly Weekly Weekly Daily Target 100% of all diseases (n=19) 100% 100% notifiable 90% 80% 80% information Source of Health facility noticeboard, Weekly 033b HMIS forms at suspected outbreaks Event based alert log records, booklets and in Routine summary reports Facility notice board Health facility alert desk for Routine summary reports facility Weekly 033b HMIS forms at reports facility Routine summary reports and case-based or line listing Interviews charge (physical or electronic) Purpose 227 The practice of health facilities Measures the practice and system to capture unusual Measure the ability of the capacity to analyse surveillance Correctly identifying and filling The practice of health facilities cases/events in submitting complete events level data in submitting timely analysis information to use for further surveillance reports to the next Measures reporting of surveillance reports to the next level surveillance data with detailed Indicator Proportion of complete surveillance reports submitted to Availability of Standard case definition (SCD) and Numerator: Number of surveillance reports submitted Existence of a mechanism to capture unusual or Denominator: Total number of reports expected from based forms or line list current line graph is available.

Denominator: N/A Numerator: N/A Numerator: Number of cases of priority diseases diseases/conditions (n=19) the district (completeness) current line graph is available.

Denominator: Number of SCDs at the health facility Numerator: Total number of notifiable diseases (n=19) Denominator: Total number of cases of diseases surveillance reported with case-based forms or line lists.

Numerator: Number of priority diseases for which a Denominator: Total number of reports expected from Proportion of priority diseases/ conditions for which a example social media platforms) selected for case-based surveillance reported with case- Proportion of cases of priority diseases for case-based Denominator: Total Number of priority public health events from non-routine sources (for IDSR forms/registers on time to the district selected for case- based surveillance that occurred in the the health facility submitted to the district the district (timeliness) Numerator: Number of complete surveillance reports Proportion of surveillance reports submitted on time to the health facility health facility Function IDSR Core Analysis and Interpretation Identify Reporting

#### Annex 8A: Indicators for monitoring IDSR core functions at the health facility level

Annually Weekly Weekly Monthly Monthly Monthly Monthly N/A 80% 80% 80% 80% 80% Lab register, Results Dispatch System (RDS) Health Facility in Charge Facility notice board Laboratory register H/F Inventory (Stock cards/ Observation stock book) registers Health facility log of Laboratory register, OPD suspected outbreaks and alerts 228 timely reporting of outbreaks Measures early detection and Timely manner Measures the practice and Measure preparedness of Health interpretation functionality Evidence of Measure capacity to the specimen referral network surveillance data data analysis and Measure preparedness of a Measures the functionality of Refer samples in a facility to respond to PHEs facility to respond to PHEs and the reference lab capacity to analyse and interpret routine laboratory Denominator: Total number of samples of suspected current lab data analysis is available.

Numerator: Number of samples of suspected cases Availability of All hazard's emergency preparedness Proportion of priority diseases for which an updated Numerator: Number of suspected outbreaks of Proportion of suspected outbreaks of epidemic prone Numerator: Number of priority diseases for which a disease and other PHE notified to the district level Numerator: N/A cases sent to the lab Denominator: N/A Numerator: N/A within 24 hours of surpassing the epidemic threshold Denominator: Total number of suspected outbreaks of Numerator: Number of priority diseases for which an epidemic prone diseases notified to the district within 24 Denominator: Total number of suspected cases Denominator: Total Number of priority diseases Numerator: Number of suspected cases for which Denominator: N/A predetermined TAT emergency response (see kit) *** spot map is available.

Proportion of priority diseases for which there is current whose lab test results have returned within the Proportion of specimens from suspected cases collected lab data analysis (if a health facility has a laboratory) epidemic prone diseases in the health facility Denominator: Total Number of priority diseases (n=19) hours of surpassing the alert threshold and response plan updated spot map is available.

samples were sent within 24hrs Availability of prepositioned key supplies for results are returned within predetermined turn-around- Proportion of samples of suspect cases whose lab test within 24 hours of alert time (TAT) confirmation of suspected outbreaks Investigation and Prepare

Quarterly Quarterly Quarterly Quarterly Quarterly Annually Monthly Monthly Depends on Depends on 100% 100% disease disease records Observation Observation Minutes from Health Facility Routine reports and outbreak Routine reports and outbreak investigation investigation Observation Community feedback reports Training reports 229 Measures continuous healthcare services) Measure response activities nosocomial infections mechanism nosocomial infections Measure ability to respond at Measure response activities Measures ability to prevent (early treatment seeking community engagement Measures ability to effectively Measures ability to prevent patients manage highly infectious behaviour and quality of Presence of a feedback health facility level Availability of IPC measures in all health facilities Attack rate for each epidemic- prone disease reported Case fatality for each epidemic- prone disease reported Numerator: Number of HCW trained in IPC in last 12 Numerator: Number of new cases detected Denominator: N/A Denominator: N/A Denominator: Population at risk Community feedback sessions at least once quarterly Denominator: Total number expected to be trained Denominator: Number of cases from the same Denominator: N/A Numerator: N/A Numerator: N/A Availability of an isolation facility in all hospitals Denominator: N/A Denominator: N/A Numerator: Number of deaths from each of the Availability of a functional Public Health Emergency Numerator: N/A including a holding area Proportion of feedback bulletins/reports received from Management Committee months at a facility X epidemic prone diseases epidemic prone diseases the facility Numerator: N/A Numerator: N/A Proportion of HCW trained in IPC in last 12 months at the next higher level Respond Provide Feedback

done When to be Quarterly Weekly Quarterly Quarterly Quarterly Weekly Target 100% 100% 80% 80% 80% 80% and case-based or line Routine summary reports Monitoring chart for Source of information timely submission of Checklist for the in Checklist for the in listing reports for diseases timely submission of targeted for elimination Monitoring chart for Routine summary reports reports/eIDSR system and supervisory charge at the H/Fs charge at the H/Fs report/DHIS2 report/DHIS2 Purpose filling cases/events Measure the ability of the Correctly identifying and events system to capture unusual Measure the availability of Measures the completeness of registers and HMIS forms submission of surveillance Measures the timeliness of surveillance data with reports submission of surveillance Measures reporting of reports 230 Indicator with standardized registers and HMIS forms Denominator: Total Number of health facilities in the district Denominator: Total Number of health facilities in the district Denominator: Total number of all HFs Numerator: Number of HFs with SCD Denominator: Total number of all HFs Numerator: Number of HFs with registers and HMIS forms forms or line lists.

Numerator: Number of HFs reporting information from EBS/eIDSR on time to the district Denominator: Total Number of all HFs Proportion of health facilities with Standard case definition (SCD) Proportion of health facilities reporting information using EBS/eIDSR Proportion of health facilities including hospitals to the district to the district Proportion of health facilities including hospitals submitting IDSR reports any diseases selected for case-based surveillance reported with case-based Proportion of cases of diseases targeted for elimination, eradication and Numerator: Number of health facilities that submitted surveillance reports Numerator: Number of health facilities that submitted surveillance reports on time to the district Proportion of health facilities including hospitals submitting IDSR reports Identify Reporting IDSR Core Function

#### Annex 8B: Indicators for monitoring IDSR core functions at the district level

Quarterly Quarterly Quarterly Quarterly 80% 80% 80% 80% Log of suspected Case Investigation Forms case-based surveillance, other routine analysis outbreaks and rumours.

Health facility notice reporting forms any diseases selected for District analysis book or , Line lists or case-based Investigation reports, Laboratory register Epidemic curve boards Supervisory report eIDSR, eHMIS tool, HMIS tools Evidence of Measures use of data and team to detect trends of data analysis and Measures the practice and thresholds for early detection additional variables for capacity of the health facility Measures availability of of outbreaks and timely routine laboratory reporting to the next level suspected/ possible outbreaks further analysis further analysis interpretation 231 Numerator: Number of outbreak investigation reports that include case- Numerator: Number of cases of diseases targeted for elimination, Numerator: Number of health facilities that have lab data analysis for Denominator: Total number of outbreak investigation reports conducted eradication, and any diseases selected for case-based surveillance reported Numerator: Number of suspected outbreaks of epidemic- prone diseases/ Denominator: Number of suspected outbreaks of epidemic-prone with case-based forms or line list Denominator: Total number of health facilities in the district Denominator: Total number of cases of diseases selected for case- based selected priority conditions Denominator: Total number of health facilities in the district diseases/ conditions in the district in the district based data based data Numerator: Number of health facilities that have current trend analysis for Proportion of health facilities that have current lab analysis data for priority Proportion of suspected outbreaks of epidemic-prone diseases/ conditions conditions notified to the next level within 24 hours of surpassing the Proportion of reports of investigated outbreaks that include analysed casesurveillance that occurred in the district notified to the district within 24 hours of surpassing the epidemic threshold diseases (if applicable) epidemic threshold Proportion of health facilities that have current trend analyses selected priority conditions.

and outbreaks of suspected confirmation Analysis and Interpretation Investigation

Quarterly Quarterly Annually Annually Annually Annually Monthly 80% 80% 80% Log of suspected outbreaks and rumours Supervisory reports Annual work plans Log of suspected outbreaks and alerts Laboratory register Laboratory reports Outbreak investigation Outbreak investigation work plans work plans Annual Annual Annual reports reports Minutes of reports, district to respond to laboratory to confirm Measures capacity of the Measures capacity of manner diagnosis and involvement of District Measure capacity to refer Health facility Measure the District readiness Measure preparedness of Measure preparedness of samples in a timely Health facility laboratory in surveillance outbreaks activities Measure preparedness of 232 Proportion of samples from suspected outbreak timely transported within Numerator: Number of investigated outbreaks with laboratory results Denominator: Number of confirmed outbreaks in the district Denominator: Number of all HF Proportion of investigated outbreaks with laboratory results within 7 days Denominator: N/A Denominator: N/A Numerator: N/A Proportion of confirmed outbreaks with a nationally recommended public Denominator: Number samples collected from suspected outbreaks on time (within 24 hours) Numerator: Number of confirmed outbreaks with a nationally Numerator: N/A Denominator: Total number of samples submitted for testing Numerator: Number of suspected outbreaks of which samples were sent within seven days Availability of a District Emergency Preparedness and Response Plan Existence of funds for emergency response (Or budget line for emergency Presence of a functional central unit for coordination of PHEMC (PH Proportion of health facilities with emergency preparedness and response funds) recommended response Numerator: Number of HF with EPR plans health emergency response 24 hours EOC) (EPR) plans Prepare

Quarterly Quarterly Quarterly Quarterly Quality reports Health Office Observation Observation Observation work plans H/F inventory H/F Inventory H/F Inventory Minutes from District H/F Inventory facility Measure preparedness of a Health facility Measure the capacity of district level Measure the capacity of Measure ability to respond at Measure preparedness of Measure the capacity of preparedness of a HFs preparedness of HFs preparedness of HFs 233 Denominator: Total Number of Health Facilities Denominator: Total Number of Health Facilities Denominator: Total Number of Labs Specimen collection and transportation Numerator: N/A Denominator: N/A Denominator: Total Number of all HF Denominator: Total Number of all HF Committee Numerator: N/A Numerator: Number of labs with performance of routine QA Proportion of Labs with performance reports of Proportion of Health facilities with available supplies for Numerator: Number of HFs with available specimen collection and 3, 6, 12 months) Numerator: Number of HFs with available lab reagents routine quality assurance supplies for the most recent outbreak (define the time frame e.g.

Numerator: Number of HF with contingency stocks transportation Presence of a Functional Public Health Emergency Management u Numerator: Number of HF that experienced shortage Proportion of HF with availability of laboratory Diagnostic reagents Proportion of health facilities that have contingency Stocks for 3-6 months Proportion of Health facility that experienced shortage of drugs and Respond

Quarterly Quarterly Annually Depen Depen 80% ds on disease ds on disease Minutes from Health Demographic data about Routine reports and Routine summary reports outbreak investigation Facility records and supervisory reports investigation report with Observation of IPC Health Office the district, Outbreaks alerts line lists or case-based Health facility log of Minutes from District suspected outbreaks and practices forms of the intervention health facility level health facility level Measures early detection and management Measures quality of case Helps to identify the Measures the practice and the population at risk and efficacy apply infection control Capacity of the hospitals to requirements Measure ability to respond at Measure ability to respond at timely reporting of outbreaks 234 Numerator: Number of new cases of an epidemic prone disease that Proportion of HFs with functional Public Health Emergency Management Denominator: Number of populations at risk during the outbreak Denominator: Number of cases from the same epidemic prone diseases Numerator: Number of deaths from each of the epidemic prone diseases Numerator: Number of suspected outbreaks of epidemic prone diseases Availability of Public Health Emergency Rapid Response Team Proportion of Outbreaks or any public health event Denominator: Total number of suspected outbreaks of epidemic prone Denominator: Total number of Hospitals in the district Numerator: Number of HFs with functional Committee Denominator: N/A Denominator: N/A Case Fatality rate for each epidemic prone disease reported Numerator: N/A Denominator: Total Number of all HF Attack rate for each outbreak of priority disease diseases/events responded to in the previous 12 months requirements established including isolation ward/unit occurred during an outbreak committee Infection Prevention and Control (IPC) requirements Numerator: Number of Hospitals that reported having established responded Proportion of Hospitals with Infection Prevention and Control (IPC) (PHERRT)

Quarterly Quarterly Observation Observation Presence of a feedback Presence of a feedback mechanism mechanism 235 Numerator: Number of reports/bulletins or any documentation actually Denominator: Total number of reports/bulletins or any form of feedback Proportion of feedback Denominator: N/A Numerator: N/A Availability of feedback reports/letters/bulletin document expected to be sent to lower levels bulletins/reports sent to the lower level sent to lower level and received Provide Feedback

done When to be Quarterly Quarterly Quarterly 100% 80% Target %00I N/A denominator reports and supervisory District and regional information for Regional rumour Source of Reports District Inventory logbook Routine summary reports numerator and 236 events from unofficial cases / events region to capture unusual reports sources system to capture unusual Measure the ability of the validation of surveillance Measure the ability of the data Measures the routine Correctly identify and fill events Purpose Denominator: N/A Numerator: N/A Denominator: Total number of all districts within the region Numerator: Number of districts having routine data Numerator: Number of Districts with Guidelines Denominator: Total number of all districts within the region Denominator: Total number of all districts within the region Numerator: Number of districts reporting information using event-based surveillance methods Proportions of districts with IDSR guidelines to guide Proportion of districts reporting information using eIDSR / Number of events recorded in the log book of rumour Proportion of districts with routine surveillance data validation system for surveillance data identification of cases EBS validation systems Indicator Function IDSR Core Identify

#### Annex 8C: Indicators for monitoring IDSR core functions at the regional level

Weekly Weekly Quarterly quarterly 90% 90% %08 80% Supervisory reports Routine summary Monitoring chart or line listing reports reports Routine summary Monitoring chart reports reports and case-based District analysis book Routine summary 237 surveillance data Measures reporting of surveillance data with for further analysis completeness of submitted Measures the practice and capacity to analyse surveillance data surveillance data Measures the practice of timely submission of detailed information to use Measures the practice of Denominator: Total number of districts that report to the Denominator: Total number of districts that report to the Denominator: Total number of diseases targeted for Numerator: Number of districts that submitted IDSR reports and any diseases selected for case-based surveillance reported Proportion of diseases targeted for elimination, eradication surveillance reported with case-based forms or line list eradication, and any diseases selected for case- based from the district to the region on time Numerator: Number of districts with priority diseases for Denominator: Total Number of districts within the region Numerator: Number of diseases targeted for elimination, elimination, eradication and any other disease selected for available for selected priority diseases case-based surveillance Proportion of weekly 033b surveillance reports submitted Proportion of districts in which a current line graph is from the district to the region which a current line graph is available.

regional level regional level to the region Proportion of weekly 033b surveillance reports submitted Numerator: Number of districts that submitted IDSR reports with case-based forms or line lists.

on time to the region Analysis and Reporting Interpretation

Quarterly Quarterly 80% %08 80% %08 %08 reports Routine summary Outbreak investigation reports District analysis book Laboratory reports Routine summary District analysis book Routine summary reports Supervisory reports reports outbreaks and alert Log of suspected Investigation reports Supervisory reports 238 Measures early detection and diagnosis and involvement surveillance data Measures capacity of the capacity to analyse Measures the practice and Measures if districts are Measures availability of additional variables for possible risk factors involved laboratory to confirm the timely reporting of outbreaks of laboratory in the collecting and reporting lab surveillance activities further analysis including data to higher level Denominator: Total number of suspected outbreaks of forms or line lists Denominator: Total number of district labs within the region Denominator: Total Number of districts within the region Proportion of districts in which an updated spot map of cases Denominator: Total number of investigated outbreaks within Proportion of reports of investigated outbreaks that includes Numerator: Number of districts with priority diseases for epidemic prone diseases / conditions within the region Numerator: Number of suspected outbreaks of epidemic Proportion of investigated outbreaks with laboratory results under surveillance reports within the region Proportion of districts that report laboratory data for diseases analysed case-based data Denominator: Total Number of outbreaks investigation the region is available for selected priority diseases Numerator: Number of investigated outbreaks with laboratory results Proportion of suspected outbreaks of epidemic prone diseases within 24 hours of surpassing the epidemic threshold prone diseases / conditions notified to the national level which an updated spot map is available.

surpassing the epidemic threshold include epi curve, mapping, personal tables and case-based Numerator: Number of outbreak investigation reports that Numerator: Number of district labs that submitted monthly data to higher level / conditions notified to the national level within 24 hours of confirmation of Investigation and suspected Cases

Quarterly Quarterly Annual 80% 80% %06 %06 %08 rumours reports Supervision reports Central Public Health Laboratories (CPHL) Minutes of reports, outbreaks and alerts Supervision reports Lab register Outbreak investigation Risk assessment and mapping reports and Annual work plans Minutes of reports, Supervisory visit Log of suspected Minutes of reports, Log of outbreaks and reports 239 Measures capacity of the outbreaks readiness to respond to AMR region to respond to Measure capacity in Measure preparedness of Measure the Regional Measure the practice and outbreaks readiness districts Measure the Regional capacity of the district to readiness Numerator: Number of labs reporting AMR results Denominator: Total Labs within the region Denominator: Total Number of confirmed outbreaks within Numerator: Number of districts with EPR plans Antimicrobial resistance Denominator: N/A Numerator: Number of confirmed outbreaks with a Proportion of labs performing routine testing and reporting of recommended public health response nationally recommended public health response Denominator: Total number of districts within the region Denominator: Total number of districts within the region Numerator: N/A Proportion of districts with preparedness and response plans the region Task Forces emergency Proportion of districts with established functional District mapping Presence of a functional coordination of PHEMC (PHEOC) at Proportion of confirmed outbreaks with a nationally Task Forces (DTFs) regional level Numerator: Number of districts with the functional District Proportion of districts with public health risk and resource Prepare

Quarterly Annually Quarterly Quarterly Quarterly Quarterly disease disease Depends on Depends on 80% 80% 80% 80% about the district, case-based forms Outbreaks investigation Annual Observation Minutes of meetings of outbreak investigation Supervisory reports minutes, observations Work plans, Meeting reports reports Resource mapping DRRT Routine reports and Demographic data report with line lists or District/Region Inventory 240 Measures quality of case conduct mapping of available resources and risks Measures ability of regions and districts preparedness Measure preparedness of Measure preparedness of population at risk and management and response to Measure the capacity of towards emergencies preparedness Helps to identify the efficacy of the intervention outbreak District district Denominator: Total number of districts within the region Denominator: Number of populations at risk during the Denominator: Number of district labs within the region Numerator: Number of districts with Budget lines for Denominator: Number of districts within the region lab supplies for 3-6 months Denominator: Total number of districts within the region Numerator: Number of new cases of an epidemic prone Attack rate for each outbreak of priority disease / conditions Numerator: Number of districts with contingency stocks Denominator: Number of districts within the region Proportion of districts with funds for emergency preparedness disease / condition that occurred during an outbreak Numerator: Number of districts with functional DRRTs Proportion of districts that have contingency stocks including Proportion of districts labs with performance reports of Numerator: Number of districts that reported having Case Fatality rate for each epidemic prone disease / condition outbreak Proportion of districts with functional District Rapid Response Teams (DRRTs) routine quality assurance outbreak preparedness conducted public health risks and resources mapping and response Numerator: Number of district labs with performance of reported routine QA Respond

Annual Annually Annual 60% 80% 80% Health facility log of Supervision reports, Routine summary bulletins, newsletters, manuscripts, brief alerts suspected outbreaks and summaries reports and supervisory 241 measures timely reporting of outbreaks Measures early detection and Measures the practice and to apply infection control the Capacity of the hospital mechanism in the region and Presence of a feedback districts Denominator: Total Number of cases from the same Denominator: Total number of suspected outbreaks of prone diseases responded to within 24hours of passing a Numerator: Number of deaths from each of the epidemic epidemic prone disease during an outbreak Proportion of districts with epidemiological analyses established Infection Prevention and Control (IPC) Denominator: Total number of health facilities within the Proportion of Outbreaks or any public health events Denominator: Total number of districts within the region Proportion of health facilities with Infection Prevention and prone diseases / conditions during an outbreak bulletins / newsletters / manuscripts / briefs summaries region summaries epidemic prone diseases/events reported Numerator: Number of suspected outbreaks of epidemic responded to within 24hours of detection requirements Control (IPC) requirements response threshold published in bulletins / newsletters / manuscripts / briefs Numerator: Number of health facilities that reported having Numerator: Number of districts with analyses published in Provide Feedback

When to Monthly be done Quarterl Quarterl Quarterl Quarterl 100% Target 80% 90% 90% numerator and Source of information denominator reports and supervisory alerts at PHEOC National logbook of for Summary reporting District Inventory Routine summary National Reports reports forms events from unofficial reported events Measure the ability of the Measure the ability of the district Correctly identify and file Measures practice of complete data from health facilities to national to capture unusual submission of surveillance cases/events sources of data Measure the routine validation system to capture unusual Purpose 242 Numerator: Number of districts having routine data Denominator: Total number of districts Denominator: Total number of districts validation system Denominator: N/A Denominator: Total number of districts Numerator: Number of health facilities submitting Numerator: Number of Districts with Guidelines Denominator: Number of health facilities Numerator: N/A Numerator: Number of districts reporting information using EBS Proportion of districts reporting information using eIDSR / Number of events recorded in the log book of alerts reports to the district reports on the district Proportion of districts with routine data validation system Proportions of districts with IDSR guidelines to identify cases Proportion of health facilities submitting weekly 033b IDSR event-based surveillance methods including eIDSR Indicator Surveillance Core Identify Reporting

#### Annex 8D: Indicators monitoring IDSR core functions at the national level

Monthly Monthly Monthly Monthly Monthly %08 90% %08 80% 80% District analysis book Central Public Health Supervisory reports Summary reporting Laboratory (CPHL) Routine summary or line listing reports Monitoring chart forms Routine summary reports reports and case-based Measures practice of timely Measures reporting of Measures the practice of timely submission of surveillance district surveillance data with detailed data from health facilities to submission of surveillance data capacity to analyse Measures the practice and laboratory data levels analyse district information to use for further analysis Measures how well regional surveillance data 243 Numerator: Number of diseases / conditions targeted for time to the district districts to the national level on time in the last 3 months districts that report to the national level Proportion of health facilities submitting weekly 033b IDSR Proportion of monthly surveillance reports submitted from the Numerator: Number of districts that submitted IDSR reports Numerator: Number of health facilities submitting reports on surveillance reported with case-based forms or line lists.

elimination, eradication and any diseases selected for case-based elimination, eradication and any other disease selected for elimination, eradication, and any diseases selected for case- Proportion of cases of diseases / conditions targeted for Denominator: Total Number of Health facilities Denominator: Total number of districts case-based surveillance based to the national lab on time to the national level Denominator: Total number of Denominator: Number of diseases / conditions targeted for reports on time to the district Numerator: Number of provincial laboratories analysing and Numerator: Number of districts in which a current line graph reporting to national level Proportion of districts in which a current line graph is for priority diseases / conditions is available.

surveillance reported with case-based forms or line list Proportion of regional laboratories reporting analysed lab data available for selected priority diseases and Interpretation Analysis

Quarterl Quarterl Quarterl Quarterl Monthly 80% 80% 80% 80% 80% Outbreak investigation rumours Routine summary reports Routine summary reports Central Public Health reports outbreaks and alerts Laboratory (CPHL) Log of suspected Log of suspected outbreaks and alerts Routine summary reports Log of outbreaks and Laboratory reports Investigation reports diagnosis and involvement of laboratory to confirm the Measures capacity of the region to respond to outbreaks Measures early detection and additional variables for further collecting and reporting lab analysis including possible risk Measures if districts are laboratory in the surveillance factors involved Measures capacity of the Measures availability of activities timely reporting of outbreaks data to higher level 244 Numerator: Number of suspected outbreaks of epidemic Denominator: Number of outbreaks investigation reports forms or line lists Denominator: Total number of district labs Numerator: Number of investigated outbreaks with Proportion of investigated outbreaks with laboratory results Proportion of reports of investigated outbreaks that includes Denominator: Number of investigated outbreaks Denominator: Total number of suspected outbreaks of Proportion of districts that report laboratory data for diseases Numerator: Number of district labs that submitted data to Proportion of suspected outbreaks of epidemic prone disease hours of surpassing the alert threshold analysed case-based data laboratory results epidemic prone diseases Numerator: Number of outbreak investigation reports that include epi-curve, mapping, personal tables and case-based under surveillance notified to the national level within 24 hours of surpassing the Denominator: Total number of regional labs prone diseases notified to the national PHEOC within 24 Proportion of confirmed outbreaks with a nationally recommended public health response alert threshold higher level and Investigation confirmation of suspected

Quarterl Annuall %06 %08 02% /006 Outbreak investigation Annual work plans Risk assessment and Standard surveillance District analysis book reports Supervisory visit reports reports District summary Supervisory reports Supervision reports reporting forms mapping reports and Work plans Checks the capacity of the outbreaks and shows that the capacity of the regions to Measures preparedness of entire health system to detect whether districts are observing readiness Measure the regional readiness resources and risks conduct mapping of available regions trends Measure the National level national level is checking Measure the practice and 245 Presence of a functional coordination of PHEMC (PHEOC) at Numerator: Number of outbreaks detected by the regional or Denominator: Total number of all health regions (n=16) Numerator: Number of regions that reported having conducted Numerator: Number of regions with the functional regional The number of outbreaks detected at the national level and Denominator: Total number of outbreaks reported by all that were missed by district level Numerator: N/A Numerator: Number of confirmed outbreaks with a nationally Denominator: Total number of all health regions (n=16) PHEOCs and/or coordination mechanism for public health Proportion of regions with emergency Denominator: Number of confirmed outbreaks epidemics/emergency health emergencies Numerator: Number of regions with EPR plan national level Denominator: N/A districts mapped Proportion of regions with established functional regional PHEOCs and/or mechanism body for coordination of public national level from analysing district specific data public health risks and resources mapping preparedness and response (EPR) plans Proportion of regions with public health risks and resources recommended public health response Prepare

Quarterl Quarterl Quarterl Quarterl Annuall on disease / disease / on Depends Depends condition 80% condition 80% 80% outbreak investigation Quality reports Observation the district, Outbreaks forms Routine reports and Annual Demographic data about Work plans District/Region line lists or case-based investigation report with Inventory Helps to identify the Measures quality of case management population at risk and efficacy of the intervention Measures preparedness of regions regions Measure preparedness of Measures the capacity of preparedness 246 Numerator: Number of regions labs with performance of disease / condition that occurred during an outbreak Denominator: Number of regions labs routine QA Numerator: Number of new cases of an epidemic prone Numerator: Number of deaths from each of the epidemic Proportion of regions with funds for emergency preparedness Case Fatality rate for each epidemic prone disease / condition Attack rate for each outbreak of priority disease / condition health risks and resource Numerator: Number of regions with contingency stocks routine quality assurance Stocks including lab supplies for 3-6 months Denominator: Number of all regions (n=16) Denominator: Number of all regions (n=16) outbreak Denominator: Total number of regions targeted for public Denominator: Number of populations at risk during the Numerator: Number of regions with Budgets / Budget line Proportion of regions labs with performance reports of Proportion of regions that have contingency prone disease / condition reported and response Respond

Quarterl Quarterl Annual 60% 80% 80% Health facility log of Supervision reports, manuscripts, brief alerts summaries suspected outbreaks and Routine summary bulletins, newsletters, reports and supervisory reports Measures the practice and the Capacity of the facility to Presence of a mechanism measures Measures early detection and timely reporting of outbreaks feedback apply infection control 247 Denominator: Number of cases from the same epidemic epidemic prone diseases/events Proportion of facilities with Infection Prevention and Control Denominator: Total number of regions (n = 16) (IPC) requirements in bulletins / newsletters / manuscripts / briefs summaries Denominator: Total number of facilities in the country bulletins / newsletters / manuscripts / briefs summaries to in the previous 12months prone diseases / condition responded to requirements established prone diseases / condition Numerator: Number of regions with analyses published in Proportion of regions with epidemiological analyses published established Infection Prevention and Control (IPC) Proportion of outbreaks or any public health event responded Numerator: Number of suspected outbreaks of epidemic Denominator: Total number of suspected outbreaks of Numerator: Number of facilities that reported having Feedback Provide

Dec Nov Oct Sep Aug Jul Jun May Apr Mar Feb Jan which reports reports of district using case-based selected for case-based events from non-routine Proportion of complete diseases / conditions surveillance, mechanism to capture Proportion of complete submitted on time to the surveillance submitted to the district Proportion of cases of surveillance sources were reported to the unusual or public health Existence or line listing forms Indicator district Availability of SCD and HMIS forms/registers Each month, summarize and compile the health facility's summary data for priority diseases. Report the summary data to the district level

#### Annex 8E: Monitoring Chart for performance of IDSR indicators at health facility level

Use this chart to keep track of the health facility's performance with those indicators relevant to health facility performance for IDSR.

or bring it to the scheduled district health team (DHT) meetings.

Instructions:

on time. Record on this chart the indicator results. Share this chart with the district supervisor during his or her visit to the health facility,

of and of Emergency diseases which there is current Proportion of priority for specimen collection Proportion of samples diseases / conditions for outbreaks of epidemic conditions notified to from suspected outbreak Availability of an Availability of supplies and control Availability emergency medicines transported for lab the district level within graph is available prone diseases / conditions for investigation within which a current line Availability of an all outbreak preparedness Proportion of priority and supplies Proportion of suspected and transportation Hazards functional task force for preparedness Availability contingency stocks of isolation facility

250 the the reports weekly weekly reports reports feedback has alert the the Attack Were Were rate for each epidemic- If YES, have you Case Fatality rate for received from the next threshold been crossed?

surveillance community the trends?

action prone disease / condition Availability Reply YES or NO to the following checklist items Are the trend graphs upeach epidemic prone observed any changes in Proportion of feedback disease/condition surveillance higher level If YES, to-date?

district?

reported If YES, have you taken bulletins

Dec Oct Nov Sep Aug Jul Jun 251 May Year:

Apr Mar Feb Region:

Jan Number of events Proportions of Health reporting information Proportion of health facilities with SCDs Proportion of health Proportion of districts district with Indicator the district Proportion of health IDSR reports to the facilities within the using eIDSR / EBS log book for rumours facilities submitting IDSR reports on time to facilities submitting District:

district recorded in the district registers and forms standardized HMIS

#### Annex 8F: Monitoring chart for performance of IDSR indicators at district, regional level

252 diseases / conditions diseases selected for forms or line lists.

case-based surveillance Proportion of cases of eradication and any targeted for elimination, Proportion of hospitals Proportion of private Proportion of health on time Proportion of priority on time health facilities submitting IDSR reports submitting IDSR reports facilities that have diseases / conditions for current lab analysis data for priority diseases which a current line Proportion of health facilities that have graph is available reported with case-based current trend analysis analysed

of the for unit with outbreaks of epidemic- Proportion of confirmed Proportion of suspected Proportion of reports of from suspected outbreaks within 24 hours or Proportion of samples investigated outbreaks Presence of a functional outbreaks conditions notified to the nationally recommended investigated outbreaks with laboratory results prone diseases/ coordination of PHEMC public health response crossing the epidemic (Regional PHEOC) case-based data region/provincial level that include analysed threshold regional for investigation laboratory within 24hrs transported

254 with with Emergency Proportion of health Attack rate for each Rapid Response Team Case Fatality rate for disease reported Emergency Preparedness functional outbreak task Proportion of hospitals each epidemic prone Proportion of outbreaks with isolation facilities outbreak of priority Health previous 12 months and Response Plan and response plans event responded to in the Availability of a District emergency preparedness or any public health Proportion of Health Availability of Public force facilities facilities

255 Availability of feedback feedback Proportion of sent to the lower level reports/letters/bulletin bulletins/reports

Oct Nov Dec 256 Jan Feb Mar Apr May Jun Jul Aug Sep Year Total number of reports not received (W) Completeness of reporting =100 * (N-W) / N Timeliness of the reports =100 * T / N Total reports sent on time (T) Total reports sent late (L) Total number of reports expected (N) Indicator W-report not received L = arrived late T = arrived on time

#### Annex 8G: Sample form for recording timeliness and completeness of weekly / monthly reporting from the health facility to the

can be taken to improve timeliness for each health facility in the district.

*The timeliness and completeness are expressed as percentages (%). When the surveillance system is good, the rates for timeliness and Country District Health Facility:

district Legend completeness should approach 100%. This table allows for monitoring the progress of these two indicators in the district so that action

COMMENT (What Caused Problem) Yes [] No [] Yes [] No[] Yes No Yes [] No [] Yes [] No [ ] Yes [] No [] Number of results obtained:

Yes [] No [] Number of expected cases seen:

ANSWER the 257 Date of Supervisory Visit:

disease / condition on a graph? (Ask to see the health facility's 1. Are diagnoses of cases of priority diseases / conditions recorded analysis book. Look to see if the trend lines are up-to date.) conditions on a case form or line list?

reports of suspected cases or deaths due to a priority disease or suspected cases and outbreaks?

laboratory specimens during an urgent situation? (show me the reported immediately to the district office?

condition?

results?

supply) tests seen since the last supervisory visit, how many had laboratory SUPERVISORY QUESTION 1. Do you plot the numbers of cases and deaths for each priority 1. How often do you collect information from the community about 1. Do health worker use a standard case definition to report the 2. For the cases of priority diseases / conditions needing laboratory 1. If an epidemic-prone disease / condition was suspected, was it 2. Do you plot the distribution of cases on a map?

3. Are appropriate supplies available or set aside for collecting of 2. Do you record information about immediately notifiable diseases / collection ACTIVITY Health Facility:

Reported Cases and Outbreaks Analyse and Interpret Data Report Investigate and Confirm within health facilities Register cases identify Suspected Cases

#### Annex 8H: Checklist for monitoring IDSR activities at the health facility

COMMENT (What Caused Problem) ACTIVITY ANSWER SUPERVISORY QUESTION Respond 1. Are appropriate supplies available for Yes [] No [] responding to a confirmed case or Supplies scen Yes [] No outbreak for example, immunization [ ] supplies and vaccine, ORS, antibiotics, and so on)?

2. Please show me the supplies for carrying Name:

out a recommended response.

3. Who is the outbreak coordinator for this facility?

4. How often do you provide information Designation:

and training in outbreak response to the Training is done:

staff of this facility?

Report it Provide 1. How often do you report information to the community?

Feedback Yes [] No [ ] 2. Do you receive the latest bulletin from the (central, subnational) level?

Evaluate Yes [ ]No [] and/ 1. Were the last 3 routine weekly reports the sent to the district office?

Improve Yes [] No [ ] 2. Were the last 3 routine monthly reports System sent on time?

1.

Minimum level of What precautions do health worker Epidemic standard Preparedness (including laboratory staff) take routinely precautions:

with all patients regardless of the patients How supplies are infection status?

estimated:

2. How do you estimate the number of supplies to set aside for use during an emergency situation?

#### Annex 81: Indicators for monitoring the performance of IDSR at Member State

level 1. Proportion of health facilities submitting weekly (or monthly) surveillance reports in time to the "district".

2. Proportion of districts submitting weekly (or monthly) surveillance reports in time to the next higher level.

3. Proportion of cases of diseases targeted for elimination, eradication and any other diseases selected for case-based surveillance that were reported to the district using case-based or linelisting forms.

4. Proportion of suspected outbreaks of epidemic-prone diseases notified to the next higher level within 48 hours of surpassing the epidemic threshold.

5. Proportion of health facilities in which a current trend analysis (line graph or histogram) or spot map is available for selected priority diseases.

6. Proportion of districts that produce a regular weekly (or monthly) IDSR bulletin.

7. Proportion of reports of investigated outbreaks and other public health emergencies that include analysed case-based data.

8. Proportion of investigated outbreaks or events with laboratory results within seven days.

9. Proportion of confirmed outbreaks or other public health emergencies with a nationally recommended public health response within 48 hours.

10. Case fatality rate for each epidemic-prone disease reported.

11. Incidence of priority diseases, events and conditions.

12. Mortality from priority diseases, events and conditions.

13. Number of epidemics detected at the national level that were missed by the "district" level during the last year.

14. Proportion of districts that report laboratory data for diseases under surveillance.

15. Proportion of district laboratories that received at least one supervisory visit that included written feedback from the provincial or national level during the last year.

16. Proportion of districts reporting monthly analysed laboratory data to the national reference laboratory.

NB: "District" for the purposes of this strategy refers to the administrative level next to the national level

#### Annex 8J: Sample Public Health Bulletin

MINISTRY OF HEALTH WEEKLY EPIDEMIOLOCICAL BULLETIN District Epidemiological Week - Ending (date) Epidemiological Situation: Week (insert week number and date here) Table 1: Epidemiological Situation: Week Disease Districts in Cases Deaths Timeliness Districts in Fatality Completeness (%) Reported Alert week (%) (%) Epidemic D1 D2 Dn - Total Comments:

Contact us:

Synthesis of the Epidemiological Situation (insert the weeks being reported on here) Table 2: Epidemiological Situation: Weeks Timeliness Districts Cases Deaths Districts in Districts in Reported Completeness (%) Fatality week Alert Epidemic (%) (%) D1 D2 Dn Total Comments:

Graphs (This section provides a graphical representation of d a t a) Epidemic Trends

SECTION 9 ELECTRONIC INTEGRATED DISEASE SURVEILLANCE AND RESPONSE (eIDSR)

## Section 9: ELECTRONIC INTEGRATED DISEASE SURVEILLANCE AND RESPONSE (eIDSR)

### 9.0 Electronic IDSR

Electronic IDSR is the application of electronic tools to IDSR to facilitate prediction, prevention, detection, reporting and response. It is based on;

- Standardized interoperable and interconnected information systems.

- Rapid collection, analysis, reporting and use of disease/events data in real-time.

### 9.1 eIDSR in the context of eHealth

Digital health encompasses all concepts and activities at the intersection of health and ICTs.

This includes the delivery of health information, using ICTs to improve public health services, and using health management information systems (HMIS) to capture, store, manage or transmit information on patient health or health facility activities. ICTs are defined as tools that facilitate communication, processing and transmission of information by electronic means and these encompass a full range of tools like radio & television, telephones (fixed and mobile), computers and the Internet. Health encompasses a range of services and systems, including;

- health and medical informatics

- tele-health (transmission of health-related information over the telecom infrastructure)

- e-learning (utilizing technologies to access education outside of the traditional classroom)

- m-health (use of mobile phone and other wireless technologies in medical health)

Digital health underscores the importance of nationally-supported digital health strategies, supporting and investing in the digital health enabling environment (including policy, standards, capacity, interoperability, privacy, security, and more) such as eIDSR.

### 9.2 eIDSR in the context of HMIS

HMIS is used to facilitate routine collection of data to support planning, management and decision-making. HMIS routinely collects data about diseases, events and conditions, as well as other administrative and service provision data. The primary source of the data is the health facility Outpatient (OPD) or Inpatient (IPD) registers. The most widely used electronic platform of HMIS is District Health Information Software 2 (DHIS2).

eIDSR is an enabling platform for reporting in real time for IDSR priority diseases, as well as public health events. These are reported immediately/weekly/monthly depending on the disease or public health event.

### 9.3 Rationale of eIDSR

Submitting and transmitting data on time is a challenge that may result into delays utilizing information for action. The eIDSR system facilitates real-time disease surveillance using electronic tools and hence strengthening surveillance and response capacities through;

- Timeliness and completeness of reporting

- Early detection, investigation, and response to outbreak or public health events

- Reduced manual data entry

- Systematic information sharing across levels and sectors

- Combining data streams

- Data use, analysis, analytics

### 9.4 Benefits of eIDSR

The eIDSR provides real-time information for immediate action with the following benefits:

- Early alert and detection: Enables rapid information capture and accurate predictions by

time and place hence enabling opportunities for prevention and controls!

- Timely reporting: Allows for rapid and timely transmission of data to action centers.

- Standardization of data tools: Provision of standardized tools in eIDSR platforms

facilitates ease, consistency and completeness of data gathering processes and facilitates ease of data exchange and comparison across reporting centers.

- Better data transmission and management including storage: A major challenge of paper

based is a need to collate reports from various sources before further transmission, data storage and transport, and the risk of data damage and loss. eIDSR enables faster data transmission, organization, access, use, interpretation and safe custody.

- Interoperability and sharing of data: eIDSR enables exchange and use of health

information across systems and sectors, through interoperability information systems.

- Automated transmission, analyses and improved quality data: eIDSR can reduces on the

number of data entry errors and facilitates automated data analysis.

- Ultimately contribute towards good response, better monitoring and evaluation: eIDSR

provides a platform for data storage and automated quality control.

- Reduced cost: eIDSR leads to early detection of disease outbreaks, which in effect, can

contribute to the overall cost reduction associated with management of these outbreaks.

### 9.5 Key guiding principles in establishing eIDSR

The following are key guiding principles in the establishment of eIDSR Use of existing infrastructure: eIDSR is built on existing frameworks and systems, such as paper-based IDSR, HMIS, DHIS2, etc with ease of adaptability by implementers.

Standardization: Standardized data and electronic tools are utilized to promote uniformity in data collection, aggregation, comparisons and quality control.

Integration: eIDSR is integrated into the routine data management protocols prescribed by IDSR in general and is data warehouse for various data sources and information systems.

Interoperability: as a health information system, eIDSR is adaptable within and across sectors as a data exchange and use platform.

Multi-sectoral Collaboration: Various stakeholders, including telecom providers are involved in building foundations for IDSR. Collaborative frameworks ease implementation in form of waivers, accelerated roll out and coverage and One Health approach to disease prevention and control.

Real-time approach: Every effort should be made to ensure provision of real-time transfer of information about events incorporated into the design and implementation of eIDSR.

Data security: Security protocols for data entry and access ensure that it is only accessible by authorized personnel and promotes ethical handling of data and patient confidentiality.

User-friendly system: The system should ideally be simple, easy to use, log on, input, share and receive information, flexible and adaptable over time.

### 9.6 Use of eIDSR in core surveillance functions

The general IDSR scope and operational environment, tools and capabilities are critical in ensuring the successful implementation of eIDSR. One Health platforms provide an opportunity for creating interoperable, interconnected electronic reporting systems between human, animal and environment surveillance systems.

e-tools can be adapted to conduct Data Quality Assessments and Audits (DQA) as part of the monitoring and evaluation strategy of IDSR core functions. eIDSR tools make it easier to identify errors, inconsistencies, discrepancies and anomalies that affect reliability, accuracy, precision and completeness of data. It is tailored to support:

Introduction Section: Real-time EBS reporting

- Section 2: Alert notification at community and health facility, Case-based reporting,

Routine reporting (weekly via mTrac, and monthly via DHIS2): Section 2.

Section 3: Generating graphs, maps and other visual displays of data Section 4: Case investigation including laboratory and clinical investigation information management; Real time line listing

- Sections 5 and 6: Contact tracing for listing and follow-up, sharing and managing

outbreak data, Logistics/deployment of Medical Countermeasures (eELIMS), (online) training, capacity building, referencing, SOPs and e-learning; event management, Research and innovations, ethical approvals, sample tracking and lab results dispatch Section 7: Information Products and BCC materials Section 8: Support supervision guidelines, checklists and feedback, M&E and DQAs

### 9.7 Roles and Responsibilities during eIDSR implementation at different levels

These roles should also be complemented by specific roles as described in relevant sections.

Table 11: Roles of stakeholders in eIDSR implementation at each level Level Roles in eIDSR implementation Community Contribute information on events e.g. through toll-free helplines Health facility Depending on the eIDSR platform, report events requiring immediate action Submit weekly IDSR reports Follow-up on events that are reported by community Act on notifications and respond as recommended for their area of jurisdiction District Provide district staff access to the eIDSR Verify and approve onward transmission of reported events from lower health facilities Issue alerts to other facilities and leaders regarding events within the district Provide feedback to the reporting health facility regarding the event Update the health facilities and leaders regarding progress in the response Training, mentorship and supervision of health staff

- Mobilization of resources to support effective implementation of eIDSR

Ensure availability of eIDSR compatible ICT equipment

Region Training and supervision Collaborate with National level to develop and update electronic tools Issue alerts to districts Provide feedback to the reporting district regarding the event Monitor implementation of actions/recommendations from the national level National Maintaining the eIDSR server Developing and updating electronic tools Managing the eIDSR system, including troubleshooting Maintaining system administration (registration of health staff using server) Training and supervision Routine routing of messages, analysis and provision of feedback to all stakeholders (national program, partners, districts as well as health facilities, and notifiers) Issue alerts to districts, region and other relevant stakeholders Coordination of partners and stakeholders in the implementation of eIDSR Ensuring linkage with other platforms, to facilitate interoperability and avoid duplication Monitoring alerts Advocacy to policy makers and mobilizing resources to sustain the system Ensuring data security Align eIDSR investments and work with the national Health/digital health strategy eIDSR System governance WHO and Facilitate creation of formal platform for sharing information and data regional bodies across countries Technical assistance to member states

- Share best practices and facilitate exchange of expertise

### 9.8 eIDSR implementation in Uganda

#### 9.8.1 Background to eIDSR implementation in Uganda

The eIDSR system is an online system running on the DHIS2 platform, implemented through email, SMS, or phone calls and aggregate data from HMISO33b via mTrac submitted weekly and HMIS105 via DHIS2 submitted monthly.

#### 9.8.2 Objectives of the eIDSR system in Uganda

eIDSR aims at facilitating real-time case reporting and notification for priority diseases, conditions and events. The system also achieves the following specific objectives:

Provide integration of case epidemiology data and laboratory results ii.

Translate surveillance and laboratory data into specific public health actions i11.

Strengthen district-level surveillance of priority diseases and response during outbreaks

#### 9.8.3 Key capabilities of the system

- Notifications: SMS and email notifications are generated and sent to target users:

- a suspect case is identified at the health facility and registered in the System;

- laboratory request is placed, specimen(s) collected and tracked via the hub

system; laboratory results are released and relayed to requesting clinicians o any deaths associated with the outbreak are reported.

- Specimen tracking: Laboratory requests may trigger shipment of specimens through the

hub system. The eIDSR system has a module for specimen tracking until the specimen reaches the final laboratory and results dispatched to intended beneficiaries.

- Outbreak identification: The eIDSR system assigns unique outbreak identifier, in line

with ICD coding, for every outbreak depending on where and when it was confirmed.

- Outbreak tracking: The system is a repository of electronic records of all outbreak data

including outbreak code, confirmed cases, notified cases, deaths, probable dates of onset and outbreak closure and other records such as epi-curves and line-lists.

- Contact tracing: Contact-tracing application is GoData. It captures data recorded on the

contact tracing form, follow up and sending alerts of those that develop symptoms. We can use this data to determine transmission tress and chains starting from the index cases.

- Integration with the weekly aggregate data from HMIS Form 033B: The system

extracts the weekly aggregate data from the mTrac system and allows for validation of casebased and aggregate data. Weekly trend curves are also pre-programed on dashboards.

- Manual Outbreak Confirmation and Closure: A user with appropriate permissions is

allowed to manually confirm or end an outbreak with clearance from the NTF.

- Epidemic Clustering (Merging Outbreaks): The system can be utilized to link and merge

public health threats based on investigations and transmission chains.

The DSFP and Biostatistician are the custodians of eIDSR in the district

#### 9.8.4 Information flow and management

**Figure 16: Information flow and management, eIDSR system in Uganda**

![Figure 16: Information flow and management in Uganda's eIDSR system](uganda-idsr-technical-guidelines-assets/figures/figure-16-eidsr-information-flow.png)

Health Event Suspected(EBS-Formal) Indicator Based Surveillance (IBS) Media Reports Public Health Event (EBS-Informal) Patient with PHE walks into the Public Health Event Health Facility captures Priority Conditions Immediately Reported to nealth facility directly from the Public Health Events using HMIS 033B Health Unit Weekly commamty Health Facility by VHT(S) reported by Media Epidemiological Surveillance Report Forr (Print, Twitter, Radio, TV) HMIS 033B Health Unit Weekly Health Facility submits report to District Hospital Epidemiological Surveillance Report Village/Parish/Subcount‹ Submitted to the District District Surveillance Officer(DSO)

- sends sMs alert via brisz aler

District Officers under leadership of DHO component I DIstrict HosDItal Keceives capture Epidemiological Report Form int Report DHIS2 system District Surveillance Officer(DSO) District Level calls PHEOC PHEOC Receives PHEOC Validates Reported Event with DSO Reported Suspected Confirmation of the Director General Health Once the PHE is controlled, the PHEOC Notify End O Action and Response Starts NECOC of the Reported Health Disaster DGHS informs the public to Services (DGHS) informs the Reported Event Event with CPHL, UVRI public return to "life-as-normal" NECOC I PHEOC I MOH I CPHL I UVR

**Figure 17: Simplified information flow diagram for eIDSR**

![Figure 17: Simplified information flow diagram for eIDSR](uganda-idsr-technical-guidelines-assets/figures/figure-17-simplified-eidsr-flow.png)

NATIONAL/CENTRAL LEVEL REGION/PROVINCE LEVEL District level:

Approval of information DISTRICT LEVEL Feedback Dashboard Weekly HEALTH FACILITY Immediate reports Weekly reports Feedback COMMUNITY

#### 9.8.5 Features of Uganda's eIDSR application

The eIDSR application has three features:

- SMS: commonly collects information from community level who send an SMS to 6767.

- Android: Use android phones using installed apps to register cases.

- Web platform: For trained personnel who login, register, update and make analysis of data.

For further reading, refer to 12,23,48,53-57

SECTION 10 TAILORING IDSR TO EMERGENCY OR FRAGILE HEALTH SYSTEM CONTEXTS

## Section 10: TAILORING IDSR TO EMERGENCY OR FRAGILE HEALTH SYSTEM CONTEXTS

### 10.0 Introduction

Humanitarian emergencies have major implications on the populations where they occur and, on their health, services including surveillance systems. They disrupt the productive capacity of people, destroy the infrastructure and resources, divert the planned use of resources, interrupt programs and retard the pace of development. Population displacement that is associated with disasters poses significant hinderance in accessing basic needs like water, food, shelter and social services.

Uganda has witnessed a number of natural and human-induced disasters. The following have been prevalent: displacement as a result of civil strife; famine as a result of drought; transport accidents, earthquakes; flooding, landslides, environmental degradation, crop pest infestation, human, livestock and wildlife epidemics 58 These conditions, thus, increase the risk of death.

Consequently, effective public health surveillance and response is a priority during public health emergencies in affected populations.

IDSR system needs to be enhanced to meet the public health surveillance and response needs in humanitarian contexts. In these settings, IDSR should be tailored to the prevailing context to meet the additional emergency needs. The system set up should be based on the IDSR strategy, structures, tools, guidelines and resources while ensuring the flexibility required in addressing the surveillance and response needs of affected populations in emergency situations. This should be done within the existing national IDSR system!.

This section introduces key principles of implementing IDSR in complex emergencies. It involves enhancing IDSR core functions to ensure early detection, assessment and response to acute public health events.

### 10.1 Health information system in emergency contexts

Due to the immediate and long-term effects on population health and health systems, disasters create disruptions in the overall functionality of the health system and routine may not be adequate to meet the surveillance information needs of a humanitarian emergency such as armed conflict, famine, natural disasters and other major emergencies.

#### 10.1.1 Key definitions in emergency contexts

Disaster: A serious disruption of the functioning of a community or a society causing widespread human, material, economic or environmental losses which exceed the ability of the affected community or society to cope using its own resources. It overwhelms local capacity.

Humanitarian emergency: A situation where the basic human needs of a population are threatened and therefore requires extra-ordinary measures and urgent action.

Complex emergency: A humanitarian crisis in a country, region or society where there is total or considerable breakdown of authority resulting from internal or external conflict and which

requires an international response that goes beyond the mandate or capacity of any single and/or ongoing UN country program.

### 10.2 Early Warning and Response

Early warning is an organized mechanism to detect as early as possible any abnormal occurrence or any divergence from the usual or normally observed frequency of diseases, conditions and events. It relies on a network of people from the community and functional static or mobile health facilities/clinics that are responsible for collection, investigation, reporting, analysis and dissemination of information from the field to the district and to the central level for appropriate action.

#### 10.2.1 Why is enhanced surveillance needed?

The enhanced surveillance needs during humanitarian emergencies demand that surveillance systems are in place for systematic collection, collation, analysis, and interpretation of data, and dissemination of information to facilitate public health response to prevent excess morbidity, mortality and disability. Consequently, during the acute phase of a humanitarian emergency, IDSR should be modified as soon as possible to focus on priority health problems during the emergency phase. The tailored IDSR should focus on diseases, conditions or events for a given emergency context and should be flexible enough to respond to other emerging public health priorities.

During emergencies, populations are more vulnerable to morbidity, mortality and disability resulting from endemic and epidemic prone diseases. Thus, IDSR should be enhanced within 3-10 days of grading the public health emergency to facilitate rapid detection and response to disease outbreaks and public health events. Ultimately, this will contribute to the overall goal of reducing avoidable mortality, morbidity, and disability during humanitarian crises.

#### 10.2.2 What are the objectives of tailoring IDS to emergency context?

The main objective is to rapidly detect and control acute public health events of any origin, with particular attention to prioritized health risks. The aim is to increase sensitivity of detection, quality of risk assessment, timeliness and effectiveness of the response to acute public health risks in order to minimize the negative health consequences to the affected population.

The specific objectives are to:

- Detect any acute public health events and health risks early;

- Ensure immediate communication of information from the community to the district and

to national levels and vice versa;

- Verify the initial information (i.e. signals);

- Document the nature of the event through epidemiological investigation and

characterization, and etiological confirmation

- Perform risk assessment to determine the level of risk posed by the detected event;

- Ensure immediate alert mechanisms from community to district to national levels and vice

versa;

- Ensure prompt investigation as necessary and implement an adequate response through

mitigation and control measures, as required by the continuous risk assessment; and

- Inform national/international stakeholders and maintain communication/coordination with

them.

#### 10.2.3 Critical components of IDSR in emergency context

During humanitarian crises, community, functional static and mobile health facilities/clinics including Internally Displaced Persons (IDP)/refugee camp clinics that provide curative, disease prevention and health promotion interventions should be included in the IDSR network to enhance the sensitivity of the system. Depending on the extent of the crisis, the surveillance network may include government and/or partner-supported clinics.

To ensure efficiency, the data collection and analysis processes need to be systematized and formalized. Epidemic intelligence should be based on the two main IDSR event detection systems, namely: indicator-based and event-based surveillance (details in Section 1). These complementary systems increase the sensitivity of IDSR to ensure timely detection and verification of outbreaks, and effective monitoring of morbidity patterns.

### 10.3 Steps in implementation of IDSR in humanitarian emergencies

Step 1: Conduct rapid assessment of the situation During the acute phase of the emergency, undertake a systematic assessment of the risk of acute public health events. This involves gauging both the likelihood of a disease occurring and its consequences/impact. The assessment should identify the epidemic-prone diseases that have the potential to cause the greatest amount of morbidity and mortality in the affected population, and determine the geographical scope of surveillance. The assessment is also done on the status of key surveillance infrastructure, including existing surveillance capacity, identification of resource needs for IDSR implementation, including staff with relevant skills, communication and IT equipment, laboratory support, transport and context in which the emergency is occurring. The assessment should be based on consensus-building, analysis of existing data, establishment of working groups and conducting in-depth interviews, as required. It should be based on an all-hazards approach and be repeated as the emergency evolves, to account for changes. The following are criteria for prioritizing diseases, conditions, and events:

- Epidemic vaccine preventable diseases due to disruption of immunization in most of the

emergencies;

- Ability to cause severe morbidity or death;

- International Health Regulations (IHR, 2005) requirements;

- Availability of prevention and control measures;

- Availability of reliable and meaningful case definitions and simple laboratory tests, where

appropriate.

Step 2: Conduct a gap analysis Gap analysis is usually done to complement the assessment of the surveillance system. In order to do this, perform the following:

- Assess the specific needs and environment/context of the humanitarian emergency

- Review the strengths, weaknesses, threats and opportunities in the existing national

surveillance system

- Identify available resources to reinforce IDSR.

The results of previous evaluations of the surveillance system may be used for the gap analysis.

If more information is required conduct focus groups or in-depth interviews with stakeholders at all levels.

Step 3: Prioritization of diseases, conditions, and events in the context of the humanitarian emergency IDSR should be tailored to adequately meet surveillance information needs for the prioritized diseases and events in the humanitarian emergency. The information obtained from the gap analysis and the list of priority events from the rapid assessment for surveillance are critical in conducting a prioritization exercise. For each priority disease, condition or event, surveillance objectives need to be specified based on the local context. The surveillance objectives will depend on the characteristics of the disease, condition or event (e.g., attack rate, morbidity and mortality, setting), the mode of transmission (e.g., person to person, point source outbreaks, exposure to toxic substances), and the nature of the public health interventions required to control spread.

Step 4: Development of a plan of action for the implementation of IDSR Once the prioritization exercise has been completed and all potential sources of information listed, a plan of action should be developed and implemented at the national, and district levels.

The plan of action should be well integrated with the national IDSR system.

Step 5: Designate a coordination mechanism The National Task Force, and the District Task Forces of affected districts together with their Rapid Response Teams should be activated to coordinate reporting, analysis and triaging information, verifying signals, assessing risks, and monitoring and responding to acute public health events.

### 10.4 Stakeholders in implementation of IDSR in humanitarian emergencies

During acute or complex emergencies, where the capacity of the national and sub-national IDSR system in the Ministry of Health is greatly constrained, the roles and responsibilities of various actors may need to be reinforced. These actors should be mapped using a 4W (who, where, what, when) matrix.

National level The overall coordination of data collection, entry, analysis and dissemination during humanitarian crises is the responsibility of the Ministry of Health. The PHEOC should be

activated to support coordination and response activities in the affected regions and districts.

An Incident Commander will be appointed with the following functions:

- Provide dedicated technical oversight to the response;

- Supervise surveillance and outbreak response activities in crisis affected areas;

- Provide guidance to health workers and partners for effective disease surveillance and

outbreak/public health response in crisis affected populations;

- Support districts to investigate and respond to outbreaks or public health events including

reorientation of staff in IDSR;

- Conduct regular analysis of epidemiological trends and production of regular surveillance

bulletins and situation reports;

- Provide tools for reporting and notifying priority diseases, conditions and events

- Support evaluation.

District level The DTF will coordinate surveillance and response activities in crisis-affected populations.

However, during acute crises or complex emergencies where the capacities of districts are constrained, the national level will deploy teams to support the following functions:

- Coordinate disease surveillance and outbreak response in crisis-affected populations;

- Ensure timely reporting of priority diseases, conditions and events related to the crisis

- Conduct trend analyses and provide feedback to health facilities and clinics;

- Conduct initial investigation of disease outbreaks and public health events;

- Respond to disease outbreaks and public health emergencies.

Health facility level Health workers at all levels of the health system shall implement the following surveillance activities:

- Detect, collect and report priority diseases, conditions and events;

- Support the verification and investigation of outbreaks and public health events;

- Implement public health and outbreak response measures with support from the VHTS,

DRRT and NRRT

### 10.5 Surveillance functions during an acute humanitarian emergency

#### 10.5.1 Support functions for surveillance in crisis affected populations

- Disseminate surveillance and outbreak response guidelines at all levels;

- Training of health workers, surveillance focal persons or points, and rapid response teams

on surveillance functions including outbreak preparedness, investigation, and response;

- Support communication (computers, phones, internet connectivity) based on local context

and surveillance needs;

- Regular support supervision to enhance surveillance functions at all levels;

- Periodic evaluation to improve the performance of the surveillance system (refer to

framework for evaluating surveillance systems).

#### 10.5.2 Develop priority diseases/conditions/events list

During the acute phase of a humanitarian emergency, a rapid risk assessment shall be undertaken to identify diseases, conditions, and events that pose a threat to the population.

These should be prioritized in addition to the ones on the national IDSR priority list (if different). Always refer to the list of IDSR priority diseases

#### 10.5.3 Identify priority diseases/ conditions and events

For the diseases, conditions, and events already included on the IDSR priority disease list, the existing case definitions should be used. Sensitive case definitions that increase the chances of detecting new outbreaks should be developed for the additional diseases, conditions, events, and syndromes identified as part of the risk assessment. These case definitions should be simple, standardized, and harmonized with the national IDSR case definitions.

#### 10.5.4 Alert and epidemic thresholds

The following thresholds are used in crisis affected populations:

- Assess the severity of the humanitarian crisis based on the crude mortality rate (CMR) and

under five mortality rates (USMR)

- The CMR threshold should be less than 1 death per 10,000 people per day;

- The USMR threshold should be less than 2 deaths per 10,000 children per day;

- Alert system for detecting possible outbreaks based on doubling of weekly incidence

compared to the weekly average of previous 2-3 weeks;

- Detection of a case of potentially severe epidemic prone disease like measles, polio, cholera,

viral haemorrhagic fevers (VHF) or meningitis based on the IDSR alert and epidemic thresholds specific to crisis affected populations.

Once the thresholds are exceeded, verification, investigation, and response should be instituted promptly to prevent further morbidity and mortality.

#### 10.5.5 Alert verification

To minimize morbidity and mortality, alert verification should start immediately once an alert is received by district surveillance focal points. Immediate Reporting Forms should be used to collect information about the alert.

#### 10.5.6 Outbreak investigation

The investigations should follow existing IDSR outbreak investigation guidelines that have been adapted to address the unique needs of crisis affected populations. The investigations should be undertaken by RRTs at national and district levels that have been established as part of the national IDSR framework. In acute and complex emergencies, dedicated and trained teams will be identified to undertake the investigations.

#### 10.5.7 Report suspected cases/conditions/events

Data is collected from data sources such as inpatient and outpatient clinics, mobile clinics, laboratories, disease-specific active case search or outbreak investigations, community health workers, community alerts, and other sources of disease surveillance data. The following tools should be used which may be paper-based tools and/or electronic platforms:

- Strict adherence to case definitions while collecting disease, conditions or event data;

- Each patient should be assigned one main diagnosis and counted once;

- New and follow up visits should be coded separately in the health facility register;

- National Health Management Information System (HMIS) outpatient and inpatient

registers;

- IDSR immediate case-based and laboratory investigation form;

- IDSR Weekly/Monthly Summary Reporting form;

- IDSR health facility rumour/alert logbook;

- Disease specific line lists;

- Generic or disease-specific case investigation forms;

- Mortality line lists;

The reporting platforms shall provide for the following reporting timelines:

- Immediate reporting of epidemic prone disease alerts;

- Daily reporting of aggregated and/or case-based data on priority diseases, conditions, events

during the acute phase of the crisis and after a new outbreak is confirmed;

- Weekly reporting of aggregated data on priority diseases;

- Weekly mortality line listing updated with community and health facility deaths.

#### 10.5.8 Laboratory support

Laboratory confirmation is very critical for suspected outbreaks in crisis affected populations and the following should be in place to facilitate timely investigation of new outbreaks:

- Adequate stocks of outbreak and sample collection kits / SOPs at the local level;

- Cold chain and shipping arrangements that are linked to the national specimen

transportation system;

- Strengthened laboratory specimen referral network to address the routine and outbreak

laboratory testing needs of crisis affected populations;

- National reference laboratories and laboratories at sub-national levels strengthened to

address the extra demands of crisis affected populations;

- The existing IDSR laboratory and case investigation forms should be used for routine

collection and reporting of laboratory aggregate and case-based data;

- Harmonized reporting systems between the laboratory and surveillance for timely

dissemination of results

#### 10.5.9 Analyze and interpret findings

The principles of data analysis utilized as part of the routine IDSR should be used in crisis affected populations.

Morbidity indicators in emergency affected populations include:

- Absolute counts of cases and deaths by priority disease

- Incidence of disease (new cases by week divided by the total population) with a graph to

show trends from recent weeks. This can be disaggregated by location and person characteristics

- Proportional morbidity (new cases of a specific disease in a week divided by the new total

consultations in the week)

- Case fatality ratio (CFR) - the proportion of cases that die from a specific disease

- Attack rate during outbreaks as the cumulative incidence of epidemic disease in a

population over a period of time.

Mortality indicators in crisis affected populations:

It is critical that mortality rates (CMR and USMR) are monitored for crisis affected populations to ensure that rates exceeding the established emergency threshold are detected and responded to promptly.

- Crude Mortality Rate (CMR) as deaths per 10,000 per day is calculated as the number of

deaths divided by the population present during the period and the total number of days over which the deaths were reported.

- USMR as deaths per 10,000 per day is calculated as the number of deaths in under-fives

divided by the population of under-fives present during the period and the total number of days over which the deaths were reported.

The existing electronic platforms (see Section 9 on eIDS) offer the advantage of automated analyses for both routine and case-based outbreak data thus saving time and ensuring analyzed data is available in real-time to inform disease surveillance and outbreak response decisions at all levels.

#### 10.5.10 Monitoring and evaluation

Monitoring for ensuring full engagement of the stakeholders is critical. In addition to informing disease control efforts, information providers must be included in feedback. Daily situation reports, weekly surveillance summaries, bulletins, and presentations should be shared and reviewed during; weekly IDSR or DTF/NTF meetings; intersectoral and other meetings The existing electronic platforms offer the advantage of producing automated disease surveillance and epidemic bulletins or situation reports to inform disease surveillance and outbreak response decisions at all levels.

#### 10.5.11 Outbreak preparedness

The key preparedness efforts in crisis affected populations should entail the following:

- Activating the DTFs and NTF;

- Updating existing or developing new outbreak prevention and response plans that

incorporate risks unique to crisis affected populations;

- Development or updating (if necessary) of standard line-list forms for data collection during

an outbreak;

- Development and distribution of standard treatment protocols for key diseases, with

strategies for training of staff;

- Calculation of potential attack rates for epidemic-prone diseases based on previous

outbreaks or similar humanitarian emergencies, where possible;

- Pre-positioning stocks of essential treatment supplies to initiate outbreak control (e.g. oral

rehydration salts, intravenous fluids, vaccination materials, personal protective equipment, transport media for samples, water purification supplies, disinfectants, spray pumps and information leaflets on preventive measures for health staff or the community);

- Procurement of laboratory sample collection materials/kits for the priority diseases, and

identification of a competent laboratory for confirmation of cases;

- Identification of potential sites for isolation and adequate treatment of patients, or for extra

capacity in the event of a surge in cases (e.g. a cholera treatment centre);

- Implementation of relevant prevention measures based on the risk assessment of diseases

(e.g. measles and cholera vaccination, indoor-residual spraying of dwellings and distribution of long-lasting insecticide-treated nets to prevent outbreaks of measles, cholera, and malaria respective).

- Accelerate preparedness and response efforts by activating DRRTs in districts with points

of entry (PoE)

#### 10.5.12 Outbreak response

Outbreak response should follow the same principles for enhanced surveillance and response adapted for the humanitarian emergency (Refer to section 6)

### 10.6 Exit strategy

During the recovery phase of the crisis, the Ministry of Health will work with health development partners to re-establish all the IDSR structures and focal points in the crisis affected populations. An evaluation (after action review) should be conducted to assess what happened, why it happened, document lessons learnt, and gaps identified to inform the recommendations to prevent future occurrence.

For further reading, refer to 10,32,35,46,47,59,60

## Section 11: SUMMARY GUIDELINES FOR SPECIFIC PRIORITY DISEASES, CONDITIONS AND EVENTS

### 11.0 Summary guidelines for specific priority diseases and conditions

This section provides summary guidelines for each priority disease, condition and event.

### Acute haemorrhagic fever syndrome

#### Background

Acute haemorrhagic fever syndromes can be attributable to Ebola and Marburg viral diseases (filoviridae); Lassa fever (arenaviridae), Rift Valley fever (RVF) and Crimean-Congo haemorrhagic fever (CCHF) (bunyaviridae); dengue (dengue haemorrhagic fever (DHF)) and yellow fever (flaviviridae); and other viral, bacterial or rickettsial diseases with potential to produce epidemics.

All cases of acute viral haemorrhagic fever syndrome whether single or in clusters, should be immediately notified without waiting for the causal agent to be identified.

#### Surveillance goal

Early detection of acute viral haemorrhagic fever syndrome cases and outbreaks, rapid investigation, and early laboratory verification of the aetiology of all suspected cases.

Investigation of all suspected cases with contact tracing.

During epidemics, most infected patients do not show haemorrhagic symptoms and a specific case definition according to the suspected or confirmed disease should be used (e.g. case definitions for Ebola-Marburg, CCHF, RVF, Lassa, DHF, and yellow fever).

#### Standard case definition

Suspected case: Illness with onset of fever and no response to treatment for usual causes of fever in the area, and at least one of the following signs:

- bloody diarrhea

- bleeding from gums

- bleeding into skin (purpura)

- bleeding into eyes and urine

Confirmed case: A suspected case with laboratory confirmation or epidemiologic link to confirmed cases or outbreak.

Note: During an outbreak, case definitions may be changed to correspond to the local event.

#### Respond to alert threshold

If a single case is suspected:

- Report case-based information immediately to the appropriate levels.

- Suspected cases should be isolated from other patients and strict barrier nursing techniques

implemented. Standard precautions should be enhanced throughout the health care setting.

- Treat and manage the patient with supportive care.

- Collect specimen safely to confirm the case.

- Conduct case-contact follow-up and active case search for additional cases.

#### Respond to action threshold

If a single case is confirmed:

- Maintain strict VHF infection control practices* throughout the outbreak.

- Mobilize the community for early detection and care and conduct community education about

how the disease is transmitted and how to implement infection control in the home care setting and during funerals.

- Conduct case-contact follow-up and active searches for additional cases that may not come to

the health care setting.

- Request additional help from other levels as needed.

- Establish isolation ward to handle additional cases that may come to the health centre.

#### Analyze and interpret data

Person: Implement immediate case-based reporting of cases and deaths. Analyze age and sex distribution. Assess risk factors and plan disease control interventions accordingly.

Time: Graph cases and deaths daily/weekly. Construct an epidemic curve during the outbreak.

Place: Map locations of cases' households and work sites.

#### Laboratory confirmation

Presence of IgM antibodies against Ebola, Marburg, CCHF, Lassa or West

#### Diagnostic test

Nile Fever or Presence of Ebola in post-mortem skin necropsy For ELISA:

#### Specimen

Whole blood, serum or plasma For PCR:

Whole blood or blood clot, serum/plasma or tissue For immunohisto-chemistry: Skin or tissue specimens from fatal cases.

When to collect Collect specimen from the first suspected case.

the specimen If more than one suspected case, collect until specimens have been collected from 5 to10 suspected cases.

Handle and transport specimens from suspected vhf patients with extreme How to prepare, caution. Wear protective clothing and use barrier precautions.

store, and For ELISA or PCR:

transport the

- Refrigerate serum or clot

specimen

- Freeze (-20C or colder) tissue specimens for virus isolation

For Immunohistochemistry:

- Fix skin snip specimen in formalin. Specimen can be stored up to 6

weeks. The specimen is not infectious once it is in formalin.

- Store at room temperature. Formalin-fixed specimens may be transported

at room temperature.

Diagnostic services for VHF are not routinely available. Advance

#### Results

arrangements are usually required for VHF diagnostic services. Contact the appropriate National authority or WHO.

#### Reference

- Interim Infection Control Recommendations for Care of Patients with Suspected or Confirmed

Filovirus (Ebola, Marburg) Hemorrhagic Fever. BDP/EPR/WHO, Geneva March 2008.

- Infection control for VHF in the African health care setting, WHO, 1998. WHO/EMC

- WHO Recommended Surveillance Standards WHO/CDS/CSR/ISR/99.2

- WHO recommended Guidelines for Epidemic Preparedness and Response: Ebola

Haemorrhagic Fever (EHF). WO/EMC/DIS/97.7.

- Infection Control for Viral Hemorrhagic Fevers in the African Health Care Setting

WHO/EMC/ESR/98.2

- Viral Infections of Humans; Epidemiology and Control. 1989. Evans, A.S. (ed). Plenum

Medical Book Company, New York

### Acute viral hepatitis

#### Background

Viral hepatitis A and viral hepatitis E

- Enterically transmitted HAV and HEV are a worldwide problem.

- Common source epidemics have been related to contaminated water and to contamination via

infected food handlers.

- In general, both HAV and HEV are self-limiting viral infections; case fatality is normally low

(0.1 - 0.3%). Women in the third trimester of pregnancy are especially susceptible to fulminant HEV disease.

- Both HAV and HEV are transmitted via the faecal-oral route.

- Prevention and control measures for hepatitis A and hepatitis E include adequate supplies of

safe-drinking water and improvement of sanitary and hygienic practices to eliminate faecal contamination of food and water.

Viral hepatitis B and viral hepatitis C:

- Estimates indicate that worldwide, there are 350 million carriers of hepatitis B virus and 170

million carriers of hepatitis C virus.

- Hepatitis B and C epidemics are uncommon.

- Chronic infection and severe sequelae occur with hepatitis B - an estimated 15% to 25% of

chronically infected persons will die prematurely of either cirrhosis or hepatocellular carcinoma.

Chronic infection is common in hepatitis C and 5% to 20% of those infected with HCV may develop cirrhosis. There seems to be a connection between HCV infection and hepatocellular carcinoma.

- Hepatitis B is transmitted by percutaneous or per mucosal exposure to blood or other infectious

body fluids. Major modes of transmission include sexual contact with an infected person, perinatal transmission from mother to infant, shared needles or syringes among injecting drug users, household contact (e.g., communally used razors and toothbrushes) and nosocomial exposure (transfusions, unsafe injection practices). In most countries where HBV is highly endemic, most infections occur during infancy and early childhood.

- Hepatitis C is transmitted by parenteral exposure to blood and plasma derivatives. It is found in

highest concentrations in blood. The major causes of HCV infection worldwide are use of unscreened blood transfusions and re-use of needles and syringes that have not been adequately sterilised.

- Prevention and control measures for hepatitis B and C include transfusion safety, safe and

appropriate use of injections and vaccination (hepatitis B).

There is no specific treatment for acute viral hepatitis A, B, C and D.

#### Surveillance goal

- Detect hepatitis outbreaks.

- Identify areas/populations at high risk to target prevention and control measures.

- Estimate burden of disease.

If countrywide surveillance is not possible, surveillance in sentinel areas or hospitals may provide useful information on potential sources of infection.

#### Standard case definition

Suspected case: Any person with acute illness typically including acute jaundice, dark urine, anorexia, malaise, extreme fatigue, and right upper quadrant tenderness. (Note: infected children are often asymptomatic.) Confirmed case: A suspected case that is laboratory confirmed

#### Respond to alert threshold

If hepatitis cases are suspected:

- Report case-based information to the appropriate levels.

- As necessary, treat and manage the patients) with supportive care.

- Collect specimens and send to laboratory to identify the aetiology of the illness

#### Respond to action threshold

If hepatitis cases are confirmed

- Determine mode of transmission

- Identify population exposed to risk of infection

- Eliminate common source(s) of infection

Implement appropriate prevention and control interventions

#### Analyze and interpret data

Time: Analysis of suspected and confirmed cases by week.

Graph cases and deaths weekly. Construct an epidemic curve during outbreaks.

Place: Plot location of case households.

Person: Analyze by age and gender. Assess risk factors to plan and monitor prevention and control measures.

#### Laboratory confirmation

Hepatitis A: IgM anti-HAV positive

#### Diagnostic test

Hepatitis B: +ve for Hepatitis B surface antigen (HbsAg) or IgM anti-HBc positive Hepatitis C: Anti-HCV positive Hepatitis D: HBsAg positive or IgM anti-HBc positive plus anti-HDV positive (only as co-infection or super-infection of hepatitis B) Hepatitis E: IgM anti-HEV positive and/or IgG anti-HEV positive Serum

#### Specimen

When to collect Specimens should be collected from suspected patient.

the specimen IgM anti-HAV becomes detectable 5-10 days after exposure.

HBAg can be detected in serum from several weeks before onset of symptoms to days, weeks or months after onset; it persists in chronic infections. IgM anti-HBc positive usually disappears within 6 months.

Use universal precautions to minimize exposure to sharps and anybody How to prepare, store fluid.

and transport the Collect 5-10 ml of venous blood.

specimen

- Let clot retract for 30 to 60 minutes at room temperature or

centrifuge to separate serum from red blood cells.

- Aseptically pour off serum into sterile, screw capped tubes.

- Store serum at 4°C.

- For storage >5 days, samples are held at -20°C

Transport serum samples using appropriate packaging to prevent

#### Results

Results are usually available within one to 3 days from arrival in the laboratory

#### Reference

- WHO Recommended Strategies for Prevention and Control of Communicable Diseases;

WHO/CDS/CPE/SMT/2001.13

- WHO Recommended Surveillance Standards WHO/CDS/CSR/ISR/99.2

- WHO Fact Sheet No 328, Hepatitis A, revised May 2008.

- WHO Fact Sheet No 204, Hepatitis B, revised August 2008

- WHO Fact Sheet No 164, Hepatitis C.

WHO Fact Sheet No 280, Hepatitis E, revised January 2005.

- World Health Organization

http://www.who.int/topics/hepatitis/

- United States, Centers for Disease Control and Prevention

http://www.cdc.gov/hepatitis/

- Control of Communicable Diseases Manual, 18th Edition

### Adverse Events Following Immunization (AEFI)

#### Background

Reports of AEFIs have had negative effects on national immunization programmes. Most reports are "coincidental" events not related to vaccines. It is important to identify real events and determine their cause.

#### Surveillance goal

To determine the cause of an AEFI or cluster of AEFIs and correct it.

#### Standard case definition

A medical incident that takes place after immunization, causes concern and is believed to be caused by the immunization

#### Respond to alert threshold

If a single case is suspected:

- Treat the patient

- Communicate with the parents and community

- Respond to rumours or public enquiries

- Complete case investigation form

Respond to epidemic threshold If a single case is confirmed:

- Monitor for a cluster

- Send report immediately to initiate investigation of cause

- Take remedial action to avoid another AEFI occurring from the same cause

#### Analyze and interpret data

Determine the cause of the event. Is it programme-related, Vaccine-induced, coincidental or unknown?

Beware of mass psychological illness if a number of school-aged or older individuals are involved at the same time.

#### Reference

1. Surveillance of adverse events following immunization. Field guide for managers of immunization programmes. WHO/EPI/93.02 Rev 1. http://www.who.int/vaccinesdocuments/DocsPDF/www9541.pdf 2. Kharabsheh S. Mass psychogenic illness following Td vaccine in Jordan. Bulletin of the WHO 2001.

79 (8); 764-770. http://www.who.int/bulletin/pdf/2001/issue8/vol79.no.8.764-770.pdf

### Anthrax (human)

#### Background

- Anthrax is a widespread zoonotic disease caused by the spore-forming bacterium Bacillus anthracis,

a Gram positive rod-shaped bacterium. A. It is transmitted from infected domestic livestock (cattle, sheep, goats, buffaloes, pigs and others) or wild game animals to humans by direct contact or indirect contact with animals or their products.

- The incubation period typically ranges from 1 to 7 days, but may be longer (up to two to three weeks

for cutaneous anthrax and up to 42 days for inhalation anthrax). Persons exposed to occupational hazards include those handling infected carcasses and those employed in the processing of bones, hides, wool and other animal products. Persons may also become infected by handling or consuming meat from animals that are sick with or have died of the disease. Biting flies have been reported to transmit the disease from infected animals to humans however how readily or often this occurs is

- Human anthrax is a serious problem in several countries and has potential for explosive outbreaks

(especially the gastrointestinal form that is contracted from eating infected meat); while pulmonary (inhalation) anthrax is mainly occupational, the threat of biological warfare attacks should not be forgotten. Anthrax has a serious impact on the trade of animal products.

- The control of anthrax is based on its prevention in livestock. Programmes based only on prevention

in humans are costly and likely to be ineffective except for those industrially exposed.

- There is an effective vaccine for those persons considered at risk for occupational exposure, and

successful vaccines are used for livestock, particularly for herds with ongoing exposure to contaminated soil or vegetation.

- In most countries anthrax is a notifiable disease.

#### Surveillance goal

- To detect outbreaks.

- To monitor control and prevention programmes

#### Standard case definition

Suspected case Any person with acute onset characterized by several clinical forms which are:

(e) Cutaneous form: Any person with skin lesion evolving over 1 to 6 days from a papular through a

vesicular stage, to a depressed black eschar invariably accompanied by edema that may be mild to extensive

(f) Castro-intestinal: Any person with abdominal distress characterized by nausea, vomiting, anorexia

and followed by fever

(g) Pulmonary (inhalation): any person with brief prodrome resembling acute viral respiratory illness,

followed by rapid onset of hypoxia, dyspnoea and high temperature, with X-ray evidence of mediastinal widening

(h) Meningeal: Any person with acute onset of high fever possibly with convulsions, loss of

consciousness, meningeal signs and symptoms; commonly noted in all systemic infections, but may present without any other clinical symptoms of anthrax.

AND has an epidemiological link to confirmed or suspected animal cases or contaminated animal products Confirmed case A confirmed case of anthrax in a human can be defined as a clinically compatible case of cutaneous, inhalational or gastrointestinal illness that is laboratory-confirmed by:

(c) isolation of B. anthracis from an affected tissue or site; or

(d) Other laboratory evidence of B. anthracis infection based on at least two supportive laboratory

tests.

Note: it may not be possible to demonstrate B. anthracis in clinical specimens if the patient has been treated with antimicrobial agents.

#### Respond to alert threshold

If a single case is suspected:

- Report case-based information immediately to the appropriate levels (public health sector and

animal health sector)

- Use standard barrier precautions for all forms. Use protective equipment and clothing (gloves, gowns,

face shields), and respiratory protection if there is a risk of aerosols, disinfection and dressing any cuts and abrasion before putting on protective clothing.

- Perform environmental cleaning (disinfection) with hypochlorite.

- Treat and manage the patient with supportive care and using antibiotics such as Penicillin V,

procaine penicillin (uncomplicated cases), or penicillin G (severe cases)

- Collect specimen safely to confirm the case.

- Conduct joint (public health and animal health sectors) investigation of cases/deaths

- Vaccination is required for animals when exported/imported

- In humans, selective preventive vaccination may be considered in case of occupational exposure

#### Respond to action threshold

If a single case is confirmed:

- Standard infection control precautions are sufficient and should be used when managing the

Patients

- Particular attention should be paid to body fluid spills which should be managed by the usual methods

for cleaning and decontamination of anybody fluid spills. This should be done promptly and thoroughly, because organisms which remain on surfaces may form spores which are infectious

- As is usual practice, personal protective equipment should be used in situations where there is

potential for splashes and inoculation injuries. Any incidents should be reported immediately

- Mobilize the community for early detection and care.

- Proper burial or cremation (if practiced) of dead bodies (humans and animals)

- Conduct community education about the confirmed case, how the disease is transmitted, and how to

use infection control in the home care setting

- Conduct active searches for additional cases that may not come to the health care setting (older women

or small children, for example) and provide information about prevention in the home and when to seek care.

- Request additional help from national levels as needed.

#### Analyze and interpret data

Time: Graphs of number of suspected / probable / confirmed cases by date.

Place: Map of suspected and confirmed human and animal cases by geographical area (district) Person: Table showing the number of suspected / probable / confirmed cases by date, age and sex

#### Laboratory confirmation

#### Diagnostic test

Isolation of Bacillus anthracis from a clinical specimen (e.g. blood, lesions, discharges) Demonstration of B.anthracis in a clinical specimen by microscopic examination of stained smears (vesicular fluid, blood, cerebrospinal fluid, pleural fluid, stools) Positive serology (ELISA, Western blot, toxin detection, chromatographic assay, fluorescent antibody test) Cutaneous

#### Specimen

1. For vesicular lesions, two swabs of vesicular fluid from an unopened vesicle 2. For eschars, the edge should be lifted and two swab samples rotated underneath 3.For ulcers, the base of the lesion should be sampled with two saline moistened swabs 4.Blood cultures obtained prior to antimicrobial therapy, if the patient has evidence of systemic symptoms.

5. A full thickness punch biopsy of a papule or vesicle including adjacent skin should be obtained from all patients with a lesion being evaluated for cutaneous anthrax, to be submitted in 10 percent formalin for histopathology.

6. In patients not on antibiotic therapy or on therapy for <24 hours, a second biopsy specimen 7. Acute and convalescent serum samples for serologic testing Castro-intestinal 1. Blood cultures obtained prior to antimicrobial therapy.

2. Ascites fluid for culture and PCR.

3. Stool or rectal swab for culture and PCR.

4. Oropharyngeal lesion, if present, for culture and PCR.

5. Acute and convalescent serum samples for serologic testing.

6. Autopsy tissues from fatal cases for histopathology.

Inhalation 1. Blood cultures obtained prior to antimicrobial therapy.

2. Pleural fluid, if present, for culture and PCR.

3. CSF, in patients with meningeal signs, for culture and PCR.

4. Pleural and/or bronchial biopsies for IHC.

5.Acute and convalescent serum samples for serology 6. Autopsy tissues from fatal cases for histopathology When to collect the Specimens should be collected from any patient being evaluated for cutaneous specimen Bacillus anthracis infection.

It may not be possible to demonstrate B.anthracis in clinical specimens if the patient has been treated with antimicrobial agents.

Organism is best demonstrated in specimen taken at the Vesicular stage Specimens for culture should be obtained prior to initiation of antimicrobial therapy If available at reference laboratories specimens may be submitted for PCR Caution: B.anthracis is highly infectious Vesicular stage: collect fluid from intact vesicles on sterile swabs.

How to prepare, Eschar stage: without removing eschar, insert swab beneath the edge of eschar, store and transport rotate and collect lesion material. Store specimen for: S24 h and transport for: S2h specimen at room temperature.

Stool: collect 5-10 g in a clean sterile leak-proof container. Store for: S24 h at 4°C. Transport: S1h at room temperature.

Blood: collect per institution's procedure for routine blood culture. Collect 10 ml of blood in EDTA for PCR. Transport: S2h in room temperature.

Sputum: collect expectorated specimen into a sterile leak proof container. Store for: S24 h at 4°C. Transport: S2 h in room temperature.

#### Results

Diagnostic services for Anthrax are not routinely available. Advance arrangements are usually required for Anthrax diagnostic services. Contact the appropriate National authority or WHO.

#### Reference

- WHO. Anthrax in humans and animals. World Health Organization, Geneva. (2008) (Available on

http://www.who.int/csr/resources/publications/ AnthraxGuidelines2008/en/index.html

- WHO Recommended Surveillance Standards WHO/CDS/CSR/ISR/99.2

- WHO recommended Strategies for the Prevention and Control of Communicable Diseases,

WHO/CDS/CPE/SMT/2001.13

- 2003 WHO Manual for Laboratory Diagnosis of Anthrax

(http://www.searo.who.int/en/Section10/Section17/ Section58/Section909.htm)

- "CDC: Anthrax Information for Health Care Providers"

(http://emergency.cdc.gov/agent/anthrax/anthrax-hcp-factsheet.asp)

- CDC: Recommended Specimens for Microbiology and Pathology for Diagnosis: Inhalation,

Cutaneous, and Gastrointestinal Anthraxi (http://emergency.cdc.gov/agent/anthrax/labtesting/recommended specimens.asp)

### Buruli ulcer (Mycobacterium ulcerans disease)

#### Background

- Skin infection caused by Mycobacterium ulcerans (an AFB)

- Occurring mainly as skin lesions (nodules, plaques and ulcers) than can be complicated by bone and

joint involvement. Involvement of other organs like the eyes is rare

- Spreading in inter-tropical areas, in swampy soils or water body surroundings, forestry or surface

mining zones

- Patients are classified into three categories:

- Category I: patient with a single lesion which size is less than 5 cm of diameter (early lesion)

- Category II: patient with single lesion which size is between 5 and 15 cm of diameter

- Category III: patient single lesion which size is over 15 cm of diameter or with multiple lesions

or lesion located in critical site (face, head & neck, breast, perineum, genitalia, lesion spanning over joints)

- BU case management has improved greatly through use of WHO recommended antibiotics (rifampicin

and streptomycin) in 2004. Surgery is still needed for late cases (category III). Cumulative number of cases is over 60,000 in 2009.

- Mode of transmission is still unknown. M ulcerans could penetrate the skin through insect bite (water

bugs); micro trauma or small wounds

- Confirmation of diagnosis is done by PCR, AFB search with ZN staining, culture or histology.

Specimens of lesions are taken by swab in ulcer, fine needle aspiration (FNA) or biopsy in case of surgery.

#### Surveillance goal

- Geographical distribution of the disease to locate endemic areas and districts and focus early case

finding, proper management with WHO recommended antibiotics and prevention of disabilities

#### Standard case definition

Suspected case: A person presenting a painless skin nodule, plaque or ulcer, living or having visited a BU endemic area Confirmed case: A suspected case confirmed by at least one laboratory test (AN for APB, PCR, culture or histology)

#### Respond to alert threshold

If a single case is suspected:

- Report the suspected case to the appropriate level of the health system

At health facility level:

Take a specimen for laboratory confirmation (Swab or FNA)

- Begin wound dressing and combined antibiotic treatment with:

-- Rifampicin 10 mg/kg daily oral intake for 8 weeks (56 days).

-- Streptomycin daily injection for 8 weeks (56 days)

- Refer category III patients to reference hospital/centre

- Fill in case report form (BU 01 or BU 02) with origin village GPS data and report to Health District,

Regional and National levels

- Search other cases in origin village of confirmed case of BU

#### Respond to action threshold

If a suspected case is confirmed (Not applicable to BU)

#### Analyze and interpret data

Time: Graph of cases by year of diagnosis, graph of cumulative number of cases.

Place: Plot cases by location of households and colour shade endemic districts Person: Count newly detected cases monthly by category of patients (Cat I, II or III). Analyze age and disability distribution and treatment outcomes (cases cured, cured without limitation of movement or amputation, relapse after recommended antibiotic treatment).

Laboratory Confirmation Mycobacterium ulcerans: Smears and biopsy specimens can be sent to the

#### Diagnostic test

laboratory for confirmation by:

Ziehl-Neelsen stain for acid-fast bacilli Culture PCR Histopathology Smears and/or Biopsy specimens

#### Specimen

When to collect the Specimens should be collected from suspected patient with clinical symptoms (nodule, plaque, ulcer, osteomielite.) specimen Specimen should be collected before any antibiotic is given. Another specimen should be collected at the end of the treatment (in case the treatment is not efficacious or surgery is indicated) Collection of specimens: it is important to avoid cross contamination between the How to prepare, collection of samples store, and transport Materials: Dry swabs and recipients.

the specimen Types of specimens: No ulcerative forms, Ulcerative forms, Bone Store at 4°C

#### Results

Buruli ulcer is usually diagnosed clinically and by finding acid fast bacilli (AFB) in smears from infected ulcers and tissue biopsies. It can also be identified using PCR.

M ulcerans can be cultured in a reference lab using the same culture media used to grow M.tuberculosis. The organism grows very slowly, usually requiring several weeks to provide visible colonies. Diagnostic services are not routinely available.

Contact the appropriate National authority or WHO.

#### References

- Resolution WHA 57.1 on surveillance and control of Mycobacterium ulcerans disease (Buruli ulcer).

In: 57th World Health Assembly, Geneva, 17-22 May 2004; Resolutions and decisions, annexes.

Geneva, WHO; 2004 (WHA57/2004/REC/1: 1-2)

- Provisional guidance on the role of specific antibiotics in the management of Mycobacterium ulcerans

disease (Buruli ulcer) WHO/CDS/CPE/GBUI/2004.10

- Buruli ulcer: First programme review meeting for West Africa - Summary report. WHO, WER,

6;2009:43-48

- Control of Communicable Diseases Manual, 18th Edition

- District Laboratory Practice in Tropical countries, Cambridge

- Ulcere de Buruli, prise en charge de l'infection a Mycobacterium ulcerans

### Chikungunya

#### Background

- Chikungunya fever is a viral illness that is spread by the bite of infected mosquitoes. The disease

resembles dengue fever, and is characterized by severe, sometimes persistent, joint pain (arthritis), as well as fever and rash. It is rarely life-threatening. Nevertheless, widespread occurrence of diseases causes substantial morbidity and economic loss

- The word "chikungunya" is Makonde for "that which bends up," in reference to the stooped posture of

patients afflicted with the severe joint pain associated with the disease. Epidemics of fever, rash and arthritis, resembling Chikungunya fever were recorded as early as 1779. However, the virus was first isolated between 1952-1953 from both man and mosquitoes during an epidemic, in Tanzania.

- Chikungunya fever historically displayed interesting epidemiological profiles in that: major epidemics

appeared and disappeared cyclically, usually with an inter-epidemic period of 7-8 years and sometimes as long as 20 years. After a long period of absence, outbreaks appeared in Indonesia in 1999 and have been virtually ongoing since 2004.

#### Surveillance goal

- Detect chikungunya sporadic cases and outbreaks promptly, and seek laboratory verification

- Identify high risk areas in order to improve prevention of outbreaks by taking steps to avoid mosquito

bites and elimination of breeding sites.

#### Standard case definition

Suspected case: Any person with acute onset of fever >38.5°C and severe arthralgia/arthritis not explained by other medical conditions.

Confirmed case: A suspected case with laboratory confirmation.

#### Respond to alert threshold

If chikungunya cases are suspected:

- Report case-based information immediately to the next level.

- Collect specimens for confirming the cases

- Conduct an investigation to determine the risk factors for transmission

- Manage and treat the cases using anti-inflammatory agents

#### Respond to action threshold

If chikungunya cases are confirmed

- Symptomatic treatment for mitigating pain and fever using anti-inflammatory drugs along with rest

usually suffices. Persistent joint pain may require analgesic and long-term anti- inflammatory therapy.

- Prevention is entirely dependent upon taking steps to avoid mosquito bites and elimination of

mosquito breeding sites.

To avoid mosquito bites:

- Wear full sleeve clothes and long dresses to cover the limbs.

- Use mosquito coils and repellents.

- Use mosquito nets - to protect babies, old people and others, who may rest during the day. The

effectiveness of such nets can be improved by treating them with permethrin (pyrethroid insecticide). Curtains (cloth or bamboo) can also be treated with insecticide and hung at windows or doorways, to repel or kill mosquitoes.

- Mosquitoes become infected when they bite people who are sick with chikungunya. Mosquito nets

and mosquito coils will help prevent mosquitoes from biting sick people

#### Analyze and interpret data

Time: Graph cases and deaths weekly. Construct an epidemic curve during outbreaks.

Place: Plot location of case households with precise mapping.

Person: Report immediate case-based information for cases and deaths. Report summary totals monthly.

During outbreak, count cases and deaths weekly. Analyze by age. Assess risk factors to improve prevention of outbreaks.

#### Laboratory confirmation

#### Diagnostic test

Serological tests show a rise in antibody titer to chikungunya virus; the virus may be isolated from the blood of acutely ill patients in newborn mice, mosquitoes or cell culture or detected using IFA or Reverse Transcription Polymerase Chain Reaction (RT-PCR) Serum

#### Specimen

Collect specimen from the first suspected case (s). Suspected CHIK cases occur When to collect the in clusters.

specimen Collect representative specimens from suspected cases. If outbreak is confirmed, collect more specimens from cases and also mosquitoes from the affected homes for testing.

Type of Specimen

- Acute-phase blood (0-10 days after onset)

- Convalescent-phase blood (7 - 21 days after onset)

Time of collection:

When patient presents; collect second sample during convalescence. Between days 7 and 21 after onset.

Transport of specimens should comply with the WHO guidelines for the safe How to prepare, store, and transport transport of infectious substances and diagnostic specimens (WHO, 1997).

For ELISA:

the specimen

- Refrigerate at 2° to 8° C serum or clot for testing within 24 hours. If kept

for longer store at -80°.

For Isolation and RT PCR

- Store at -80° or transport in fully charged dry shipper.

Mosquitoes for testing should be transported in fully charged dry shipper.

Focus on Aedes species

#### Results

Diagnostic services for Chikungunya are not routinely available. Contact the appropriate National authority or WHO.

- Minstry of Health, Disease Outbreak Management Unit should send

samples to WHO reference labs e.g. KEMRI

- Preliminary results are ready within 24 hours after samples arrive in the

laboratory. Confirmatory results are ready within a week from sample reception.

#### Reference

- Weekly Epidemiological Record N° 1, 2005, 80, 1-8; http//www.who.int/wer

- World Health Organization http://www.who.int/mediacentre/factsheets/fs327/en/

- United States, Centers for Disease Control http://www.cdc.gov/ncidod/dvbid/chikungunya/

- Sergon et al Seroprevalence of Chikungunya Virus (CHIKV) Infection on Lamu Island, Kenya,

October 2004. Am J Trop Med Hyg. 2008 Feb;78(2):333-337

- Powers et al. Evolutionary relationships and systematics of the alphaviruses. J Virol. 2001

Nov; 75(21): 10118-31

### Cholera

#### Background

- Acute illness with profuse watery diarrhoea caused by Vibrio cholerae serogroups 01 or 0139.

The disease is transmitted mainly through the faecal-oral route; that is through eating or drinking contaminated food or water.

- Cholera causes over 100 000 deaths per year. It may produce rapidly progressive epidemics or

worldwide pandemics. In endemic areas, sporadic cases (less than 5% of all non-outbreak- related diarrhoea cases) and small outbreaks may occur.

- Incubation period is from a few hours to 5 days, usually in the range of from 2 to 3 days.

- There has been a resurgence of cholera in Africa since the mid- 1980s, where over 80% of the world's

cases occurred in 1999. The majority of cases occurred from January through A pril.

- Cholera may cause severe dehydration in only a few hours. In untreated patients with severe

dehydration, the case fatality rate (CFR) may exceed 50%. If patients present at the health facility and correct treatment is received, the CFR is usually less than 1%. At least 90% of the cases are mild, and they remain undiagnosed.

- Risk factors: eating or drinking contaminated foods such as uncooked seafood or shellfish from

estuarine waters, lack of continuous access to safe water and food supplies, attending large gatherings of people including ceremonies such as weddings or funerals, contact with persons who died of cholera.

- Other enteric diarrhoea may cause watery diarrhoca, especially in children less than 5 years of age.

Please see Diarrhoea with dehydration summary guidelines.

#### Surveillance goal

- Detect and respond promptly and appropriately to cases and outbreaks of watery diarrhoea. To

confirm an outbreak, collect and transport stool specimens transported in Cary-Blair medium.

- Do immediate case-based reporting of cases and deaths when an outbreak is suspected.

#### Standard case definition

Suspected case:

- In a patient age 5 years or more, severe dehydration or death from acute watery diarrhoea.

- If there is a cholera epidemic, a suspected case is any person age 5 years or more with acute

watery diarrhoea, with or without vomiting.

Confirmed case:

- A suspected case in which Vibrio cholerae O1 or 0139 has been isolated in the stool.

#### Respond to alert threshold

If a single case is suspected:

- Report case-based information immediately.

- Manage and treat the case according to national guidelines.

- Enhance strict hand-washing and isolation procedures.

- Conduct case-based investigation to identify similar cases not previously reported.

- Obtain stool specimen from 5 patients within 5 days of onset of acute watery diarrhoea, and before

antibiotic treatment is started. See laboratory guidelines for information on how to prepare, store and transport the specimens.

#### Respond to action threshold

If a suspected case is confirmed:

- Establish treatment centre in locality where cases occur. Treat cases onsite rather than asking

patients to go to standing treatment centres elsewhere.

- Strengthen case management including treatment.

- Mobilize community early to enable rapid case detection and treatment. Survey the availability of

clean drinking water.

- Work with community leaders to limit the number of funerals or other large gatherings for

ceremonies or other reasons, especially during an epidemic.

- Reduce sporadic and outbreak-related cases through continuous access to safe water. Promote safe

preparation of food (especially seafood, fruits, and vegetables). Promote safe disposal of human waste.

#### Analyze and interpret data

Time: Graph weekly cases and deaths and construct an epidemic curve during outbreaks. Report casebased information immediately and summary information monthly for routine surveillance.

Place: Plot the location of case households.

Person: Count weekly total cases and deaths for sporadic cases and during outbreaks. Analyze distribution of cases by age and according to sources of drinking water. Assess risk factors to improve control of sporadic cases and outbreaks.

#### Laboratory confirmation

#### Diagnostic test

Isolate V. cholerae from stool culture and determine O1 serotype using polyvalent antisera for V.

cholerae 01.

If desired, confirm identification with Inaba and Ogawa antisera.

If specimen is not serotypable, consider, V. cholerae 0139 (see note in Results column).

Liquid stool or rectal swab

#### Specimen

For each new area affected by the outbreak, a laboratory confirmation should be When to done.

collect the Collect stool sample from the first suspected cholera case. If more than one specimen suspected case, collect until specimens have been collected from 5 to 10 cases.

Collect stool from patients fitting the case definition and:

- Onset within last 5 days, and

- Before antibiotics treatment has started

Do not delay treatment of dehydrated patients. Specimens may be collected after rehydration (ORS or IV therapy) has begun.

If possible, specimens should be collected from 5 - 10 suspected cases every 1 - 2 weeks to monitor cessation of the outbreak, changes in serotypes, and antibiotic sensitivity patterns of V.cholerae.

- Place specimen (stool or rectal swab) in a clean, leak proof container and

How to prepare, transport to lab within 2 hours.

store, and transport • If more than 2-hour delay is expected, place stool-soaked swab into Carythe specimen Blair transport medium.

If Cary-Blair transport medium is not available and specimen will not reach the lab within 2 hours:

- Store at 4°C to 8°C

- Do not allow specimen to dry. Add small amount of 0.85% NaC if

necessary

- To transport, transport in well marked, leak proof container

- Transport container in cold box at 4°C to 8°C

- Cholera tests may not be routinely performed in all laboratories.

#### Results

- Culture results usually take 2 to 4 days after specimen arrives at the

laboratory.

- Cary-Blair transport medium is stable and usually good for at least one year

after preparation. It does not require refrigeration if kept sterile and in properly sealed container. If colour changes (medium turns yellow) or shrinks (depressed meniscus), do not use the medium.

- The O139 serotype has not been reported in Africa and only in a few places

in southwest Asia.

Serological determination of Ogawa or Inaba is not clinically required. It is also not required if polyvalent antisera results are clearly positive.

#### Reference

- Management of the patient with cholera, World Health Organization, 1992.

WHO/CDD/SER/91.15 Rev1 (1992)

- Epidemic diarrhoeal disease preparedness and response--Training and practice. Facilitator and

participant manuals. World Health Organization, 1997. WHO/EMC/DIS/97.3 and WHO/EMC/DIS/97.6

- "Laboratory Methods for the Diagnosis of Epidemic Dysentery and Cholera." CDC/WHO, 1999

CDC, Atlanta, GA, USA

### Dengue Fever

#### Background

- Dengue fever is an arbovirus transmitted by Aedes mosquitoes (both Ae. aegypti and Ae.

albopiticus). Dengue is caused by four serologically distinct, but closely related viruses: dengue virus (DENV) 1, 2, 3, and 4 of the flaviviridae family.

- Dengue fever is an emerging pandemic that has spread globally during the past 30 years as a result

of changes in human ecology. Dengue is found in tropical and sub-tropical regions around the world, predominately in urban and semi-urban areas. During dengue epidemics, infection rates among those who have not been previously exposed to the virus are often 40% to 50%, but can reach 80% to 90%.

- Dengue fever is a severe, influenza-like illness that affects infants, young children and adults, but

seldom causes death. Dengue haemorrhagic fever (DHF) is a potentially deadly complication that has become a leading cause of hospitalization and death among children in Asia. There is good evidence that sequential infection with the different serotypes of dengue virus increases the risk of more severe disease that can result in shock syndrome (DSS) and death.

- Epidemic dengue activity in Africa has mostly been classical dengue fever caused by DENV-1 and

DENV-2 without associated mortality. The first major outbreak of DENV-3 in Africa was documented in Mozambique in 1984-1985. During this outbreak, most patients experienced secondary infections and 2 deaths were attributed to DHF and shock. In 2008, yellow fever and DENV-3 were found to be co-circulating in Abidjan, Cote d'Ivoire, however, no severe dengue cases or deaths attributable to dengue were identified.

- There is no specific treatment for dengue, but appropriate medical care frequently saves the lives of

patients with dengue haemorrhagic fever.

- Infected humans are the main carriers and multipliers of the virus, serving a source of the virus for

uninfected Aedes aegypti mosquitoes which maintain the urban dengue transmission cycle. The virus circulates in the blood of infected human for 2-7 days, at approximately the same time that they have a fever. A sylvatic transmission cycle has been documented in west Africa where DENV-2 has been found in monkeys. There is no evidence of person-to-person transmission.

- At present, the only method of controlling or preventing dengue virus transmission is to combat the

vector mosquitoes using environmental management and chemical methods.

#### Surveillance goal

- Surveillance for suspected cases and investigation of clusters of suspected cases in areas with

Ae. aegypti and Ae. albopiticus mosquitoes

#### Standard case definition

Dengue Fever Suspected case: Any person with acute febrile illness of 2-7 days' duration with 2 or more of the following: headache, retro-orbital pain, myalgia, arthralgia, rash, haemorrhagic manifestations, leucopenia.

Dengue Fever Confirmed case: A suspected case with laboratory confirmation (positive IgM antibody, rise in IgG antibody titres, positive PCR or viral isolation).

Dengue Haemorrhagic Fever: A probable or confirmed case of dengue with bleeding tendencies as evidenced by one or more of the following: positive tourniquet test; petechieae, ecchymoses or purpura; bleeding: mucosa, gastrointestinal tract, injection sites or other; haematemesis or melaena; and thrombocytopenia (100 000 cells or less per mm3) and evidence of plasma leakage due to increased vascular permeability, manifested by one or more of the following: 20% rise in average haematocrit for age and sex, 20% drop in haematocrit following volume replacement therapy compared to baseline, signs of plasma leakage (pleural effusion, ascites, hypo-proteinaemia).

Dengue Shock Syndrome: All the above criteria, plus evidence of circulatory failure manifested by rapid and weak pulse, and narrow pulse pressure (:S 20 mm Hg) or hypotension for age, cold, clammy skin and altered mental status.

#### Respond to alert threshold

If a single case is suspected:

- Report case-based information immediately to the next level.

- Conduct active search for additional cases

- Collect specimens for confirming the cases

#### Respond to action threshold

If a single case is confirmed:

- Report case-based information immediately to the next level.

- Conduct active search for additional cases

- Collect specimens for confirming the cases

- Survey the community to determine the abundance of vector mosquitoes, identify the most

productive larval habitats, promote and implement plans for their elimination, management or treatment with appropriate larvicides.

- Educate the public and promote behaviors to remove, destroy or manage mosquito vector larval

habitats.

- Manage and provide supportive treatment to dengue fever cases. Implement standard infection

control precautions. Prevent access of mosquitoes to patients by using mosquito be d n e ts.

- Refer suspected DHF/DSS cases to more advanced facilities.

#### Analyze and interpret data

Time: Graph cases and deaths weekly/monthly. Construct an epidemic curve during the outbreak.

Place: Plot location of case households and work sites using precise mapping.

Person: Case-fatality rate. Analyze age and sex distribution. Percentage of DHF / DSS cases and of hospitalizations.

#### Laboratory confirmation

#### Diagnostic test

Demonstration of IgM and IgG by Antibody Assays.

Detection of viral genomic sequences by PCR. Isolation of the dengue virus using cell culture.

Antigen detection Assays for acute phase samples when PCR or isolation is negative.

Demonstration of dengue virus antigen in autopsy tissue by immunohistochemistry or immunofluorescence or in serum samples by EIA Note: there are several diagnostic techniques available to document an infection by the dengue virus. The IgM ELISA is the basic test for serologic diagnosis.

ELISA: Whole blood, serum or plasma from acute (0-5 days) and

#### Specimen

convalescent 6 or more days) depending on each case.

PCR: Whole blood or blood clot, serum/ plasma or tissue preferably from acute specimens (0-5 days) The samples should be collected for diagnosing a suspected dengue fatality:

A blood sample to attempt PCR, virus isolation and serology. If an autopsy is performed, blood from the heart should be collected.

Collect specimen from the first suspected case.

When to collect the If more than one suspected case, collect until specimens have been specimen collected from 5 to10 suspected cases.

Type of Specimen

- Acute-phase blood (0-5 days after onset of symptoms)

- Convalescent-phase blood (6 days after onset)

Time of collection

- Collect 2nd sample during convalescence. Between days 6 and 21

after onset.

Lab diagnosis of fatal cases is indispensable for understanding the risk factors for severe cases.

Transport of specimens should comply with the WHO guidelines for How to prepare, store, the safe transport of infectious substances and diagnostic specimens.

and transport the For ELISA or PCR:

specimen

- Refrigerate serum or clot. For long term storage freeze -20C

- Freeze (-20C or colder) tissue specimens for virus isolation

If an autopsy has been performed and no fresh tissues are available, tissues fixed in formalin should be submitted for immunohistochemical studies.

Diagnostic services for Dengue fever and Dengue hemorrhagic fever

#### Results

are not routinely available. Advance arrangements are usually required for VHF diagnostic services. Contact the appropriate National authority or WHO.

#### Reference

- WHO Recommended Surveillance Standards WHO/CDS/CSR/ISR/99.2

- Dengue: clinical and Public Health Aspects/CDC

### Diabetes

#### Background

- Diabetes mellitus (DM) is a widespread chronic disease that occurs when the pancreas does not

produce enough insulin, or when the body cannot effectively use the insulin it produces. Diabetes can cause serious health complications including heart disease, blindness, kidney failure, and lower-extremity amputations.

- Diabetes mellitus (DM) is a widespread chronic disease that occurs when the pancreas does not

produce enough insulin, or when the body cannot effectively use the insulin it produces. Diabetes can cause serious health complications including heart disease, blindness, kidney failure, and lower-extremity amputations.

- The most common form is Type 2 diabetes that represents more than 85% of the cases. Other

forms are less common such as Type 1 (10% of cases), specific diabetes and gestational diabetes (5% of cases).

- The risk factors that affect the onset of diabetes are well-known. They comprise non- modifiable

factors like old age (over 45 years of age), family history, and the causes of diabetes in pregnancy.

Modifiable risk factors for diabetes are obesity, physical inactivity and excessive alcohol consumption.

- The global prevalence in 2000 was estimated at 2.8%, with projections of 4.8% by 2030. The total

number of persons affected will rise from 171 million in 2000 to 366 million in 2030 if no action is taken. Annual mortality linked to diabetes worldwide is estimated at more than one million.

- Diabetes is no longer considered rare in Africa. Recent estimates based on the WHO STEP-wise

approach for monitoring the risk factors of non-communicable diseases indicate prevalence of between 1% and 20%. In some countries such as Mauritius, it reaches 20%.

- The rate of limb amputations due to diabetes varies from 1.4% to 6.7% of diabetic foot cases. In

some African countries, the mortality rate is higher than 40 per 10,000 inhabitants.

- In the African Region, efforts made to create an environment that enhances the fight against

diabetes include adoption of resolutions on non-communicable diseases in 2000, cardiovascular diseases strategy in 2005, and diabetes mellitus strategy in 2007. The World Health Organization and the International Diabetes Federation (IDF) have also jointly carried out actions to contribute to promoting diabetes awareness in Africa.

#### Surveillance goal

- Estimate the magnitude of the disease

- Monitor trends and risk factors

- Identify populations at highest risk (e.g.; age groups, urban vs. rural)

- Monitor prevention and control program activities

#### Standard case definition

Suspected new case:

Any person presenting with the following symptoms:

- Increased thirst

- Increased hunger

- Frequent urination

Confirmed new case:

Any person with a fasting venous plasma glucose measurement of 7 mmol/L (126 mg/dl) or capillary glucose 6.1 mmol/L (110 mg/dl) Or Any person with a non-fasting venous plasma glucose measurement of 11. 1mmol/L (200 mg/dl) or capillary glucose 11,1 nnik>k (200 mg/dl) *Report only the first lab-confirmed diagnosis of the patient Recommended public health action For people with diabetes:

- Treat confirmed cases according to the standardized case management guidelines (WHOPEN).

District-level Prevention:

- Implement an integrated prevention and control programme for non-communicable diseases

focusing on diabetes through community awareness and education activities, in accordance with national prevention and control programmes for non-communicable diseases like multisectoral strategies and plans of action on diet, weight-reduction, and physical activity.

- Implement clinical preventive measures and treatment interventions using evidence-based

guidelines (screening high risk patients, for example).

#### Analyze and interpret data

Time: Graph cases quarterly to analyze trends.

Place: Compare district trends with national and regional trends.

Person: Analyze the distribution of cases by age and other demographic factors.

* Data for non-communicable diseases is analyzed for long term trends

#### Laboratory confirmation

#### Diagnostic test

Measuring glucose in capillary blood using a reagent strip test and reference meter Measuring glucose in plasma using a glucose-oxidase colorimetric test method Lab case definition (see section 8.0)

#### Specimen

Plasma, Capillary blood When to Blood glucose measurements must be carried out on the day and at the time collect requested.

specimen Fasting specimen: for adult the fasting time is usually 10 tu 16 hours. For children the fasting time is 6 hours.

Post-prandial specimen: 2h post-prandial specimen.

Specimen should be examined as soon as possible (before 2 hours) at health How to prepare, facility where the specimen is taken.

store, and transport

#### Results

Results are ready within few hours.

#### Reference

- Non-communicable Diseases: A strategy for the African Region, AFR/RC50/10

- Cardiovascular Diseases in the African Region: Current situation and perspectives,

AFR/RCS5/12

- Diabetes prevention and control: a strategy for the African Region, AFR/RC57/7

- Steps manual: http://www.who.int/chp/steps/en/

- Gojka R et al, Global prevalence of diabetes, Diabetes care 27(5): 1047-1053, 2004.

- IDF, Diabetes Atlas, 2nd Edition, Brussels, International Diabetes Federation, 2003.

- WHO, Preventing chronic diseases: A vital investment, Geneva, World Health

Organization, 2005.

- WHO, The burden of mortality attributable to diabetes, Geneva, World Health Organization,

2004.

- WHO-PEN: Protocols for health promotion, prevention and management of NCDs at primary care

level http://www.afro.who.int/en/divisions-a-programmes/ddc/division/2257-who-penprotocols.html

- District Laboratory Practice in Tropical countries, Cambridge

### Diarrhoea with blood (Shigella)

#### Background

- Shigella dysenteriae type 1 (SD1) is the most common cause of enteric infections and is

transmitted from person-to-person through faecal-oral spread.

- Large scale outbreaks may be caused by Shigella dysenteriae type 1 (SD1) with up to 30% of

populations infected. The case fatality rate may approach 20% among young children and elderly persons with severe dehydration.

The incubation period is from 1 to 4 days.

- Clinical illness is characterized by acute fever and bloody diarrhoea, and can also present with

systemic symptoms and signs as well as dehydration especially in young children.

- Risk factor: overcrowded areas with unsafe water and poor sanitation (for example, refugee and

tamine populations).

- SD1 is frequently resistant to multiple antibiotics including trimethoprim-sulfamethoxazole.

- Enterohaemorrhagic and enteroinvasive E. coli and other bacteria or parasites such as

Entamoeba histolytica may also cause bloody diarrhoea.

#### Surveillance goal

- Detect and respond to dysentery outbreaks promptly.

- Improve percentage of laboratory-confirmed cases and evaluate proportion verified as type 1

(SD1).

- Determine antibiotic sensitivity pattern of the agents isolated (especially SD1) both for routine

surveillance and during outbreaks.

#### Standard case definition

Suspected case: A person with diarrhoea with visible blood in stool.

Confirmed case: Suspected case with stool culture positive for Shigella dysenteriae typel.

#### Respond to alert threshold

If you observe that the number of cases or deaths is increasing over a period of time:

- Report the increase to the next level of the health system.

- Treat the suspected cases with oral rehydration and antibiotics based on recent susceptibility

results, if available.

- Obtain stool or rectal swab specimen for confirming the SD1 outbreak.

- Investigate the case to determine risk factors contributing to transmission.

#### Respond to action threshold

If a suspected outbreak is confirmed:

- Search for additional cases in locality of confirmed cases.

- Strengthen case management and treatment.

- Mobilize community to enable rapid case detection and treatment.

- Identify high risk populations using person, place, and time data.

- Reduce sporadic and outbreak-related cases by promoting hand-washing with soap or ash and water

after defecating and before handling food. Strengthening access to safe water supply and storage, and use of latrines and safe disposal of human waste.

#### Analyze and interpret data

Time: Graph monthly trends in cases and deaths. Construct an epidemic curve for outbreak cases.

Place: Plot location of case households.

Person: Count cases and deaths each month. During an outbreak, count outbreak-related cases by week. Routinely analyze age distribution. Assess risk factors to improve control and prevention of sporadic diseases and outbreaks.

#### Laboratory confirmation

Isolate Shigella dysenteriae type 1 (SD1) in culture to confirm shigella Diagnostic test outbreak. If SD1 is confirmed, perform antibiotic sensitivity tests with appropriate drugs.

#### Specimen

Stool or rectal swab.

to When For each new outbreak area, a laboratory confirmation should be done.

the Collect sample when an outbreak is suspected. Collect stool from 5-10 patients collect who have bloody diarrhoea and:

specimen

- Onset within last 4 days, and

- Before antibiotic treatment has started.

Collect stool in a clean, dry container. Do not contaminate with urine. Sample stool with a swab, selecting portions of the specimen with blood or mucus. If stool cannot be collected, obtain a rectal swab sample with a clean, cotton swab.

How to Place stool swab or rectal swab in Cary-Blair transport medium. Transport to laboratory refrigerated.

prepare, store, If Cary-Blair not available, send sample to lab within 2 hours in a clean, dry and container with a tightly-fitting cap. Specimens not preserved in Cary-Blair will transport the have significant reduction of shigellae after 24 hours.

specimen If storage is required, hold specimens at 4°C to 8°C, and do not freeze.

#### Results

Culture results are usually available 2 to 4 days after receipt by the laboratory.

SD1 isolates should be characterized by antibiotic susceptibility.

After confirmation of initial 5-10 cases in an outbreak, sample only a small number of cases until the outbreak ends, to monitor cessation of the outbreak, and antibiotic sensitivity patterns, which will guide the definitive treatment.

Refer to disease specific guidelines in Section 8.0 for additional information about the epidemic potential of Shigella dysenteriae 1

#### Reference

- Guidelines for the control of epidemics due to Shigella dysenteriae type 1. WHO/CDR/95.4

- Safe Water Systems for the Developing World: A Handbook for Implementing Household- based

Water Treatment and Safe Storage Projects. Department of Health & Human Services. Centers for Disease Control and Prevention. Atlanta. 2000

- "Laboratory Methods for the Diagnosis of Epidemic Dysentery and Cholera". CDC/WHO, 1999

CDC, Atlanta, GA, USA

### Diarrhoea with dehydration in children less than 5 years of age

#### Background

- Diarrhoea with dehydration in children less than 5 years of age is due to infections of the

gastrointestinal tract caused by viruses (especially Rotavirus), bacteria (E. Coli, Salmonellae, shigellae, Campylobacter, Yersinia, and others), and parasites (Giardia, Entamoeba, cryptosporidia, and cyclospora). These diseases are transmitted through eating contaminated food or water, or through faecal-oral spread.

- Diarrhoeal diseases represent the second leading cause of death among children less than 5 years

of age in many African countries, with more than 3 million deaths per year.

- Different epidemiological patterns (for example, seasonality) are observed for different pathogens.

- The WHO and UNICEF advocate that each district team use the Integrated Management of

Childhood Illnesses (IMCI) strategy to reduce morbidity and mortality of childhood diarrhoea.

#### Surveillance goal

- Detect diarrhoea outbreaks promptly. Laboratory confirmation can confirm specific pathogenic

agent outbreak, but laboratory confirmation is not necessary for routine surveillance of diarrhoea with dehydration.

- Monitor antimicrobial resistance during outbreaks of bacterial origin.

#### Standard case definition

Suspected case:

Passage of 3 or more loose or watery stools in the past 24 hours with or without dehydration and:

- Some dehydration -- two or more of the following signs: restlessness, irritability; sunken eyes;

thirsty; skin pinch goes back slowly, or

- Severe dehydration -- two or more of the following signs: lethargy or unconsciousness; sunken

eyes; not able to drink or drinking poorly; skin pinch goes back very slowly.

Confirmed case: Suspected case confirmed with stool culture for a known enteric pathogen. Note: Laboratory confirmation of specific agent causing outbreak is not routinely recommended for surveillance purposes.

#### Respond to alert threshold

If you observe that the number of cases or deaths is increasing over a period of time:

Report the problem to the next level.

- Investigate the cause for the increased number of cases or deaths and identify the problem.

- Make sure that cases are managed according to IMCI guidelines.

- Encourage home-based therapy with oral rehydration.

#### Respond to action threshold

If the number of cases or deaths increase to two times the number usually seen in a similar period in the past:

Assess health worker practice of IMCI guidelines for managing cases and improve performance for classifying diarrhoea with dehydration in children less than 5 years of age.

- Teach mothers about home treatment with oral rehydration.

- Conduct community education about boiling and chlorinating water, and safe water storage and

preparation of foods.

#### Analyze and interpret data

Time: Graph cases and deaths to compare with same period in previous years. Prepare graphs for outpatient diarrhoea with some dehydration and for diarrhoea with severe dehydration.

Construct an epidemic curve when outbreaks are detected.

Place: Plot location of case households.

Person: Report monthly totals due to diarrhoea with some dehydration and also for diarrhoca with severe dehydration from outpatient services. Also report monthly inpatient total cases and deaths due to diarrhoea with severe dehydration.

#### Laboratory confirmation

Laboratory culture of stools may be used to confirm possible outbreaks of specific agents, but is not necessary for case definition.

#### Reference

- Management of childhood illness: Clinical skills training course for first level health facilities.

World Health Organization. WHO/CDR/95.14

- Integrated Management of Childhood Illness: A WHO/UNICEF Initiative Bulletin of the World

Health Organization. Vol. 75, 1997, Supplement 1, 1997. ISBN 92 4 068750 5

### Dracunculiasis

#### Background

- Dracunculiasis is commonly known as Guinea worm disease. It is caused by a large nematode, a

disabling parasite that emerges through the skin of the infected person.

- This is an old disease, known since antiquity, leaving many patients with unfortunate socio- economic

consequences. It is transmitted through ingestion of water containing a crustacean (cyclops) which is infested by an immature form (larvae) of the nematode. The Cyclops is found in stagnant surface water sources (ponds, traditional shallow wells) in rural areas. The female nematode discharges from the host's skin when there is contact with water. The incubation period is between 9 to 12 months There is no treatment or vaccine against the disease.

- Successful disease control strategies conducted by the endemic countries and an international coalition

of partners has pushed Dracunculiasis towards eradication. By December 2008, 4619 cases of Guinea worm were reported to WHO, worldwide, compared to 892 000 that were reported in 1989, showing a reduction of 99.47%.

- In 1989, the disease was endemic in 20 countries, worldwide: Benin, Burkina Faso, Cameroon, Central

African Republic, Cote d'Ivoire, Chad Ghana, Ethiopia, India, Pakistan, Kenya, Mali, Mauritania, Niger, Nigeria, Sudan, Senegal, Togo, Uganda and Yemen

- Currently, solely Africa remains affected where 6 countries are still endemic in 2009: Sudan, Ghana,

Mali, Ethiopia, Nigeria, and Niger.

#### Surveillance goal

- Active detection and investigation of each case at the community level. Monthly reporting of cases

to the next level.

- In zones where, local transmission of the Guinea worm disease has been interrupted, maintain

active searches for additional cases or rumors of case.

Report all imported cases to countries or areas of origin.

Integrate into surveillance to confirm absence of transmission.

#### Standard case definition

Suspected case:

- A person presenting a skin lesion with itching or blister living in endemic area of Guinea worm.

- Confirmed case: at the last phase of the programme, confirmation of last cases by knowledgeable

health staff is required.

#### Respond to alert threshold

If a single case is suspected:

- Report the case according to national program guidelines for eradication of Dracunculiasis.

- Treat the wound (if any) to decrease disability associated with painful leg lesions.

- Conduct case investigation to confirm risk factors.

- Improve access to safe water according to national guidelines.

#### Analyze and interpret data

Time:

Graph cases monthly.

Place: Plot distribution of households and work sites for cases from which cases have been reported.

Person: Count monthly cases, and analyze age distribution. Report monthly to next levels.

#### Laboratory confirmation

Routine laboratory confirmation for surveillance is not required. Diagnosis is made by visual recognition of the adult worm protruding from a skin lesion (see section 8.0) or by microscopic identification of larvae.

Laboratory tests to investigate dracunculiasis are limited because the larvae of

D. medinensis are normally washed into water. A diagnosis usually made when the blister has ruptured and the anterior end of the female worm can be seen. If required, laboratory confirmation of the diagnosis can be made as follows: place a tew drops of water on the ulcer, collect and transter the water to a slide and examine microscopically for motile larvae.

#### Reference

- Control of Communicable Diseases Manual, 18th Edition

- Dracunculiasis or guinea-worm, Geneva, World Health Organization WHO/CDS/CEE/DRA/99.2,

1999 and WHO/WER N°37 September 2003

- District Laboratory Practice in Tropical countries, Cambridge

### Ebola or Marburg virus diseases

#### Background

- The Ebola and Marburg viruses are both filoviruses. Almost 3,000 cases of Ebola with over 1,900

deaths have been documented since the Ebola virus was discovered in 1976. Major Ebola outbreaks have occurred in Sudan, DRC, Cote d'Ivoire, Gabon, Uganda and Congo. More than 500 cases of Marburg with over 400 deaths were reported during outbreaks of Marburg virus that occurred in DRC (1998-2000), Angola (2004-2005) and Uganda (3 cases in 2007).

- These two viruses are transmitted by direct contact with the blood, secretions, organs or other body

fluids of infected persons. The infection of humans with Ebola virus through the handling of infected chimpanzees, gorillas, and forest antelopes (alive and dead) has been documented.

- Ecological studies are in progress to identify the natural reservoirs of both Marburg and Ebola. There

is evidence that bats are involved

- Epidemics can be dramatically amplified in health care facilities with inadequate infection control

precautions/barrier nursing procedures.

- Incubation period for Ebola and Marburg is 2 to 21 days.

- Between 20% and 80% of patients have haemorrhagic manifestations depending on the Ebola or

Marburg virus strain. Patients become increasingly infectious as their illness progresses.

- High case fatality ratios have been reported during Ebola outbreaks (25% to 90%) and during Marburg

outbreaks (25% to 80%)

- There is no specific treatment for either disease. Severe cases require intensive supportive care, as

patients are frequently dehydrated and in need of intravenous fluids or oral rehydration with solutions containing electrolytes.

- Close contact with a severely ill patient, during care at home or in hospital, and certain burial practices

are common routes of infection. Transmission via contaminated injection equipment or through needlestick injuries is associated with more severe disease. Infection may also be spread through contact with soiled clothing or bed linens from an infected patient.

Surveillance goals

- Early detection of cases and outbreaks, rapid investigation, and early laboratory verification of the

aetiology of all suspected cases.

- Investigation of all suspected cases with contact tracing.

During epidemics, most infected patients do not show haemorrhagic symptoms and a specific case definition according to the suspected or confirmed disease should be used.

Standard case definition (routine surveillance) Suspected case: Illness with onset of fever and no response to usual causes of fever in the area, and at least one of the following signs: bloody diarrhoea, bleeding from gums, bleeding into skin (purpura), bleeding into eyes and urine.

Confirmed case: A suspected case with laboratory confirmation (positive IgM antibody, positive PCR or viral isolation), or epidemiologic link to confirmed cases or outbreak.

Note: During an outbreak, these case definitions may be changed to correspond to the local event.

#### Respond to alert threshold

If a single case is suspected:

- Report case-based information immediately to the appropriate levels.

- Suspected cases should be isolated from other patients and strict barrier nursing techniques

implemented

- Standard precautions should be enhanced throughout the healthcare setting.

- Treat and manage the patient with supportive care.

- Collect specimen to confirm the case(s).

- Conduct case-contact follow-up and active case search for additional cases.

#### Respond to action threshold

If a single case is confirmed:

- Maintain strict VHF infection control practices* throughout the outbreak.

- Mobilize the community for early detection and care of cases and conduct community education about

how the disease is transmitted and how to implement infection control in the home care setting and during funerals.

- Conduct case contact follow-up and active searches for additional cases that may not come to the

health care setting.

- Request additional help from other levels as needed.

- Establish isolation ward to handle additional cases that may come to the health centre.

#### Analyze and interpret data

Person: Implement immediate case-based reporting of cases and deaths. Analyze age and sex distribution. Assess risk factors and plan disease control interventions accordingly.

Time: Graph cases and deaths daily/weekly. Construct an epidemic curve during the outbreak.

Place: Map locations of cases' households.

#### Laboratory confirmation

#### Diagnostic test

Presence of IgM antibodies against Ebola, Marburg, CCHF, Lassa or West Nile Fever or Presence of Ebola in post-mortem skin necropsy

#### Specimen

For ELISA: Whole blood, serum or plasma For PCR: Whole blood or blood clot, serum/plasma or tissue For immunohisto-chemistry: Skin or tissue specimens from fatal cases.

When to collect Collect specimen from the first suspected case.

If more than one suspected case, collect until specimens have been collected from 5 to10 suspected cases.

HANDLE AND TRANSPORT SPECIMENS FROM SUSPECTED EBOLA/ How to prepare, store, MARBURG CASES WITH EXTREME CAUTION. WEAR PROTECTIVE and transport CLOTHING AND USE BARRIER PRECAUTIONS.

For ELISA or PCR:

- Refrigerate serum or clot

- Freeze (-20C or colder) tissue specimens for virus isolation

For Immunohistochemistry:

- Fix skin snip specimen in formalin. Specimen can be stored up to 6 weeks.

The specimen is not infectious once it is in formalin.

Store at room temperature. Formalin-fixed specimens may be transported at room temperature.

#### Results

Diagnostic services for VHF are not routinely available. Advance arrangements are usually required for VHF diagnostic services. Contact the appropriate National authority or WHO.

#### Reference

- Interim Infection Control Recommendations for Care of Patients with Suspected or Confirmed

Filovirus (Ebola, Marburg) Hemorrhagic Fever. BDP/EPR/WHO, Geneva March 2008.

- Infection control for VHF in the African health care setting, WHO, 1998. WHO/EMC

- WHO Recommended Surveillance Standards WHO/CDS/CSR/ISR/99.2

- WHO Fact Sheet No 103, Ebola haemorrhagic fever, revised December 2008

- WHO Fact Sheet, Marburg haemorrhagic fever, revised July 2008

- Interim Infection Control Recommendations for Care of Patients with Suspected or Confirmed

Filovirus (Ebola, Marburg) Hemorrhagic Fever. BDP/EPR/WHO, Geneva March 2008.

- WHO recommended Guidelines for Epidemic Preparedness and Response: Ebola

Haemorrhagic Fever (EHF). WO/EMC/DIS/97.7.

- Dengue haemorrhagic fever: diagnosis, treatment, prevention and control. 2nd edition. Geneva:

World Health Organization. 1997.

### Foodborne Illnesses

#### Background

- Foodborne illnesses are caused by a variety of bacterial, viral, parasitic and bacterial or fungal

pathogens or their toxins that enter the body through consumption of food or water. In addition to diseases listed elsewhere in this guideline such as cholera, and shigellosis, surveillance for foodborne illnesses may involve other causes such as salmonellosis, hepatitis A or chemical contamination.

- A foodborne illness occurs when two or more people have shared common food or drink followed by

an onset of symptoms within a short time period.

- Most people with a foodborne illness do not seek medical care, so cases and outbreaks of foodborne

illness usually are neither recognized nor reported.

- The first symptoms often occur in gastrointestinal tract. Nausea, vomiting, abdominal cramps and

diarrhoea are frequent symptoms of foodborne diseases.

- Outbreaks may be localized affecting as few as 2 individuals who ate a common meal or product, but

large and geographically widespread outbreaks may also occur. Large outbreaks occur when food is contaminated prior to distribution and is widely consumed by many people in many areas.

- Surveillance for foodborne illnesses is needed to monitor food safety and target health promotion

actions aimed at food handlers for safer food practices and improved personal hygiene.

Surveillance Coal

- To promptly identify any unusual cluster of disease potentially transmitted through food, which may

need a public health investigation or response.

- Monitor the magnitude of foodborne illnesses

- Identify high risk foods or food practices.

- Monitor risk factors to inform public health interventions and health promotion for targeted foods or

food practices.

#### Standard case definition

A foodborne illness is suspected when 2 or more people present with similar symptoms and who consumed common food or drink A foodborne illness is defined according to the specific agent causing the discase (for example, cholera, hepatitis A, salmonellosis, shigellosis).

A confirmed foodborne illness is a laboratory confirmed case of a specific agent with a link to a common food or drink source.

#### Respond to alert threshold

If observed that 2 people are ill and have eaten food from a common source:

- Immediately report the illness to the next level of the heath system

- From patients and from the suspected food items and drinks, collect specimens for laboratory

confirmation

- Treat suspected cases

#### Respond to action threshold

If an outbreak of a foodborne illness is confirmed:

- Search for additional cases in locality of confirmed cases

- Strengthen case management and treatment

- Mobilize community for rapid case detection and treatment

- Identify high risk groups

- Remove from the restaurant menu or the supermarkets shelves, food items from which evidence of

unsafe food may be obtained.

- Eventually call for in-depth investigation of the food chains that may be associated with the

outbreak

- Reduce sporadic and outbreak-related cases by promoting handwashing with soap and water after

defaecating/urinating and before food handling/meals; strengthen access to safe water supply and storage, use of latrines and safe human waste disposal

- Scale-up food safety health promotion activities using the WHO Five Keys to Safer Food (see

reference below) and the Hazard Analysis Critical Control Point (HACCP) system

- Scale-up food inspection activities

#### Analyse and interpret data

- Time: Graph monthly trends in cases and deaths; Construct an epidemic curve for outbreak cases.

- Place: Plot location of households for cases and deaths

- Person: Count cases and deaths each month. During an outbreak, count outbreak-related cases by

- Routinely review clinical data and laboratory results from food and human analyses to identify clusters

of cases in time, place or person. Investigate any suspected foodborne outbreaks detected in the data.

- Investigate all suspected outbreaks of foodborne illnesses.

#### Reference

- Guidelines for Strengthening Foodborne Disease Surveillance in the WHO African Region

- WHO Five Keys to Safer Food at www.who.int/fst/Documents/Skeys-ID-eng.pdf

- WHO Foodborne disease outbreaks: Guidelines for investigation and control

http://whqlibdoc.who.int/publications/2008/9789241547222 eng.pdf

### Human influenza caused by a new subtype

#### Background

- An influenza pandemic occurs when a new influenza A virus emerges with efficient and sustained

human-to-human transmission in populations with limited immunity. Influenza pandemics occurred in 1918, 1957 and 1968. The 1918 pandemic killed an estimated 40-50 million people. It is predicted that a pandemic of equivalent magnitude could kill 62 million people, 96% of them in developing countries.

- Successful containment or control of pandemic influenza is dependent on early recognition of

sustained human-to-human transmission. Countries have been encouraged as part of pandemic preparedness planning to enhance surveillance to (i) detect the emergence of new disease; (ii) characterize the disease (epidemiology, clinical manifestations, severity); (iii) monitor its evolution.

Influenza A (H1N1) 2009: On 11 June 2009, WHO declared a global pandemic due to influenza A (HIN1) 2009 virus and of 8 October 2009, 195 countries, territories and areas had reported cases and/or outbreaks of pandemic (HIN1) virus. The spectrum of disease ranges from non-febrile, mild upper respiratory tract illness to severe or fatal pneumonia.

- Influenza A (H5N1): Another influenza subtype, H5N1 has been circulating among birds for more

than 10 years. In 2003, infections in people exposed to sick birds were identified. Since 2003, H5N1 has been confirmed in poultry and/or wild birds in 62 countries and 442 confirmed human H5N1 cases with 262 deaths have been reported from 15 countries. One confirmed death from human infection with A (H5N1) was reported from Nigeria in January 2007. Most patients with H5N1 present with symptoms of fever, cough and shortness of breath and radiological evidence of pneumonia. The large majority of cases for which risk factor data are available indicate that direct contact with live or recently dead poultry is the most important risk factor for human HSNI infection. However, the continued geographical spread of this highly pathogenic avian influenza virus among birds in Asia, Europe, the Middle East and Africa has heightened concerns about the possibility of a global human pandemic of influenza H5N1.

- Under the IHR (2005), a State Party is required to notify WHO of the first occurrence of human

influenza caused by a new subtype, including pandemic (H1N1) 2009 virus.

Surveillance goals

- To detect and investigate the first evidence of sustained human-to-human transmission of an influenza

virus with pandemic potential.

- To assess the earliest cases of pandemic influenza occurring in a country in order to characterize the

new disease including its clinical characteristics, risk factor information, and epidemiological and virological features.

- To monitor the course of the pandemic within the country, regionally and globally.

Standard case definition Suspected H5NI case:

Any person presenting with unexplained acute lower respiratory illness with fever (>38 °C) and cough, shortness of breath or difficulty breathing AND one or more of the following exposures within the 7 days prior to symptom onset:

/ Close contact (within 1 meter) with a person (e.g. caring for, speaking with, or touching) who is a suspected, probable, or confirmed H5N1 case;

g) Exposure (e.g. handling, slaughtering, de-feathering, butchering, preparation for consumption) to

poultry or wild birds or their remains or to environments contaminated by their faeces in an area where H5N1 infections in animals or humans have been suspected or confirmed in the last month;

h) Consumption of raw or undercooked poultry products in an area where H5N1 infections in

animals or humans have been suspected or confirmed in the last month; Close contact with a confirmed H5N1 infected animal other than poultry or wild birds; Handling samples (animal or human) suspected of containing H5N1 virus in a laboratory or other setting.

Confirmed H5NI case: A person meeting the criteria for a suspected case AND positive laboratory results from a laboratory whose H5N1 test results are accepted by WHO as confirmatory.

Suspected pandemic (HINI) 2009 virus infection: An individual presenting with influenza- like-illness (sudden onset of fever > 38 °C and cough or sore throat in the absence of another diagnosis) with a history of exposure to a pandemic (H1N1) 2009 virus.

Confirmed pandemic (HINI) 2009 virus infection: An individual with a laboratory-confirmed pandemic (H1N1) 2009 virus infection by one or more of the following tests: PCR; viral culture; 4-fold rise in pandemic (HIN1) 2009 virus-specific neutralizing antibodies.

#### Respond to alert threshold

Respond to a suspected case of human influenza caused by a new subtype or to an unusual event of severe acute respiratory infection:

- Report case-based information immediately to the appropriate levels; Search for additional cases.

- Implement acute respiratory disease infection control precautions immediately and enhance

Standard Precautions throughout the health care setting.

- Treat and manage the patient according to national guidelines.

- Collect laboratory specimens from case-patient and from symptomatic contacts and arrange for

laboratory testing

- Review clinical and exposure history during 7 days before disease onset.

- Identify and follow-up close contacts of case-patient.

- Conduct epidemiological investigation to identify risk factors for infection and populations at risk

for severe disease.

- Plan and implement prevention and control measures.

#### Respond to action threshold

If a single case of human influenza caused by a new subtype is confirmed or if another acute respiratory disease of epidemic or pandemic potential is confirmed:

- Maintain strict acute respiratory disease infection control precautions and establish an isolation ward

to manage additional cases who may present for care.

- Treat and manage the patient according to national guidelines.

- Implement active surveillance of case-patient contacts.

- Conduct active searches for additional cases.

- Distribute laboratory specimen collection kits to health care facilities.

- Identify high risk populations.

- Mobilize the community to enable rapid case detection and treatment.

- Conduct community education on how influenza is transmitted and on how to implement infection

measures in home and community settings.

#### Analyze and interpret data

Time:

Graph weekly cases and deaths, construct an epidemic curve Place:

Plot location of case households and work sites using precise mapping.

Person: Count weekly total cases and deaths for sporadic cases and during outbreaks. Analyze age and sex distribution. Characterize the illness in terms of clinical presentation, the spectrum of disease, the proportion of cases requiring hospitalization, clinical outcomes, case fatality ratio, attack rates by age/occupation/blood relation.

#### Laboratory confirmation

Identification of human influenza virus infections by:

#### Diagnostic test

1) Detection of influenza-specific RNA by reverse transcriptase-

polymerase chain reaction

2) Isolation in cell culture (BSL3 lab required for suspected new subtype)

3) Direct antigen detection (low sensitivity)

#### Specimen

A variety of specimens are suitable for the diagnosis:

- Throat swab

- Nasopharyngeal swab

- Nasal swab

- Nasopharyngeal aspirate

Intubated patients: tracheal swab or broncholavage fluid Blood

Specimens should be collected in the following order of priority:

- Throat swab/Nasopharyngeal aspirate

- Acute serum

Convalescent serum When to collect the Obtained specimen within 3 days of the onset of symptoms, specimen Initial specimens (respiratory or blood) should ideally be collected from suspected patients before antiviral therapy is begun but treatment must not be delayed in order to take specimens.

Optimally, paired sera (3-5 ml of whole blood), collected first during the acute phase of illness and then 14 days or later after the onset of illness, should be tested simultaneously.

Specimens should be collected from deceased patients as soon as possible after death Respiratory specimens should be transported in virus transport media.

How to prepare, Media that could be used for a variety of viruses are commercially available.

store, and Specimens in viral transport medium for viral isolation should be kept at transport 4°C and transported to the laboratory promptly. If specimen is transported the specimen within 2 days, it may be kept at 4°C; otherwise should be frozen at or below -70 °C until transported to the laboratory. Repeated freezing and thawing must be avoided to prevent loss of infectivity.

Sera may be stored at 4°C for approximately one week, but thereafter should be frozen at -20°C.

Transport of specimens should comply with the WHO guidelines for the safe transport of infectious substances and diagnostic specimens

#### Results

Laboratory results should be confirmed by an approved laboratory.

Any specimen with a positive result for influenza A virus and suspected of avian influenza infection/new subtype should be further tested and verified by a designated WHO CC/ WHO H5 Reference laboratory. Laboratories that lack the capacity to perform specific influenza A subtype identification procedures are requested to:

- Forward specimens or virus isolates to a National Influenza Centre or to

a WHO CC/WHO H5 Reference Laboratory for further identification or characterisation.

- Inform the WHO Office in the country that specimens or virus isolates

are being forwarded to other laboratories for further identification or further characterization.

#### References

- WHO guidelines for global surveillance during an influenza pandemic, April 2009.

- WHO updated interim guidance on global surveillance of human infection with pandemic (HIN1)

2009 virus, July 2009.

- WHO guidelines for investigation of human cases of avian influenza A (H5N1), 2007

- WHO interim guidelines on infection prevention and control of epidemic- and pandemic- prone

acute respiratory diseases in health care, June 2007.

- Collecting, preserving and shipping specimens for the diagnosis of avian influenza A (H5N1) virus

infection. Guide for field operations, October 2006

- WHO Rapid Advice Guidelines on pharmacological management of humans infected with avian

influenza A (H5N1) virus, May 2006.

- WHO guidelines for clinical management of human infection with new influenza A (H1N1) virus:

Initial Guidance, May 2009.

- WHO Guidelines for pharmacological management of pandemic (HIN1) 2009 influenza and other

influenza viruses, 20 August 2009.

- Recommended laboratory tests to identify avian influenza virus A in specimens from humans,

WHO, revised August 2007.

- Collecting, preserving and shipping specimens for the diagnosis of avian influenza A (H5N1) virus

infection. Guide for field operations, October 2006 WHO/CDS/EPR/ARO/2006.1

### Hypertension

#### Background

- Hypertension or high blood pressure (HBP) is a chronic condition in which the blood pressure in

the arteries is elevated. It is classified as either primary (essential) or secondary. 'Primary' Hypertension is elevated blood pressure where no medical cause is found. 'Secondary' Hypertension is caused by other conditions that affect the arteries, heart, endocrine system or kidneys.

- Hypertension is a major risk factor for cardiovascular diseases such as heart attack or stroke.

According to The World Health Report 2001, cardiovascular disease related deaths are increasing in the African Region, and in 2000 accounted for 9.2% of the total deaths in the African Region.

Prevalence ranges from 25% to 35% in adults aged 25 to 64 years.

- Hypertension affects approximately 1 billion worldwide and it is estimated that more than 20 million

people in the African Region are affected.

- Major risk factors for hypertension are ageing, lack of physical activity, obesity, and a diet high in

salt and fat. Other risk factors include; tobacco and alcohol use.

- Lifestyle modifications shown to lower BP include; weight reduction for individuals who are

overweight or obese, reducing the amount of fat and salt in the diet, and eating more fresh fruits and vegetables, increased physical activity, and reduction of alcohol and tobacco consumption.

#### Surveillance goal

- Prevention of secondary illness by early detection and standardized treatment

- Estimation of disease burden and reduction of identified risk factors

- Monitor control and prevention activities

#### Standard case definition

Suspected new case at first visit: Any individual presenting with a resting blood pressure measurement (based on the average of 3 readings) at or above 140 mm Hg for systolic pressure, or greater than or equal to 90 mm Hg for diastolic pressure.

Confirmed case: Any individual presenting on at least two occasions with a resting blood pressure measurement (based on the average of 3 readings) at or above 140 mm Hg for systolic pressure, or greater than or equal to 90 mm Hg for diastolic pressure.

* Report only the first diagnostic of the case in the health centre Recommended public health action

- Health promotion for non-communicable diseases focusing on HBP should be established, including

community-based education on behavior change and adoption of healthy lifestyles

- Promote secondary prevention and treatment interventions at health facilities according to national

guidelines.

#### Analyze and interpret data

Time: Graph cases quarterly to analyze trends.

Place: Compare district trends with national and regional trends.

Person: Analyze the distribution of cases by age and other demographic factors.

*Data for non-communicable diseases is often analyzed for long term trends Laboratory confirmation: Diagnostic is clinical.

#### Reference

- WHO, Atlas of heart disease and stroke, Geneva, World Health Organization, 2004.

- Non-communicable Diseases: A strategy for the African Region, AFR/RC50/10

- Cardiovascular Diseases in the African Region: Current situation and perspectives, AFR/RC55/12

- http://www.who.int/chp/steps/en/

- http://www.afro.who.int/dnc/databases/afro infobase/index.html

- WHO CVD-risk management package for low-and medium resource settings.

- The Seventh Report of the Joint National Committee on Prevention, Detection, Evaluation, and

Treatment of High Blood Pressurei U.S. Department of health and Human Services, National Institutes of Health, National Heart, Lung, and Blood Institute, NIH Publication No. 03-5233, December 2003

- Handbook of Hypertension, Vol 20. Editor; C.J. Bulpitt, 2000

- http://www.cdc.gov/bloodpressure/

### Influenza-like Illness (ILI)

#### Background

- Respiratory infections are a significant cause of infectious disease morbidity and mortality in the

world. The mortality rates are particularly high among infants, children and the elderly. However, the burden of disease is not well characterized in Africa.

- The most common pathogens causing respiratory infections are; Streptococcus pneumoniae,

Haemophilus influenzae type b (Hib), Staphylococcus aureus and other bacterial species, Respiratory Syncytial Virus (RSV), measles virus, human parainfluenza viruses type 1, 2, and 3 (PIV-1, PIV-2 and PIV-3), influenza virus and varicella virus.

- An improved understanding of the epidemiology and seasonality of respiratory infections in Africa is

essential for optimizing public health strategies for their prevention and control (e.g., vaccines and antivirals for prophylaxis and treatment, infection control).

- The threat of respiratory infections due to novel organisms that have epidemic or pandemic potential

warrants special precautions and preparedness. Respiratory disease events that may constitute a public health emergency of international concern include; Severe Acute Respiratory Syndrome (SARS); human influenza caused by a new subtype, including human episodes of avian influenza; pneumonic plague; and novel agents that can cause large-scale SARI outbreaks with high morbidity and mortality.

- Surveillance for respiratory infections is based on the Influenza-like Illness (ILI) case definition. Lab-

based surveillance or investigations using the ILI case definition is used to identify the disease-causing pathogen.

Surveillance goals

- Early detection of unusual events that might indicate a shift in the severity or pattern of disease

associated with influenza, or emergence of a new influenza strain.

- Establish and monitor baseline rates of severe respiratory disease, including monitoring the severity

and impact of influenza,

- Describe and monitor vulnerable groups at highest risk of severe disease

- Detection of antigenic or genetic changes in circulating viruses or the appearance of antiviral

resistance

#### Standard case definition

Influenza-like Illness: Any person with:

- Sudden onset of fever > 38 °C AND

- Cough or sore throat in the absence of other diagnoses

A confirmed case of influenza is a case that meets the clinical case definition and is laboratory confirmed (laboratory results must be positive for influenza virus).

Respond to an alert threshold If there is an unusual event (a cluster of deaths, for example) of respiratory infection, or if a single case of pandemic-prone acute respiratory disease is suspected:

- Unusual cases of influenza-like illness.

- Health-care workers with only occupational exposure risks develop ILI after providing care to

patients with ILI.

- Two or more children and/or adults presenting with a respiratory infection or who died from a

respiratory infection with onset of illness in a two-week period and in the same geographical area and/or are epidemiologically linked.

- Persons who have contact with birds/animals present with ILI;

- Any rumor of clusters of acute respiratory infections or of atypical respiratory infections

Respond to a suspected case of an epidemic- or pandemic-prone acute respiratory disease or to an usual event of severe acute respiratory infections:

- Report case-based information immediately to the appropriate levels.

- Practice infection control precautions for an acute respiratory disease with epidemic/pandemic

potential (e.g., Standard plus Contact plus Droplet Precautions) immediately and enhance Standard Precautions throughout the health care setting.

- Treat and manage the patient according to national guidelines.

- Collect and transport laboratory specimens from case-patient and from symptomatic contacts and

arrange for laboratory testing

- Review clinical history and exposure history during 7days before disease onset.

- Identify and follow-up close contacts of case-patient.

- Conduct active searches for additional cases.

- Conduct risk assessment to guide decision-making

- Public health measures related to international border and travel should be implemented under the

framework of the international health regulations (2005)

#### Analyze and interpret data

Time: Graph cases and deaths weekly. Describe changes in the level of respiratory activity compared to the previous week. Construct an epidemic curve throughout the year and describe transmission patterns.

Person: Characterize the illness in terms of clinical presentation, the spectrum of disease including severity of illness, count and report cases and deaths, the proportion of cases requiring hospitalization, clinical outcomes, case fatality ratio, attack rates by age/occupation/blood relation, laboratory confirmed cases.

Describe the overall level of respiratory disease activity. Immediate case-based reporting of cases and deaths. During the outbreak, Analyze age and sex distribution. Assess risk factors immediately Place: Describe the degree of disruption of schools, health care infrastructure, workplace and point of entry (PoE). Ascertain whether any evidence exists that the virus may have increased its ability to cause human disease or improved its transmissibility. Also use trends of flu remedies and painkillers sales

#### Laboratory confirmation

Further technical information on the role of laboratory can be found in the WHO guideline on sentinel surveillance of influenza viruses

#### Reference

- World Health Organization - Acute Respiratory Infections

http://www.who.int/vaccine research/diseases/ari/en/index.html

- World Health Organization - Influenza resources

http://www.who.int/csr/disease/influenza/inforesources/en/index.html

World Health Organization - Interim guidelines on infection prevention and control of epidemic- and pandemic-prone acute respiratory diseases in health care, June 2007 http://www.who.int/csr/resources/publications/WHO CD EPR 2007 6/en/index.html

- World Health Organization - Guidelines for investigation of human cases of avian influenza A

(H5N1), January 2007.

http://www.who.int/csr/resources/publications/influenza/WHO CDS EPR GIP 2006 4/en /index.html

- World Health Organization - Collecting, preserving and shipping specimens for the diagnosis of

avian influenza A (H5N1) virus infection. Guide for field operations, October 2006.

http://www.who.int/csr/resources/publications/surveillance/WHO CDS EPR ARO 2006 1/en/index.html

- World Health Organization - Guidelines for the collection of human specimens for

laboratory diagnosis of avian influenza infection, 12 January 2005.

http://www.who.int/csr/disease/avian influenza/guidelines/humanspecimens/en/

### Injuries (Road traffic accidents)

#### Background

- Injury is a physical damage resulting when the human body is briefly or suddenly subjected to levels

of energy exceeding its physiological tolerance or the impairment in function resulting from the lack of one or more vital elements (water, air, warmth). The energy causing the injury can be mechanical, electrical, thermal, radiant or chemical. Injury is classified as intentional and unintentional.

- Road traffic accidents result in unintentional injury. All injuries account for 10% of the world's deaths

### 5.8 million People die each year as a result of different types of injuries. Of the all systems that people

have to deal with on a daily basis; road transport is the most complex and the most dangerous.

- A traffic collision (motor vehicle collision, motor vehicle accident, car accident, or car crash) occurs

when a road vehicle collides with another vehicle, pedestrian, animal, road debris, or other geographical or architectural obstacle. Traffic collisions can result in injury, property damage, and death.

- Global death due to road traffic crashes annually is estimated at 1.2 million, while the number of injured

could be as high as 50 million. Road traffic injuries are a major but neglected global public health problem, requiring concerted efforts for effective and sustainable prevention.

- Road traffic injuries continue to be among the leading causes of death and disability among young

people aged between 5 and 44 years and the leading cause of death in the category of people between 15-29 years; majorly among "vulnerable road users"-pedestrians, pedal cyclists and motorcyclists.

- Without increased efforts and new initiatives, the total number of road traffic deaths worldwide and

injuries is forecast to rise by some 67% by 2020, and in low income and middle-income countries deaths are expected to increase by as much as 83%

- The African region has the highest fatality rate for road traffic crashes at 32/100 000 population

- Road traffic injuries are preventable. Very substantial reductions in juries can be achieved by

implementing measures which address risk factors (excessive and inappropriate speed, driving under the influence of alcohol, non-use of seat belts and child restraints, non- use of helmets for cyclists)

#### Surveillance goal

- Estimate and monitor incidence of road traffic injuries and related outcomes

- Identify risk factors and high-risk areas to inform prevention policy and programs

- Evaluate programmes aimed at preventing road traffic injuries

- Establish alert thresholds for fatalities to allow health facility personnel review care and services

provided to injured persons

- Establish incidence alert thresholds and monitor trends to enable district health personnel inform

relevant stakeholders

#### Standard case definition

Road traffic injury: Any person who has sustained an injury as a result of a road traffic crash presenting for the first time.

Road traffic fatality: Any person killed immediately or dying within 30 days as a result of an injury crash.

#### Respond to alert threshold

- Promote primary prevention by supporting interventions to address risk factors

- Review and monitor care and services provided to injured persons

- Review arrangements for mass casualty management

#### Respond to action threshold

- Step up enforcement of measures to address risk factors

- Activate mass casualty management system

#### Analyze and interpret data

Person: Analyze the distribution of cases by sex, age and other demographic factors Time: Graphs to show monthly figures of cases and deaths, curves for the year to depict trends Place: Plot location of cases and identify high risk areas

#### Laboratory confirmation

Imaging of the injured person - when required

#### Reference

- WHO-2004, World Health report

- WHO- 2010 Status report on Road Safety in Africa

- WHO, 2004-Peden, M.; et al (eds) World report on Road Traffic Injury prevention

- WHO,2001 - Holder Y., Peden M., Krug E. et al(eds) Injury Surveillance Guidelines, Geneva

- Harvey A, (Ed).Data systems, Geneva, World Health Organisation, 2010

### Lassa and Crimean-Congo Haemorrhagic Fevers

#### Background

- Crimean-Congo haemorrhagic fever (CCHF) belongs to the Bunyaviridae virus family and Lassa fever

belongs to the Arenaviridae virus family.

- CCHF is endemic in Africa and outbreaks have been reported from Uganda, Mauritania, and South

Africa. Mauritania reports a few cases each year and South Africa reported 165 laboratoryconfirmed cases between 1981 and March 2006.

- Lassa fever is known to be endemic in Guinea, Liberia, Nigeria and Sierra Leone, but probably

exists in other West African countries as well. Some studies indicate that 300,000 to 500,000 Lassa fever cases with 5,000 deaths occur each year in West Africa.

- CCHF spreads to humans either by tick-bites, or through contact with viraemic animal tissue immediately

post-slaughter.

- The animal reservoir of the Lassa virus is a rodent of the genus Mastomys. Mastomys infected with Lassa

virus do not become ill but shed the virus in their excreta (urine and faeces) and humans usually become infected through aerosol or direct contact with excreta of infected rodents. Lassa fever can also be spread between humans through direct contact with the blood, pharyngeal secretions, urine, faeces or other body secretions of an infected person.

- Person-to-person transmission of both CCHF and Lassa fever has occurred in health care settings after

exposure to blood and secretions of infected patients.

- The incubation period for CCHF following a tick bite is usually 1-3 days (max 9 days) and following

contact with blood or tissues is usually 5-6 days (max 13 days). The incubation period for Lassa fever ranges from 6-21 days.

- The onset of symptoms among CCHF patients is sudden with fever, myalgia and other signs and

symptoms. The reported case fatality ratio for CCHF is between 3% and 30%.

- About 80% of human Lassa fever infections are mild or asymptomatic; the remaining cases have severe

multi-system disease. The onset of disease in symptomatic patients is usually gradual starting with fever, general weakness and malaise. Lassa fever is difficult to distinguish from many other diseases which cause fever, including malaria, shigellosis, typhoid fever, yellow fever and other VHFs. The overall case fatality ratio is 1-15% among hospitalized patients.

General supportive therapy is the mainstay of patient management in CCHF. Intensive monitoring to guide volume and blood component replacement is required. The antiviral drug, ribavirin, has been used in the treatment of established CCHF infection. Both oral and intravenous formulations seem to be effective.

Ribavirin is effective treatment for Lassa fever is given early in the course of clinical illness.

#### Surveillance goal

- Early detection of cases and outbreaks, rapid investigation, and early laboratory verification of the

aetiology of all suspected cases.

- Investigation of all suspected cases with contact tracing.

- Assess and monitor the spread and progress of epidemics and the effectiveness of control measures.

#### Standard case definitions

Suspected case of CCHF: Illness with sudden onset of fever, malaise, weakness, irritability, headache, severe pain in limbs and loins and marked anorexia. Early development of flush on face and chest and conjunctival infection, haemorrhagic enanthem of soft palate, uvula and pharynx, and often fine petechial rash spreading from the chest and abdomen to the rest of the body, sometimes with large purpuric areas.

Confirmed case of CCHF: Any person with laboratory confirmation (positive IgM antibody, PCR, viral isolation or IgG seroconversion by ELISA or IFA) or epidemiologic link to confirmed cases or outbreak.

Suspected case of Lassa Fever: Illness with gradual onset with one or more of the following: malaise, fever, headache, sore throat, cough, nausea, vomiting, diarrhoea, myalgia, chest pain hearing loss and a history of contact with excreta of rodents or with a case of Lassa Fever Confirmed case of Lassa Fever: A suspected case that is laboratory confirmed (positive IgM antibody, PCR or virus isolation) or epidemiologically linked to a laboratory confirmed case.

#### Respond to alert threshold

If a single case is suspected:

- Report case-based information immediately to the appropriate levels.

- Suspected cases should be isolated from other patients and strict barrier nursing techniques

implemented.

- Standard infection control precautions should be enhanced throughout the healthcare setting.

- Treat and manage the patient with supportive care.

- Collect specimen to confirm the case(s).

- Case-contact follow-up and active case search for additional cases.

#### Respond to action threshold

If a single case is confirmed:

- Maintain strict VHF infection control practices* throughout the outbreak.

- Mobilize the community for early detection and care and conduct community education about how the

disease is transmitted and how to implement infection control in the home care setting. For CCHF, educate the public about the mode of tick transmission and enhance rodent control activities for Lassa fever.

Conduct active searches for additional cases. Request additional help from other levels as needed D111:1

#### Analyze and interpret data

Person: Implement immediate case-based reporting of cases and deaths. Analyze age and sex distribution.

Assess risk factors and plan disease control interventions accordingly.

Time: Graph cases and deaths daily/weekly. Construct an epidemic curve during the outbreak.

Place: Map locations of cases' households.

#### Laboratory confirmation

#### Diagnostic test

Presence of IgM antibodies against CCHF, or Lassa Fever For ELISA: Whole blood, serum or plasma

#### Specimen

For PCR: Whole blood or blood clot, serum/plasma or tissue For immunohisto-chemistry: Skin or tissue specimens from fatal cases.

Collect specimen from the first suspected case. If more than one suspected case, When to collect the collect until specimens have been collected from 5 to10 suspected cases.

specimen

Handle and transport specimens from suspected VHF patients with extreme How to prepare, caution. Wear protective clothing and use barrier precautions.

store, and transport For ELISA or PCR:

the specimen

- Refrigerate serum or clot

- Freeze (-20C or colder) tissue specimens for virus isolation

For Immunohistochemistry:

- Fix skin snip specimen in formalin. Specimen can be stored up to 6 weeks.

The specimen is not infectious once it is in formalin.

- Store at room temperature. Formalin-fixed specimens may be transported at

room temperature.

Diagnostic services for VHF are not routinely available. Advance arrangements

#### Results

are usually required for VHF diagnostic services. Contact the appropriate National authority or WHO.

#### References

- Interim Infection Control Recommendations for Care of Patients with Suspected or Confirmed

Filovirus (Ebola, Marburg) Hemorrhagic Fever. BDP/EPR/WHO, 2008.

- Infection control for VHF in the African health care setting, WHO, 1998. WHO/EMC

- Ergonul O. Crimean-Congo haemorrhagic fever. Lancet Infect Dis 2006;6:203-14.

- WHO Recommended Surveillance Standards WHO/CDS/CSR/ISR/99.2

- WHO Fact Sheet No 208, Crimean-Congo Haemorrhagic Fever, revised November 2001

- WHO Fact Sheet No 179, Lassa Fever, revised April 2005

### Leprosy

#### Background

- Leprosy is a chronic mycobacterial disease of the skin, the peripheral nerves and upper airway mucous

membranes. The disease is transmitted mainly through airborne spread from nasal secretions of patients infected by Hansen's bacillus and also through inoculation into broken skin. Leprosy is endemic in several tropical areas around the world, including Africa.

- Patients are classified into two groups, depending on presence of skin and nerve signs:

- Multibacillary patients (MB) with more than 5 skin patches and several nerve enlargements.

- Paucibacillary patients (PB) with one to five skin patches and a single nerve enlargement.

- Leprosy control has improved greatly through use of WHO recommended multidrug therapy (MDT).

Multiple drug therapy combining two or three drugs (rifampicin, clofaximine and dapsone) is very effective in curing leprosy. At the end of 1999, leprosy point prevalence in African countries was 1.6 cases per 10 000 population with about 70 000 registered cases.

- Incubation period is 6 months to 20 years or more. Infection is probably frequent but clinical disease

is rare, even among the closest contacts of patients. Multibacillary patients are most contagious, but infectiousness is reduced rapidly as soon as multiple drug therapy begins. Leprosy can be complicated by neuritis and leprosy reactions, resulting in impairment and disabilities of hands, feet, and eyes.

- Leprosy has historically been associated with social isolation and psychosocial consequences. This

social stigma still persists in some countries in Africa.

- Some skin diseases such as tinea versicolor, mycosis, vitiligo, Scleroderma, psoriasis, systemic lupus

erythematosus and Von Recklinghausen disease may be mistaken for leprosy.

#### Surveillance goal

Observe national trends towards the leprosy elimination target, defined as a reduction in prevalence to less than 1 case per 10 000 population.

- Monitor for resistance of Hansen's bacillus to drugs used for multi-drug therapy (MTD) daily.

- As leprosy nears elimination, supplement routine surveillance with community-based surveillance.

#### Standard case definition

Suspected case: A person showing one of three cardinal signs of leprosy: hypo-pigmented or reddish skin lesion, loss or decrease of sensations in skin patch, enlargement or peripheral nerve.

Confirmed case: A person showing at least two cardinal signs of leprosy and who has not completed a full course of treatment with multidrug therapy (MDT).

#### Respond to alert threshold

If a single case is suspected:

Report the suspected case to the appropriate level of the health system.

Investigate case for risk factors.

Begin appropriate case management:

- MB patients must be treated for 12 months with a three-drug regimen (12 MB blister

packs to be taken in a period of 18 months).

- PB patients must be treated for 6 months with a two drugs MDT regimen (6 PB blister

packs to be taken in a period of 9 months)

#### Respond to action threshold

If a suspected case is confirmed:

Examine patients for skin and nerve signs at each contact patient with a health worker to diagnose and care for leprosy reactions and impairments.

Examine risk factors for treatment interruption (for example, inadequate supplies of MDT in the health centre, poor accessibility of patients' villages, and so on). Give sufficient blister packs for a full course of treatment to patients unable to attend a health centre monthly.

Identify any fast increase or decrease of new cases during a period. Assess adequacy of surveillance in areas where under- or ever-reporting is suspected. Monitor distribution of MDT drugs.

#### Analyze and interpret data

Graph cases by date diagnosed and treatment begun.

Plot cases by location of households and disease classification (MB or PB) Person:

Count newly detected cases monthly by the type of leprosy (MB or PB). Analyze age and disability distribution and treatment outcomes (cases cured, defaulted, relapsed).

Laboratory confirmation: Routine laboratory confirmation for surveillance is not required.

#### Reference

- Enhanced global Strategy for Further Reducing the Disease Burden due to Leprosy (SEA-GLP-

2009.3)

- WHO Recommended Surveillance Standards WHO/CDS/CSR/ISR/99.2

### Lymphatic Filariasis

#### Background

Lymphatic filariasis is the second leading cause of permanent and long-term disability worldwide. It affects over 120 million persons in 80 countries, and over 40 million persons are seriously incapacitated by the disease; 20% of the world population is at risk of infection. Of those infected, roughly 1/3 are in India, 1/3 in Africa, and the rest in the Americas, Asia, and the Pacific. In 1997, resolution WHA50.29 called for the elimination of lymphatic filariasis as a global public health problem. The strategy adopted is based on:

o Reducing transmission below a threshold where new infection ceases to occur o Treatment of the problems associated with disability control and prevention.

Causal agents:in Africa only the filariae Wuchereria bancrofti, Brugia malayi, and Brugia timori

- Modes of transmission: transmitted by various species of mosquitoes, these parasitic filarial worms

lodge in the human lymphatic system, producing millions of immature microfilariae that circulate in the blood. Microfilariae appear in the peripheral blood after 3 to 6 months for Brugia malayi, 6 to 12 months for Wuchereria bancrofti, often with nocturnal periodicity. When a mosquito thereafter bites the infected person, the microfilariae are picked up and infection may be transmitted to others after about 2 weeks.

- Clinical description: Filarial infection may be clinically asymptomatic (even in the presence of

laboratory evidence of lymphatic and kidney damage); the disease may also present as one or more acute manifestations (fever, local swellings, tropical pulmonary eosinophilia syndrome, lymphangitis)

- Chronic complications include:

- Lymphoedema or elephantiasis of the limbs

o Damage to the genital organs (including hydrocoele in men)

#### Surveillance goal

There are currently 3 options and the choice will depend on the local situation:

1. Routine monthly reporting of aggregated data on probable and confirmed cases from periphery to intermediate level and to central level 2. Sentinel population surveys (standardized and periodical), 3. Active case-finding through surveys of selected groups or through mass surveys.

International: Annual reporting from central level to WHO (for a limited number of countries).

#### Standard case definition

Suspected case: Resident of an endemic area with a clinical sign of hydrocoele or lymphoedema for which other causes of these findings have been excluded.

Confirmed case: A person with positive laboratory diagnosis of microfilaremia in blood smear, filarial antigenaemia or positive ultrasound test.

#### Respond to alert threshold

- Confirm community prevalence of infection by surveys

#### Respond to action threshold

Case management Hygiene measures for the affected body parts (and, when necessary, antibiotics and antifungal agents) can decrease the risk of adenolymphangitis:

- Washing the affected parts twice daily with soap and water

- Raising the affected limb at night

- Exercising to promote lymph flow

- Keeping nails short and clean

- Wearing comfortable footwear

- Using antiseptic or antibiotic creams to treat small wounds or abrasions, or in severe cases

systemic antibiotics.

For the treatment of filarial carriers, the regimen recommended by the country is to be followed:

- In areas where there is neither Onchocerciasis nor loiasis: DEC 6 mg/kg single dose.

- In areas where Onchocerciasis has been excluded but not loiasis: individual clinical decision.

The current strategy for Filariasis control rests essentially on anti-parasitic measures. To interrupt transmission, the entire at-risk population must be given a yearly, 1-dose regimen of the following: Areas with concurrent onchocerciasis:

- 400mg of albendazole + ivermectin 150 micrograms per kg body weight once a year for 4-6

years Areas with no concurrent Onchocerciasis

- Diethylcarbamazine 6 milligrams per kg of body weight + albendazole 400 mg once a year, or

- Diethylcarbamazine fortified salt for daily use for at least 6-12 months.

NOTE: In areas with concurrent loiasis (sub-Saharan Africa), mass interventions cannot at present be envisaged systematically (unless Onchocerciasis is a severe public health problem), because of the risk of severe adverse reactions in patients with high-density Loa infections (about 1 in 10,000 treatments).

It is important to educate the population on the importance of compliance during mass chemotherapy.

Special efforts for vector control are not required as regards Lymphatic Filariasis. They should be carried out under other existing vector control programmes such as anti-malaria vector control operations.

#### Analyze and interpret data

- Map the distribution of Lymphatic Filariasis and identify implementation units that will require mass

drug administration

- Analyze the drug coverage in implementation units

- Assess the decline of parasitological indices microfilaremia before starting MDA and after at least four

rounds of MDA till the criteria of less than 1% microfilaraemia in the population and less than 0.1% antigenaemia in school entry children is achieved

#### Laboratory confirmation

- Night blood smear

#### Diagnostic test

- Filarial antigen test

- Blood smear

#### Specimen

- Blood

When to collect Night between 10pm and 2am Any time of the day the specimen

Spread three drops of blood on a glass slide and spread across the slide to make How to prepare, store, and three lines. After fixing with heat stain with Geimsa stain and examine under microscope transport Either a rapid ICT card test or by an lab based ELISA test Positive test is when microfilarieae of W.bancrofti is seen under the microscope

#### Results

Positive if filarial antigen is detected

#### Reference

- WHO.Monitoring and epidemiological assessment of the programme to eliminate lymphatic filariasis

at implementation unit level WHO/CDS/CPE/CEE/2005.50

- WHO. Lymphatic filariasis. WHO/CDS/CPE/SMT/2001.7

- WHO. Training module on lymphatic filariasis for drug distributors (in countries where onchoerciasis

is not co-endemic). WHO/CDS/CPE/CEE/2000.10 (Parts 1 &2)

- WHO. Training module on lymphatic filariasis for drug distributors (in countries where onchoerciasis

is co-endemic). WHO/CDS/CPE/CEE/2000.11 (Parts 1 & 2)

- WHO. The programme to eliminate lymphatic filariasis - essential elements for medical personnel (in

countries where onchoerciasis is not co-endemic). WHO/CDS/CPE/CEE/2000.12

- WHO. The programme to eliminate lymphatic filariasis - essential elements for medical personnel (in

countries where onchoerciasis is co-endemic). WHO/CDS/CPE/CEE/2000.13

- WHO. Preparing and implementing a national plan to eliminate filariasis (in countries where

onchoerciasis is not co-endemic). WHO/CDS/CPE/CEE/2000.15

- WHO. The programme to eliminate lymphatic filariasis (in onchoerciasis co-endemic countries).

WHO//CDS/CPE/CEE/2000.16 Webpage: www.who.int/lymphatic filariasis

### Malaria

#### Background

- Malaria is a highly prevalent tropical illness with fever following the bite of infected female Anopheles

mosquitoes which transmit a parasite, Plasmodium falciparum, P. ovale, P. vivax, or P. malariae.

Serious malarial infections are usually due to P. falciparum which may result in severe anaemia and vital organ involvement. Over 95% of the malaria infections in Uganda are due to P. falciparum.

- Malaria is one of the leading causes of illness and death in Uganda. Malaria contributes 30% Of all

outpatients and 10% of the mortality in Uganda. The groups at higher risk of contracting malaria and getting severe disease are pregnant women, children under 5, patients with HIV/AIDS, as well as nonimmune migrants, mobile populations and travelers from non-endemic countries.

- Incubation period from the time of being bitten to onset of symptoms is 7 to 30 days. The incubation

period may be longer, especially with non- P. falciparum species.

- Malaria is highly seasonal in some in African countries and perennial in the rest of the region

#### Surveillance goal

Have a system that ensures early warning, forecasting, detection and prompt response to malaria epidemics, especially in areas prone epidemics

#### Standard case definition

Uncomplicated malaria: Any person living in area at risk of malaria with fever or history of fever within 24 hours; without signs of severe disease (vital organ dysfunction) is diagnosed clinically as malaria.

Confirmed uncomplicated malaria: Any person with fever or history of fever within 24 hours; and with laboratory confirmation of diagnosis by malaria blood film or other diagnostic test for malaria parasites.

Unconfirmed severe malaria: Any patient living in area at risk of malaria hospitalized with severe febrile disease with accompanying vital organ dysfunction diagnosed clinically Confirmed Severe malaria: Any patient hospitalized with P. falciparum asexual parasitaemia as confirmed by laboratory tests with accompanying symptoms and signs of severe disease (vital organ dysfunction) diagnosed through laboratory.

Preparedness, Forecasting and early warning This entails use of climatic data, rainfall, humidiaty or teamperature to predict malaria epidemics. Other Other indicators that are useful include mosquito and larval densities, nutritional status, drug and insecticide resistance, loss of immunity because of a recent reduction in population exposure and human population movements in and out of endemic areas The following actions should be taken during this period; Ensure adequate stock of malaria diagnostics and drugs for the peak transmission season LLIN distribution (mass/routine) and ensure functionality of health facilities and community health workers providing malaria case management Inform district authorities and Health workers of increased risk Reactivating epidemic Response Task Forces at district and lower levels

#### Respond to alert threshold

If there is an unusual increase in the number of new malaria cases or deaths as compared to the same period in previous non-epidemic years:

Verify the epidemic (an observed increase in cases can be due to errors in data, improved case management, improved surveillance/diagnostic tools) Report suspected epidemic to the next level Treat with appropriate anti-malarial drugs according to national treatment guidelines Investigate the cause for the increase in new cases Make sure new cases in children age 2 months up to 5 years are managed according to national treatment guidelines.

Conduct community education for prompt detection of cases and access to health facilities.

#### Respond to action threshold

If the number of new cases exceeds the upper limit of cases seen in a previous non-epidemic period in previous years: Evaluate and improve, as needed coverage and uptake of prevention strategies, such as mosquito nets, Malaria case management, Social Behavioural change and community mobilization, test and treat outreaches, Indoor Residual spraying for all at risk of malaria.

#### Analyze and interpret data

In order to confirm the existence of a malaria epidemic at an early stage there is a need to monitor malaria cases and to compare the observed numbers to what can be considered "EXPECTED" for a particular health facility or district during a similar period of the year based on the data from the recent past. In order to do this, one has to obtain the data on malaria cases for the most recent non-epidemic 5 years. These data are then used to determine the expected cases also commonly referred to as the "NORMAL CHANNEL".

Two methods are proposed;

A) Computerised & statistical for the national, district and HSD level and

B) Simple & non-statistical for the HCII and III level

A) Computerised & statistical for the national, district and HSD level

1. Tabulate malaria cases using MS Excel for the 52 weeks in a year for the most recent five (5) years.

2. Plot the 75"h percentile for each of the week for the past 5 years using the function =PERCENTILE (A1:A4,0.75). This is the upper normal 3. Plot the 25th percentile for each of the week for the past 5 years using the function PERCENTILE (A1:A4,0.25). This is the lower normal 4. The area between the two lines is the expected number of malaria cases (NORMAL CHANNEL) 5. Plot the weekly malaria cases observed in the current year to present 6. If the observed weekly malaria cases are above the upper plot of the Normal channel an epidemic alert exists and should be investigated within 24-48 hours.

B) Epidemic threshold alert for the health centre II and IIII

1. Tabulate the observed weekly malaria cases at the health facility for the most recent five (5) years for each of the 52 weeks in a year.

2. Sort the weekly cases in ascending order i.e. from the lowest to highest.

3. The number in the middle of the list is the median.

4. The fourth highest number [the fourth from the bottom], represents the 3rd quartile (75th percentile).

This is considered as the upper limit of the expected normal number of cases.

5. Plot the 3r quartile (75th percentile) for each week and connect the points with a line. This forms the upper normal limit.

6. The second highest number [the second from the bottom], represents the 1st quartile (25th percentile).

This is considered as the lower limit of the expected normal number of cases. (Although the desired situation is to have zero cases i.e below the 25th percentile, as malaria interventions are scaled up and epidemiology changes towards pre-elimination and elimination levels) 7. The area between the two lines is the expected (Normal Channel).

If the number of currently observed cases falls between the two lines, this is considered normal. If, however, the number is above the line of the 3r quartile [upper limit] for 2 consecutive weeks this may be an indication of an epidemic and must therefore be reported within 24-48 hours to the District Health Office.

One of the ways to detect early the existence of a malaria epidemic is to monitor the number of malaria cases and compare the present numbers to what can be considered "normal" for a particular health facility based on the data from the past. A malaria normal channel graph is a malaria surveillance chart that shows the number of expected malaria cases seen per week. Since malaria epidemics tend to be localised, to be more useful, this chart should be filled at and interpreted by the health facility itself. The interpretation will trigger action by the health facility in-charge. Below is an example of a facility Malaria surveillance Chart for Nkuti HCII.

Nkuti HIII Malaria surveillance Chart 3000 2500 2000 1500 1000 500 1 3 5 7 9 11 13 15 17 19 21 23 25 27 29 31 33 35 37 39 41 43 45 47 49 51 current vear 2019) There are many variants of the surveillance chart, you must also monitor malaria related deaths and stock of antimalarial on the same chart: see template for such a chart in annex Time: Graph the number of cases by month/week. Construct an epidemic curve during epidemics.

Place: Identify the most affected villages. Plot location of households for new cases and deaths Person: Count number of new malaria cases and deaths by month; analyze age groups and time of onset.

#### Laboratory confirmation

- Microscopy: Presence of malarial parasites in blood films for suspected cases

#### Diagnostic test

- Malaria Rapid diagnostic test: Positive or negative test

Blood: Usually finger-stick sample for all ages or other accepted method for

#### Specimen

collecting blood from very young children For blood smear: prepare blood film for all suspected cases admitted to inpatient When to collect facility, or according to national malaria case management guidelines Blood smear:

How to prepare, store, and transport • Collect blood directly onto correctly cleaned and labeled microscope slides and prepare thick and thin smears.

- Allow smears to dry thoroughly

- Stain using the appropriate stain and technique

- Store stained and thoroughly dried slides at room temperature out of direct

sunlight.

For rapid diagnostic test:

- Collect specimen and perform test according to manufacturers'

instructions.

Thick and thin smear results can be available the same day as preparation.

#### Results

Microscopic examination of malarial slides may also reveal the presence of other blood-borne parasites.

RDT result is obtained immediately. Note: In the inpatient setting, perform a hemoglobin estimation laboratory test to confirm severe anaemia, in children 2 months to 5 years in age.

#### Reference

- Malaria epidemics: Detection and control, forecasting and prevention. Geneva. World Health

Organization. WHO/MAL/98.1084

- "Basic Laboratory Methods in Medical Parasitology" WHO, Geneva, 1991

- 'Guidelines for Malaria Epidemic Preparedness and Response' Ministry of Health, Uganda 2012

- 'Malaria Surveillance Monitoring and Evaluation: A reference manual', Geneva, World Health

Organization 2018

### Malnutrition

#### Background

- Globally, maternal and child under-nutrition are underlying causes for 3•5 million deaths, including 35%

of the disease burden in children younger than 5 years. Of the 40 countries with a child stunting prevalence of 40% or more, 23 are in Africa.

- Severe malnutrition may act as a direct cause of death or an indirect cause by increasing dramatically

the number of deaths in children suffering from common childhood illnesses such as diarrhea and pneumonia.

- Despite the above, the burden of child mortality due to severe malnutrition remains largely absent from

the international health agenda and few countries, even in high prevalence areas, have specific national policies aimed at addressing it comprehensively.

- The most vulnerable are children under five and pregnant and lactating women. The poor nutritional

status and nutritional intake of pregnant women may contribute to newborns with low birth weight (a weight measured immediately after birth). A newborn weighing less than 2500 grams (2.5 kilos or 5.5 pounds) is considered a newborn with low birth weight (LBW). LBW is a major determinant of death, illness and disability in infancy and childhood and also impacts health outcomes in adult life.

- Socio-economic conditions, poor water and sanitation, mothers' nutritional education on how to feed

babies and young children, and repeated infections are the main causes of malnutrition.

- Programmes elaborated to eradicate malnutrition are on food security, water and sanitation, promotion

of infant and young children feeding practices, micronutrient supplementation programmes, management of severe cases of malnutrition in the communities and in the health facilities, management of infections mainly diarrhocal disease.

- Many sporadic surveys are being organized, but nutrition surveillance is currently poorly implemented

and does not allow for interventions related to prevention and management of malnutrition.

#### Surveillance goal

- Early warning and problem identification.

- Policy-making and planning.

- Programme management and evaluation.

- Assess effectiveness of public health response that address causes of low birth weight, malnutrition in

children and malnutrition in pregnant women

#### Standard case definition

Low birth weight newborns: Any new born with a birth weight less than 2500 grams (or 5.5 1bs) Malnutrition in children:

Children under five who are underweight (indicator: weight for age<-2 ZScore) Children 6 to 59 months with MUAC<11.5 cm (high risk of mortality) Bilateral pitting edema Malnutrition in pregnant women: Pregnant women given birth to low birth weight babies (birth weight <

### 2.5 Kg) (poor nutritional and health status of the women, can predict which population groups may benefit

from improved antenatal care of women and neonatal care for infants).

Response to alert threshold If more than 20% of children are underweight: Programme emphasis on, Breastfeeding support, Nutrition education, Supplementation of child and mother, Prevention and treatment of diarrhea, Prevention and treatment of severe malnutrition, Socio-economic support As soon as one case with MUAC less than 11.5 cm is detected or presence of bilateral edema identified: Alert, further investigation should be conducted. In addition, refer the child to a therapeutic feeding programme.

If more or equal than 15% of low birth weight are less than 2.5 Kg: Targeting interventions for improved antenatal care for women and neonatal care of infants including nutritional care (anti-smoking and anti-alcohol campaigns, nutritional care for women before and during antenatal and during lactating period, malaria prophylaxis, new-born care facilities, etc.) to those at risk of poor pregnancy outcomes and treat new born to prevent morbidity and death.

#### Analyze and interpret data

Time: Graph cases monthly to analyze trends and weekly in emergency Place: Plot location of households/community with cases Person: Count monthly/weekly cases and analyze age and gender distribution

#### Laboratory confirmation

Routine laboratory confirmation for surveillance is not required.

#### Reference

- Maternal and child undernutrition: global and regional exposures and health consequences: Black R.E.

et al: The Lancet, Volume 371, Issue 9608, Pages 243 - 260.

- Gross R, Webb P, Wasting time for wasted children: severe child undernutrition must be resolved in

non-emergency settings. Lancet 2006; 367: 1209-1211.

- Physical status: the use and interpretation of anthropometry.Report of a WHO Expert Committee.WHO

Technical Report Series, 1995, No 854: 81, 128-130, 198-208.

- WHO child growth standards and the identification of severe acute malnutrition in infants and children.

A Joint Statement by the World Health Organization and the United Nations Children's Fund

### Maternal Deaths

#### Background

Deaths during pregnancy, childbirth or termination of pregnancy, and deaths up to 6 weeks (42 days) alter childbirth or termination of pregnancy related to pregnancy are considered Maternal Deaths.

- Globally, about 80% of maternal deaths are due to; severe bleeding (mostly bleeding postpartum),

infections (also mostly soon after delivery), hypertensive disorders in pregnancy (eclampsia) and obstructed labor. Complications after unsafe abortion cause 13% of maternal deaths.

- Across the developing world, maternal mortality levels remain too high, with more than 500,000 women

dying every year as a result of complications during pregnancy and childbirth. About half of these deaths occur in sub-Saharan Africa where a woman's lifetime risk of maternal death is 1 in 22, compared with 1 in 8,000 in industrialized countries.

- Hemorrhage is the leading cause of maternal death in sub-Saharan Africa, and unattended births are a

particular risk, especially in rural areas where transport to health care facilities is a problem.

#### Surveillance goal

- Estimate and monitor maternal mortality rates.

- Identify risk factors and high-risk areas for maternal mortality to inform program decisions.

- Evaluate programs aimed at reducing maternal mortality.

#### Standard case definition

The death of a woman while pregnant or within 42 days of the delivery or termination of the pregnancy, irrespective of the duration and site of the pregnancy, from any cause related to or aggravated by the pregnancy or its management but not from accidental or incidental causes.

Recommended public health action

- Establish alert thresholds to allow health facility or district health personnel determine when special

targeted interventions are necessary.

- Monitor trends and respond to alert thresholds

- Increase availability and use of antenatal care

- Provide specialized training to traditional and profession birth attendants

- Support interventions to improve recognition and response to high-risk pregnancies at the community

level

#### Analyze and interpret data

Time: Graph cases to construct an epidemic curve throughout the year in order to identify trends.

Place: Plot the location of cases and analyze the distribution.

Person: Analyze the distribution of cases by age and other demographic factors.

Laboratory confirmation: Routine laboratory confirmation for surveillance is not required

#### Reference

- http://www.who.int/making pregnancysafer/topics/maternal mortality/en/index.html

- http://www.unicef.org/index.php

### Measles

#### Background

- Measles is a febrile rash illness due to paramyxovirus (Morbillivirus) transmitted human-to- human via

airborne droplet spread. It is the fourth leading cause of death in children less than 5 years of age in many African countries.

- Among children with vitamin A deficiency and malnutrition, measles may result in severe illness due to

the virus itself and associated bacterial infections, especially pneumonia; only the minority of cases are

- Measles is among the most transmissible of human infections. Large outbreaks occur every few years in

areas with low vaccine coverage and where there is an accumulation of persons who have never been infected or vaccinated. The true incidence of measles far exceeds reported cases.

- Risk factors include low vaccine coverage (<85 to 90%) which allows accumulation of susceptible persons

at high risk for measles. Outbreaks can be explosive in areas of high population density.

- Other viral illnesses such as rubella may cause or contribute to similar outbreaks.

#### Surveillance goal

Detect outbreaks of fever with rash illness promptly:

In countries with a measles elimination target: immediate case-based reporting of suspected cases and deaths of fever with rash illness; confirm all suspected measles cases with laboratory test (usually serum IgM).

In countries with accelerated measles control programs: Summary reporting of cases and deaths for routine surveillance and outbreaks; confirm the first five cases of suspected measles in a health facility per week with laboratory test (usually serum IgM). Uganda's target is to achieve measles elimination by 2020.

#### Standard case definition

Suspected case: Any person with fever and maculopapular (non-vesicular) generalized rash and cough, coryza or conjunctivitis (red eyes) or any person in whom a clinician suspects measles.

Confirmed case: A suspected case with laboratory confirmation (positive IgM antibody) or epidemiological link to confirmed cases in an outbreak.

#### Respond to alert threshold

If an outbreak is suspected:

- Report suspected case to the next level.

- Collect blood samples from the first five cases to confirm the outbreak.

- Line list the other cases without collecting any blood samples

- Treat cases with oral rehydration, vitamin A, and antibiotics for prevention of bacterial super- infection.

Use airborne isolation precautions where feasible.

- Investigate the case or outbreak to identify causes for outbreak.

#### Respond to action threshold

If an outbreak is confirmed:

- Improve routine vaccine coverage through the EPI, and lead supplemental vaccination activities in areas

of low vaccine coverage.

- Mobilize the community early to enable rapid case detection and treatment.

#### Analyze and interpret data

Time: Graph weekly cases and deaths. Construct epidemic curve for outbreak cases.

Place: Plot location of case households.

Person: Count total cases and analyze by age group and immunization status.

#### Laboratory confirmation

#### Diagnostic test

Presence of IgM antibodies to measles virus in serum.

Serum Whole blood

#### Specimen

When to collect Collect specimens within the first 30 days of rash onset the specimen Collect blood samples on 5 suspected measles cases when the number of cases exceeds the measles outbreak threshold (that is more than 5 cases in a district in a month).

In countries with an elimination target:

- Collect specimen from every suspected case of measles

- Collect serum for antibody testing at first opportunity or first visit to the health

facility.

For children, collect 1 to 5 ml of venous blood depending on size of child.

How to prepare, store, • Collect into a test tube, capillary tube or microtainer.

and transport the specimen Separate blood cells from serum. Let clot retract for 30 to 60 minutes at room temperature. Centrifuge at 2000 rpm for 10-20 minutes and pour off serum into a clean glass tube.

- If no centrifuge, put sample in refrigerator overnight (4 to 6 hours) until clot

retracts. Pour off serum the next morning.

- If no centrifuge and no refrigerator, let blood sit at an angle for at least 60

minutes (without shaking or being driven in a vehicle). Pour off serum into a

- Store serum at 4°C.

- Transport serum samples using appropriate packaging to prevent breaking or

leaks during transport.

- Do not freeze whole blood

#### Results

The specimen should arrive at the laboratory within 3 days of being collected.

Results are usually available after 7 days.

If as few as 3 out of 5 suspected measles cases are laboratory confirmed, the outbreak is confirmed.

Avoid shaking of specimen before serum has been collected To prevent bacterial overgrowth, ensure that the serum is poured into a clean glass test tube. The test tube does not need to be sterile, just clean.

Transport the serum in a specimen carrier at 4°C to 8°C to prevent bacterial overgrowth (up to 7 days). If not refrigerated, serum stored in a clean tube will be good for at least 3 days.

#### Reference

- Field guide for training operational level health workers on vaccine preventable disease surveillance,

MoH/ UNEPI (Revised edition 2012)

- Using surveillance data and outbreak investigations to strengthen measles immunization programs,

Geneva, World Health Organization. WHO/EPI/GEN/96.02

- WHO Guidelines for Epidemic Preparedness and Response to Measles Outbreaks

WHO/CDS/CSR/ISR/99.1

### Meningococcal Meningitis

#### Background

- Neisseria meningitidis, Haemophilus influenzae type b (Hib), and Streptococcus pneumoniae constitute

the majority of all cases of bacterial meningitis and 90% of bacterial meningitis in children.

- Meningococcal meningitis is the main form of meningitis to cause epidemics and remains a major

public health challenge in the African meningitis belt, an area that extends from Senegal to Ethiopia. In these countries, large outbreaks may occur during the dry season (e.g., November through May).

Outside of the meningitis belt, smaller outbreaks may occur year-round.

- Epidemics in the meningitis belt are traditionally associated with Neisseria meningitides serogroup A

although in 2002 an epidemic due to Nm serogroup W135 occurred in Burkina and in 2006 Nm serogroup X was isolated in Niger.

- Human-to-human disease transmission is via large respiratory droplets from the nose and throats of

infected people.

- Incubation period is 2 to 10 days.

- Attack rates are highest among children aged less than 15 years. Case fatality rates are usually 8-15%

among treated patients, and >70% among untreated cases. Many survivors suffer long-term sequelae including mental retardation, hearing loss and loss of limb use.

- Oily chloramphenicol is the drug of choice during epidemics because a single dose of this long-acting

formulation has been shown to be effective. Antimicrobial resistance to chloramphenicol has not yet been detected in Africa, however, resistance to sulphonamides is widespread.

- The current response to meningitis epidemics consists of reactive mass vaccination campaigns with

bivalent (A and C) and/or trivalent polysaccharide vaccine (A, C, and W135) as soon as possible after an epidemic has been declared. Polysaccharide vaccines do not protect very young children and only provide protection for up to three years resulting in repetitive meningitis outbreaks.

- A meningococcal A conjugate vaccine has been developed which is immunogenic in both infants and

adults and is expected to confer long-term protection. It is expected that introduction of this conjugate vaccine into meningitis belt countries is likely to dramatically reduce the circulation of Nm A and eliminate Nm A epidemics.

Surveillance goals

- To promptly detect meningitis outbreaks and to confirm actiology of meningitis outbreaks.

- To use the data to plan for treatment and vaccination supplies and other prevention and control

measures.

- To assess and monitor the spread and progress of the epidemic and the effectiveness of control measures.

- To monitor the situation including serogroup shifts throughout the year.

#### Standard case definition

Suspected case: Any person with sudden onset of fever (>38.5°C rectal or 38.0°C axillary) and one of the following signs: neck stiffness, altered consciousness or other meningeal signs.

Confirmed case: A suspected case confirmed by isolation of N. meningitidis from CSF or blood.

#### Respond to alert threshold

Alert threshold:

- For populations between 30 000 and 100 000 inhabitants, an attack rate of 5 cases per 100 000

inhabitants per week.

- For populations less than 30 000 inhabitants, 2 cases in 1 week or an increase in the number compared

to the same time in previous non-epidemic years.

Respond to alert threshold:

Inform next level of health system Record cases on a line listing form Investigate and laboratory confirm the cases Treat all suspected cases with appropriate antibiotics as recommended by National protocol.

Intensify surveillance for additional cases in the area Prepare to conduct a mass vaccination campaign

#### Respond to action threshold

Epidemic threshold:

For populations between 30 000 and 100,000: an attack rate of 15 cases per 100 000 inhabitants per week.

When the risk of an epidemic is high (no epidemic during last 3 years, alert threshold reached in dry season), epidemic threshold is 10 cases per 100 000 inhabitants per week.

- For populations less than 30 000 inhabitants: 5 cases in 1 week or the doubling of the number of cases

over a 3-week period.

Respond to epidemic threshold:

Immediately vaccinate the epidemic district as well as any contiguous districts in alert phase.

- Mobilize community to permit early case detection and treatment, and improve vaccine coverage

during mass vaccination campaigns for outbreak control.

Continue data collection, transmission and analysis.

- Maintain regular collection of 5-10 CSF specimens per week throughout the epidemic season in all

affected districts to detect possible serogroup shift.

- Treat all cases with appropriate antibiotics as recommended by National protocol.

#### Analyze and interpret data

Time: In meningitis belt countries during epidemic season, graph weekly cases and deaths. Otherwise, graph monthly trends in cases and deaths. Construct an epidemic curve for outbreak cases.

Place: In epidemics (not in endemic situations), plot location of case households and estimate distance to the nearest health facility.

Person: Count total sporadic and outbreak cases. Analyze age distribution.

Target case fatality rate: <10%

#### Laboratory confirmation

Microscopic examination of CSF for Gram negative diplococci Culture

#### Diagnostic test

and isolation of N. meningitidis from CSF Cerebral spinal fluid (CSF)

#### Specimen

Note: CSF is the specimen of choice for culture and microscopic exam. If CSF not available, collect blood (10 ml adults, 1-5 ml for children) for culture.

When to collect the Collect specimens from 5 to 10 cases once the alert or epidemic threshold (see specimen "Meningitis" in Section 8.0) has been reached.

- Prepare the patient and aseptically collect CSF into sterile test tubes with

How to prepare, store, and transport the tops.

specimen

- Immediately place 1 ml of CSF into a pre-warmed bottle of trans-isolate

medium.

- Incubate at body temperature (36C to 37C).

- Never refrigerate specimens that will be cultured

Keep CSF for microscopic exam and chemistry in the original syringe (replace cap). Refrigerate the capped syringe and send it to the laboratory as soon as possible.

#### Results

- Isolation of Neiseria meningitidis, a fastidious organism, is expensive, and

difficult. It requires excellent techniques for specimen collection and handling and expensive media and antisera.

- Initial specimens in an outbreak or for singly occurring isolates of N.

meningitis should be serotyped and an antibiogram performed to ensure appropriate treatment.

- Trans Isolate medium (TI) is stable. If properly stored at temperature (4°C) it

can be kept for up to two years after preparation. In the refrigerator, the liquid phase turns gelatinous but reliquifies at room temperature. Unused TI bottles should be kept tightly sealed. If there is any colour change (yellowing or clouding of the liquid medium) or drying or shrinkage of the agar slant, the medium should not be used.

#### Reference

- Weekly Epidemiological Record N 38, September 2000

(http://www.who.int/wer/pdf/2000/wer7538.pdf)

- WHO Regional Office for Africa Standard Operating Procedures for Enhanced Meningitis

Surveillance in Africa, August 2009

- Control of epidemic meningococcal disease. WHO Practical Guidelines, 2nd Edition.

WHO/EMC/BAC/98.3.

- Laboratory Methods for the Diagnosis of Meningitis Caused by Neisseria meningitidis,

Streptococcus pneumoniae and Haemophilus influenzaei WHO document WHO/CDS/EDC/99.7 WHO, Geneva

### Mental Illness (Epilepsy)

#### Background

- Epilepsy is defined as the recurrence of, at least, two epileptic seizures with sudden occurrence of abnormal

signs which could be: motor, tonic, sensitive, sensorial, neuro-vegetative, or psycho-behavioral. These symptoms could or could not be associated to a loss of conscience. It can appear at any age.

- Epilepsy is the most common result of brain cells disturbance that lead to excessive nerve-cell discharges.

According to the disturbance on some or many groups of cells, seizures could be partial or generalized

- Seizures with tonic-clonic muscle movements are named convulsion or fit or attack. Convulsion can

appear at any age; all convulsions are not systematically epilepsy.

- Epilepsy is frequent in the Region and its prevalence rate range from 2.2 to 58 per 1000. Studies from

five sub-Saharan African countries showed an incidence ranging from 64 to 156 per 100,000 person/year.

This higher incidence may be a consequence of many risk factors which are related with predisposing factors such as poor perinatal care, head trauma, consanguinity.

- Many etiological factors are related with communicable diseases (malaria, tuberculosis, meningitis,

neurocysticerocisis and HIV), non-communicable diseases (high blood pressure, diabetes, alcoholism and illicit drug use), poorer medical facilities, poorer general health and a lower standard of living.

Misunderstanding linked to cultural beliefs, sigma and exclusion do not facilitate appropriate care.

- Epilepsy substantially increases mortality risk, particularly in conditions of later detection due to lack of

well-trained health workers to diagnose and treat neurological disorders.

- Death and injury occur primarily due to status epilepticus (especially in the case of abrupt medication

withdrawal), burns and drowning.

- It has been estimated that in developing countries, up to 80% of people with epilepsy are not receiving

treatment, or are often not even identified. While the etiological diagnosis of the epilepsies may be more difficult in developing countries, due to limited investigative resources, many can be diagnosed on the basis of simple clinical and epidemiological knowledge.

#### Surveillance goal

- Early detection and immediate intervention to prevent morbidity and mortality rates due to epilepsy

- Register and monitor epilepsy cases

#### Standard case definition

Suspected case: Any person with one epileptic seizure Suspected new case: Report only the first diagnostic of the case in the health centre Confirmed case: Any person with recurrence of, at least, two epileptic seizures. A positive response to treatment with any AED strengthens the hypothesis of a confirmed case. Epileptic seizures can last for 30 seconds to 3 minutes. When they are intricate without a pause, they can lead to status epilepticus.

#### Respond to alert threshold

Suspected cases

- All health personnel should check for early signs of epilepsy. Diagnosis should include good

interviews (describing as precisely as possible the seizure type) and clinical examination.

- Once diagnosed, search for underlying and associated causes. Check for abnormal increases on number

of cases and propose appropriate environmental measures if needed Confirmed cases

- Immediate treatment should be ensured starting with low doses of any anti-epileptic drug then

increasing progressively until an effective steady state. In case of poor seizure control management strategies must be: increase the dose or try an alternative drug, refer to an upper level health structure

- Referral to higher level health structure should be done if seizures continue regardless of

pharmacological treatment or if first seizure occurs in an adult aged 30 and above.

#### Respond to action threshold

All cases: Information and education measures on epilepsy and risk factors at community level

#### Analyze and interpret data

Person: Analyse sex and age distribution (by age group from 6 years onwards) Time: Graph quarterly cases Place: Plot the distribution by area of residence

#### Laboratory confirmation

- Blood glucose( random capillary blood, and venous blood sugar), electrolytes

#### Diagnostic test

to exclude other conditions such as diabetes, kidney pathology

- Exclude other conditions such as Cerebral Malaria, meningitis, toxoplasmosis;

cerebro calcifications follow tuberculosis (tuberculoma), parasitic diseases and others by conducting appropriate medical investigations.

Blood, and cerebro-spinal fluid

#### Specimen

Glucose - During the emergency admission of the patient (random blood glucose) When to collect the Confirmed subsequently (fasting blood glucose) specimen How to prepare, Use universal precautions to minimize exposure to sharps and any body fluid store, and transport the specimen Results are always available within 1 to 3 hours from arrival in the laboratory

#### Results

References:

- WHO, Epilepsy in the WHO African Region: Bridging the Gap, WHO Regional Office for Africa,

Congo, 2004.

WHO, Epilepsy: a manual for medical and clinical officers in Africa, World health, Geneva 2002

### Neonatal tetanus

#### Background

- A neuromuscular toxin-mediated illness caused by the anaerobic spore-forming soil bacterium Clostridium

tetani. The disease is transmitted when spores enter open wounds (injections, cutting the umbilical cord) or breaks in the skin.

- While tetanus may occur in adults, infection primarily affects newborns. Neonatal tetanus has decreased

dramatically in countries with improved maternal tetanus immunization rates. As a result, tetanus is targeted for elimination in many African countries.

- Incubation period is 3 to 21 days, with an average of approximately 6 days.

- Risk factors: Unclean cord care practices during delivery for neonates. Lack of antibody protection in

incompletely immunized mothers.

#### Surveillance goal

- Detect cases of neonatal tetanus immediately to confirm the case and prevent additional cases by

immunizing at least pregnant women in area around the confirmed case.

- Identify high risk areas and target tetanus toxoid campaigns to women of childbearing age.

#### Standard case definition

Suspected case: Any newborn with a normal ability to suck and cry during the first two days of life, and who, between the 3 and 28th day of age, cannot suck normally, and becomes stiff or has convulsions or both.

Confirmed case: No laboratory confirmation recommended.

#### Respond to alert threshold

If a single case is suspected:

Report case-based information immediately to the next level.

- Conduct an investigation to determine the risk for transmission

- Treat and manage the case according to national recommendations, usually with supportive care and, if

feasible, in intensive care. No routine isolation precautions are needed.

#### Respond to action threshold

If a case is confirmed through investigation:

Immunize the mother and other pregnant women in the same locality as the case with at least 2 doses of tetanus toxoid.

Conduct a supplemental immunization activity for women of childbearing age in the locality.

Improve routine vaccine coverage through EPI and maternal immunization program activities.

- Educate birth attendants and women of childbearing age on the need for clean cord cutting and care.

Increase the number of trained birth attendants.

#### Analyze and interpret data

Time: Graph cases and deaths monthly. Target should reflect elimination target for each district.

Plot location of case households and location of birth attendants.

Place:

Person: Count monthly cases and deaths. Analyze each case of NNT by cord care practices.

#### Laboratory confirmation

Laboratory confirmation is not required.

#### Reference

- Field guide for training operational level health workers on vaccine preventable disease surveillance,

MoH/UNEPI (Revised edition 2012)

- Field manual for neonatal tetanus elimination. Geneva, World Health Organization. WHO/N&B/99.14

### New AIDS Cases

#### Background

- AIDS is an infection of human lymphocytes (types of white blood cells) and other organs. It is caused by

a retrovirus, human immunodeficiency virus (HIV). Sexual intercourse, needle injections, transfusions, trans-placental or trans-vaginal routes, breast milk or other direct contact with infected human body fluids transmits the virus from human to human.

- Acquired immunodeficiency syndrome (AIDS) results in late-stage HIV infection and immuno-

suppression, with reduced numbers and function to T-lymphocytes. Primary HIV- related organ involvement and a variety of opportunistic infections result in death unless the growth of the virus is stopped by drugs that can kill the virus (antiretroviral therapy). When HIV infection progresses to illness, the symptoms are usually due to the failure of the immune system to resist other infectious diseases called opportunistic infections (OI). These include tuberculosis, bacterial pneumonia or sepsis, oro-pharyngeal candidiasis, chronic diarrhoea, chronic skin infections, recurrent herpes zoster, and others.

- Twenty-four million Africans, close to one in ten adults between the ages of 15 and 49 years of age, are

living with HIV/AIDS. The impact of the epidemic is already measurable in greatly increased adult and child morbidity and mortality. HIV/AIDS is now the leading cause of adult mortality in the African Region.

- Incubation period is approximately 1 to 3 months from the time of infection to the time that antibodies can

be detected in a laboratory process. The time from HIV infection to the onset of AIDS is generally 7 to 9 years.

- Risk factors: populations at high risk of acquiring HIV are commercial sex workers with or without other

sexually transmitted infections (STIs). Some STIs may increase HIV transmission. Others at risk include intravenous drug users (IDU), recipients of unscreened blood products and neonates born to HIV-infected mothers.

- Tuberculosis, visceral leishmaniasis, trypanosomiasis, and other subacute or chronic bacterial, parasitic,

and viral infections may cause similar syndromes.

#### Surveillance goal

- Monitor the impact of HIV/AIDS interventions in trends of incidence and prevalence of HIV infections,

AIDS and STIs through sentinel sites, surveys and special studies (according to guidelines for second generation surveillance of HIV/AIDS).

- Estimate the burden of HIV/AIDS in the district using available information from HIV sentinel

populations so that each new AIDS case is counted.

- Monitor local STI epidemiology as possible cofactor for HIV transmission.

- Monitor local opportunistic infection epidemiology, including TB

- Improve percentage of suspected HIV/AIDS cases confirmed via serology.

- Improve HIV/AIDS screening.

#### Standard case definition

WHO/AFRO recommends that countries use either Bangui or Abidjan HIV/AIDSR case definitions. A positive ELISA for confirming HIV and a rapid test for confirming the positive results are sufficient for an epidemiologic case definition for HIV infection.

Public health actions

- Monitor local STI and opportunistic infections, including TB, as possible cofactor for HIV.

- Improve percentage of suspected HIV/AIDS cases confirmed via serology.

- Monitor use of condoms by commercial sex workers.

- Provide voluntary counselling and testing services at district and sub-district levels.

- Treatment of individual cases with antiretroviral therapy is not yet widely available in most African

countries. Rapid diagnosis and treatment of AIDS-related opportunistic infection (OI) may prolong life expectancy but this has not been widely evaluated in developing countries.

- Promote condom use, especially among high-risk individuals.

- Treat STIs, especially syphilis, chancroid diseases, and other ulcerative processes.

- Mobilize non-paid blood donors and promote appropriate use of blood.

- Promote good infection control practices within health facilities in the district.

- Educate patients and their sexual partners to refrain from donating blood, tissues, semen or breast milk.

#### Analyze and interpret data

Time: Count new AIDS cases and report monthly. Analyze by number of cases confirmed with serology. At the end of the year, calculate the total number of cases and include trends for HIV sero-surveillance, STI surveillance and results of any special studies (socio- behavioural studies, drug sensitivity to antimicrobial agents, and so on).

#### Laboratory confirmation

Adults and children 18 months or older:

Diagnostic test HIV infection is diagnosed based on:

- Positive HIV antibody testing (rapid or laboratory- based enzyme immunoassay).

This is confirmed by a second HIV antibody test (rapid or laboratory-based enzyme immunoassay) relying on different antigens or of different operating characteristics; AND/OR Positive virological test for HIV or its components (HIV-RNA or HIV-DNA or ultrasensitive HIV p24 antigen) confirmed by a second virological test obtained from a separate determination Children younger than 18 months:

HIV infection is diagnosed based on positive virological test for HIV or its components (HIV-RNA or HIV-DNA or ultrasensitive HIV p24 antigen) confirmed by a second virological test obtained from a separate determination taken more than four weeks after birth.

Positive HIV antibody testing is not recommended for definitive or confirmatory diagnosis of HIV infection in children until 18 months of age.

Serum

#### Specimen

When to collect Obtain specimens according to national HIV/AIDS program strategy for clinical or epidemiological sampling.

the specimen Use universal precautions to minimize exposure to sharps and any body fluid.

How to ELISA: Collect 10 ml of venous blood.

prepare, store, and

- Let clot retract for 30 to 60 minutes at room temperature or centrifuge to

transport the separate serum from red blood cells.

specimen

- Aseptically pour off serum into sterile, screw capped tubes.

- Store serum at 4°C.

Transport serum samples using appropriate packaging to prevent breakage or leakage.

#### Results

HIV testing is highly regulated with strict controls on release of information. Results are usually available within one week from arrival in the laboratory.

#### Reference

- Guidelines for Sexually Transmitted Infections Surveillance. Geneva. UNAIDS and World Health

Organization. WHO/CDS/CSR/EDC/99.3. UNAIDS/99.33E

- WHO Case definitions of HIV for surveillance and revised clinical staging and immunological

classification of HIV-Related disease in adults and children.

- WHO Recommended Surveillance Standards WHO/CDS/CSR/ISR/99.2

WHO

- Guidelines for Second Generation HIV Surveillance,

and UNAIDS, 2000 WHO/CDC/CSR/EDC/2000.5

- Consultation on technical and operational recommendations for clinical laboratory testing harmonization

and standardization, Jan 2008, WHO, CDC

### Noma

#### Background

- Noma (cancrum oris, stomatitis gangrenosa) is an opportunistic bacterial infection affecting children 1-4

years characterized by quickly spreading orofacial gangrene, evolving from a gingival inflammation.

- Noma results from complex interactions between risk factors such as poor sanitation, malnutrition,

recurrent illnesses, and compromised immunity. Diseases that commonly precede noma include measles, malaria, severe diarrhea, and necrotizing ulcerative gingivitis.

- Noma occurs worldwide, but is most common in sub-Saharan Africa. In 1998, WHO estimated that

worldwide 140 000 children contract noma each year, and 79% of them die from the disease and associated complications.

- In Africa the highest prevalence of Noma occurs in countries bordering the Sahara desert, where a recent

report estimates an annual incidence of 25,000. However, Noma can occur wherever there is extreme poverty.

- Early detection and treatment with antibiotics is key to preventing severe disfigurement or death. In the

acute stage, death can be prevented with high doses of penicillin; however disfigurement can only be treated with costly surgery.

- Prevention should focus on education and awareness of the disease, improved nutrition and household

hygiene, promotion of exclusive breastfeeding in the first 3-6 months of life, access to prenatal care, and immunizations against common childhood diseases.

- Clinical features include soreness of the mouth, pronounced halitosis (bad smelling breath), fetid taste,

tenderness of the lip or cheek, cervical lymphadenopathy, a foul-smelling purulent oral discharge, and a blue-black discoloration of the skin and swelling in the affected area.

- Health workers should recognize risk factors for Noma:

- Severe growth failure in first 6 months of life

o Evidence of malnutrition and poor dietary habits;

- Persistent diarrhea

- Oral ulcers in children from high risk areas

- Prominent bad smelling breath

#### Surveillance goal

- Early detection and treatment of cases

- Identification of high-risk communities and families

- Estimation of disease incidence and identification of risk factors

#### Standard case definition

Suspected new case: Any child with a mouth ulcer and other warning signs such as; malnutrition, poor hygiene, recent illness from; measles, persistent diarrhoea, or malaria should be regarded as a potential noma case.

Confirmed new case: Any person with a gangrenous disease which starts as gingival ulceration and spreads rapidly through the tissues of the mouth and face, destroying the soft and hard tissues.

Recommended public health action When a suspected case is detected:

- Treat the case with nationally recommended antibiotic

- Conduct health promotion activities in the community for:

- Awareness of Noma among the community and in the household

- Improved environmental sanitation and personal hygiene

- Separation of livestock from areas where humans live

- Exclusive breast feeding for the first 6 months of life

o Improved nutrition and food preparation techniques

- Increase vaccination coverage in the district

- Improve sources of drinking water in at-risk communities

- Train public health personnel on early recognition of oral lesions that can lead to Noma.

#### Analyze and interpret data

Time: Monitor number of cases detected in time for treatment and use of standardized treatment.

Monitor cases over time to estimate burden of disease and identify trends.

Place: Plot the location of case households and analyze the distribution.

Person: Analyze the distribution of cases by age and other demographic factors.

Laboratory confirmation: Routine laboratory confirmation for surveillance is not required.

#### Reference

- Enwonwu, C. (2006). "Noma--the ulcer of extreme poverty." New England Journal of Medicine, The

354(3): 221-224

- Enwonwu, C., W. Falkler, et al. (2006). "Noma (cancrum oris)." The Lancet 368(9530): 147- 156.

- Fieger, A., K. Marck, et al. (2003). "An estimation of the incidence of noma in north-west Nigeria."

Tropical medicine & international health 8(5): 402-407.

- Enwonwu, C. O. (1995). "Noma: a neglected scourge of children in sub-Saharan Africa." Bulletin of the

World Health Organization 73(4): 541-545.

- Enwonwu, C. O., W. A. Falkler, et al. (1999). "Pathogenesis of cancrum oris (noma): confounding

interactions of malnutrition with infection." The American journal of tropical medicine and hygiene 60(2): 223-232.

### Onchocerciasis

#### Background

- Filarial infection of the skin and eye caused by Onchocerca volvulus transmitted by the bite of female

Simulium black flies.

- Nearly the entire world's estimated 18 million infected persons (of whom more than 250

000 are blind) live within 26 African countries. Onchocerciasis is the second leading infectious cause of blindness worldwide. It causes debilitating skin problems, leading to significant decreases in productivity in areas where it is endemic. Entire villages have relocated away from the fertile lands near rivers where black flies breed.

- Incubation period is years to decades since repeated infection is necessary for disease manifestations.

Clinical illness is unusual in children even in endemic areas.

- Other filaria (for example, Loa loa and Mansonella) and other chronic skin and eye disease can produce

similar clinical findings.

#### Surveillance goal

Early detection with goal of reducing the recurrence of transmission of the parasite in areas where it has been eradicated (zones covered by the Onchocerciasis Program).

Conduct periodic surveillance in sentinel villages: screen using diethylcarbamzaine (DEC); in case of a positive reaction to DEC, confirm with a microscopic examination of a skin biopsy from each suspected case.

#### Standard case definition

Suspected case: In an endemic area, any person with fibrous nodules in subcutaneous tissues.

Confirmed case: A suspected case that is laboratory confirmed by presence of one or more of the following: microfilariae in skin snips, adult worms in excised nodules, or typical ocular manifestations (such as slit-lamp observations of microfilariae in the cornea, the anterior chamber, or the vitreous body).

#### Respond to alert threshold

If a suspected case is detected:

- Report the case according to national guidelines

- Collect specimen for confirming the case

- Investigate the case to determine the cause of the case

- Treat the case according to national guidelines.

#### Respond to action threshold

If a case is confirmed:

- Conduct a migration investigation to identify the origins of infection and initiate control activities.

- Carry out vector control activities according to OCP guidelines.

- Conduct periodic mass treatment with ivermectin in areas with endemic onchocerciasis during the last 10

years.

- Conduct active case finding via population-based surveys and skin snips.

#### Analyze and interpret data

Time:

Graph cases quarterly.

Place:

Plot distribution of patients household and workplaces Person: Count quarterly cases and analyze age distribution.

#### Laboratory confirmation

#### Diagnostic test

Microscopy.

Laboratory criteria for confirmation: One or more of the following:

- presence of microfilariae in skin snips taken from the iliac crest

- presence of adult worms in excised nodules

- presence of typical ocular manifestations, such as slit-lamp observations of

microfilariae in the cornea, the anterior chamber, or the vitreous body Skin snips from:

#### Specimen

- Nodule fluids

- liac crests

Scapula area When to collect Take snips and nodule fluids from suspected cases 1hour after administration of Diethyl carbomazine Put the sample in a general container. Add a few drops of normal saline. Close it How to prepare, store, and transport tightly before transporting it to the laboratory. Transported at ambient temperature.

the specimen

#### Results

Result should be ready within 1 day.

#### Reference

- WHO Recommended Surveillance Standards. Second edition. WHO/CDS/CSR/ISR/99.2

- WHO Recommended Surveillance Standards WHO/CDS/CSR/ISR/99.2

### Perinatal Deaths

#### Background

- Perinatal mortality refers to the number of stillbirths and deaths in the first week of life (early neonatal

mortality).

- The perinatal period commences at 28 completed weeks of gestation and ends 7 completed days after birth.

- Perinatal and maternal health are closely linked.

- About 80% of perinatal deaths are due to births asphyxia, complications due to prematurity and infections.

Other factors underlying prenatal deaths are maternal conditions such as poor obstetric care, malaria, HIV

- In 2009, there were 2.6 million stillbirths globally with more than 8200 deaths a day. At least half of all

stillbirths occurred in the intrapartum period.

- Among the 133 million babies born alive each year, 2.8 million die in the first week of life. The patterns

of these deaths are similar to the patterns for maternal deaths; many occurring in developing countries.

- In Uganda, the perinatal deaths are estimated to be 29 per 1000 live births (UDHS, 2011).

- Quality skilled care during pregnancy and childbirth are key for the health of the baby and the mother.

#### Surveillance goal

- Estimate and monitor perinatal deaths including still births

- Identify risk factors and high-risk area for perinatal death including still births to inform program

decisions

- Evaluate programmes aimed at reducing perinatal/newborn deaths

#### Standard case definition

Death of a baby that occurred around the time of birth, including both:

- Death of a newborn occurring during the first seven days of life

- Stillbirth (death prior to the complete expulsion or extraction from its mother of a fetus/baby of 28 or

more weeks of gestation; indicated by failure to breathe or show any other evidence of life, such as beating of the heart, pulsation of the umbilical cord or definite movement of voluntary muscles after such separation of the fetus).

Recommended public health action

- Monitor trends of perinatal deaths including still births.

- Promote public awareness and educate the community about predisposing factors and how to prevent

them.

- Advocate for and implement low cost maternal newborn high impact interventions along the

continuum of care and contribute to social economic growth and the attainment of human right.

- Identify high risk areas and communities

#### Analyze and interpret data

Time: Graph cases to construct an epidemic curve throughout the year in order to identify trends.

Place: Plot the location of cases and analyze the distribution.

Person: Analyse the distribution of cases by age and or weight and other demographic factors Laboratory confirmation: Routine laboratory confirmation for surveillance is not required.

#### Reference

- http://www.who.int/maternal_child_adolescent/topics/maternal/maternal_perinatal/en/

### Plague

#### Background

- Zoonotic systemic bacterial infection caused by Yersinia pestis (plague bacillus) usually transmitted to

humans by rodents and their fleas.

- Main disease forms: bubonic, pneumonic, and septicaemic; large-scale epidemics may occur in urban or

rural settings.

- Incubation period is 1 to 7 days.

- Case fatality rate (CFR) may exceed 50-60% in untreated bubonic plague and approaches 100% in untreated

pneumonic or septicaemic plague, but is usually <1% with appropriate treatment.

- Risk factor: rural residence. Exposure to infected populations of wild or domesticated rodents and their

fleas.

#### Surveillance goal

Detect outbreaks of plague promptly. Verify aetiology of all suspected non-outbreak-related cases and the first 5 to 10 outbreak-related cases.

#### Standard case definition

Suspected case: Any person with sudden onset of fever, chills, headache, severe malaise, prostration and very painful swelling of lymph nodes, or cough with blood stained sputum, chest pain, and difficulty in breathing.

Confirmed case: Suspected case confirmed by isolation of Yersinia pestis from blood or aspiration of buboes, or epidemiologic link to confirmed cases or outbreak.

#### Respond to alert threshold

If a single case is suspected:

- Report case-based information to the next level.

- Collect specimen for confirming the case.

- Investigate the case.

- Treat the patient with streptomycin, gentamicin or chloramphenicol, and administer chemoprophylaxis of

close contacts with tetracycline for seven days from time of last exposure.

#### Respond to action threshold

If the suspected case is confirmed:

- Isolate patients and contacts of pneumonic plague with precautions against airborne spread (wear masks, for

example) until at least after 48 hours of appropriate antibiotic therapy.

- Mobilize community to enable rapid case detection and treatment, and to recognize mass rodent die-off as

a sign of possible impending epidemic.

- Identity high risk population groups through person, place, and time analysis.

- Reduce sporadic and outbreak-related cases via improved control or rodent populations (remove trash, food

sources, and rat harbourages) and protect against fleas with insect repellent on skin and clothing and environmental flea control (especially in homes and seaports and airports).

#### Analyze and interpret data

Time: Graph monthly trends in cases and deaths. Construct epidemic curve for outbreak cases.

Plot the location of case households.

Place:

Person: Immediate case-based reporting of cases and deaths for routine surveillance. Count weekly cases and deaths for outbreaks. Analyze age distribution and assess risk factors to improve control of sporadic disease and outbreaks.

#### Laboratory confirmation

Isolation of Yersinia pestis from bubo aspirate or culture of blood, CSF or sputum.

#### Diagnostic test

Identification of antibodies to the Y. pestis F1 antigen from serum.

#### Specimen

Aspirate of buboes, blood, CSF, sputum, tracheal washes or autopsy materials for culture OR Blood for serological tests

Collect specimen from the first suspected plague case. If more than one suspected When to collect case, collect until specimens have been collected on 5 to 10 suspected cases before the specimen the administration of antibiotics. With buboes, a small amount of sterile saline (1-2 ml) may be injected into the bubo to obtain an adequate specimen If antibiotics have been started, plague can be confirmed by seroconversion (4-fold or greater rise in titer) to the F1 antigen by passive haemaglutination using pared sera.

Serum should be drawn within 5 days of onset then again after 2-3 weeks.

Specimens should be collected using aseptic techniques. Materials for culture How to prepare, store, should be sent to the laboratory in Cary Blair transport media or frozen and transport the (preferably with dry ice (frozen CO2). Unpreserved specimens should reach the specimen laboratory the same day.

- Liquid specimens (aspirates) should be absorbed with a sterile cotton swab and

placed into Cary-Blair transport medium. Refrigerate.

- If transport will require 24 or more hours and Cary Blair transport is not

available, freeze the specimen and transport it frozen with cool packs.

Cultures should only be sent to a laboratory with known plague diagnostic

#### Results

capabilities or to a WHO Collaborating Centre for Plague.

Plague culture results will take a minimum of 3 to 5 working days from reception in the laboratory.

Antibiotic treatment should be initiated before culture results are obtained. Plague patients seroconvert to the F1 Y. pestis antigen 7-10 days after onset.

#### Reference

- Plague Manual: Epidemiology, Distribution, Surveillance and Control/ Manuel de la Peste:

Epidemiologie, Répartition, Surveillance et Lutte. WHO/CDS/CSR/EDC/99.2

- "Laboratory Manual of Plague Diagnostic tests." CDC/WHO publication, 2000, Atlanta, GA

### Poliomyelitis (Acute flaccid paralysis)

#### Background

- Poliovirus (genus Enterovirus) serotypes 1, 2, and 3 are transmitted from person-to-person via faecal-oral

spread.

- Incubation period is 7 to 14 days for paralytic cases and the range is approximately 3 to 35 days. The virus

may be shed for several years by immuno-compromised persons.

- Infection is usually asymptomatic, but may cause a febrile syndrome with or without meningitis. In less

than 5% of infections paralysis results, often of a single leg.

- Polio infection occurs almost exclusively among children. Infection may occur with any of 3 serotypes of

Poliovirus. Immunity is serotype-specific and lifelong.

- Paralytic polio, though not fatal, has devastating social and economic consequences among affected

individuals.

- The Polio Eradication Program has nearly halted ongoing wild-type polio transmission worldwide through

use of oral poliovirus (OPV) vaccine. Globally, poliovirus type 2 appears to have been eliminated. Serotypes 1 and 3 polioviruses still circulate in three endemic countries including Nigeria in Africa and surveillance is not yet adequate to assure eradication in many countries.

- Areas with low vaccine coverage may allow ongoing wild-type transmission.

- Other neurological illnesses may cause AFP, for example, Guillain-Barre syndrome and transverse myelitis.

#### Surveillance goal

- Immediate case-based reporting of all Acute Flaccid Paralysis cases. Weekly summary reporting of cases

for routine surveillance and outbreaks.

- Detect cases of acute flaccid paralysis (AFP) and obtain laboratory confirmation of the aetiology of all

suspected AFP cases. Obtain two stool specimens within 14 days of the onset of paralysis for viral isolation.

- Surveillance for AFP is used to capture all true cases of paralytic poliomyelitis. Target for surveillance

performance to provide certification of polio eradications is 4 cases of AFP per year per 100 000 population aged less than 15 years.

#### Standard case definition

Suspected case: Any child under 15 years of age with acute flaccid paralysis or any person with paralytic illness at any age in whom the clinician suspects poliomyelitis.

Confirmed case: A suspected case with virus isolation in stool.

#### Respond to alert threshold

If a single case is suspected:

- Report the suspected case immediately according to the national polio eradication program guidelines.

- Conduct a case-based investigation. Include a vaccination history for the patient.

- Collect two stool specimens. Collect the first one when the case is investigated. Collect the second one from

the same patient 24 to 48 hours later. See laboratory guidelines for information on how to prepare, store and transport the specimen.

- If identified beyond 14 days of onset of paralysis collect two stool specimens from at least 3- 5 contacts of

the AFP case

- Obtain virological data from reference laboratory to confirm wild-type poliomyelitis or VAPP.

#### Respond to action threshold

If a case is confirmed:

If wild polio virus is isolated from stool specimen, refer to national polio eradication program guidelines for recommended response actions. The national level will decide which actions to take. They may include the following:

- Specify reasons for non-vaccination of each unvaccinated case and address the identified deficiencies.

- Immediately conduct "mopping-up" vaccination campaign around the vicinity of the case.

- Conduct surveys to identify areas of low OPV coverage during routine EPI activities, and improve routine

vaccine coverage of OPV and other EPI antigens.

- Lead supplemental vaccination campaigns during National Immunization Days (NIDs) or Sub-National

Immunization Days (SNIDs). Focus supplemental vaccination activities in areas of low vaccine coverage during EPI. Consider use of house-to-house vaccination teams in selected areas.

#### Analyze and interpret data

Time: Graph weekly cases (which should be zero to very few cases per area per year), or weekly cases during an outbreak. Evaluate the percent of suspected cases reported within 48 hours and the percentage with adequate laboratory evaluation.

Place: Plot location of case households. Investigate the circumstances of poliovirus transmission in each case thoroughly. Examine the possibility of other potential areas of transmission.

Person: Count monthly routine and outbreak-related cases. Analyze age distribution. Assess risk factors for low vaccine coverage.

#### Laboratory confirmation

Isolation of polio virus from stool

#### Diagnostic test

Stool

#### Specimen

Note: If no specimen is collected, re-evaluate patient after 60 days to confirm clinical diagnosis of polio (AFP).

Collect a sample from every suspected AFP case. Collect the When to collect the specimen here can i same are 2 1048 hour lates

- Place stool in clean, leak-proof container and label clearly.

How to prepare, store,

- Immediately place in refrigerator or cold box not used for storing vaccines or

and transport the other medicines.

specimen

- Transport specimens so they will arrive at designated polio laboratory within 72

hours of collection When there is a delay, and specimen will not be transported within 72 hours, freeze specimen at -20°C or colder. Then transport frozen specimen with dry ice or cold packs also frozen at -20°C or colder.

Confirmed results are usually available within 21 after receipt of specimen by the

#### Results

laboratory. If wild or vaccine derived polio virus is detected, the national program will plan appropriate response actions

#### Reference

- Field guide for training operational level health workers on vaccine preventable disease surveillance,

MoH/UNEPI (Revised edition 2012)

- Field Guide for Supplementary Activities Aimed at Achieving Polio Eradication. World Health

Organization.

- WHO global action plan for laboratory containment of wild polio viruses.

WHO/V&B/99.32, Geneva, 1999

- Manual for the virological investigation of polio, WHO/ EPI/GEN/97.01, Geneva, 2004

- Supplement to the Manual for the virological investigation of Polio- WHO/EPI 2007

### Rabies

#### Background

- Rabies is a zoonotic disease (a disease that is transmitted to humans from animals) that is caused by a virus.

Rabies infects domestic and wild animals, and is spread to people through close contact with infected saliva (via bites or scratches).

- The rabies virus infects the central nervous system, causing disease in the brain and, eventually, death.

Early symptoms in people include: fever, headache, and general weakness or discomfort. As the disease progresses, symptoms include; insomnia, anxiety, confusion, slight or partial paralysis, excitation, hallucinations, increase in saliva, difficulty swallowing, and fear of water.

- In unvaccinated humans, rabies is almost always fatal if post-exposure prophylaxis is not administered

before the onset of severe symptoms. Death usually occurs within days of the onset of neurological symptoms.

- Dogs are the main carrier of rabies in Africa and are responsible for most (approximately 97%) of the

human rabies deaths worldwide.

- WHO estimates approximately 55,000 human deaths worldwide due to rabies each year; in Africa the

annual death toll is 24,000.

- People most at risk of rabies live in rural areas, and children are at highest risk of dog rabies. About 30%

to 60% of the victims of dog bites (the primary mode of virus transmission) are children less than 15 years of age. Children often play with animals and are less likely to report bites or scratches.

- Control of rabies in dog populations and access to human rabies post exposure prophylaxis can substantially

reduce the burden of rabies in human populations

- Rapid and accurate laboratory diagnosis of rabies in humans and other animals is essential for timely

administration of post-exposure prophylaxis. Within a few hours, a diagnostic laboratory can determine whether or not an animal is rabid and inform the responsible medical personnel.

#### Surveillance goal

- Detect and respond promptly and appropriately to cases and outbreaks of rabies.

- Identify high-risk areas

- Estimation of disease burden

- Immediate reporting of cases and routine monthly summary reports

#### Standard case definition

Suspected: A person with one or more of the following: headache, neck pain, nausea, fever, fear of water, anxiety, agitation, abnormal tingling sensations or pain at the wound site, when contact with a rabid animal is suspected.

Confirmed: A suspected case that is laboratory confirmed Recommended Public Health Action For a single case:

- Post exposure prophylaxis to prevent rabies

- Isolate patient if rabies develops to prevent infection of others

- Immunize contacts if patient develops rabies

- Vaccinate local dogs and cats to prevent outbreaks

General preventive measures:

- Promote public awareness of rabies

- Target immunization campaign for domestic or wild animals in high-risk areas

- Maintain active surveillance of rabies in animals

#### Analyze and interpret data

Time: Plot cases monthly.

Place: Plot the location of case households and animal exposures.

Person: Analyze distribution of cases by age, exposing animal, and circumstances of infection. Assess risk factors to improve control of cases

#### Laboratory confirmation

Detection of rabies viral antigens by direct fluorescent antibody (FA) in clinical

#### Diagnostic test

specimens, preferably brain tissue (collected post mortem)

- Detection by FA on skin or corneal smear (collected ante mortem)

- FA positive after inoculation or brain tissue, saliva or CSF in cell

culture, in mice or in suckling mice

- Detectable rabies-neutralizing antibody titre in the CSF of an

unvaccinated person

- Identification of viral antigens by PCR on fixed tissue collected

postmodern or in a clinical specimen (brain tissue or skin, cornea or saliva)

- Isolation of rabies virus from clinical specimens and confirmation of

rabies viral antigens by direct fluorescent antibody testing.

Brain tissue (collected post mortem)

#### Specimen

- Skin biopsy (usually from the neck)

- corneal

- Saliva

- CSF

- Head of suspected rabid animal (dogs)

When to collect the When a person is bitten by a pet that appears sick or by a wild animal, the biggest concern is rabies. No test can determine whether the rabies virus has been specimen transmitted to the person immediately after the bite. So, the animal is evaluated to determine whether the person requires treatment. A wild animal that has bitten a person is killed if possible, so that its brain can be examined.

If a person who has been bitten by an animal becomes increasingly confused and agitated or paralyzed, the diagnosis is probably rabies. At this point, tests can detect the rabies virus.

Post mortem: within 4-6hrs after death of patient, as soon as the suspected animal dies or is killed How to prepare, store, Safety precautions in handling rabies virus should be taken to avoid intection.

and Remove the head of the suspected animal, wrap head completely such that no blood is oozing out. Where possible, request a veterinarian to assist in the transport the specimen collection and preservation of the specimen.

Sample should be sent to Reference Lab for Rabies virus.

#### Results

The treatment should never await the results of laboratory diagnosis. A laboratory diagnosis may be delayed for a variety of reasons. Results can be obtained from the reference lab within 1-2days.

#### Reference

- WHO Recommended Surveillance Standards WHO/CDS/CSR/ISR/99.2

- Laboratory techniques in rabies, Fourth Edition, WHO, edited by F.-X. Meslin and all

- World Health Organization, Rabies Fact Sheet

http://www.who.int/mediacentre/factsheets/fs099/en/

- Council of State and Territorial Epidemiologists (CSTE). National Surveillance for Human Rabies. CSTE

position statement 09-ID-70. Atlanta: CSTE; June 2009. Available from: http://www.cste.org.

- Centers for Disease Control and Prevention (CDC). Human Rabies Prevention - United States, 2008:

Recommendations of the Advisory Committee on Immunization Practices. MMWR 2008; 57(RR03): 1-26,28.Available from: http://www.cdc.gov/mmwr/

- Bleck TP, Rupprecht CE. Chapter 160 - Rhabdoviruses. In: Mandell GL, Bennett JE, Dolin R, editors.

Principles and Practice of Infectious Diseases, 6th edition. Philadelphia: Churchill Livingstone; 2005.

### Rift Valley Fever (RVF)

#### Background

- Rift Valley Fever (RVF) is a viral disease that affects mainly animals and occasionally humans. The virus

is a member of the Phlebovirus genus, one of the five genera in the family Bunyaviridae. The disease is frequently reported following heavy rainfall and floods. It was first isolated in Rift Valley Province of Kenya in 1930. The disease was reported in Kenya after the El Nino flooding of 1997/98 and more recently in 2006 to 2007. In 2007 and 2010, Tanzania and South Africa respectively were also affected. Other outbreaks have previously been reported in Somalia, Egypt, Saudi Arabia and Yemen.

- RVF is mainly transmitted from animals (sheep, cattle, goats, camels) to humans through close contact with

infected animals (such as handling meat and body fluids and consumption of raw milk). During established RVF outbreaks in animals' humans can also get infected through bites of infected mosquitoes and other biting insects.

- The incubation period of RVF varies from 2 to 6 days. The clinical symptoms include an influenza-like

illness, with sudden onset of fever, headache, myalgia and backache. These symptoms usually last from 4 to 7 days. Most of the infected people recover on their own. However, a small proportion (about 1%) get complications such as vomiting blood, nose bleeding and passing bloody stool. Other severe types of the disease are eye disease and meningo-encephalitis.

- Management of RVF in humans is mainly supportive as there is no definitive treatment for RVF. Early

detection and management of the disease is important. Human control of RVF is through control of the disease in animals through a sustained vaccination program and limiting human-animal contact. Use of insecticide treated nets and mosquito repellants can also reduce infections in human. In addition to human suffering and death, RVF has far reaching economic implications to the Livestock industry. In outbreak settings, the disease manifestation includes non-hemorrhagic febrile syndromes, and laboratory testing should be considered among persons with milder symptoms suggestive of viral illness.

- Immediate Notification to WHO is formally required by IHR (Annex)

#### Surveillance goal

Detect, confirm aetiology and respond to outbreaks promptly of all cases of suspected VHF

#### Standard case definition

Suspected case:

Early disease:

- Acute febrile illness (axillary temperature >37.5 °C or oral temperature of >38.0°C) of more than 48 hours

duration that does not respond to antibiotic or antimalarial therapy, and is associated with:

- Direct contact with sick or dead animal or its products AND / OR:

- Recent travel (during last week) to, or living in an area where, after heavy rains, livestock die or abort,

and where RVF virus activity is suspected/confirmed AND / OR:

- Abrupt onset of any 1 or more of the tollowing: exhaustion, backache, muscle pains, headache (often

severe), discomtort when exposed to light, and nausea/vomiting AND / OR:

- Nausea/vomiting, diarrhoea OR abdominal pain with 1 or more of the following:

- Severe pallor (or Hb < 8 gm/dL)

- Low platelets (thrombocytopenia) as evidence by presence of small skin and mucous membrane

haemorrhages (petechiae) (or platelet count < 100x109 / dL)

- Evidence of kidney failure (edema, reduced urine output) (or creatinine > 150 mol/L) AND / OR:

- Evidence of bleeding into skin, bleeding from puncture wounds, from mucous membranes or nose,

from gastrointestinal tract and unnatural bleeding from vagina AND / OR:

- Clinical jaundice (3-fold increase above normal of transaminases)

Late stages of diseases or complications (2-3 weeks after onset

- Patients who have experienced, in the preceding month a flu-like illness, with clinical criteria, who

additionally develop the following:

- CNS manifestations which resemble meningo-encephalitis AND/OR:

- Unexplained visual loss OR:

- Unexplained death following sudden onset of acute flu-like illness with haemorrhage, meningo-ecephalitis,

or visual loss during the preceding month.

Confirmed case:

Any patient who, after clinical screening, is positive for anti-RVF IgM ELISA antibodies (typically appear from fourth to sixth day after onset of symptoms) or tests positive on Reverse Transcriptase Polymerase Chain Reaction (RT-PCR).

#### Respond to alert threshold

If a single case is suspected:

Report case-based information immediately to the appropriate levels.

Enhance the usual standard precautions throughout the health care setting.

Treat and manage the patient with supportive care.

Collect specimen safely to confirm the case.

#### Respond to action threshold

If a single case is confirmed:

- Mobilize the community for early detection and care.

- Conduct community education about the confirmed case, how the disease is transmitted, and how to

prevent contact with tissues of infected animals and avoid mosquito bites.

- Provide information about prevention in the home and when to seek care.

Provide supportive treatment to all cases identified

- Request additional help from national levels as needed.

- Collaborate with the animal health specialists to search and document cases among animals as well.

#### Analyze and interpret data

Time: Graph cases and deaths monthly. Construct an epidemic curve during the outbreak.

Place: Plot location of case households and work sites using precise mapping.

Person: Immediate case-based reporting of cases and deaths. During the outbreak, count and report cases and deaths. Analyze age and sex distribution. Assess risk factors immediately and consider request for assistance to improve outbreak control.

#### Laboratory confirmation

Acute RVF can be diagnosed using several different methods. Serological tests

#### Diagnostic test

such as ELISA may confirm the presence of specific IgM antibodies to the virus.

The virus itself may be detected in blood during the carly phase of illness or in postmortem tissue using a variety of techniques including, antigen detection tests by ELISA, RT-PCR, virus propagation (in cell cultures), Immunohistochemistry in formalin-fixed tissues.

ELISA IgG can be used for retrospective diagnostic.

Same test can be used for animal diagnosis ELISA (serology)

#### Specimen

- Whole blood

- Serum or plasma

- Whole blood or clot

- Tissues (fresh frozen) RT-

PCR - Virus isolation

- Blood

- Serum/plasma

- Liver biopsy from fatal cases

Pathology

- Tissue biopsy from fatal cases

Identical specimen can be collected from animal When to collect the Collect specimen from the first suspected case.

specimen If more than one suspected case, collect until specimens have been collected from 5 to10 suspected cases.

Laboratory workers are at risk. Samples taken from suspected human cases of RVF How to prepare, store, and transport the for diagnosis should be handled by trained staff and processed in suitably equipped laboratories.

specimen

ELISA/PCR/ISOLATION

- Preparation and storage (freeze of refrigerate/as cold as possible)

Immunohistochemistry:

- Preparation and storage: Fix in formalin (can be stored up to 6 wks)

- Shipping: Room temperature (do not freeze).

Same shipping conditions for animal specimens Diagnostic services for RVF are not routinely available. Advance arrangements are

#### Results

usually required for RVF diagnostic services. Contact the appropriate National authority or WHO.

Contact national Veterinary Services for animal diagnostic.

#### Reference

- WHO/EMC Infection control for VHF in the African health care setting, WHO, 1998.

WHO Recommended Surveillance Standards WHO/CDS/CSR/ISR/99.2

- Fact sheet N°207 Revised September 2007.

- Infection Control for VHF in the African Health Care Setting /CDC (Annexes 11-12)

### Severe Acute Respiratory Infections (SARIS)

#### Background

- Severe acute respiratory infections (SARIs) are a significant cause of infectious disease morbidity and

mortality in Africa. The mortality rates are particularly high among infants, children and the elderly.

- An improved understanding of the epidemiology and seasonality of SARIs in Africa is essential for

optimizing public health strategies for their prevention and control (e.g., vaccines and antivirals for prophylaxis and treatment, infection control).

- The threat of SARIs due to novel organisms that have epidemic or pandemic potential warrants special

precautions and preparedness. Respiratory disease events that may constitute a public health emergency of international concern include severe acute respiratory syndrome (SARS); human influenza caused by a new subtype, including human episodes of avian influenza; pneumonic plague; and novel agents that can cause large-scale SARI outbreaks with high morbidity and mortality.

Surveillance goals

- To detect, in a timely manner, unusually severe morbidity and mortality caused by both known and

unknown respiratory pathogens that have the potential for large scale epidemics or pandemics.

- To characterize and monitor trends in illnesses and deaths attributable to SARIs.

#### Standard case definition

Severe acute respiratory infection (persons 2: 5 years old) Any severely ill person presenting with manifestations of acute lower respiratory infection with:

- Sudden onset of fever (>38°C) AND

- Cough or sore throat AND

- Shortness of breath, or difficulty breathing

- With or without Clinical or radiographic findings of pneumonia OR

Respond to a alert threshold If a single case of an epidemic- or pandemic-prone acute respiratory disease is suspected. OR If there is an unusual event (deaths, outbreak) of severe acute respiratory infection:

- Atypical cases of influenza-like illness (ILI) or severe acute respiratory infection (SARI).

- Two or more persons presenting with a SARI or who died from a SARI are detected with onset of illness

in a two-week period and in the same geographical area and/or are epidemiologically linked.

- Health-care workers with only occupational exposure risks develop SARI after providing care to patients

with SARI.

- Persons who have contact with birds/animals present with SARI;

- Any rumor of clusters of severe acute respiratory infections or of atypical respiratory infections

Respond to a suspected case of an epidemic- or pandemic-prone acute respiratory disease or to an usual event of severe acute respiratory infections:

- Report case-based information immediately to the appropriate levels.

- Practice infection control precautions for an acute respiratory disease with epidemic/pandemic potential4

(e.g., Standard plus Contact plus Droplet Precautions) immediately and enhance Standard Precautions throughout the health care setting.

- Treat and manage the patient according to national guidelines.

- Collect and transport laboratory specimens from case-patient and from symptomatic contacts and arrange

for laboratory testing 5,6

- Review clinical history and exposure history during 7days before disease onset.

- Identify and follow-up close contacts of case-patient.

- Conduct active searches for additional cases.

#### Analyze and interpret data

Time: Estimate incubation period; describe transmission patterns.

Person: Characterize the illness in terms of clinical presentation, the spectrum of disease, the proportion of cases requiring hospitalization, clinical outcomes, case fatality ratio, attack rates by age/occupation/blood relation.

Place: Describe risk factors, possible exposures. Ascertain whether any evidence exists that the virus may have increased its ability to cause human disease or improved its transmissibility.

#### Laboratory confirmation

Routine laboratory confirmation for surveillance is not required.

#### References

- International Health Regulations, IHR (2005)

- AFRO Technical Guidelines for Integrated Disease Surveillance in the African Region, May 2002

- WHO guidelines for investigation of human cases of avian influenza A(H5NI), January 2007.

- WHO interim guidelines on infection prevention and control of epidemic- and pandemic- prone acute

respiratory diseases in health care, June 2007

- WHO guidelines for the collection of human specimens for laboratory diagnosis of avian influenza

infection, 12 January 2005

- Collecting, preserving and shipping specimens for the diagnosis of avian influenza A(H5N1) virus

infection. Guide for field operations, October 2006.

### Severe Acute Respiratory Syndrome (SARS)

#### Background

- Severe acute respiratory syndrome (SARS) was first recognized as a global threat in 2003 when international

spread resulted in 8,098 SARS cases in 26 countries, with 774 deaths.

- Nosocomial transmission of SARS-CoV was a striking feature of the SARS outbreak.

- The majority of the cases were adults. The case fatality ratio of SARS is estimated to range from 0% to more

than 50% depending on the age group affected and reporting centre, with a crude global CFR of approximately 9.6%.

- The mean incubation period is 5 days, with the range of 2-10 days. Patients initially develop influenza-like

prodromal symptoms including fever, malaise, myalgia, headache and rigors. Cough (initially dry), dyspnoea and diarrhoea may be present in the first week but more commonly reported in the second week of illness. Severe cases develop rapidly progressing respiratory distress. Up to 70% of the patients develop diarrhoea.

- Disease transmission occurs mainly during the second week of illness.

- The SARS coronavirus (SARS-CoV) which causes SARS is believed to be an animal virus that crossed the

species barrier to humans recently.

- In the inter-epidemic period, all countries must remain vigilant for the recurrence of SARS and maintain

their ability to detect and respond to the possible re-emergence of SARS

- Immediate Notification to WHO is formally required by IHR (Annex 2, IHR).

Surveillance goals: Early detection and investigation of individuals with clinically apparent SARS-CoV.

#### Standard case definition

Suspected case of SARS is an individual with:

1. A history of fever, or documented fever 2 38 °C AND 2. One or more symptoms of lower respiratory tract illness (cough, difficulty breathing, shortness of breath) AND 3. Radiographic evidence of lung infiltrates consistent with pneumonia or ARDS or autopsy findings consistent with the pathology of pneumonia or ARDS without an identifiable cause AND 4. No alternative diagnosis can fully explain the illness.

Confirmed case of SARS: An individual who tests positive for SARS-CoV infection by the WHO recommended testing procedures.

Respond to suspected case

- Report case-based information immediately to the appropriate levels.

- Practice infection control precautions for an acute respiratory disease with epidemic/pandemic potential

immediately and enhance Standard Precautions throughout the health care setting.

- Treat and manage the patient according to national guidelines.

- Collect and transport laboratory specimens from case-patient and from symptomatic contacts and arrange

for laboratory testing.

- Review clinical history and exposure history during 2-10 days before disease onset.

- Identify and follow-up close contacts of case-patient.

- Conduct active searches for additional cases.

- Expedite the diagnosis. (WHO will assist in the investigation of SARS alerts as appropriate, including

facilitating access to laboratory services)

#### Respond to alert threshold

Response to SARS alert is same as response to suspected case (see above).

SARS ALERT:

1) An individual with clinical evidence of SARS AND with an epidemiological risk factor for SARS-CoV

infection in the 10 days before the onset of symptoms OR Two or more health-care workers with clinical evidence of SARS in the same health- care unit and with onset of illness in the same 10-day period OR 3 Three or more persons (health-care workers and/or patients and/or visitors) with clinical evidence of SARS with onset of illness in the same 10-day period and epidemiologically linked to a health-care facility.

#### Analyze and interpret data

Time: Graph cases and deaths daily/weekly/monthly. Construct an epidemic curve during the outbreak.

Place: Plot locations of case households and work sites using precise mapping.

Person: Immediate case-based reporting of cases and deaths. During the outbreak, count and report cases and deaths. Analyze age and sex distribution. Assess risk factors immediately.

#### Laboratory confirmation

Confirmed positive PCR for SARS virus:

#### Diagnostic test

- At least 2 different clinical specimens (eg nasopharyngeal and stool) OR

- The same clinical specimen collected on 2 or more days during the course of the

illness (eg 2 or more naspharyngeal aspirates) OR

- 2 different assays or repeat PCR using the original clinical sample on each

occasion of testing Seronconversion by ELISA or IFA:

- Negative antibody test on acute serum followed by positive antibody test on

convalescent serum OR

- Four-fold or greater rise in antibody titre between acute and convalescent phase

sera tested in parallel.

Virus isolation: Isolation in cell culture of SARS-Cov from any specimen; plus PCR confirmation using a validated method Nasopharyngeal wash/aspirate specimen of choice for respiratory viruses.

#### Specimen

Nasopharyngeal swabs or oropharyngeal swabs Stool Serum When to collect The respiratory tract specimen can be collected at any time, but are best taken during the acute phase of illness.

The time collection of paired blood samples is very important:

- Collect an acute illness sample at first contact with the patient at days 7, 14, 28

and 90 after onset where possible

- Collect blood on discharge if collection of a convalescent sample is unlikely.

SARS specimens should be handled according to appropriate biosafety practices in How to prepare, order to avoid laboratory-related infections and spread of disease to close contacts.

store, and transport Nasopharyngeal wash/aspirate: have the patient sit with the head titled slightly backward. Instill 1.5 ml non-bacteriostatic sterile saline (Ph 7.0) into one nostril. Flush a plastic catheter or tubing (e.g. mucus trap tubing) with 2-3 ml of saline. Insert the tubing into the nostril parallel to the palate. Aspirate nasopharyngeal secretions. Repeat for the other nostril. Collect aspirates in sterile vial or mucus trap. Remove tubings and discard in plastic bag.

Nasopharyngeal or oropharyngeal swabs: use only sterile Dacron or rayon swab with plastic shafts. Place each swab immediately in a tube containing Virus Transport Media.

Serum collection: Collect 5-10 ml of whole blood in a serum separator tube. Allow blood to clot Respiratory/stool/blood/serum specimens: Refrigerate immediately (4°C). If transport/shipping will be international or will occur > 5 days after collection of last specimens, freeze the specimens at - 20 °C (serum), -20/-70°C (respiratory specimens) for planned shipping with dry ice if available. Fixed tissues (formalin fixed) from all major organs. Store and ship fixed tissue at room temperature.

#### Results

Diagnostic services for SARS are not routinely available. Advance arrangements are usually required for SARS diagnostic services. Contact the appropriate National authority or WHO. If there is a high level of suspicion, WHO will support countries to contact a reference laboratory if necessary.

#### Reference

- WHO Guidelines for the Global Surveillance of SARS, Updated Recommendations, October 2004

- WHO Interim Guidelines, Infection Prevention and Control of Epidemic- and Pandemic- Prone Acute

Respiratory Diseases in Health Care, June 2007. WHO/CDS/EPR/2007.6.

- Use of laboratory methods for SARS diagnosis, WHO

- WHO Biosafety guidelines for handling of SARS specimens

- A practical Guide for SARS laboratories: from samples collection to shipment. WHO, 29 Dec 2003.

### Severe Pneumonia in Children under 5 years of age

#### Background

- Infection of the lower airways caused by bacteria or viruses transmitted person-to-person via aerosolized

respiratory droplet spread. The main bacterial causes of pneumonia among children are Streptococcus pneumoniae (the pneumococcus) and Haemophilus influenzae type b (Hib).

- Acute respiratory infections (ARIs) and pneumonia represent the number one cause of mortality among

children less than 5 years of age.

- Incubation period is usually less than 7 days, depending on the aetiology.

- WHO and UNICEF recommend use of Integrated Management of Childhood Illness (IMCI) strategy to

reduce morbidity and mortality attributable to childhood pneumonia. Early antimicrobial therapy has been shown to reduce mortality.

- Resistance of the pneumococcus and Hib to beta-lactams (for example, ampicillin), sulfonamides (for

example, trimethoprim-sulfamethoxazole) and other antimicrobials is increasing

- Viruses such as respiratory syncytial virus (RSV) may also cause ARI and pneumonia.

#### Surveillance goal

- Early identification of pneumonia cases and epidemics using clinical definitions.

- Monitor antimicrobial resistance routinely and during outbreaks.

- Reducing the proportion of severe pneumonia cases compared to non-severe pneumonia cases to monitor

quality of interventions.

#### Standard case definition

Clinical case definition (IMCI) for pneumonia: A child presenting with cough or difficult breathing and:

- 50 or more breaths per minute for infant age 2 months up to 1 year

- 40 or more breaths per minute for young child 1 year up to 5 years.

Note: A young infant age 0 up to 2 months with cough and fast breathing is classified in IMCI as "serious bacterial infectioni and is referred for further evaluation.) Clinical case definition (IMCI) for severe pneumonia: A child presenting with cough/difficult breathing and any general danger sign, or chest indrawing or stridor in a calm child. General danger signs for children 2 months to 5 years are: unable to drink or breast feed, vomits everything, convulsions, lethargy, or unconsciousness.

Confirmed case: Radiographic or laboratory confirmation of pneumonia will not be feasible in most districts.

#### Respond to alert threshold

If you observe that the number of cases or deaths is increasing over a period of time:

- 

Report the problem to the next level.

Investigate the cause for the increase and identify the problem.

Make sure that cases are managed according to IMCI guidelines.

Treat cases appropriately with recommended antimicrobial drugs

#### Respond to action threshold

If the number of case or deaths increases to two times the number usually seen during a similar period in the past:

- Assess health worker practices of IMCI guidelines for assessing, classifying and treating children with

pneumonia and severe pneumonia.

- Identify high risk populations through analysis of person, place and time.

- Conduct community education about when to seek care for pneumonia.

#### Analyze and interpret data

Time: Conduct month-to-month analysis for unexpected or unusual increases. Graph cases and deaths by month.

Construct epidemic curve for outbreak cases. Plot month-to-month data and compare to previous periods.

Place: Plot location of case households.

Person: Count monthly pneumonia and severe pneumonia cases. Count pneumonia deaths. Analyze age distribution.

#### Laboratory confirmation

Routine laboratory confirmation for surveillance is not required.

#### Reference

- Integrated Management of Childhood Illnesses. World Health Organization.

WHO/CDR/95.14.1

### Sexually transmitted infections

#### Background

- Infections of the human genito-urinary and reproductive systems transmitted via human sexual contact

(sexually transmitted disease, STIS). The most common causes of male urethral discharge are a) the gonococcus Neisseria gonorrhoea and b) Chlamydia trachomatis. The most common causes of male and female genital ulcer are c) syphilis (Treponema pallidum), d) herpes simplex virus (HSV1 or 2) and e) chancroid (Haemophilus ducreyi).

- STIs are endemic in most countries of the world. Multiple simultaneous STIs are common (for example,

gonorrhoea plus Chlamydia). STIs may be most highly prevalent in areas where HIV occurs and may facilitate HIV transmission. STIs may be primary or from repeated attacks of urethral discharge.

- STIs are a leading cause of abortion and stillbirth, prematurity, and congenital infections. They may lead to

pelvic inflammatory disease (PID), a major cause of decreased fertility.

- Incubation periods for gonorrhoea are 2 to 7 days; Chlamydia 7 to 14 days (or longer); syphilis, 10 days to

12 weeks (usually around 3 weeks), and chancroid, 3 to 14 days.

- STIs may be more commonly diagnosed in men, in whom clinical evidence of infection is readily apparent.

#### Surveillance goal

- Early detection and treatment of STI reduces transmission rates. Active efforts to diagnose latent syphilis

may prevent significant disability.

- Improve early and effective treatment of STIs using simple algorithms based on syndromic diagnosis for

index cases and partners.

- Carry out laboratory-based anti-microbial sensitivity monitoring and modify treatment guidelines

accordingly at the national level.

- Compare surveillance data for both STIs and HIV/AIDS since STIs may reflect co-presence of HIV.

#### Standard case definition

Genital ulcer syndrome (non-vesicular):

Suspected case: Any male with an ulcer on the penis, scrotum, or rectum, with or without inguinal adenopathy, or any female with ulcer on labia, vagina, or rectum, with or without inguinal adenopathy.

Confirmed case: Any suspected case confirmed by a laboratory method.

Urethral discharge syndrome:

Suspected case: Any male with urethral discharge with or without dysuria.

Confirmed case: Urethral discharge syndrome: A suspected case confirmed by a laboratory method (for example Gram stain showing intracellular Gram-negative diplococci).

#### Public health action

Conduct active case finding for specific target groups.

Conduct primary prevention activities such as promotion of safer sexual behaviours and condom use.

Assess use of algorithms for detection and treatment of STIs. And improve health worker practice with algorithms.

Include STI prevention and care services in maternal and child health, and family planning services.

- 

Target acceptable and effective STI prevention and care services to populations identified as vulnerable to STI transmission.

Promote early STI health seeking behaviour.

#### Analyze and interpret data

Time:

Graph cases each quarter.

Place:

No recommendation for analysis of place.

Person:

Count quarterly cases and analyze age distribution.

Laboratory confirmation: Routine laboratory confirmation for surveillance is not required.

#### Reference

- Guidelines for Sexually Transmitted Infections Surveillance. Geneva. UNAIDS and World Health

Organization. WHO/CDS/CSR/EDC/99.3. UNAIDS/99.33E

### Smallpox (Variola)

#### Background

- Smallpox is an acute contagious disease caused by variola virus, a member of the orthopoxvirus family. Other

members of the genus include cowpox, camelpox, and monkeypox. Monkeypox virus has caused the most serious recent human poxvirus infections.

- Smallpox killed as many as 30% of those infected. In 1967, when WHO launched an intensified plan to

eradicate smallpox, the disease threatened 60% of the world's population and killed every fourth patient.

- The global eradication of smallpox was certified by a commission of eminent scientists in December 1979

and subsequently endorsed by the World Health Assembly in 1980.

- Smallpox had two main forms: variola major and variola minor. The disease followed a milder course in

variola minor, which had a case-fatality rate of less than 1 per cent. The fatality rate of variola major was around 30%. There are two rare forms of smallpox: haemorrhagic and malignant. In the former, invariably fatal, the rash was accompanied by haemorrhage into the mucous membranes and the skin. Malignant smallpox was characterized by lesions that did not develop to the pustular stage but remained soft and flat. It was almost invariably fatal.

- The incubation period of smallpox is usually 12-14 days (range 7-17), during which there is no evidence of

viral shedding. During this period, the person looks and feels healthy and cannot infect others.

- The incubation period is followed by the sudden onset of influenza-like symptoms. Two to three days later,

the temperature falls and the patient feels somewhat better, at which time the characteristic rash appears, first on the face, hands and forearms and then after a few days progressing to the trunk. Lesions also develop in the mucous membranes of the nose and mouth, and ulcerate very soon after their formation, releasing large amounts of virus into the mouth and throat. The centrifugal distribution of lesions, more prominent on the face and extremities than on the trunk, is a distinctive diagnostic feature of smallpox and gives the trained eye cause to suspect the disease. Lesions progress from macules to papules to vesicles to pustules. All lesions in a given area progress together through these stages. From 8 to 14 days after the onset of symptoms, the pustules form scabs which leave depressed depigmented scars upon healing.

- Varicella (chickenpox) can be distinguished from smallpox by its much more superficial lesions, their

presence more on the trunk than on the face and extremities, and by the development of successive crops of lesions in the same area.

- Smallpox is transmitted from person to person by infected aerosols and air droplets via face-to-face contact

with an infected person after fever has begun and other symptoms, including cough. The disease can also be transmitted by contaminated clothes and bedding, though the risk of infection from this source is much lower.

The frequency of infection is highest after face-to-face contact with a patient after fever has begun and during the first week of rash, when the virus is released via the respiratory tract.

- In the absence of immunity induced by vaccination, humans appear to be universally susceptible to infection

with the smallpox virus.

- Vaccine administered up to 4 days after exposure to the virus, and before the rash appears, provides protective

immunity and can prevent infection or ameliorate the severity of the disease.

- Immediate Notification to WHO is formally required by IHR (2005).

Surveillance goal: To detect and immediately respond to any suspected case of smallpox.

#### Standard case definition

Suspected case: An illness with acute onset of fever ≥ 38.3°C (101°F) followed by a rash characterized by vesicles or firm pustules in the same stage of development without other apparent cause.

Probable case: A case that meets the clinical case definition, is not laboratory confirmed, but has an epidemiological link to a confirmed or probable case.

Confirmed case: A clinically compatible case that is laboratory confirmed.

#### Respond to alert threshold

If a single case is suspected:

- Report case-based information immediately to the appropriate levels.

- Implement airborne infection control precautions.

- Treat and manage the patient with supportive care.

- Collect specimen safely to confirm the case.

- Implement contact tracing and contact management.

- Conduct active surveillance to identify additional cases.

- Notify WHO.

#### Respond to action threshold

If a single case is confirmed:

- Maintain strict infection control measures practices throughout the duration of the outbreak.

- Mobilize the community for early detection and care.

- Conduct community education about the confirmed case, how the disease is transmitted, and how to

implement infection control in the home care setting and during funerals.

- Conduct active searches for additional cases.

- Request additional help from national and international levels.

- Establish isolation ward to handle additional cases that may be admitted to the health facility.

#### Analyze and interpret data

Time: Graph cases and deaths daily/weekly/monthly. Construct an epidemic curve.

Place:

Map location of case households.

Person: Immediate case-based reporting of cases and deaths. During the outbreak, count and report cases and deaths. Analyze age and sex distribution. Assess risk factors immediately.

#### Laboratory confirmation

Isolation of smallpox (Variola) virus from a clinical specimen OR PCR assay

#### Diagnostic test

identification of Variola DNA in a clinical specimen in Level C or D laboratories ONLY.

*, Scabs*

#### Specimen

Biopsy specimens* Vesicular fluid*, Lesion skin (roof) *, Pustule material* Blood samples Note: blood samples from person where severe, dense rash may be difficult to draw as the skin may slough off. A central line may be needed for access in cases where a peripheral blood draw is difficult.

* preferred specimens for diagnosis of acute illness during rash phase When to collect A suspected case of smallpox is a public health and medical emergency. Collect samples from every suspected case at available times to achieve specimen types How to prepare, Typical practices associated with collection of patient specimens are appropriate for collection of orthopoxvirus lesions as well. These include wearing personal protective store, and transport equipment, including gloves and sanitizing the site prior to collection. If alcohol is used to prepare the lesion for collection, make sure the lesion to dries before it is collected.

Biopsy specimens:

Aseptically place two to four portions of tissue into a sterile, leak-proof, freezable container. Storage -20 °C to - 70 °C. Transport - 6h at 4°C.

Note: package non-formalin lesion biopsy for shipping on dry ice, leave formalin fixed biopsy at room temperature. Do not freeze formalin fixed biopsy sample.

Scabs:

Aseptically place scrapings/material into a sterile, leakproof, freezable container.

Storage -20 °C to - 70 °C. Transport - 6h at 4 °C.

Vesicular fluid:

Collect fluid from separate lesions onto separate sterile swabs. Be sure to include cellular material from the base of each respective vesicule. Storage -20 °C to - 70°C.

Transport - 6h at 4°C.

Draw 10 cc of blood into a plastic marble-topped tube, or a plastic yellow-topped serum separator tube.

Note: approval must be obtained prior to the shipment of potential smallpox patient clinical specimens to a Reference laboratory.

#### Results

Diagnostic services for smallpox are not routinely available. Advance arrangements are usually required for smallpox diagnostic services. Contact the appropriate National authority or WHO.

#### Reference

- WHO Fact Sheet, Smallpox. http://www.who.int/mediacentre/factsheets/smallpox

### Trachoma

#### Background

- Trachoma is the leading cause of preventable blindness worldwide. It is caused by infection with Chlamydia

trachomatis bacteria, and is both treatable and preventable.

- Infections often begin during infancy or childhood and can become chronic. If left untreated, the infection

eventually causes the eyelid to turn inwards, which in turn causes the eyelashes to rub on the eyeball, resulting in intense pain and scarring of the front of the eye. This ultimately leads to irreversible blindness, typically between 30 and 40 years of age.

- Trachoma is easily spread through direct personal contact, shared towels and cloths, and flies that have

come in contact with the eyes or nose of an infected person.

- WHO estimates 6 million cases of blindness due to trachoma and 11 million cases of trichiasis worldwide

each year. Prevalence of active disease in children varies from 10-40% in some African countries.

- The infection primarily affects young children, with blindness occurring later in life. Females are three times

more likely than males to suffer from trichiasis, the in-turning of the eyelashes that can lead to blindness.

People are most at risk for trachoma infection in areas where there is poor sanitation, lack of latrines, poor sources of clean water, and the presence of flies.

- Primary interventions advocated for preventing trachoma infection include improved sanitation, reduction

of fly breeding sites and increased facial cleanliness (with clean water) among children at risk of disease.

The scaring and visual change for trachoma can be reversed by a simple surgical procedure performed at village level which reverses the in- turned eyelashes.

#### Surveillance goal

- Prevention of blindness by early detection

- Identification of high-risk areas and epidemiologic trends

- Estimation of disease burden

- Monitoring of control programs

#### Standard case definition

Suspected case: Any patient with red sticky eyes who complains of pain and itchiness of the eyes.

Confirmed case: Any patient with red sticky eyes who complains of pain and itchiness of the eyes where examination of the eyes confirms one of the stages of Trachoma infection according to the WHO Simplified Trachoma Grading System. (see reterence below).

Recommended public health action The World Health Organization has developed a series of interventions to control trachoma known by the acronym SAFE: Surgery, Antibiotics, Facial cleanliness, and Environmental improvement.

Effective Trachoma control has four main components:

- Eye lid surgery for those at immediate risk of blindness

- Antibiotics to treat individual cases and to reduce infection in a community

- The promotion of facial cleanliness and hygiene to reduce transmission

- Environmental improvements such as provision of water and household sanitation

#### Analyze and interpret data

Time: Monitor epidemiologic trends over time.

Place: Plot the location of case households and analyze the distribution.

Person: Analyze the distribution of cases by age and other demographic factors.

Laboratory confirmation: Routine laboratory confirmation for surveillance is not required.

#### Diagnostic test

Detection of specific antigen. Nucleic acid tests and tissue culture techniques.

Occasionally, in epithelial cells in Giemsa or iodine stained smears by direct microscopy.

Collection of conjunctival scrapings

#### Specimen

When to collect the specimen After anaesthetizing the conjonctiva with anesthetic eye drops, blot away any discharge How to prepare, and using a spatula with a thin blunt end, scrape the whole of the conjuctiva. Spread store, and the specimen evenly on a slide. As soon as the preparation is air-dry, fix it with transport the methanol for 2-3 minutes if the preparation is to be Giemsa stained.

specimen

#### Results

Outside of specialist laboratories, most ocular infection is diagnosed clinically (see annex 8 on the recommended case definition for the confirmed case) or immunologically.

#### Reference

- WHO Trachoma Page

http://www.who.int/topics/trachoma/en/

- World Health Organization. Trachoma control: A guide for program managers. Geneva:

World Health Organization, 2006.

- World Health Organization. Achieving Community Support for Trachoma Control. Geneva:

World Health Organization, 2006.

- World Health Organization. Primary Health Care Level Management of trachoma. Geneva:

World Health Organization, 2006.

- World Health Organization. Trachoma epidemiologic survey protocol. Geneva:

World Health Organization, 2006.

- CDC Trachoma

http://www.cdc.gov/healthywater/hygiene/disease/trachoma.html

- The Carter Center

http://www.cartercenter.org/health/trachoma/index.html

### Trypanosomiasis

#### Background

- Trypanosomiasis is an infection of blood, lymphatics and central nervous system. In Africa it is caused by

the protozoan Trypanosoma burcei rhodesiense and T. b. gambiense, which are transmitted by the bit of infected Glossina (tsetse) flies.

- Trypanosomiasis is endemic in over 30 African countries in West, Central and East Africa. It is highly

epidemic in the Democratic Republic of Congo, Angola, and other areas of civil conflict, where 80% of some village populations may be infected. Cattle are the major reservoir of Trypanosoma brucei rhodesiense, and humans are the major reservoir for T. b. gambiense.

- Incubation period is usually days to weeks with T. b. rhodesiense, and months to years with

T. b. gambiense infections. Without treatment, both forms are usually fatal.

- Trypanosomiasis control strategies include human and cattle population surveys to treat infected persons

and diminish cattle reservoirs, and tsetse fly habitat control (for example, removal of bushes and tall grasses near villages, and use of residual insecticides).

- Tuberculosis, malaria, bacterial meningitis, HIV/AIDS, and other central nervous system or systemic

infections can produce similar clinical findings.

#### Surveillance goal

- Increase percentage of cases confirmed by laboratory methods.

- Use population-based surveys and serologic screening for active case finding in endemic areas.

- Conduct human and cattle screening in trypanosomiasis-free areas.

#### Standard case definition

Suspected case:

Early stage: a painful chancre originating as a papule and then evolving into a nodule at the primary fly bite site.

There may be fever, intense headache, insomnia, painless lymphadenopathy, anaemia, local edema and rash.

Late stage: cachexia, somnolence, and central nervous system signs.

Confirmed case: A suspected case confirmed by card agglutination trypanosomal test (CATT) or by isolation of trypanosomes in blood lymph nodes or cerebrospinal fluid.

#### Respond to alert threshold

If you observe that the number of cases or deaths is increasing over a period of time:

Report the problem according to national guidelines.

Treat individual suspected and confirmed cases with appropriate therapy in closely monitored setting Collect specimen for laboratory confirmation.

Investigate cause of increasing number of cases to identify problems with prevention activities.

#### Respond to action threshold

If the number of cases or deaths increases to two times the number usually seen in a similar period in the past:

Assess prevention activities in the area around the cases and take action to improve them as indicated.

Conduct active case finding activities if it is an endemic area.

Conduct vector control activities specified by national guidelines.

#### Analyze and interpret data

Time: Graph quarterly cases.

Place: Plot the distribution of case households.

Person: Count monthly cases, and analyze age distribution.

#### Laboratory confirmation

Presumptive:

#### Diagnostic test

Serological: card agglutination trypanosomiasis test (CATT) Confirmation:

Parasitological: detection (microscopy) of trypanosomes in blood, lymph nodes aspirates or CSF Whole blood

#### Specimen

Lymph nodes aspirates Cerebrospinal fluid When to collect the Suspects from endemic places with fever Any patient with fever and may have come into contact with tsetse flies.

specimen For slides: Put the slides in a slide box and close properly. Store at room temperature in How to prepare, a dust-free place. In case there is no slide box, the slides can be wrapped in soft tissue store, and transport paper (filter papers, serviettes, toilet paper, etc.) the specimen For blood in anticoagulant bottles, refer to reference lab.

#### Results

Results should be available the same day.

#### Reference

- Control and Surveillance of African Trypanosomiasis. Report of a WHO Expert Committee, Geneva,

World Health Organization, 1998 (WHO Technical Report Series, No. 881).

- WHO Recommended Surveillance Standards WHO/CDS/CSR/ISR/99.2

### Tuberculosis

#### Background

- Infection of the lungs and other organs usually caused by Mycobacterium tuberculosis transmitted person-

to-person by droplet infection through coughing, sneezing or spitting. Clinically, the pulmonary form of the disease is more common than the extra-pulmonary form. The cardinal symptoms of pulmonary TB are chronic cough, weight loss, fever, loss of appetite and night sweats.

- Tuberculosis (TB) is a leading cause of infectious illness and death worldwide with over 8 million new cases

and 3 million deaths per year. In African countries, approximately 1.6 million of the new cases and over 600 000 cases occur each year. It is also estimated that between 30 and 50% of all new TB cases detected are infected with HIV and 40% of all AIDS deaths are due to TB. Those who are at highest risk of dying from TB include people with HIV/AIDS, malnutrition and other immuno-compromising conditions, the very young, and the very old.

- The global HIV pandemic has been a major cause of increasing TB cases, especially in African countries.

- Incubation period is approximately 1 to 3 months.

- WHO recommends the Directly Observed Therapy, Short-course (DOTS) strategy to maximize compliance

and treatment efficacy and to reduce development of drug-resistant strains. The DOTS strategy has been implemented by at least 40 of 46 Member States in the African Region. Varying degrees of success have been achieved in controlling TB where resources and motivation for diagnosis, treatment, and patient follow up are adequate.

- Clinically, bacterial pneumonia, malaria, trypanosomiasis, HIV/AIDS and a variety of other bacterial,

parasitic, and viral infections may cause similar syndromes of fever, cough, fatigue, and weight loss, or may themselves precipitate active TB in an already infected individual. Abdominal or other extrapulmonary sites of infection may occur after ingestion of un-pasteurized cow's milk (M. bovis).

#### Surveillance goal

Early detection of persons with infectious lung disease to improve chances of clinical improvement and reduce transmission of TB Improve percentage of TB cases confirmed by microscopy

#### Standard case definition

Suspected case: Any person with a cough of 3 weeks or more.

Confirmed case: Smear-positive pulmonary TB: a) a suspected patient with at least 2 sputum specimens positive for acid-fast bacilli (AFB), or b) one sputum specimen positive for AFB by microscopy and radiographic abnormalities consistent with active PTB as determined by the treating medical officer, or c) one positive sputum smear by microscopy and one sputum specimen positive on culture for AFB.

Smear negative PTB: a patient who fulfils all the following criteria: a) two sets taken at least 2 weeks apart of at least two sputum specimens negative for AFB on microscopy, radiographic abnormalities consistent with PTB and a lack of clinical response despite one week of a broad spectrum antibiotic, a decision by a physician to treat with a full course of anti-TB chemotherapy, or b) a patient who fulfils all the following criteria: severely ill, at least two sputum specimens negative for AFB by microscopy, radiographic abnormalities consistent with extensive pulmonary TB (interstitial and miliary), a decision by a physician to treat with a full course of anti-TB chemotherapy, or c) a patient whose initial sputum smears were negative, who had sputum sent for culture initially, and whose subsequent sputum culture result is positive.

#### Respond to alert threshold

If you observe that the number of cases or deaths is increasing over a period of time:

Report problem to the next level, or according to national guidelines.

Treat individual cases with direct observation (DOTS) including a treatment supporter.

Where feasible, isolate persons using respiratory infection control practices, especially if multi-drug resistant TB is suspected.

Investigate cause of increase, including performance of DOTS program in your area.

#### Respond to action threshold

If the number of cases or deaths increases to two times the number usually seen in a similar period in the past:

- Assess health worker performance with detection and treatment of smear-positive PTB and improve

practices as needed.

- Assess DOTS program and take action to make identified improvements.

- Conduct drug susceptibility tests to establish patterns of resistance.

#### Analyze and interpret data

Time:

Graph cases and deaths monthly.

Plot distribution of case households and workplaces.

Count monthly cases and deaths. Analyze age and sex distribution quarterly.

#### Laboratory confirmation

Microscopy: Presence of acid-fast bacillus (AFB) in Ziehl Neelsen (ZN) stained smears

#### Diagnostic test

Culture and identification Drug susceptibility test: Anti-tuberculosis drug resistance occurs when a strain of Mycobacterium tuberculosis isolate is resistant to one or more antimicrobial agents as evidenced by internationally recommended methods for susceptibility tests) MDR Resistance to Isoniazid and Rifampicin; X-DR= Resistance to Isoniazid and Rifampicin (MDR); plus, additional resistance to a fluoroquinolone and a second-line injectable agent Deep-chest sputum Aspirates

#### Specimen

When to collect the Collect sputum (not saliva) for direct smear microscopy and examine at least two specimen stained specimens taken on different days.

Smear should be examined at health facility where the specimen is taken.

How to prepare, TB cultures should be packaged in leak proof containers, wrapped in cotton wool.

store, and transport the specimen Transport in waterproof container to reference lab.

#### Results

TB microscopy is read daily. Quantification of observed mycobacterium are reported using various reporting methods. Refer to the criteria used by the examining laboratory.

Culture: after 6 - 8 weeks Anti-tuberculosis drug resistance: The national reference laboratory should be linked to a Supranational reference laboratory by strain exchange to ensure quality control

#### Reference

- Treatment of Tuberculosis: Guidelines for National Programs. WHO/TB/97.230

- Policy Statement of Prevention Therapy Against TB in People Living with HIV, WHO/TB/98.255

- Laboratory Services in Tuberculosis Control, Parts 1, II and III. WHO publications WHO/TB/98.258

- Guidelines to surveillance of drug resistance in tuberculosis 4th ed. WHO/HTM/TB/2009.422

### Typhoid Fever

#### Background

- Typhoid fever is a bacterial disease, caused by Salmonella typhi. Symptoms usually develop 1-3 weeks after

exposure, and may be mild or severe. They include high fever, malaise, headache, constipation or diarrhoea, rose-coloured spots on chest, and enlarged spleen and liver. Healthy carrier state may follow acute illness

- Typhoid fever remains a serious public health problem throughout the world, with an estimated 16-33

million cases and 500 000 to 600 000 deaths annually. In the last outbreak in the Democratic Republic of Congo, between 27 September 2004 and early January 2005, no less than 42 564 cases of typhoid fever were reported, including 214 deaths and 696 cases of peritonitis and intestinal perforations.

- In virtually all endemic areas, the incidence of typhoid fever is highest in children from 5-19 years old. The

disease is transmitted by food and water contaminated by the faeces and urine of patients and carriers.

- Polluted water is the most common source of typhoid transmission. In addition, shellfish taken from sewage-

contaminated beds, vegetables fertilized with night-soil and eaten raw, contaminated milk and milk products have been shown to be a source of infection.

- Typhoid fever has been virtually eliminated in most areas of the industrialized world with the advent of

proper sanitary facilities. Most cases in developed countries are imported from endemic countries.

- People can transmit the disease as long as the bacteria remain in their body; most people are infectious prior

to and during the first week of convalescence. 10% untreated patients discharge bacteria for up to 3 months.

- Typhoid fever can be treated with antibiotics. However, resistance to common antimicrobials is widespread.

Healthy carriers should be excluded from handling food.

#### Surveillance goal

- Detect Typhoid Fever sporadic cases and outbreaks promptly, and seek laboratory verification

- Identify areas/population at high risk in order to improve prevention of the disease by taking hygienic

measures Standard case definitions Suspected case: Any person with gradual onset of steadily increasing and then persistently high fever, chills, malaise, headache, sore throat, cough, and, sometimes, abdominal pain and constipation or diarrhoea.

Confirmed case: Isolation of Salmonella typhi from blood, bone marrow, bowel fluid or stool.

#### Respond to alert threshold

If Typhoid fever cases are suspected:

- Arrange for laboratory testing of stool specimens or rectal swabs of suspected cases, especially in situations

where food- or waterborne transmission is suspected.

- Report and investigate all suspected outbreaks of typhoid. Search for case/carrier that is the source of

infection and for the vehicle (water or food) through which infection is being transmitted.

- Treat typhoid fever patients with antibiotics. Severe cases should be provided supportive measures such as

oral or intravenous hydration, the use of antipyretics, and appropriate nutrition.

#### Respond to action threshold

If Typhoid Fever cases are confirmed

- Identify areas/populations at high risk to identify source(s) and mode(s) of transmission in order to prevent

and control the disease.

- Conduct health education programmes on hygiene with simple messages on safe water, safe food handling

practices, hygiene and hand washing.

- Support provision of clean water and proper sanitation to affected population(s). Chlorinate suspected water

supplies. All drinking water should be chlorinated or boiled before use.

- More than 90% of patients can be managed at home with oral antibiotics, reliable care and close medical

follow-up for complications or failure to respond to therapy. Patients with persistent vomiting, severe diarrhoea and abdominal distension may require hospitalization and parenteral antibiotic therapy.

#### Analyze and interpret data

Time: Graph cases and deaths weekly. Construct an epidemic curve during outbreaks.

Place: Plot location of case households with precise mapping.

Person: Report immediate case-based information for cases and deaths. Report summary totals monthly. During outbreak, count cases and deaths weekly. Analyze by age. Assess risk factors to improve prevention of outbreaks.

#### Laboratory confirmation

#### Diagnostic test

Culture: Isolation of salmonella spp. from stool or blood of a patient The WIDAL Test should not be used for diagnostic purpose Blood Stool

#### Specimen

#### When to collect the specimen

Collected samples preferably before antibiotics are administrated 5-10 ml of blood distributed in a blood culture bottle. Stool in How to prepare, store, and stool container transport Store specimens at 4-8 C or ambient temperature away from heat and direct sunlight.

#### Results

Blood culture 4 days to 2 weeks Stool 3-4 days.

#### Reference

- The diagnosis, Treatment and Prevention of Typhoid Fever; WHO/V&B/03.07

- Weekly Epidemiological Record; N° 1, 2005, 80, 1-8; http//www.who.int/wer

- WHO Recommended Surveillance Standards WHO/CDS/CSR/ISR/99.2

### West Nile Fever

#### Background

- West Nile Fever is a febrile illness resulting from a mosquito-borne arbovirus in the Flavivirudae family. It

is a zoonotic disease transmitted from birds to humans and other animals. Serological evidence suggests that the infection is present throughout practically the entire African continent. West Nile Fever most likely emerged in Africa and is now found world-wide. Outbreaks occur in humans, birds and horses.

- Most cases are mild and may not come to the attention of the health system. Patients seeking health care

usually present with flu-like symptoms such as fever, headache and body aches. Occasionally patients present with a skin rash on the neck, trunk, arms or legs.

- People of all ages and conditions may be affected. However, those who are above age 50 years or who have

had an organ transplant are at increased risk of severe illness.

- Very severe cases include signs of encephalitis, meningo-encephalitis or meningitis. Symptoms include high

fever, headache, neck stiffness, stupor, tremors, convulsions, flaccid paralysis and coma.

- The case fatality rate in patients with neurological involvement ranges from 4% to 14% and as high as 29%

in elderly patients.

- West Nile Fever can be prevented by avoiding mosquito bites especially at dusk when mosquitoes are most

active. Insect repellents, wearing long sleeves and trousers, staying indoors and draining breeding sites like pools of standing water can reduce exposure to mosquitoes.

- Confirmation of West Nile Fever in patients with clinical symptoms requires laboratory confirmation of

specific IgM antibodies in cerebrospinal fluid and serum specimens.

- Because there is no specific treatment for West Nile Fever, patients with severe disease are usually

hospitalized for supportive treatment and nursing care.

#### Surveillance goal

- Identify risk factors for infection and determine high-risk populations for targeted prevention activities

- Identify geographic areas for targeted prevention and control activities

- Identify most severe cases for referral to hospitalized care

#### Standard case definition

Suspected case: A hospitalized case of encephalitis due to unknown cause Confirmed case: Confirmation of West Nile Fever is through ELISA to identify WNV-specific IgM

#### Respond to alert threshold

If a single case is suspected:

- Report case-based information immediately to the appropriate levels.

Treat and manage the patient with supportive care.

- Collect specimen safely to confirm the case.

#### Respond to action threshold

If a single case is confirmed:

- Treat and manage the patient with supportive care

- Mobilize the community through education in order to promote adoption of behaviours that reduce disease

risk such as protection against mosquito bites and reduction of mosquito breeding sites

- Conduct community education on how WNV is transmitted and on how to prevent being infected

#### Analyze and interpret data

Time: Construct an epidemic curve during the outbreak.

Place: Plot location of case residence and worksite.

Person: Immediate case-based reporting of cases and deaths. During an outbreak, count and report cases and deaths. Analyze age and sex distribution. Assess risk factors immediately and consider request for assistance to improve outbreak control.

#### Laboratory confirmation

Presence of IgM antibodies against West Nile Fever

#### Diagnostic test

#### Specimen

For ELISA: Whole blood, serum or plasma For PCR: Whole blood or blood clot, serum/plasma or tissue For immunohisto-chemistry: Skin or tissue specimens from fatal cases.

When to collect the Collect specimen from the first suspected case.

If more than one suspected case, collect until specimens have been collected from 5 specimen to 10 suspected cases.

HANDLE AND TRANSPORT SPECIMENS FROM SUSPECTED VHF How to prepare, store, PATIENTS WITH EXTREME CAUTION. WEAR PROTECTIVE CLOTHING and transport the AND USE BARRIER PRECAUTIONS.

specimen For ELISA or PCR:

- Refrigerate serum or clot

- Freeze (-20C or colder) tissue specimens for virus isolation

For Immunohistochemistry:

- Fix skin snip specimen in formalin. Specimen can be stored up to 6 weeks. The

specimen is not infectious once it is in formalin. Store at room temperature.

Formalin-fixed specimens may be transported at room temperature.

#### Results

Diagnostic services for VHF are not routinely available. Advance arrangements are usually required for VHF diagnostic services. Contact the appropriate National authority or WHO.

#### Reference

- Global Alert and Response; West Nile Fever epidemic updates

http://www.who.int/csr/don/archive/disease/west nile _fever/en/

- Pedro N. A and Boris Szyfres. Zoonoses and Communicable Diseases Common to Man and Animals.

Third edition, Volume II. Chlamydioses, Rickettsioses and Viroses, Part II: Viroses Pages 372-376. Pan American Health Organization, WHO

- Epidemic/Epizootic West Nile Virus in the United States: Guidelines for Surveillance, Prevention

and Control. http://www.cdc.gov/ncidod/dvbid/westnile/resources/wnv- guidelines-aug-2003.pdf

- Infection Control for Viral Hemorrhagic Fevers in the African Health Care Setting

WHO/EMC/ESR/98.2

- Viral Infections of Humans; Epidemiology and Control. 1989. Evans, A.S. (ed). Plenum Medical

Book Company, New York

### Yellow fever

#### Background

- Acute viral hemorrhagic disease caused by a flavivirus transmitted human-to-human via the domestic

species of Aedes mosquitoes (Urban epidemics) or to humans from primate reservoir via a forest mosquito species (Sylvatic cycle).

- Large scale outbreaks occur every 3 to 10 years in villages or cities in the absence of large scale

immunisation. Sporadic cases can occur regularly in endemic areas. Resurgence of disease in Africa since mid-1980s. True incidence far exceeds reported cases.

- Incubation period 3 to 6 days after the bite from an infected mosquito. About 15% of infections progress to

fever and jaundice.

- While only the minority of cases are severe, case fatality rate may be 25% to 50% among patients with

syndrome of haemorrhage, jaundice, and renal disease.

- Risk factor: sporadic cases often linked to occupation or village location near woods or where monkeys are

numerous. Also, non-vaccinated persons.

- International reporting to WHO required within 24 hours.

- Viral hemorrhagic fevers (VHF) and other parasitic, viral, or bacterial diseases such as malaria, Dengue

Chikungunya, leptospirosis, hepatitis A-E, Epstein-Barr virus, West Nile, Q fever, anthrax, rickettsial diseases, etc, and toxic exposures may mimic yellow fever.

- Infection and disease can be prevented by vaccination. With a vaccine efficacy > 95% and duration of

immunity of at least 10 years.

#### Surveillance goal

- Seek confirmation of yellow fever and rule out other possible etiologies of fever with jaundice

- Provide information in order to adopt appropriate control measures

- Identify populations at risk of yellow fever

- Monitor the epidemiology of the disease and the impact of control measures Support operational research

and innovation

#### Standard case definition

Suspected case:

Any person with acute onset of fever, with either a negative laboratory test (blood slide or RDT) for malaria or failure to respond to a full course of antimalarials AND any one of the following:

1. Jaundice or scleral icterus appearing within 14 days of onset of the first symptoms 2. Bleeding from either the mouth, nose, gums, skin, eyes or stomach (gastrointestinal tract) Probable case: Any person meeting the suspect case definition criteria with epidemiological link to a confirmed case or an outbreak.

Confirmed case: A probable case AND Any person who meets the suspect or probable case definition criteria AND has not had yellow fever immunization within 30 days before onset of illness; and one of the following:

Detection of yellow fever-specific IgM; 2. Detection of fourfold increase in yellow-fever IgM, or IgG antibody titres between acute and convalescent serum samples, or both; Detection of yellow fever-specific neutralizing antibodies.

*YF-specific means that antibody tests (such as IgM or neutralizing antibody) for other prevalent flavivirus are negative. This testing should include at least IgM for Dengue and West Nile and may include other flavivirus depending on local epidemiology. OR Any person who meets the suspect or probable case definition criteria and has not had yellow fever immunization within 14 days before onset of illness; and one of the following:

o detection of yellow fever virus genome in blood or other organs by PCR;

- detection of yellow fever antigen in blood, liver or other organs by immunoassay;

o isolation of yellow-fever virus

#### Respond to alert threshold

If a single case or cluster is suspected or probable:

- Fill out notification form, including clinical information, case based forms, check vaccination status and

travel history

- Take blood specimen for laboratory confirmation. You may obtain convalescent specimen from patient(s),

Diagnose and treat patients) with supportive care.

- Notify immediately to the next level. In the case of probable case inform nearby health units

- Strengthen surveillance (apply the community case definition ie. fever and jaundice)

- Initiate a preliminary field investigation if cluster of cases with fever and jaundice. Obtain information to

determine probable site of infection. Determine vaccination coverage of the community and start planning for vaccination (in case of a cluster)

- Strengthen routine yellow fever immunization

#### Respond to action threshold

In addition to alert threshold response If a single case is confirmed:

- Continue / complete epidemiological investigation including screening for vaccination status

- Initiate entomological investigation if indicated

- Determine vaccination coverage in affected area (routine EPI, recent outbreak responses or preventive

campaigns)

- Initiate social mobilization for interventions selected

- Continue risk communication and action to reduce risk including vector control if indicated

- Initiate vaccination in affected villages, district or town/city based on epidemiological findings

- Notify to WHO through Central Authorities using IHR decision instrument

- Continue to strengthen routine yellow fever immunization, especially for hard-to-reach areas

#### Analyze and interpret data

Time:

Generate Weekly Graphs of cases and deaths.

During outbreaks, construct epidemic curves (to monitor daily then weekly trends).

Plot location of case households and occupation with precise mapping Person: Report immediate case-based information for cases and deaths. Report summary totals weekly.

During outbreak, count cases and deaths daily as they occur, then weekly when the epidemic matures or ends.

Analyze by person variables (age, sex, occupation.). Assess risk factors to improve prevention of sporadic outbreaks.

#### Laboratory confirmation

1. ELISA for the presence of yellow fever Specific IgM and IgG antibodies.

#### Diagnostic test

2. Exclusion of Dengue, West Nile virus and other locally prevalent flavivirus will be necessary for the confirmation of yellow fever.

3. PCR, YF specific seroncutralization, virus isolation or histopathology

#### Specimen

Serum in the acute and convalescent phases of the illness; In the event of death, postmortem liver specimen Within 14 days of onset of first symptoms When to collect the specimen Collect specimen from at least the first to 10th suspected cases of yellow fever. Collect specimen from last cases (based on epidemic curves) to decide on the end of the epidemic.

- Collect 10 ml of venous blood from adults, 1-5 ml from children, in a capillary

How to prepare, tube, microtainer, or if necessary in a standard glass test tube.

store, and Separate blood cells from serum:

transport the

- Let clot retract for 30 to 60 minutes at room temperature. Centrifuge at

2000 rpm for 10-20 minutes and pour off serum into a clean glass tube.

specimen

- If no centrifuge, put sample in refrigerator overnight (4 to 6 hours) until

clot retracts. Pour off serum the next morning.

- If no centrifuge and no refrigerator, let blood sit at an angle for at least 60

minutes (without shaking or being driven in a vehicle. Pour off serum into a clean tube.

- Store serum at 4°C.

Transport serum samples using appropriate packaging to prevent breaking or leaks during transport. Avoid glass tubes for shipment and transport if possible.

The specimen should arrive at the laboratory within 3 days of being collected. Avoid

shaking of specimen before serum has been collected.

To prevent bacterial overgrowth, ensure that the serum is poured into a clean glass test tube. The test tube does not need to be sterile - just clean.

Transport the serum in an EPI hand vaccine carrier at 4°C-8°C to prevent bacterial overgrowth (up to 7 days). If not refrigerated, serum stored in a clean tube will be good for at least 3 days.

Laboratory results should be received within 7 days of reception of the specimen in the

#### Results

laboratory.

#### Reference

- District guidelines for yellow fever surveillance. WHO 1998 WHO/GPVI/EPI/98.09

- Yellow Fever. 1998. WHO/EPI/Gen/98.11

- Recommendation of Expert Meeting on Yellow Fever Surveillance and Response in Africa. Brazzaville,

Congo, from 13 to 15 October 2010

### Annexes to SECTION 11

The following annexes are examples of program specific forms. Some forms are for documenting initial findings while others are designed for in-depth investigation. Refer to your country's national surveillance program for the appropriate forms.

ANNEX 11A Reporting form for adverse events following immunization (AEFI) ANNEX 11B Acute flaccid paralysis - case investigation form ANNEX 11C Cholera - case-based investigation form ANNEX 11D Guinea worm - case investigation form ANNEX 11E Maternal death - reporting form ANNEX 11F Measles - case investigation form ANNEX 11G Neonatal tetanus - case investigation form ANNEX 11H Perinatal death audit form ANNEX 111 Tuberculosis - MDR and XDR TB - case-based reporting form ANNEX 11J Viral hemorrhagic fever - case report form

#### Annex 11A: Reporting form for adverse events following immunization (AEFI)

AEFI reporting ID No.

*Reporter's Name:

*Patient name:

*Patient's full Address:

Institution / Designation, Department & address:

Telephone:

Sex: M Telephone & e-mail:

*Date of birth (DD/MM/YYYY):

Years Months Days OR Age at onset:

1 to 5 Years > 5 Years *Date today (DD/MM/YYYY):

OR Age Group: < 1 Year Health facility (or vaccination centre) name:

Expiry date *Time of Dose *Date of *Name of Vaccines Received *Batch/ Lot number vaccination vaccination (e. g. 1"t, 2nd, etc.) *Adverse event (s):

Describe AEFI (Signs and symptoms):

Severe local reaction > 3 days beyond nearestjoint Seizures febrile afebrile Abscess Sepsis Encephalopathy Toxic shock syndrome Thrombocytopenia Anaphylaxis Fever238°C Other (specify)...

Date & Time AEFI started (DD/MM/YYYY):

Min Hr Yes No Was the patient hospitalized?

Date patient notified event to health system (DD/MM/YYYY):

*Outcome:

Unknown Not Recovered Recovering Recovered Recovered with sequelae Died If died, date of death (DD/MM/YYYY): / / Unknown Autopsy done: Yes No Past medical history (including history of similar reaction or other allergies), concomitant medication and other relevant information (e.g. other cases). Use additional sheet if needed:

First Decision making level to complete:

National level to complete.

If yes, date investigation planed (DD/MI/YYYY) Investigation needed: • Yes - No AEFI worldwide unique ID:

Date report received at national level (DD/MM/YYYY):

Comments:

#### Annex 11B: Acute flaccid paralysis - case investigation form

Revised December 2012 Revised Polanelitia/Acate Flaccid Paralysis Case Investigation Forta-Acate Harts Ministry of Health, Republic of E ganda COMFLLSORY NOTIFICATION (PLEASE COMPLETE ALL INFORMATION IN FULL) (Complate this form for all ca occurring within the previous 12 months) Circle or 52 the farm an appo Bretard Sepicher 280% (F00 In inplicatic) _(District of'ausst - where the child

- Bring when

nected (2 wesks prier to aust of paralysis) 1. Age in yen Fe: Male Pole Latitade:

Date of Time of collection Tate Sent Tate Resul to LIVRI Recctved Renalt Specimen 1:

Speciman 2:

15. Was this AFT cases detected after 14 e stool spacin ad conduct the 60-day follow up as soon as posible ather to days have clapsed since of age living in the same hose as AFT case. If here are less than 5 c ciran collection forra for sach contact. Use separate spectran carrier far contacts specimens and the AFF case specimens.

cinera.

TITLE PERSON RECORDING _ DATE TELEPIONE PLEASE SEND A COPY OF THES COMPLETED FORM WITH THE SPECIMENS TO UVELEPI LABORATORY IN ENTERBE IF VOU HAVE ANY QUESTIONS, PLEASE CONTACT: 8414328538 OR 8414328385

#### Annex 11C: Cholera - case-based investigation form

Cholera Case Investigation Form Area: Patient and clinical laboratory related information Answers Variables/Questions Detection day (dd/mm/yyyy) Detection place (Health facility or Community) 2 Patient identification number (yyyy-week- CCC- PPP-DDD-Reporting site-nnn) 4 Patient surname or last name Patient first name(s) Age (years) Sex (F/M) Number of people in same household 9 Patient's residencial Adress 10 Village/Town Neighborhood 12 District 13 Province 14 Country Date of onset (first symptoms) (dd/mm/yyyy) 15 16 Clinical signs and Symptoms Was patient exposed to any known risk factor for 17 this disease? (Yes/No) If yes, specify risk factors): Water used by the patient for drinking: (list by type, e.g. tap water, 18 Borehole, unprotected well, protected well, River, dam, lake, pond) 19 Number of doses of cholera Vaccine 20 Date last dose was administered Laboratory related information: at least first 21 and last cases Vibrio cholerae identified in stools?

22 23 Drugs to which the vibrio strain is sensitive 24 Drugs to which the vibrio strain is resistant 25 Outcome (Died, Survived, Unknown)

Final Classification (Not a case, Suspect, Probable, 26 Confirmed by Lab, Confirmed by epidemiological link, Pending) Other Notes and Observations 27 Date latest update of this record (dd/mm/yyyy) 28 Area: Risk factor search (Information to be obtained from the water and sanitation group of the investigation team) Answers Variables/Questions Mapping Potential Hazards 1 Potential vibrio vehicles: drinking water 2 Drinking water source 1 Drinking water source 2 4 Drinking water source 3 5 Drinking water source 4 Potential vibrio vehicles: non drinking water 7 Non drinking water source 1 Non drinking water source 2 9 Non drinking water source 3 10 Non drinking water source 4 11 Potential vibrio vehicles: Food items Food items 1 12 13 Food items 2 14 Food items 3 15 Food items 4 17 Food items 5 Food items 6 18 19 Food items 7 20 Food items 8 21 Bacteriology lab findings 22 Drinking water found infected by vibrio Non drinking water found infected by Vibrio 23 24 Food items found infected by vibrio to the out Looking for Exposure 25 identified hazards Water used by the patient for drinking: (list by type, water, e.g.

Borehole, unprotected well, tap protected well, River, dum, lake, pond):

26

Within 3 days prior to the onset of the disease did 27 the patient drink from 28 Water source 2 (Yes/No) 29 Water source 3 (Yes/No) 30 Water source 4 (Yes/No) 31 Water source 5 (Yes/No) Within 3 days prior to the onset of the disease did 32 the patient eat 33 Food item 1 (Yes/No) 34 Food item 2 (Yes/No) 35 Food item 3 (Yes/No) 36 Food item 4 (Yes/No) 37 Food item 5 (Yes/No) Within 3 days prior to the onset of the disease did 38 the patient attend any 39 funerals (Yes/No) 40 other social event (Yes/No)

Position:

District:_ Region:

Position:

To be completed in triplicate 378 Zone:

Ethnicity Residence since when(in months):

Land Marks:

Zone:

Reported by:

District:

Father's Name/Landlord's Name:

Investigated by:

Occupation:_ Sex:

Village:_ COU-REG-DIS-YR-CA SE Epid No: - Area/Sub District:

Place of residence is same as the reporting village: YES/NO GUINEA WORM ERADICATION PROGRAMME II. Patient Information and Place of Residence III. Place stayed in the last 10-14 months if not the same as above.

(Please fill BOX "III. Place stayed in the last 10-14 months. -" if the number of months stayed in this box was less than 10.) Date Case Investigated:_ Age:

CASE INVESTIGATION FORM FOR GUINEA WORM DISEASE Setting: Urban/Rural I. Reporting/Investigation Information Region:

Name:

Date Case Reported: (dd/mm/yyyy) Resident Address: Village:

Reporting

#### Annex 11D: Guinea worm - case investigation form

Region:

with Abate and Date Check box if Treated Source District:

Area/Sub District:

To be completed in triplicate Country:

Type 379 Sub District Zone:

Longitude Region:

Village:

Latitude Date To:

COU-REG-DIS-YR-CASE Epid No: - - - - GUINEA WORM ERADICATION PROGRAMME District:_ IV. Travel History of patient in the last 10-14 months CASE INVESTIGATION FORM FOR GUINEA WORM DISEASE Name Date From:

Possible water sources that the patient might have contaminated with location details and GPS: Village:

Regular bandaging completely expelled Admission Date:

Date of guinea-worm To be completed in triplicate 380 Is this the first guinea worm emerged this year? YES/NO Date of the Was the case detected before worm emerged? YES/NO Discharged Date:

Patient entered any water source: YES/NO Place by supervisor:

COU-REG-DIS-YR-CA SE Epid No: - - - - What was the first sign/symptom before the emergence of worm? Blister/Itching/Swelling/Others,Specify.

V. Sign and symptom GUINEA WORM ERADICATION PROGRAMME Received any health education: YES/NO Emergence of guinea worm: YES/NO No of Worms:_ First guinea worm emerged: / / CASE INVESTIGATION FORM FOR GUINEA WORM DISEASE VII. Case Containment Measures and Guinea-worm registry Extracted emergence SN.NO. Location of worm Date worm detected Date of guinea-worm Date confirmed Managed: CCC/Home/Health Centers/Hospital Name of Health Facility/Health Center/Other Centers if patient was hospitalized:

Date:

Date:

To be completed in triplicate 381 Received By:

Received By:

COU-REG-DIS-YR-CASE Epid No: - - - - GUINEA WORM ERADICATION PROGRAMME Date sent to Region:

CASE INVESTIGATION FORM FOR GUINEA WORM DISEASE Was a specimen (worm) saved and preserved in alcohol?YES/NO If NO WHY?

VIII. Specimen Handling Date sent to National:

Received by:

Received by:

Sent to: _ SIGNATURE To be completed in triplicate 382 CELL PHONE NO Date sent:

Frequency of changing filters 1-rarely; 2-sometimes; 3-always; 4-never POSITION COU-REG-DIS-YR-CASE Epid No: - - - - GUINEA WORM ERADICATION PROGRAMME Disease Control or Surveillance Officer:

IX. Other Information Did you send it for confirmation? Yes/No CASE INVESTIGATION FORM FOR GUINEA WORM DISEASE Date Result Received Use of cloth filter: YES/NO NAME Result:

For National Secretariat Only:

Person who completed this form:

Remarks:

#### Annex 11E: Maternal death - reporting form

Maternal Death Reporting Form The form must be completed for all deaths, including abortions and ectopic gestation related deaths, in pregnant women or within 42 days after termination of pregnancy irrespective of duration or site of pregnancy Answers Questions / Variables 1 Country 2 District 3 Reporting Site 4 How many of such maternal deaths occured cumulatively this year at this site?

Date this maternal death occured (day/month/year) 6 Maternal death locality (Village or Town) Record's unique identifier (year-Country code-District-sitematernal death rank) 8 Maternal death place (Community, health facility, district hospital, referral hospital or private hospital, on the way to health facility or hospital) Age (in years) of the deceased Gravida: how many times was the decease pregnant?

11 Parity: how many times did the late deliver a baby of 22 weeks/500g or more?

12 Time of death (specify ¿'During pregnancy, At delivery, during delivery, during the immediate post partum period, or long after delivery") 13 If abortion: was it spontaneous or induced?

Maternal death history and risk factors 14 Was the deceased receiving any antenatal care? (Yes/No) Did she have Malaria? (Yes or No) 15 Did she have Hypertension? (Yes or No) 16 Did she have Anaemia? (Yes or No) 17 Did she have Abnormal Lie? (Yes or No) 18 Did she undergo any Previous Caesarean Section? (Yes or No) 19 What was her HIV Status? (choose HIV+; HIV-; or Unknown HIV status") Delivery, puerperium and neonatal information 20 How long (hours) was the duration of labor

Maternal Death Reporting Form The form must be completed for all deaths, including abortions and ectopic gestation related deaths, in pregnant women or within 42 days after termination of pregnancy irrespective of duration or site of pregnancy Answers Questions / Variables 21 What type of delivery was it? (choose one from 1=Vaginal non 2= vaginal-assisted delivery assisted delivery, (Vacuum/forceps), or 3=Caesarean section" 22 What was the the baby status at birth? (Alive or Stillborn) 23 In case the baby was born alive, is he/she still alive or died within 28 days after his/her birth? (choose 1=Still alive, 2-neonatal death, 3=died beyond 28 days of age) 24 Was the deceased referred to any health facility or hospital?

(Yes/No/Don't know) 25 If yes, how long did it take to get there? (hours) 26 Did the deceased receive any medical care or obstetrical/surgical interventions for what led to her death?

27 If yes, specify where and the treatment received* 28 Primary cause of the Maternal Death 29 Secondary cause of the Maternal Death 30 Analysis and Interpretation of the information collected so far (investigator's opinion on this death) 31 Remarks 32 Maternal death notification date (day/month/year) 33 Investigator (Title, name and function) * Treatment received I.V. Fluids; Plasma; Blood Transfusion; Antibiotics; Ocytocin; Anti-seizure drugs; Oxygen; Anti-malarial; Other medical treatment; Surgery; Manual removal of placenta; Manual intra uterine aspiration; Curettage, laparotomy, hysterectomy, intsrumental delivery (Forceps; Vacuum), Caesarian section, anesthesia ( general, Definitions Gravida: The number of times the woman was pregnant- Parity: Number of times the woman delivered a baby of 22 weeks/500g or more, whether alive or dead

#### Annex 11F: Measles case investigation form

Lab No.

EPID No.

(For Lab Use Only).

Demographic Details District of onset Reporting Health Unit Name of Patient _Sex Date of Birth / / Age (in months) Home: Name of head of household where the child lives:

Guardian's occupation _ LC1 (zone) _ Sub-county_ District Parish LC 1 Chairman's name Clinical History Date of this visit / / Symptoms: (circle as appropriate) ) In/Out Patient (1 = In-patient, No (2 = Out-patient, No) Date of onset / / Rash: Yes/No Date of onset / / Fever: Yes/No Temperature _degrees Cough: Yes/No Red eyes: Yes/ No Running nose: Yes/No Other complications: Yes/NO, If yes, specify.

Outcome:

_(1 = Alive 2 = Dead 3 = Unknown) Date Health Unit Notified District No ofdoses _ Was vitamin A given during the current illness Yes/No Card seen/not seen Immunisation History 2. Number of measles doses Date of last measles vaccination / / 3. Diagnosis written in the register Specimens Blood:

Date of collection Date sent to the lab Date received Specimen condition / / Urine:

Date of collection Date sent to the lab Date received Specimen condition Investigators Date / / Title_ Name: (person filling form).

----------- ResultsSerology: IgM Date_/ / Date sent to EPI Date_/ / Virus Isolation: Urine Final Classification(1 = confirmed, 2 = Epidemiological linkage, 3 = Probable/Compatible, 4 = Discarded, 5 =Suspected) Date results sentto district /

#### Annex 11G: Neonatal Tetanus case investigation form

District:

Health Facility:

NEONATAL TETANUS CASE DEFINITION: An infant with history of all 3 of the following: (1) normal suck and cry for first 2 days of life (2) onset of illness between 3 and 28 days of life (3) inability to suck followed by generalized stiffness and/or spasms.

PATIENT IDENTIFICATION 1. FIRST NAME:

3. Date ofbirth // 2. SECOND NAME:

4. AGE: _days 5.Sex (M/F) 6. PARENTS: MOTHER'S NAME FATHER'S NAME:

RESIDENCE: District Sub-county:

Parish LC1:

CLINICAL INFORMATION 8. DATE OF ADMISSION or FIRST SEEN AT HEALTH UNIT / / 9. DATE OF ONSET OF SYMPTOMS:

2=No 10. SYMPTOMS: (1=Yes 3= Unknown) History of normal suck and cry the first 2 days of life Inability to suck Stiffness in Fever Difficulty Convulsions Pneumonia breathing 2-Survived 9-Unknown) 11. OUTCOME: (1=Died; 12. DATE OF DISCHARGE/DEATH: / - / DELIVERY 13. PLACE OF DELIVERY If a health facility, record the name of the facility.

2= Health centre _ 3= Home 1= Hospital

14. BIRTH ATTENDANT 4=TBA 1= Doctor 2=Nurse 5=Midwife 8= Other 9= Unknown 3=Friend or Relative 8=Other 9=Unknown 15. ON WHAT SURFACE WAS THE BABY DELIVERED 1=Cloth 4-Ground, Outside 2-Uncovered table 8-Other 3=Uncovered floor 9-Unknown 8=other 1=Razor blade 16. WHAT WAS USED TO CUT THE CORD?

2=Knife 9=Unk nown 3=Scissors 1=Soap & unboiled 17. WHAT WAS APPLIED TO THE CORD STUMP?

water 5=Ashes 6= Nothing 2=Soap & boiled water 8=Other _ 3=Antiseptic 9=Unknown 4-Cow dung MOTHER 18. WHAT IS THE MOTHER'S AGE?

19. EDUCATION (last school year completed):

1= None 3=Secondary (1-6 2=Primary (1-7 years) 4=Post-Secondary 20. OCCUPATION:

1=Housewife 3=Office 2=Market vendor 4 = Other _ ANTENATAL CARE (ANC) 21. BIRTH ORDER FOR THIS CHILD 22. DID THE MOTHER RECEIVE ANC DURING THIS PREGNANCY? (1=Vec )=No 9=I Inknown) 23. IF YES, HOW MANY VISITS?

24. IF YES WHAT KINDOF FACILITY?

Name_

1=Government 4-Private Midwife 5=TBA 2=NGO clinic 8=Other 3=Private Doctor 9=Unknown TETANUS TOXOID IMMUNIZATION 25. IMMUNIZATION RECEIVED 2=Yes (1= Yes by card by history 3= No 9=Unknown) DOS DATE OF NAME OF IMMUNIZATION ATTA MONT TT1 TT2 TT3 TT4 TTS Note: If the T'T card is not available, record the month and year of any doses that the mother says that she has received based on the interview with the mother.

REMARKS PERSON RECORDING TITLE Date / /

Annex 11H New-born Perinatal Death Audit Form.

A copy of this form should be sent to the Ministry of Health HMIS 010b:

Date of Audit..

1. SECTION ONE: Identification

#### 1.1.2 IP No. (Newborn)

### 1.1 IPNO. (Mother):

### 1.2 Name of the Health Facility:

### 1.3 Type of Health Facility (tick)

Others HC IV National Referral General Regional Referral

### 1.4 District.

### 1.5 Mother's initials.

(yrs) 1.5.3 Address:

#### 1.5.2 Age:

2. No 1. Yes

### 1.6 Was baby referred?

4.TBA 3.VHT 2. HC L

### 1.7 If Yes; from? 1. Hospital

5. Others (specify).

### 1.8 If referred from health facility, name of the facility

2.SECTION TWO: Pregnancy progress and Care

### 1.1 Mother's Parity

#### 2.1.2 No. of mother's living children

Twin

### 1.2 Type of pregnancy 1. Singleton

2. No

### 1.3 Attendance of Antenatal care: 1. Yes

### 2.5 Core ANC Interventions (tick appropriately)

### 2.4 If yes how many times

2. IPT2 _ 3. IPT3 |

#### 2.5.1 Malaria prophylaxis: 1. IPT1

#### 2.5.2 Tetanus Toxoid:

3. T13 1. TT1 | 2. TT2 2. No

#### 2.5.2 HIV test done

1. Yes

#### 2.5.3 HIV test results 1. -ve

2. tve

#### 2.5.4 If HIV positive: 1. On ARVs

2. Not on ARVs 2. tve

#### 2.5.3 Syphilis test done;1. Yes

2. No 2.5.4 Syphilis test results 1. -ve

### 2.6 Conditions in present pregnancy (tick all applicable)

1. Antepartum Hemorrhage 2. Hypertension 3. Pre-labour rupture of membranes 5.Anaemia 4. Diabetes 6. UTI 8. Trauma-accidental 7. Malaria 9. Trauma-gender-based violence 11.Others 10. Multiple pregnancy specify..

N.B. If multiple pregnancy, indicate birth order of the newborn. Fill separate form for each perinatal death 3. SECTION THREE: Labour and Birth

#### 3.1.2 Date of delivery

### 3.1 Weeks of amenorrhea at delivery

2. Home

### 3.2 Place of delivery 1. Health facility

3. TBA

#### 3.2.1 If health facility specify name

2. No

### 3.3 On admission, were there fetal sounds present? 1. Yes

3. Not assessed 2. No

### 3.4 Was partograph used? 1. Yes

3. Unknown If No mention If 'Yes' was partograph usedcorrectly? 1. Yes 2. No error..

2. Caesarean Section

### 3.5 Mode of Delivery: 1. Normal Delivery

3. Vacuum or Forceps 4. Others specify:

#### 3.5.2 Indication for Instrumental /or Caesarean section:

### 3.6 Time between decisions for Cesarean section /instrumental and actual delivery of the

baby:

3. Greater than 1 hour 2. 30 minutes - 1 hour 1. Less than 30 minutes

#### 3.6.1 Did vaginal delivery occur in spite of decision to do caesarean section?? 1. Yes

2. No

### 3.7 Condition of the Baby

Don't At 5min At 10min

#### 3.7.1 Apgar score at 1 min

know

#### 3.7.2 Resuscitation done: 1. Yes

2. No 2.Suction

#### 3.7.3 If 'Yes' what was done? 1. Stimulation

3. Oxygen given 4. Bag and Mask

5. Endotracheal and Positivepressure ventilation 6. CPR 7. Medication 8. All 2. Nurse

#### 3.7.4 Resuscitation done by: 1. Doctor

8. Trainee (doctor/ nurse) 4. Others (specify):.

2. Female gms 3.7.6 Sex: 1. Male

#### 3.7.5 Weight of the baby:

### 3.8 Type of Perinatal Death

3.8.1. Fresh Still Birth 3. Neonatal Death 2. Macerated still Birth If neonatal death, reason for admission/ diagnosis at admission (Tick all applicable) 1. Difficult feeding (baby) 2. Difficult breast feeding (mother) 3. Jaundice 4. Anaemia 5. Difficult breathing 6. Hypoglycaemia _ 7. Septicaemia 8. Hypothermia 11. Convulsions 10. Fever 12. Bleeding 9. Bulging fontanelle Other conditions specify:

### 3.9 Probable cause of death: Tick all applicable

Code Cause of death Cause of death Code Tetanus A 33 Q 80 Congenital Anomalies P 36 Septicaemia P 15 Birth trauma Other - specify...

P 22 Birth Asphyxia P 07 *Prematurity complications specify..

* Premature: Born after 28 weeks Unknown but before 37 weeks of gestation Avoidable factors/missed opportunities/substandard care. Which of the following factors were present (tick all appropriate) 1. Delay to seek health care 2. Delay to reach the health facility 3. Delay to provide care 4. Absence of critical human resources

5. Lack of resuscitation equipment 6. Lack of supplies and drugs including blood 7. Misdiagnosis 8. Inappropriate intervention 9. Poor documentation 10. Others specify Comments on avoidable factors and missed opportunities:

Actions taken to address the avoidable problems CONFIRMATION OF DETAILS --Tel:

The form was completed by: Name:

Email:

- Date:

-Signature

Other (Specify) Mf Of Lf E Z S 394 Drug Susceptibility Test Results (S-sensitive; R=Resistant; I=intermediate; U=unknown) /Unknown) HIV Status (positive /negative /Don't Know) treatment /Not on treatment Patient Treatment Status (On first treatment /After failure of /After default /After failure of Type of TB Case (New /Relapse Year:

Month:

Pulmonay) TB Site (Pulmonary or extra TB* or XDR-TB**) Type of Notification (MDR- (dd/mm/yyyy) Date of Diagnosis Age (Year) Sex (F/M) Number in Tb Register) (Detection year-Country code- Case unique Identifier Country:

Case based Multi-Drug Resistant and Extensively Drug Resistant Tuberculosis Report Form Quarter:

Cs=Cycloserine PAS=P-am ino salicy lic acid Second-line drugs: Am=Amikacin Km=Kanamycin Cm=Capreomycin Cfx=Ciprofloxacin Ofx=Ofloxacin Lfx=Levofloxacin Mfx=Moxifloxacin Gfx=Gatifloxacin Pto=Protionamide Eto=Ethionamide First-line drugs: H = Isoniazid R = Rifampicin E = Ethambutol Z = Pyrazinamide S = Streptomycin Th = Thioacetazone (Capreomycin, Kanamycin and Amikacin).

* Multi-drug Resistant TB = Resistance to at least Isoniazid and Rifampicin **Extensively Drug Resistant TB = MDR-TB plus: Resistance to any fluoroquinolone such as Ciprofloxacin, Oxfloxacin, etc, and Resistance to at least one of the three second line injectable anti-TB drugs

#### Annex 111: Tuberculosis - MDR and XDR TB - case-based reporting form

Annex 11J Viral haemorrhagic fever - case reporting form IDSR Viral Hemorrhagic Fever Case Report Form Answers Variables / Questions 1 Detection day (ddmm/yyyy) 2 Detection place (Health facility or Community) Patient identification number (yyyy-week- CCC- PPP-DDD-Reporting site-nnn) 4 Patient surname or last name 5 Patient first name(s) Age (years) 7 Sex (F/M) 8 Number of people in same household 9 Number of other contacts 10 Patient's residencial adress 11 Village/Town 12 Neighborhood 13 District 14 Province 15 Country 16 Date of first symptoms onset (dd/mm/yyyy) 17 Observed Symptoms and Clinical signs Was patient exposed to any known risk factor 18 for this disease? (Yes/No) 19 If yes, specify risk factor(s) 20 Lab results Final Classification (Not a case, Suspect, 21 Probable, Confirmed by Lab, Confirmed by epidemiological link, Pending) 22 Outcome (Died, Survived, Unknown) 23 End of latest contact followed-up (dd/mm/yyyy) 24 Other Notes and Observations 25 Date latest update of this record (dd/mm/yyyy)

#### Annex 11K: Viral Haemorrhagic Fever Case Investigation Form

UGANDA VIRAL HEMORHAGIC FEVER MoH/UVRI CASE INVESTIGATION FORM Case ID:

Send completed form and laboratory samples to:

UVRI/CDC, Attn: Viral Hemorrhagic Fever Laboratory Plot 51-59 Nakhwogo Rd., P.O. Box 49, Entebbe, Uganda Health Contact #: 0600 264384 (VHFUG) (Toll Free) Facility Case ID:

_ (dd, mm, yVW - Example: 19 / 12 / 2018) Date of Case Report _ Patient Information Section 1.

Patient's Surname:

Other Names:

Age:

. O Years D Months Owner of Phone:

Gender: • Male D Female Phone Number of Patient/Family Member:

Status of patient at time of this case report: • Alive • Dead If dead, Date of Death: _ Permanent residence:

Head of Household:

Parish:

Village/Town:

District:

Country of Residence:

Sub-County:

Occupation:

- Miner

- Religious leader • Housewife • Pupil/student • Child

- Farmer • Butcher • Hunter/trader of game meat

- Transporter; type of transport:

- Businessman/woman; type of business:

- Traditional healer

healthcare facility: _

- Healthcare worker; position:

- Other, please specify occupation:

Location where patient became ill:

Sub-County:

_ District: _ Village/Town:

GPS Coordinates at House: latitude:

‚longitude: _ If different from permanent residence, Dates residing at this location:

Section 2.

Clinical Signs and Symptoms _ (da, mm, УУУУ) Date of initial symptom onset:

Please tick an answer for ALL symptoms indicating if they occurred during this illness between symptom onset and case detection: Fever

- Yes • No D Unknown

- Yes • No QUnknown

Unexplained bleeding from any site If yes, TEMP:

_*C Source: • Axillary • Oral O Rectal If Yes:

- Yes •No •Unknown

Vomiting/nausea

- Yes • No O Unknown

Bleeding of the gums Diarrhea

- Yes 0 No DUnknown

- Yes • No 0 Unknown

Bleeding from injection site

- Yes • No • Unknown

Intense fatigue/general weakness

- Yes • No JUnknown

Nose bleed (epistaxis)

- Yes • No Unknown

Anorexia/loss of appetite Bloody or black stools (melena)

- Yes O No O Unknown

- Unknown

Abdominal pain

- Yes ONo

- Yes • No • Unknown

Blood or "coffee grounds" in vomit

- Unknown

- Yes ONo

Chest pain (hematemesis)

- Unknown

Muscle pain

- Yes ONo

- Yes O No O Unknown

Coughing up blood (hemoptysis)

- Unknown

Joint pain Yes ONo Bleeding from vagina,

- Yes O No O Unknown

- Yes

- No

- Unknown

Headache other than menstruation Cough

- Unknown

- No

- Yes

Bruising of the skin

- Yes • No O Unknown

- Unknown

- Yes ONo

Difficulty breathing (petechiae/ecchymosis)

- Unknown

- Yes ONo

Difficulty swallowing Blood in urine (hematuria)

- Yes • No O Unknown

Sore throat

- Unknown

- Yes • No

- No

- Yes

- Unknown

Jaundice (yellow eyes/gums/skin)

- Yes O No O Unknown

Other hemorrhagic symptoms

- Yes

- No

- Unknown

Conjunctivitis (red eyes) If yes, please specify:

- Yes • No • Unknown

Skin rash Hiccups

- Unknown

- Yes ONo

Other non-hemorrhagic clinical symptoms:

- Yes • No • Unknown

Pain behind eyes/sensitive to light

- Yes D No D Unknown

- Yes

- No • Unknown

Coma/unconscious If yes, please specifiy:

Confused or disoriented

- Yes

- No • Unknown

Section 3.

Hospitalization Information At the time of this case report, is the patient hospitalized or currently being admitted to the hospital? • Yes • No _ (dd, mm, yvy) Health Facility Name:

If yes, Date of Hospital Admission:

District:

Sub-County:

Village/Town:

Is the patient in isolation or currently being placed there? L Yes • No If yes, date of isolation: _ (da, mm. 3339)

- No • Unknown

Was the patient hospitalized or did he/she visit a health clinic previously for this illness? • Yes If yes, please complete a line of information for each previous hospitalization:

District Health Facility Name Was the patient isolated?

Village Dates of Hospitalization

- Yes

- No

- Yes

- No

MOH/UVRI Case ID:

Section 4.

Epidemiological Risk Factors and Exposures IN THE PAST ONE(1) MONTH PRIOR TO SYMPTOM ONSET:

1. Did the patient have contact with a known or suspect case, or with any sick person before becoming ill? • Yes • No • Unk If yes, please complete one line of information for each sick contact:

Relation to Village District Contact Was the person dead or alive?

Name of Contact Dates of Exposure Patient Types**

- Allve

- Dead, date of death:_

- Alive

- Dead, date of death:

- Alive

- Dead, date of death:

I Touched the body nuids of the case (blood, vomit, saliva, urine, leces) **Contact Types:

2 - Had direct physical contact with the body of the case (alive or dead) (lIst all that apply) 3 - Touched or shared the linens, clothes, or dishes/eating utensils of the case 4 - Slept, ate, or spent time in the same household or room as the case.

2. Did the patient attend a funeral before becoming ill? • Yes • No • Unknown If yes, please complete one line of information for each funeral attended:

Dates of Funeral Name of Deceased Relation to Patient Did the patient participate District Village (carry or touch the body)?

Attendance (old, mam, 399y)

- Yes • No O Unknown

- Yes • No •Unknown

3. Did the patient travel outside their home or village/town before becoming ill?

- Yes

- No

- Unknown

(dd, mm, YVVy) District:

Date(s):

If yes, Village: _ 4. Was the patient hospitalized or did he/she go to a clinic or visit anyone in the hospital before this illness? • Yes C No D Unk Date(s): _ If yes, Patient Visited:

(dd., mm, УУУУ) _District:

Village:

Health Facility Name:

- No •Unk

5. Did the patient consult a traditional/spiritual healer before becoming ill? • Yes Date:

District:

(ald, mn, YVYV) _Village: _ If yes, Name of Healer. _ 6. Did the patient have direct contact (hunt, touch, eat) with animals or uncooked meat before becoming ill?

- Yes • No • Unknown

If yes, please tick relevant boxes) below:

Animal:

Status (check one only):

- Sick/Dead

- Chickens or wild birds

- Bats or bat feces/urine

- Healthy • Sick/Dead

- Healthy

- Sick/Dead

- Healthy • Sick/Dead

- Primates (monkeys)

- Cows, goats, or sheep

- Sick/Dead

- Rodents or rodent feces/urine

- Healthy

- Other

- Healthy • Sick/Dead

Please specify

- Sick/Dead

- Pigs

- Healthy

- No

- Unknown

- Yes

7. Did the patient get bitten by a tick in the past 2 weeks?

- No

- Unknown

- Yes

8. Did the patient skin and/or eat bush meat in the past 21 days?

Section 5.

Clinical Specimens and Laboratory Testing Sample 2:

Sample 1:

Sample Collection Date:

Sample Collection Date:

_ (da, mm, yVYV) (dd, m, УУУУ) , (Hrs, Min) - • AM • PM _ (Hrs, Min) - • AM • PM Sample Collection Time:

Sample Collection Time:

Sample Type:

Sample Type:

- Whole Blood

- Whole Blood

- Post-mortem heart blood

- Post-mortem heart blood

- Skin biopsy

- Skin biopsy

- Other specimen type, specify: _

- Other specimen type, specify: _

- NEG

HIV RDT: • POS Malaria RDT: • POS • NEG • NOT DONE

- NOT DONE

Specimen/shipping instructions:

Send specimens to:

- Label sample with patient name, date of collection, and case ID

Uganda Virus Research Institute/CDC

- Send sample cold with a cold/ice pack, and packaged appropriately.

Attn: Viral Special Pathogens Branch,

- Collect whole blood in a purple top (EDTA) tube - green or red top tubes

Plot 51-59 Nakiwogo Rd., P.O. Box 49, Entebbe, Uganda Phone: 0800 284384 (VHFUG) (Toll Free) acceptable if purple not available

- Preferred sample volume = 4 ml (minimum sample volume = 2ml)

Section 6.

Case Investigation Form completed by:

E-mail:

Name: _ Phone: _ Health Facility:

District Position:

Relation to Patient:

Information provided by: C Patient O Proxy; If proxy, Name:

#### Annex 11L: Human Anthrax Case Investigation Form

Anthrax Disease Investigation form (Please refer to the Disease Investigation Guideline for additional guidance.) Patient Name:

_DOB:_/CASE ID:

.......Parish:..

District:..

.. Village:.

.. Sub county:..

__ First Symptom experienced:

Date of Onset: _/__ Status: Hospitalized; Location:

_Admit: ___ Discharge: - Treatment given if any:

- Died; date of death:

/GPS Coordinates: LAT:...........LONG:..

Patient contact:

_Time:..

..Date of investigation Symptom Information No Yes Symptoms Unk Comments / Specifies Fever Max. temp:

Headache Malaise, severe Myalgia Stiff Neck Abdominal Pain Nausca Vomiting Diarrhea Location Eschar Edema (swelling) Lymphadenopathy Location Other Skin lesions / Rashes Describe:

Abnormal chest x-ray Breathing difficult (Shortness of Cough unproductive Upper respiratory symptoms Other symptoms (list):

Initial Laboratory Testing Collection Laboratory Obtain Copy of Results Test Type

#### Specimen

If not previously reported, send copies of any results to Tel:

Date: __ 1. Contact at Hospital:

Time: - _ Phone Phone:

2. Additional Contacts:

3. Details on specimen being sent (i.e., type, where, when, how):

Anthrax Investigation form (Please refer to the Disease Investigation Guideline for additional guidance.) Initial Information to Collect (Activities 6 weeks before onset) Yes No Unk If yes, describe Initial questions (Exact duties, type of business/industry and location) 4. Is any information available on the patient's occupation?

2. Does the patient own, work with or around livestock or wild mammals especify animals and describe exposure, including dates or their body fluids?

3. Do you have animals recently brought on your farm? If yes, where and when?

4. Do you have any animals that have died recently in this home? If yes what signs and how many presented before death?

5. Has the patient had any contact with animal skins, furs, hair, or bone products?

6. Does the patient garden, work with soil?

7. Does the patient work in a clinical or microbiological 8. Has the patient been involved in If yes, when and where?.

activities of hunting wild animals?

9. Did the patient involve him/herself If yes, date of slaughter_//_; location:

in animal slaughter?

10. For GI symptoms, has the patient eaten any animal died instantly /suddenly?

11. If no additional risk factors are identified, review patient activities the past 6 weeks. Has the patient:

a. Attended large gathers or special events?

f. Had recent contact or visited an elected official or government office?

If yes, use general investigation contact form for 12. Have any houschold members or documentation.

close contacts experienced similar symptoms recently?

LIST OF ALL HUMAN CASES IN THE HOME SEX AGE | SYMPTOMS DATE NO NAME OF OCCUPATION HISTORY ONSET

## References

1.

Ministry of Health. National Technical Guidelines for Integrated Disease Surveillance and Response | Ministry of Health Knowledge Management Portal. Published 2012.

Accessed September 8, 2021.

http://library.health.go.ug/publications/guidelines/national-technical-guidelinesintegrated-disease-surveillance-and-response Nsubuga P, White ME, Thacker SB, et al. Public Health Surveillance: A Tool for Targeting and Monitoring Interventions. Jamison DT, Breman JG, Measham AR, et al., eds. Dis Control Priorities Dev Ctries. Published online 2006:997-1015. Accessed September 8, 2021. https://www.ncbi.nlm.nih.gov/books/NBK11770/ World Health Organization. Implementation of Early Warning and Response with a Focus on Event-Based Surveillance.; 2014. Accessed September 8, 2021.

www.who.int/about/licensing/copyright_form/en/index.html 4.

World Health Assembly. International Health Regulations. 3rd ed.; 2005.

doi: 10.1136/bmj.1.5746.415 5.

WHO/AFRO. Implementation of the International Health Regulations (2005) Report of the Review Committee on Second Extensions for Establishing National Public Health Capacities and on IHR Implementation.; 2015.

6.

AK M, JF W, MN, A O, IM, JR A. Ebola viral hemorrhagic disease outbreak in West Africa- lessons from Uganda. Afr Health Sci. 2014;14(3):495-501.

doi: 10.4314/AHS.V1413.1 World Health Organization. TECHNICAL FRAMEWORK IN SUPPORT TO IHR (2005) MONITORING AND EVALUATION: Joint External Evaluation Tool. 2ND ed.

(World Health Organization, ed.). Accessed September 8, 2021.

https://apps.who.int/iris/bitstream/handle/10665/259961/9789241550222-eng.pdf World Health Organization. Protocol for Assessing National Surveillance and Response Capacities for the International Health Regulations (2005) - in Accordance with Annex 1 of the IHR: A Guide for Assessment Teams. 2010;(December).

WHO Regional Office for Africa. Report of the One Health Technical and Ministerial Meeting to Address Zoonotic Diseases and Related Public Health Threats | WHO | Regional Office for Africa.; 2016. Accessed September 8, 2021.

https://www.afro.who.int/publications/report-one-health-technical-and-ministerialmeeting-address-zoonotic-diseases-and 10.

World Health Organization Regional Office for Africa. DISASTER RISK MANAGEMENT: A STRATEGY FOR THE HEALTH SECTOR IN THE AFRICAN REGION Report of the Secretariat.; 2012. Accessed September 8, 2021.

http://www.disasterpublications.info/english 11.

International Federation of the Red Cross. Community-Based Surveillance: Guiding Principles.; 2017. www.ifrc.org 12.

Ministry of Health Liberia. NATIONAL TECHNICAL GUIDELINES FOR Integrated Disease Surveillance & Response.; 2016. Accessed September 8, 2021.

https://www.resilientinstitutionsafrica.org/sites/default/files/files/2017/Liberia- National_Tech_Guidelines_for_Integrated_Disease_Surveillance_Response-2016.pdf

13. World Health Organization. International Health Regulations (2005) and chemical events. Who. 2015;1(9):33.

World Health Organization Regional Office for Africa. Integrated Disease Surveillance and Response in the African Region. A Guide for Establishing Community Based Surveillance: Disease Surveillance and Response Programme Area. Disease Prevention and Control Cluster.; 2014.

World Health Organization Regional Office for Europe. Strategic Tool for Assessing Risks (STAR). Published August 13, 2021. Accessed August 13, 2021.

https://www.euro.who.int/en/health-topics/health-emergencies/pages/about-healthemergencies-in-the-european-region/emergency-cycle/prepare/strategic-tool-forassessing-risks-star 16.

World Health Organization. Laboratory Quality Management System Handbook.; 2011. Accessed September 8, 2021.

http://www.who.int/about/licensing/copyright_form/en/index.html 17.

Ali Ahmed Yahaya, Jean Bosco Ndihokubwayo, Sheick Oumar Coulibaly, et al.

Laboratory capacity in 2012 for diagnosis of epidemic prone diseases in the context of Integrated Disease Surveillance and Response in the WHO African Region | African Health Observatory. African Health Monitor. Published 2012. Accessed September 8, 2021. http://www.aho.afro.who.int/sites/default/files/ahm/reports/786/ahm-18-11laboratory-capacity-2012-diagnosis-epidemic-prone-diseases.pdf 18.

WHO WHO. Stepwise Laboratory Quality Improvement Process Towards Accreditation (SLIPTA) Checklist.

World Health Organization. ENDING CHOLERA A G LO B A L ROAD M A P TO 2 0 3 0 OVERVIEW OF.; 2017. Accessed September 8, 2021.

http://www.who.int/cholera/publications/global-roadmap.pdf?ua=1 20.

CDC. Hygiene-related Diseases | Hygiene-related Diseases | Hygiene | Healthy Water | CDC. Cent Dis Control Prev. Published online 2020. Accessed September 8, 2021.

https://www.cdc.gov/healthywater/hygiene/disease/trachoma.html 21.

World Health Organization W. Trachoma. Accessed September 8, 2021.

https://www.who.int/news-room/fact-sheets/detail/trachoma 22.

Bernstein AB, Sweeney MH, Centers for Disease Control. Public health surveillance data: legal, policy, ethical, regulatory, and practical issues. MMWR Surveill Summ.

2012;61 Suppl: 30-34. Accessed September 8, 2021.

https://www.cdc.gov/mmwr/preview/mmwrhtml/su6103a7.htm WHO WHO. ESURVEILLANCE IMPLEMENTATION IN THE CONTEXT OF INTEGRATED DISEASE SURVEILLANCE AND RESPONSE IN. 2015; (June).

24.

Kwesiga B, Pande G, Ario AR, Tumwesigye NM, Matovu JB, Zhu B-P. A contaminated by sewage in Kasese District, western Uganda. BMC Public Heal 2017 181. 2017;18(1):1-8. doi:10.1186/S12889-017-4589-9 25.

Nsereko G, Kadobera D, Okethwangu D, et al. Malaria Outbreak Facilitated by Appearance of Vector-Breeding Sites after Heavy Rainfall and Inadequate Preventive Measures: Nwoya District, Northern Uganda, February-May 2018. J Environ Public Health. 2020;2020. doi: 10.1155/2020/5802401

26.

Ratnayake R, Crowe S.J, Jasperse J, et al. Assessment of Community Event-Based Surveillance for Ebola Virus Disease, Sierra Leone, 2015. Emerg Infect Dis.

2016;22(8): 1431. doi:10.3201/EID2208.160205 27.

WHO Western Pacific Region. A Guide to Establishing Event-based Surveillance.

World Heal Organisation. Published online 2008:21.

28.

World Health Organization W. WHO Updates Personal Protective Equipment Guidelines for Ebola Response. Vol 35.; 2014. Accessed September 8, 2021.

https://www.who.int/news/item/31-10-2014-who-updates-personal-protectiveequipment-guidelines-for-ebola-response Centers for Disease Control and Prevention. Guidance for the Selection and Use of 29.

Personal Protective Equipment (PPE) in Healthcare Settings.; 2016. Accessed September 8, 2021. https://www.cdc.gov/hai/pdfs/ppe/ppeslides6-29-04.pdf°%0A 30.

(CDC) C for DC and P. Weekly Epidemiological Record (WER), 19 December 2014, vol. 89, nos. 51/52 (pp. 577-588) [EN/FR] - World | ReliefWeb. MMWR Morb Mortal Wkly Rep. Published online 2014. Accessed September 8, 2021.

https://reliefweb.int/report/world/weekly-epidemiological-record-wer-19-december- 2014-vol-89-nos-5152-pp-577-588-enfr 31.

World Health Organization W. Coordination of Public Health Surveillance between Points of Entry and the National Public Health Surveillance System: Advising Principles.; 2018. Accessed September 8, 2021.

www.who.int/about/licensing/copyright_form/en/index.html 32.

WHO. Framework for a Public Health Emergency Operations Centre. MMWR Morb Mortal Wkly Rep. 2015;50(RR13) (July 27):1-35.

www.who.int/about/licensing/%0Ahttps://apps.who.int/iris/bitstream/handle/10665/196 135/9789241565134_eng.pdt?sequence=1 33.

World Health Organization [WHO]. Standard operating procedures or coordinatin public health event preparedness and response. World Heal Organ Reg Off Africa.

Published online 2014:52.

http://www.who.int/hac/techguidance/tools/standard_operating_procedures_african_re gion_en_2014.pdf 34.

European Centre for Disease Prevention and Control. Operational Guidance on Rapid Risk Assessment Methodology.; 2011. doi:10.2900/57509 35.

World Health Organization W. Rapid Risk Assessment of Acute Public Health Events.

World Heal Organ. Published online 2012.

36.

WHO Africa. REGIONAL STRATEGY FOR HEALTH SECURITY AND EMERGENCIES 2016-2020 Report of the Secretariat.; 2016. Accessed August 18, 2021. http://www.who.int/ihr/publications/9789241596664/en/ 37.

Global Task Force on Cholera Control. Cholera Outbreak Response: Field Manual.; 2019. Accessed September 8, 2021. https://choleraoutbreak.org/home 38.

WHO. Meningitis Outbreak Response in Sub-Saharan Africa.; 2014. Accessed September 8, 2021. http://www.who.int/about/licensing/copyright_form/en/index.html 39.

World Health Organization W. Strategy for managing meningitis epidemics in Africa.

Published online 2015. Accessed September 8, 2021.

https://www.ncbi.nlm.nih.gov/books/NBK299453/ WHO-AFRO. Standard Operating Procedures for Surveillance of Meningitis 40.

Preparedness and Response to Epidemics in Africa.; 2018. Accessed September 8, 2021. https://www.who.int/publications-detail-redirect/standard-operating-proceduresfor-surveillance-of-meningitis-preparedness-and-response-to-epidemics-in-africa World Health Organization. Emergency Risk Communication International health agreements Module B1. Published online 2005.

42.

World Health Organization W. Communicating Risk in Public Health Emergencies: A WHO Guideline for Emergency Risk Communication (Erc) Policy and Practice.

Gesundheitswesen. 2019;81(1):846-849. doi: 10.1055/a-0887-4545 (CDC) C for DC and P. Community Engagement: Definitions and Organizing Concepts from the Literature | Principles of Community Engagement ATSDR.; 2018. Accessed August 11, 2021. https://www.atsdr.cdc.gov/communityengagement/pce_intro.html World Health Organization W. Communicating Risk in Public Health Emergencies: A WHO Guideline for Emergency Risk Communication (Erc) Policy and Practice. Vol 81.; 2019. doi: 10.1055/a-0887-4545 45.

WHO. World Health Organization outbreak communication planning guide. World Heal Organ. Published online 2008:30. Accessed September 8, 2021.

http://www.who.int/ihr/elibrary/WHOOutbreakCommsPlanngGuide.pdf World Health Organisation. Communicating Risk in Public Health Emergencies. A WHO Guidel Emerg risk Commun policy Pract. Published online 2017:57. Accessed September 8, 2021.

https://apps.who.int/iris/bitstream/handle/10665/259807/9789241550208eng.pdf?sequence=2 47.

World Health Organization. WHO Outbreak Communication Guidelines.; 2005.

Accessed September 8, 2021.

http://www.who.int/csr/resources/publications/WHO_CDS_2005_28en.pdf 48.

WHO WHO. EHEALTH SOLUTIONS IN THE AFRICAN REGION: CURRENT CONTEXT AND PERSPECTIVES.; 2010. Accessed August 18, 2021.

https://apps.who.int/iris/bitstream/handle/10665/19931/AFR-RC60- R3.pdf?sequence=1&isAllowed=y 49.

WHO/AFRO. Integrated Disease Surveillance in the African Region: A Regional Strategy for Communicable Diseases 1999-2003.; 2001.

50.

World Health Organization W. World health organization - Revision of the international health regulations. Eur J Health Law. 2005;12(3):269-271.

doi: 10.1163/157180905774857989 Kite-Powell A, Hamilton JJ, Hopkins RS, DePasquale JM. Potential effects of electronic laboratory reporting on improving timeliness of infectious disease notification -Florida, 2002-2006. Morb Mortal Wkly Rep. 2008;57(49): 1325-1328.

Accessed August 18, 2021.

https://www.cdc.gov/mmwr/preview/mmwrhtml/mm5749a2.htm 52.

Valenciano M, Coulombier D, Cardozo BL, et al. Challenges for Communicable Disease Surveillance and Control in Southern Iraq, April-June 2003. J Am Med Assoc.

2003;290(5):654-658. doi:10.1001/jama.290.5.654 (CDC) C for DC and P. CDC's Vision for Public Health Surveillance in the 21st 53.

Century. Vol 61.; 2012. Accessed September 8, 2021.

http://wonder.cdc.gov/wonder/help/cmf/ 54.

World Health Organization, International Telecommunication Union. National eHealth Strategy Toolkit Overview. Published online 2012:1-9. Accessed September 8, 2021.

www.who.int 55.

World Health Organisation. 3rd Meeting on African Surveillance Informatics Governance Board (ASIGB) - WHO | Regional Office for Africa. Published 2015.

Accessed September 8, 2021. https://www.afro.who.int/news/3rd-meeting-africansurveillance-informatics-governance-board-asigb 56.

WHA. Digital Health.

57.

WHO AFRO. Regional Strategy for IDSR 2020-2030.; 2019. Accessed August 27, 2021. https://www.afro.who.int/sites/default/files/2019-08/AFR-RC69-6 Regional Strategy for IDSR 2020-2030.pdf 58.

Office of the Prime Minister. The National Policy For Disaster Preparedness And Management DEPARTMENT OF DISASTER PREPAREDNESS AND MANAGEMENT OFFICE OF THE PRIME MINISTER THE REPUBLIC OF UGANDA. 2011; (April): 1-76. Accessed August 18, 2021. http://www.necocopm.go.ug/publications/1.%0ANational%0APolicy%0Afor%0ADisaster%0APrepared ness%0A&%0AManagement.pdf 59.

World Health Organization. Outbreak surveillance and response in humanitarian emergencies - WHO guidelines for EWARN implementation. World Heal Organ.

Published online 2012:1-68.

http://www.who.int/diseasecontrol_emergencies/publications/who_hse_epr_dce_2012.

1/en/index.html 60.

World Health Organization W. Surveillance / EWARN in Emergencies. New York.

2009;(February).
